-- ====== SWRP T-Menu (clientside) ======
local OPEN_KEY = KEY_T       -- press T
local MAX_DIST = 600         -- units

local function SWRP_OpenTargetMenu(target)
    if not IsValid(target) or not target:IsPlayer() then return end

    local m = vgui.Create("DMenu")
    m:AddOption("Promote", function()
        net.Start("SWRP_MenuAction")
            net.WriteString("promote")
            net.WriteEntity(target)
            net.WriteString("") -- no rank text
        net.SendToServer()
        surface.PlaySound("buttons/button14.wav")
    end)

    m:AddOption("Demote", function()
        net.Start("SWRP_MenuAction")
            net.WriteString("demote")
            net.WriteEntity(target)
            net.WriteString("")
        net.SendToServer()
        surface.PlaySound("buttons/button14.wav")
    end)

    m:AddOption("Set Rank...", function()
        Derma_StringRequest(
            "Set Rank",
            "Enter exact rank (case-insensitive):",
            "",
            function(txt)
                if not txt or txt == "" then return end
                net.Start("SWRP_MenuAction")
                    net.WriteString("setrank")
                    net.WriteEntity(target)
                    net.WriteString(txt)
                net.SendToServer()
                surface.PlaySound("buttons/button15.wav")
            end
        )
    end)

    m:Open()
    m:Center()
end

hook.Add("PlayerButtonDown", "SWRP_TMenu_OpenOnKey", function(ply, button)
    if ply ~= LocalPlayer() then return end
    if button ~= OPEN_KEY then return end

    -- Trace player you’re looking at
    local tr = ply:GetEyeTrace()
    local tgt = (tr.Hit and IsValid(tr.Entity) and tr.Entity:IsPlayer()) and tr.Entity or nil
    if not IsValid(tgt) then return end

    -- Range check
    if ply:GetPos():DistToSqr(tgt:GetPos()) > (MAX_DIST * MAX_DIST) then return end

    -- Open the menu
    SWRP_OpenTargetMenu(tgt)
end)