-- =======================================
-- SWRP Rank Tiers - CLONE WARS VERSION
-- Used for auto job switching & whitelist promotion
-- =======================================

SWRP_RankTiers = {
    -- ===== Clone Troopers =====
    ["Private"]                  = "Enlisted",
    ["Private First Class"]      = "Enlisted",
    ["Lance Corporal"]           = "Enlisted",
    ["Corporal"]                 = "Enlisted",

    ["Specialist"]               = "Enlisted",

    ["Sergeant"]                 = "NCO",
    ["Staff Sergeant"]           = "NCO",
    ["Drill Sergeant"]           = "NCO",

    ["Gunnery Sergeant"]         = "NCO",
    ["Master Sergeant"]          = "NCO",

    ["Warrant Officer"]          = "NCO",

    ["Second Lieutenant"]        = "Officer",
    ["Lieutenant"]               = "Officer",
    ["Lieutenant Captain"]       = "Officer",

    ["Captain"]                  = "Officer",
    ["Major"]                    = "Officer",
    ["Colonel"]                  = "Officer",

    ["Battalion Commander"]      = "Command",
    ["Field Commander"]          = "Command",
    ["Commander"]                = "Command",

    ["Marshal Commander"]        = "Command",

    -- ===== Republic Navy =====
    ["Cadet"]                    = "Enlisted",
    ["Junior Crewman"]           = "Enlisted",
    ["Crewman"]                  = "Enlisted",
    ["Senior Crewman"]           = "Enlisted",
    ["Master Crewman"]           = "Enlisted",
    ["Petty Officer"]            = "NCO",
    ["Senior Petty Officer"]     = "NCO",
    ["Chief Petty Officer"]      = "NCO",
    ["Senior Chief Petty Officer"] = "NCO",
    ["Master Chief Petty Officer"] = "NCO",
    ["Warrant Officer"]          = "NCO",
    ["Chief Warrant Officer"]    = "NCO",
    ["Ensign"]                   = "Officer",
    ["Sub-Lieutenant"]           = "Officer",
    ["Lieutenant"]               = "Officer",
    ["Lieutenant Commander"]     = "Officer",
    ["Commander"]                = "Officer",
    ["Flag Commander"]           = "Command",
    ["Captain"]                  = "Command",
    ["Flag Captain"]             = "Command",
    ["Commodore"]                = "Command",

    -- ===== Republic Starfighter Corps =====
    ["Cadet"]                    = "Enlisted",
    ["Junior Spaceman"]          = "Enlisted",
    ["Spaceman"]                 = "Enlisted",
    ["Senior Spaceman"]          = "Enlisted",
    ["Master Spaceman"]          = "Enlisted",

    ["Flight Sergeant"]          = "NCO",
    ["Flight Chief"]             = "NCO",
    ["Senior Flight Chief"]      = "NCO",
    ["Master Flight Chief"]      = "NCO",
    ["Junior Warrant Officer"]   = "NCO",
    ["Warrant Officer"]          = "NCO",
    ["Chief Warrant Officer"]    = "NCO",

    ["Junior Flight Officer"]    = "Officer",
    ["Flight Officer"]           = "Officer",
    ["Senior Flight Officer"]    = "Officer",
    ["Flight Commander"]         = "Officer",
    ["Squadron Commander"]       = "Officer",
    ["Wing Commander"]           = "Command",
    ["Group Commander"]          = "Command",
    ["Group Captain"]            = "Command",
    ["Flight Commodore"]         = "Command",

    -- ===== Jedi Order =====
    ["Jedi Youngling"]           = "Youngling",
    ["Jedi Padawan"]             = "Padawan",
    ["Jedi Knight"]              = "Knight",
    ["Jedi Master"]              = "Master",
    ["Jedi Council Member"]      = "Council",
    ["Senior Jedi General"]      = "HighCommand",
    ["Jedi General"]             = "General",

    -- ===== Republic Intelligence =====
    ["Cadet Operative"]          = "Enlisted",
    ["Acting Operative"]         = "Enlisted",
    ["Junior Operative"]         = "Enlisted",
    ["Operative"]                = "Enlisted",
    ["Senior Operative"]         = "Enlisted",

    ["Acting Agent"]             = "NCO",
    ["Junior Agent"]             = "NCO",
    ["Agent"]                    = "NCO",
    ["Senior Agent"]             = "NCO",
    ["Special Agent"]            = "NCO",
    ["Field Agent"]              = "NCO",
    ["Lead Agent"]               = "NCO",

    ["Officer Cadet"]            = "Officer",
    ["Junior Officer"]           = "Officer",
    ["Senior Officer"]           = "Officer",
    ["Field Officer"]            = "Officer",
    ["Command Officer"]          = "Officer",

    ["Deputy Inspector"]         = "Command",
    ["Inspector"]                = "Command",
    ["Sector Inspector"]         = "Command",
    ["Chief Inspector"]          = "Command",

    -- ===== ARC Troopers =====
    ["ARC Trooper"]              = "ARC",
    ["ARC Sergeant"]             = "ARC",
    ["ARC Lieutenant"]           = "ARCOfficer",
    ["ARC Captain"]              = "ARCOfficer",
    ["ARC Commander"]            = "ARCCommand",

    -- ===== Senate Guard =====
    ["Guard Recruit"]            = "Enlisted",
    ["Guard"]                    = "Enlisted",
    ["Senior Guard"]             = "NCO",
    ["Guard Sergeant"]           = "NCO",
    ["Guard Commander"]          = "Officer",
    ["Senior Guard Commander"]   = "Command",
    ["Captain of the Guard"]     = "HighCommand"
}
