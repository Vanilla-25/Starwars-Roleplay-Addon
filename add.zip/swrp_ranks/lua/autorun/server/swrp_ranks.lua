SWRP_RANKS = {
    ["CloneTroopers"] = {
        "Private", "Private First Class", "Specialist",
        "Lance Corporal", "Corporal",
        "Sergeant", "Staff Sergeant", "Drill Sergeant", "Gunnery Sergeant", "Master Sergeant",
        "Warrant Officer",
        "Second Lieutenant", "Lieutenant", "Lieutenant Captain",
        "Captain", "Major", "Colonel", "Battalion Commander", "Field Commander", "Commander",
        "Marshal Commander"
    },
    ["501st Legion"] = {
        "Private", "Private First Class", "Specialist",
        "Lance Corporal", "Corporal",
        "Sergeant", "Staff Sergeant", "Drill Sergeant", "Gunnery Sergeant", "Master Sergeant",
        "Warrant Officer",
        "Second Lieutenant", "Lieutenant", "Lieutenant Captain",
        "Captain", "Major", "Colonel", "Battalion Commander", "Field Commander", "Commander",
        "Marshal Commander"
    },
    ["212th Attack Battalion"] = {
        "Private", "Private First Class", "Specialist",
        "Lance Corporal", "Corporal",
        "Sergeant", "Staff Sergeant", "Drill Sergeant", "Gunnery Sergeant", "Master Sergeant",
        "Warrant Officer",
        "Second Lieutenant", "Lieutenant", "Lieutenant Captain",
        "Captain", "Major", "Colonel", "Battalion Commander", "Field Commander", "Commander",
        "Marshal Commander"
    },
    ["104th Battalion"] = {
        "Private", "Private First Class", "Specialist",
        "Lance Corporal", "Corporal",
        "Sergeant", "Staff Sergeant", "Drill Sergeant", "Gunnery Sergeant", "Master Sergeant",
        "Warrant Officer",
        "Second Lieutenant", "Lieutenant", "Lieutenant Captain",
        "Captain", "Major", "Colonel", "Battalion Commander", "Field Commander", "Commander",
        "Marshal Commander"
    },
    ["Republic Navy"] = {
        "Cadet", "Junior Crewman", "Crewman", "Senior Crewman", "Master Crewman", 
        "Petty Officer", "Senior Petty Officer", "Chief Petty Officer", "Senior Chief Petty Officer", "Master Chief Petty Officer", 
        "Warrant Officer", "Chief Warrant Officer", 
        "Ensign", "Sub-Lieutenant", "Lieutenant", "Lieutenant Commander",
        "Commander", "Flag Commander", "Captain", "Flag Captain", "Commodore"
    },
    ["Republic Starfighter Corps"] = {
        "Cadet", "Junior Spaceman", "Spaceman", "Senior Spaceman", "Master Spaceman",
        "Flight Sergeant", "Flight Chief", "Senior Flight Chief", "Master Flight Chief",
        "Junior Warrant Officer", "Warrant Officer", "Chief Warrant Officer",
        "Junior Flight Officer", "Flight Officer", "Senior Flight Officer",
        "Flight Commander", "Squadron Commander", "Wing Commander", "Group Commander",
        "Group Captain", "Flight Commodore"
    },
    ["Jedi Order"] = {
        "Jedi Initiate", "Jedi Padawan", "Jedi Knight", "Jedi Master", 
        "Jedi Council Member", "Jedi General", "Senior Jedi General"
    },
    ["Republic Intelligence"] = {
        "Cadet Operative", "Acting Operative", "Junior Operative", "Operative", "Senior Operative",
        "Acting Agent", "Junior Agent", "Agent", "Senior Agent", "Special Agent",
        "Field Agent", "Lead Agent",
        "Officer Cadet", "Junior Officer", "Senior Officer", "Field Officer", "Command Officer",
        "Deputy Inspector", "Inspector", "Sector Inspector", "Chief Inspector"
    },
    ["ARC Troopers"] = {
        "ARC Trooper", "ARC Sergeant", "ARC Lieutenant", "ARC Captain", "ARC Commander"
    },
    ["Senate Guard"] = {
        "Guard Recruit", "Guard", "Senior Guard", "Guard Sergeant", 
        "Guard Commander", "Senior Guard Commander", "Captain of the Guard"
    },
    ["Republic High Command"] = {
        "Major General", "Lieutenant General", "General", "High General", "Grand General"
    }
}
