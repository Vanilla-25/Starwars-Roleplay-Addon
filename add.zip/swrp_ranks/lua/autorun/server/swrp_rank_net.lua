util.AddNetworkString("SWRP_OpenMenuAction")

net.Receive("SWRP_OpenMenuAction", function(len, ply)
    local action = net.ReadString()
    local target = net.ReadEntity()
    local rankName = net.ReadString() or ""

    if not IsValid(target) or not target:IsPlayer() then return end

    if action == "promote" then
        PromotePlayer(ply, target)
    elseif action == "demote" then
        DemotePlayer(ply, target)
    elseif action == "setrank" and rankName ~= "" then
        SetPlayerRank(ply, target, rankName)
    end
end)
-- ====== SWRP T-Menu networking (serverside) ======
util.AddNetworkString("SWRP_MenuAction")

net.Receive("SWRP_MenuAction", function(_, ply)
    local action  = net.ReadString() or ""
    local target  = net.ReadEntity()
    local rankArg = net.ReadString() or ""

    if not IsValid(ply) or not IsValid(target) or not target:IsPlayer() then return end
    -- (Optional) distance sanity check; mirror client
    if ply:GetPos():DistToSqr(target:GetPos()) > (600 * 600) then return end

    if action == "promote" then
        PromotePlayer(ply, target)
        print("[SWRP][T-Menu] Promote ->", ply:Nick(), "->", target:Nick())
    elseif action == "demote" then
        DemotePlayer(ply, target)
        print("[SWRP][T-Menu] Demote ->", ply:Nick(), "->", target:Nick())
    elseif action == "setrank" and rankArg ~= "" then
        SetPlayerRank(ply, target, rankArg)
        print("[SWRP][T-Menu] SetRank ->", ply:Nick(), "->", target:Nick(), ":", rankArg)
    end
end)
