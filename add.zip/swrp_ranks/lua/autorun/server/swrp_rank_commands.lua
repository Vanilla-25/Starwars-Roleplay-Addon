-- lua/autorun/server/swrp_rank_commands.lua
local function PromotePlayer(ply, target)
    local regiment = target:GetNWString("SWRP_Regiment")
    local rank = target:GetNWString("SWRP_Rank")

    local ladder = SWRP_RANKS[regiment]
    if not ladder then return end

    local idx = table.KeyFromValue(ladder, rank) or 1
    if idx < #ladder then
        local newRank = ladder[idx + 1]
        target:SetNWString("SWRP_Rank", newRank)
        SavePlayerRank(target, regiment, newRank)
        ply:ChatPrint("You promoted " .. target:Nick() .. " to " .. newRank)
        target:ChatPrint("You have been promoted to " .. newRank)
    else
        ply:ChatPrint(target:Nick() .. " is already max rank.")
    end
end

local function DemotePlayer(ply, target)
    local regiment = target:GetNWString("SWRP_Regiment")
    local rank = target:GetNWString("SWRP_Rank")

    local ladder = SWRP_RANKS[regiment]
    if not ladder then return end

    local idx = table.KeyFromValue(ladder, rank) or 1
    if idx > 1 then
        local newRank = ladder[idx - 1]
        target:SetNWString("SWRP_Rank", newRank)
        SavePlayerRank(target, regiment, newRank)
        ply:ChatPrint("You demoted " .. target:Nick() .. " to " .. newRank)
        target:ChatPrint("You have been demoted to " .. newRank)
    else
        ply:ChatPrint(target:Nick() .. " is already lowest rank.")
    end
end

-- Chat commands (you could replace with ULX commands later)
hook.Add("PlayerSay", "SWRP_PromoteDemote", function(ply, text)
    local args = string.Explode(" ", text)
    if args[1] == "!promote" and IsValid(ply) then
        local target = DarkRP and DarkRP.findPlayer(args[2]) or nil
        if IsValid(target) then
            PromotePlayer(ply, target)
        end
        return ""
    elseif args[1] == "!demote" and IsValid(ply) then
        local target = DarkRP and DarkRP.findPlayer(args[2]) or nil
        if IsValid(target) then
            DemotePlayer(ply, target)
        end
        return ""
    end
end)
