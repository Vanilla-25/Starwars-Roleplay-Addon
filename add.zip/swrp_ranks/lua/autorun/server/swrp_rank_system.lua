-- =======================================
-- SWRP Rank System (JSON, permissions, auto job switch, sub-branch aware, with debug)
-- =======================================

if file.Exists("autorun/server/swrp_rank_tiers.lua", "LUA") then
    include("autorun/server/swrp_rank_tiers.lua")
else
    print("[SWRP][WARN] swrp_rank_tiers.lua not found! Tier lookups will fail.")
end

SWRP_Rank = SWRP_Rank or {}

-- Debug logging (enable with:  sv_swrp_debug_jobs 1  OR  swrp_debug_jobs 1)
-- Try both names so servers that already set one of them get logs.
local function DLog(...)
    if cvars.Bool("swrp_debug_jobs", false) or cvars.Bool("sv_swrp_debug_jobs", false) then
        MsgC(Color(0,200,255), "[SWRP][DEBUG] ", Color(255,255,255), table.concat({...}," "), "\n")
    end
end

-- File path for saving ranks
local RANK_FILE = "swrp_ranks.json"
local RankData = util.JSONToTable(file.Read(RANK_FILE, "DATA") or "{}") or {}

local function SaveRanks()
    file.Write(RANK_FILE, util.TableToJSON(RankData, true))
end

-- Prefer stored NW branch first, then fallback to job.SubBranch, then "Main".
local function GetPlayerSubBranch(ply)
    local nw = ply:GetNWString("SWRP_SubBranch", "")
    if nw ~= "" then return nw end
    local job = RPExtraTeams[ply:Team()]
    return (job and job.SubBranch) or "Main"
end

-- Save a single player's rank
function SWRP_Rank.Save(ply, regiment, rank, subBranch)
    if not IsValid(ply) then return end
    local sid = ply:SteamID()
    local sb = subBranch or GetPlayerSubBranch(ply) or "Main"
    RankData[sid] = { regiment = regiment, rank = rank, subBranch = sb }
    SaveRanks()
    DLog("Saved ", ply:Nick(), " (", sid, "): ", regiment, " - ", rank, " [", sb, "]")
end

-- Load a player's rank when they join
local function LoadPlayerRank(ply)
    local sid = ply:SteamID()
    local data = RankData[sid]
    if data then
        ply:SetNWString("SWRP_Regiment", data.regiment)
        ply:SetNWString("SWRP_Rank", data.rank)
        ply:SetNWString("SWRP_SubBranch", data.subBranch or "Main")
        print("[SWRP] Loaded " .. ply:Nick() .. " (" .. sid .. "): " .. data.regiment .. " - " .. data.rank .. " [" .. (data.subBranch or "Main") .. "]")
    else
        local reg = (RPExtraTeams[ply:Team()] and RPExtraTeams[ply:Team()].category) or "Stormtroopers"
        local ladder = SWRP_RANKS and SWRP_RANKS[reg] or SWRP_RANKS and SWRP_RANKS["Stormtroopers"]
        local startRank = (ladder and ladder[1]) or "Private"
        ply:SetNWString("SWRP_Regiment", reg)
        ply:SetNWString("SWRP_Rank", startRank)
        ply:SetNWString("SWRP_SubBranch", "Main")
        SWRP_Rank.Save(ply, reg, startRank, "Main")
        print("[SWRP] No saved rank, defaulting " .. ply:Nick() .. " to " .. reg .. " - " .. startRank .. " [Main]")
    end
end

hook.Add("PlayerInitialSpawn", "SWRP_LoadRank_JSON", LoadPlayerRank)
hook.Add("PlayerDisconnected", "SWRP_SaveRank_JSON", function(ply)
    SWRP_Rank.Save(ply, ply:GetNWString("SWRP_Regiment"), ply:GetNWString("SWRP_Rank"), ply:GetNWString("SWRP_SubBranch"))
end)
hook.Add("ShutDown", "SWRP_SaveAll_JSON", SaveRanks)

-- =======================================
-- Promotion Permission Config
-- =======================================

local ALLOWED_GROUPS = {
    ["superadmin"] = true,
    ["Administrator"] = true,
    ["Community Developer"] = true,
}
local GLOBAL_JOBS = {
    ["Imperial High Command High General"] = true,
    ["Imperial High Command Major General"] = true,
    ["Grand Inquisitor"] = true,
}
local REGIMENT_JOBS = {
    ["501st Legion Officer"] = true,
    ["501st Legion Command"] = true,
    ["501st SCAR Trooper Officer"] = true,
    ["Imperial Starfighter Corps Officer"] = true,
    ["Imperial Starfighter Corps Command"] = true,
    ["Shocktrooper Officer"] = true,
    ["Shocktrooper Command"] = true,
    ["Shocktrooper Forensics Officer"] = true,
    ["Shocktrooper Forensics Command"] = true,
    ["Shocktrooper Heavy Officer"] = true,
    ["Shocktrooper Heavy Command"] = true,
    ["Shocktrooper SCAR Officer"] = true,
    ["Naval Staff Officer"] = true,
    ["Naval Staff Command"] = true,
    ["Naval Staff Engineer Officer"] = true,
    ["Naval Staff Engineer Command"] = true,
    ["Chief Inquisitor"] = true,
}

local function CanPromote(ply, target)
    if not IsValid(ply) or not IsValid(target) then return false end
    if ALLOWED_GROUPS[ply:GetUserGroup()] then return true end
    local job = RPExtraTeams[ply:Team()]
    if not job then return false end
    if GLOBAL_JOBS[job.name] then return true end
    if REGIMENT_JOBS[job.name] then
        local myReg = job.category or ""
        local theirReg = target:GetNWString("SWRP_Regiment", "")
        if myReg == theirReg then return true end
    end
    return false
end

-- =======================================
-- Auto Job Switcher (RankTier + SubBranch)
-- =======================================

local function HandleAutoJobSwitch(ply, regiment, rank)
    if not IsValid(ply) then return end
    local tier = SWRP_RankTiers and SWRP_RankTiers[rank]
    if not tier then
        DLog("No tier for rank '", tostring(rank), "' — check SWRP_RankTiers.")
        return
    end

    local subBranch = GetPlayerSubBranch(ply) or "Main"
    DLog("AutoSwitch: reg=", regiment, " rank=", rank, " tier=", tier, " subBranch=", subBranch)

    -- Pass 1: exact sub-branch match
    for jobID, job in pairs(RPExtraTeams) do
        if job and job.category == regiment and job.RankTier == tier then
            local jobBranch = job.SubBranch or "Main"
            if jobBranch == subBranch then
                if ply:Team() ~= jobID then
                    DLog("Found exact job: ", job.name, " (", tier, "/", subBranch, ")")
                    timer.Simple(0.1, function()
                        if IsValid(ply) then
                            ply:changeTeam(jobID, true)
                            ply:SetNWString("SWRP_SubBranch", subBranch)
                            SWRP_Rank.Save(ply, regiment, rank, subBranch)
                            DLog("Switched to exact match.")
                        end
                    end)
                end
                return
            end
        end
    end

    -- Pass 2: fallback to main branch
    DLog("No exact sub-branch match; trying Main fallback...")
    for jobID, job in pairs(RPExtraTeams) do
        if job and job.category == regiment and job.RankTier == tier and (not job.SubBranch) then
            if ply:Team() ~= jobID then
                timer.Simple(0.1, function()
                    if IsValid(ply) then
                        ply:changeTeam(jobID, true)
                        ply:SetNWString("SWRP_SubBranch", "Main")
                        SWRP_Rank.Save(ply, regiment, rank, "Main")
                        DLog("Switched using Main fallback: ", job.name)
                    end
                end)
            end
            return
        end
    end

    DLog("No job found in regiment '", regiment, "' for tier '", tier, "' (branch ", subBranch, ").")
end

-- =======================================
-- Promotion / Demotion / Set (sub-branch safe)
-- =======================================

function SWRP_Rank.Promote(ply, target)
    if not CanPromote(ply, target) then
        ply:ChatPrint("❌ You are not allowed to promote players.")
        return
    end

    local regiment = target:GetNWString("SWRP_Regiment")
    local rank     = target:GetNWString("SWRP_Rank")
    local ladder   = SWRP_RANKS and SWRP_RANKS[regiment]
    if not ladder then
        ply:ChatPrint("No rank ladder for " .. regiment)
        return
    end

    local idx = table.KeyFromValue(ladder, rank) or 1
    if idx < #ladder then
        local newRank   = ladder[idx + 1]
        local subBranch = target:GetNWString("SWRP_SubBranch", "Main")

        target:SetNWString("SWRP_Rank", newRank)
        target:SetNWString("SWRP_SubBranch", subBranch)
        SWRP_Rank.Save(target, regiment, newRank, subBranch)
        HandleAutoJobSwitch(target, regiment, newRank)

        ply:ChatPrint("✅ You promoted " .. target:Nick() .. " to " .. newRank .. " ["..subBranch.."]")
        target:ChatPrint("✅ You have been promoted to " .. newRank .. " ["..subBranch.."]")
        DLog("Promoted ", target:Nick(), " → ", newRank, " [", subBranch, "]")
    else
        ply:ChatPrint(target:Nick() .. " is already max rank.")
    end
end

function SWRP_Rank.Demote(ply, target)
    if not CanPromote(ply, target) then
        ply:ChatPrint("❌ You are not allowed to demote players.")
        return
    end

    local regiment = target:GetNWString("SWRP_Regiment")
    local rank     = target:GetNWString("SWRP_Rank")
    local ladder   = SWRP_RANKS and SWRP_RANKS[regiment]
    if not ladder then
        ply:ChatPrint("No rank ladder for " .. regiment)
        return
    end

    local idx = table.KeyFromValue(ladder, rank) or 1
    if idx > 1 then
        local newRank   = ladder[idx - 1]
        local subBranch = target:GetNWString("SWRP_SubBranch", "Main")

        target:SetNWString("SWRP_Rank", newRank)
        target:SetNWString("SWRP_SubBranch", subBranch)
        SWRP_Rank.Save(target, regiment, newRank, subBranch)
        HandleAutoJobSwitch(target, regiment, newRank)

        ply:ChatPrint("✅ You demoted " .. target:Nick() .. " to " .. newRank .. " ["..subBranch.."]")
        target:ChatPrint("⬇️ You have been demoted to " .. newRank .. " ["..subBranch.."]")
        DLog("Demoted ", target:Nick(), " → ", newRank, " [", subBranch, "]")
    else
        ply:ChatPrint(target:Nick() .. " is already lowest rank.")
    end
end

function SWRP_Rank.Set(ply, target, rankName)
    if not CanPromote(ply, target) then
        ply:ChatPrint("❌ You are not allowed to set ranks.")
        return
    end

    local regiment = target:GetNWString("SWRP_Regiment")
    local ladder   = SWRP_RANKS and SWRP_RANKS[regiment]
    if not ladder then
        ply:ChatPrint("No rank ladder for " .. regiment)
        return
    end

    local chosenRank
    for _, r in ipairs(ladder) do
        if string.lower(r) == string.lower(rankName) then
            chosenRank = r
            break
        end
    end
    if not chosenRank then
        ply:ChatPrint("Rank '" .. rankName .. "' not found in " .. regiment)
        return
    end

    local subBranch = target:GetNWString("SWRP_SubBranch", "Main")
    target:SetNWString("SWRP_Rank", chosenRank)
    target:SetNWString("SWRP_SubBranch", subBranch)
    SWRP_Rank.Save(target, regiment, chosenRank, subBranch)
    HandleAutoJobSwitch(target, regiment, chosenRank)

    ply:ChatPrint("✅ You set " .. target:Nick() .. " to " .. chosenRank .. " in " .. regiment .. " ["..subBranch.."]")
    target:ChatPrint("✅ Your rank has been set to " .. chosenRank .. " ["..subBranch.."]")
    DLog("Set rank ", target:Nick(), " → ", chosenRank, " [", subBranch, "]")
end

-- =======================================
-- Chat Commands (promote/demote/setrank + setbranch + myrank)
-- =======================================

hook.Add("PlayerSay", "SWRP_ChatCommands", function(ply, text)
    local args = string.Explode(" ", text or "")
    if not args[1] then return end

    if args[1] == "!promote" and args[2] then
        local target = DarkRP and DarkRP.findPlayer(args[2]) or nil
        if IsValid(target) then SWRP_Rank.Promote(ply, target) end
        return ""
    elseif args[1] == "!demote" and args[2] then
        local target = DarkRP and DarkRP.findPlayer(args[2]) or nil
        if IsValid(target) then SWRP_Rank.Demote(ply, target) end
        return ""
    elseif args[1] == "!setrank" and args[2] and args[3] then
        local target = DarkRP and DarkRP.findPlayer(args[2]) or nil
        if IsValid(target) then
            local rankName = table.concat(args, " ", 3)
            SWRP_Rank.Set(ply, target, rankName)
        else
            ply:ChatPrint("Target not found.")
        end
        return ""
    elseif args[1] == "!setbranch" and args[2] then
        local branch = table.concat(args, " ", 2)
        ply:SetNWString("SWRP_SubBranch", branch)
        local reg  = ply:GetNWString("SWRP_Regiment")
        local rank = ply:GetNWString("SWRP_Rank")
        SWRP_Rank.Save(ply, reg, rank, branch)
        ply:ChatPrint("✅ Sub-branch set to: " .. branch)
        HandleAutoJobSwitch(ply, reg, rank)
        return ""
    elseif args[1] == "!myrank" then
        ply:ChatPrint(("Regiment: %s | Rank: %s | Tier: %s | Branch: %s"):format(
            ply:GetNWString("SWRP_Regiment"),
            ply:GetNWString("SWRP_Rank"),
            SWRP_RankTiers and (SWRP_RankTiers[ply:GetNWString("SWRP_Rank")] or "nil") or "nil",
            GetPlayerSubBranch(ply)
        ))
        return ""
    end
end)

-- =======================================
-- Reset Rank on Job Change
-- =======================================

hook.Add("OnPlayerChangedTeam", "SWRP_ResetRankOnJobChange", function(ply, before, after)
    local newJob = RPExtraTeams[after]
    if not newJob then return end

    local newReg = newJob.category or "Stormtroopers"
    local newSub = newJob.SubBranch or GetPlayerSubBranch(ply) or "Main"
    local sid = ply:SteamID()
    local saved = RankData[sid]

    if saved and saved.regiment == newReg then
        ply:SetNWString("SWRP_Regiment",  saved.regiment)
        ply:SetNWString("SWRP_Rank",      saved.rank)
        ply:SetNWString("SWRP_SubBranch", saved.subBranch or newSub or "Main")
        print("[SWRP] " .. ply:Nick() .. " stayed in " .. newReg .. " as " .. saved.rank .. " [" .. (saved.subBranch or newSub or "Main") .. "]")
        if newJob.SubBranch and (saved.subBranch ~= newJob.SubBranch) then
            SWRP_Rank.Save(ply, newReg, saved.rank, newJob.SubBranch)
        end
        return
    end

    local ladder = SWRP_RANKS and SWRP_RANKS[newReg] or SWRP_RANKS and SWRP_RANKS["Stormtroopers"]
    local startRank = (ladder and ladder[1]) or "Private"

    ply:SetNWString("SWRP_Regiment", newReg)
    ply:SetNWString("SWRP_Rank", startRank)
    ply:SetNWString("SWRP_SubBranch", newSub)

    SWRP_Rank.Save(ply, newReg, startRank, newSub)
    HandleAutoJobSwitch(ply, newReg, startRank)

    ply:ChatPrint("Your regiment has been set to " .. newReg .. " and your rank reset to " .. startRank .. ".")
    print("[SWRP] " .. ply:Nick() .. " switched regiment → " .. newReg .. " - " .. startRank .. " [" .. newSub .. "]")
end)

-- =======================================
-- Net for T-Menu
-- =======================================

util.AddNetworkString("SWRP_MenuAction")
net.Receive("SWRP_MenuAction", function(_, ply)
    local action  = net.ReadString() or ""
    local target  = net.ReadEntity()
    local rankArg = net.ReadString() or ""

    if not IsValid(ply) or not IsValid(target) or not target:IsPlayer() then return end
    if ply:GetPos():DistToSqr(target:GetPos()) > (600 * 600) then return end

    if action == "promote" then
        SWRP_Rank.Promote(ply, target)
    elseif action == "demote" then
        SWRP_Rank.Demote(ply, target)
    elseif action == "setrank" and rankArg ~= "" then
        SWRP_Rank.Set(ply, target, rankArg)
    end
end)
