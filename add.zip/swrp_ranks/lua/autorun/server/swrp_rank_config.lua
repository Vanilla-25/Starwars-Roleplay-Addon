-- lua/autorun/server/swrp_rank_config.lua
require("mysqloo")

SWRP_DB = SWRP_DB or {}

-- Edit these with your database details
local DB_HOST = "n/a"
local DB_USER = "db209205"
local DB_PASS = "Sd4S75VwR6"
local DB_NAME = "db209205"
local DB_PORT = 3306

function SWRP_DB.Connect()
    SWRP_DB.db = mysqloo.connect(DB_HOST, DB_USER, DB_PASS, DB_NAME, DB_PORT)

    function SWRP_DB.db:onConnected()
        print("[SWRP] Connected to MySQL!")

        -- Create table if it doesn’t exist
        self:query([[
            CREATE TABLE IF NOT EXISTS swrp_ranks (
                steamid VARCHAR(32) PRIMARY KEY,
                regiment VARCHAR(64),
                rank VARCHAR(64)
            );
        ]]):start()
    end

    function SWRP_DB.db:onConnectionFailed(err)
        print("[SWRP] MySQL connection failed: " .. err)
    end

    SWRP_DB.db:connect()
end

hook.Add("Initialize", "SWRP_DB_Init", function()
    SWRP_DB.Connect()
end)
