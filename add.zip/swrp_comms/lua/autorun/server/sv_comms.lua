-- ============================================================
--  SW_COMMS | Server-Side Handler
--  Star Wars Roleplay Communications System
-- ============================================================

util.AddNetworkString("SW_Comms_Broadcast")

-- Configuration
local COMMS_CONFIG = {
    cooldown     = 10,      -- seconds between broadcasts per player
    maxLength    = 200,     -- max message character length
    adminOnly    = false,   -- restrict to admins/superadmins only
    logToConsole = true,    -- log broadcasts to server console
}

-- Per-player cooldown tracking
local cooldowns = {}

-- Helper: check if player has permission
local function HasPermission(ply)
    if not COMMS_CONFIG.adminOnly then return true end
    return ply:IsAdmin() or ply:IsSuperAdmin()
end

-- Helper: get caller's rank string for display
local function GetRank(ply)
    local rank = ply:GetUserGroup() or "user"
    -- Capitalise first letter
    return rank:sub(1,1):upper() .. rank:sub(2)
end

-- Chat command listener
hook.Add("PlayerSay", "SW_Comms_ChatCommand", function(ply, text)
    -- Only respond to /broadcast, nothing else
    if not text:match("^/broadcast") then return end

    local msg = text:match("^/broadcast%s+(.*)")  -- requires at least one space + character

    -- Permission check
    if not HasPermission(ply) then
        ply:ChatPrint("[COMMS] You do not have permission to broadcast.")
        return ""
    end

    -- If no message provided after /broadcast, show usage hint
    if not msg or msg:Trim() == "" then
        ply:ChatPrint("[COMMS] Usage: /broadcast <your message here>")
        return ""
    end
    msg = msg:Trim()

    -- Length check
    if #msg > COMMS_CONFIG.maxLength then
        ply:ChatPrint("[COMMS] Message too long. Maximum " .. COMMS_CONFIG.maxLength .. " characters.")
        return ""
    end

    -- Cooldown check
    local now   = CurTime()
    local last  = cooldowns[ply:SteamID()] or 0
    if (now - last) < COMMS_CONFIG.cooldown then
        local remaining = math.ceil(COMMS_CONFIG.cooldown - (now - last))
        ply:ChatPrint("[COMMS] Cooldown active. Please wait " .. remaining .. " seconds.")
        return ""
    end
    cooldowns[ply:SteamID()] = now

    -- Log to server console
    if COMMS_CONFIG.logToConsole then
        MsgC(Color(0, 200, 255), "[SW_COMMS] ", Color(255,255,255),
              ply:Nick() .. " (" .. ply:SteamID() .. "): ", Color(200, 255, 200), msg .. "\n")
    end

    -- Send to all clients
    net.Start("SW_Comms_Broadcast")
        net.WriteString(ply:Nick())
        net.WriteString(GetRank(ply))
        net.WriteString(msg)
        -- Send the broadcaster's avatar entity index (for potential future use)
        net.WriteUInt(IsValid(ply) and ply:EntIndex() or 0, 16)
    net.Broadcast()

    -- Suppress the chat message so it doesn't appear normally
    return ""
end)

-- Console command alternative (for admins)
concommand.Add("sw_comms_broadcast", function(ply, cmd, args)
    if not IsValid(ply) then return end  -- server console guard
    if not HasPermission(ply) then
        ply:ChatPrint("[COMMS] No permission.")
        return
    end
    local msg = table.concat(args, " "):Trim()
    if msg == "" then return end

    net.Start("SW_Comms_Broadcast")
        net.WriteString(ply:Nick())
        net.WriteString(GetRank(ply))
        net.WriteString(msg)
        net.WriteUInt(IsValid(ply) and ply:EntIndex() or 0, 16)
    net.Broadcast()
end)
