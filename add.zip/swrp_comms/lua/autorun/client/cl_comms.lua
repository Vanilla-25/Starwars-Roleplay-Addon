-- ============================================================
--  SW_COMMS | Client-Side Holographic UI
--  Star Wars Roleplay Communications System
--  Styled after Battlefront II comms overlay
-- ============================================================

-- ──────────────────────────────────────────────
--  Configuration
-- ──────────────────────────────────────────────
local CFG = {
    -- Position: TOP-LEFT corner
    marginX     = 30,       -- px from left edge  (at 1920 base)
    marginY     = 30,       -- px from top edge

    -- Panel dimensions (at 1920 base)
    panelW      = 480,
    panelH      = 130,
    imgW        = 130,      -- left image square (same as height)

    -- Timing
    fadeInTime  = 0.35,
    holdTime    = 6.0,
    fadeOutTime = 0.6,

    -- Colours
    colBorder   = Color(180, 190, 200),      -- outer border
    colBorderDim= Color( 80, 100, 120),      -- inner border / dividers
    colBg       = Color(  8,  14,  22, 210), -- panel background
    colImgBg    = Color(  5,  10,  18, 255), -- image area background
    colGrid     = Color(180, 190, 200,  55), -- grid lines right panel
    colGridImg  = Color(180, 190, 200,  70), -- grid lines over image
    colScan     = Color(200, 215, 230, 160), -- vertical scan line
    colRedBar   = Color(200,  30,  20),      -- red vertical bars
    colText     = Color(210, 225, 240),      -- message text
    colName     = Color(230, 240, 255),      -- sender name
    colDim      = Color(100, 120, 140),      -- muted labels
    colCorner   = Color(200, 215, 230),      -- corner brackets

    -- Fonts
    fontName  = "SW_Comms_Name",
    fontMsg   = "SW_Comms_Msg",
    fontLabel = "SW_Comms_Label",
    fontSmall = "SW_Comms_Small",

    -- Sound
    sound         = "sw_comms/transmission.wav",
    soundFallback = "buttons/button15.wav",
}

-- ──────────────────────────────────────────────
--  Font Registration
-- ──────────────────────────────────────────────
surface.CreateFont(CFG.fontName, {
    font = "Trebuchet MS", size = 14, weight = 800, antialias = true,
})
surface.CreateFont(CFG.fontMsg, {
    font = "Trebuchet MS", size = 13, weight = 400, antialias = true,
})
surface.CreateFont(CFG.fontLabel, {
    font = "Trebuchet MS", size = 10, weight = 600, antialias = true, italic = true,
})
surface.CreateFont(CFG.fontSmall, {
    font = "Trebuchet MS", size = 9, weight = 400, antialias = true,
})

-- ──────────────────────────────────────────────
--  State
-- ──────────────────────────────────────────────
local queue   = {}
local current = nil

local function NextTransmission()
    if #queue == 0 then current = nil return end
    current           = table.remove(queue, 1)
    current.startTime = RealTime()
    current.phase     = "in"
end

-- ──────────────────────────────────────────────
--  Net Receiver
-- ──────────────────────────────────────────────
net.Receive("SW_Comms_Broadcast", function()
    local name    = net.ReadString()
    local rank    = net.ReadString()
    local msg     = net.ReadString()
    local _entIdx = net.ReadUInt(16)

    local isFirst = (#queue == 0 and current == nil)
    table.insert(queue, { name = name, rank = rank, msg = msg })
    if isFirst then NextTransmission() end

    if isFirst then
        local snd = CFG.sound
        if snd and file.Exists("sound/" .. snd, "GAME") then
            surface.PlaySound(snd)
        else
            surface.PlaySound(CFG.soundFallback)
        end
    end
end)

-- ──────────────────────────────────────────────
--  Helpers
-- ──────────────────────────────────────────────
local function CA(col, a)
    return Color(col.r, col.g, col.b, a)
end

local function DrawCorner(x, y, s, flipX, flipY, col)
    local dx = flipX and -1 or 1
    local dy = flipY and -1 or 1
    surface.SetDrawColor(col)
    surface.DrawLine(x,    y,    x+dx*s, y      )
    surface.DrawLine(x,    y,    x,      y+dy*s )
    surface.DrawLine(x,    y+dy, x+dx*s, y+dy   )
    surface.DrawLine(x+dx, y,    x+dx,   y+dy*s )
end

local function WrapText(text, font, maxW)
    surface.SetFont(font)
    local words = string.Explode(" ", text)
    local lines, line = {}, ""
    for _, w in ipairs(words) do
        local test = line == "" and w or (line .. " " .. w)
        if surface.GetTextSize(test) > maxW and line ~= "" then
            table.insert(lines, line)
            line = w
        else
            line = test
        end
    end
    if line ~= "" then table.insert(lines, line) end
    return lines
end

-- ──────────────────────────────────────────────
--  Main HUD Hook
-- ──────────────────────────────────────────────
hook.Add("HUDPaint", "SW_Comms_Draw", function()
    if not current then return end

    local now     = RealTime()
    local elapsed = now - current.startTime
    local alpha   = 1

    if current.phase == "in" then
        alpha = math.Clamp(elapsed / CFG.fadeInTime, 0, 1)
        alpha = alpha * alpha * (3 - 2 * alpha)  -- smoothstep
        if elapsed >= CFG.fadeInTime then
            current.phase = "hold"
            current.startTime = now
        end
    elseif current.phase == "hold" then
        alpha = 1
        if elapsed >= CFG.holdTime then
            current.phase = "out"
            current.startTime = now
        end
    elseif current.phase == "out" then
        alpha = 1 - math.Clamp(elapsed / CFG.fadeOutTime, 0, 1)
        alpha = alpha * alpha
        if elapsed >= CFG.fadeOutTime then
            NextTransmission()
            return
        end
    end

    local A = math.floor(alpha * 255)
    if A <= 0 then return end

    -- ── Scale & layout (TOP-LEFT) ─────────────
    local sw = ScrW()
    local sc = sw / 1920
    local W  = math.floor(CFG.panelW * sc)
    local H  = math.floor(CFG.panelH * sc)
    local iW = math.floor(CFG.imgW   * sc)
    local X  = math.floor(CFG.marginX * sc)
    local Y  = math.floor(CFG.marginY * sc)

    -- ── Background fill ───────────────────────
    local bg = CFG.colBg
    surface.SetDrawColor(bg.r, bg.g, bg.b, math.floor(bg.a * alpha))
    surface.DrawRect(X, Y, W, H)

    -- ── Grid — right panel ────────────────────
    local rX   = X + iW
    local cell = math.max(math.floor(18 * sc), 4)
    local gc   = CFG.colGrid
    surface.SetDrawColor(gc.r, gc.g, gc.b, math.floor(A * gc.a / 255))
    for lx = rX, X + W, cell do
        surface.DrawLine(lx, Y, lx, Y + H)
    end
    for ly = Y, Y + H, cell do
        surface.DrawLine(rX, ly, X + W, ly)
    end

    -- ── Image panel bg ────────────────────────
    local ib = CFG.colImgBg
    surface.SetDrawColor(ib.r, ib.g, ib.b, math.floor(255 * alpha))
    surface.DrawRect(X, Y, iW, H)

    -- Avatar texture
    local mat = Material("sw_comms/avatar")
    if not mat:IsError() then
        surface.SetMaterial(mat)
        surface.SetDrawColor(255, 255, 255, A)
        surface.DrawTexturedRect(X, Y, iW, H)
        -- slight dark overlay so it reads as a darker image like the ref
        surface.SetDrawColor(5, 10, 18, math.floor(A * 0.3))
        surface.DrawRect(X, Y, iW, H)
    end

    -- Grid overlay on image
    local gi = CFG.colGridImg
    surface.SetDrawColor(gi.r, gi.g, gi.b, math.floor(A * gi.a / 255))
    for lx = X, X + iW, cell do
        surface.DrawLine(lx, Y, lx, Y + H)
    end
    for ly = Y, Y + H, cell do
        surface.DrawLine(X, ly, X + iW, ly)
    end

    -- Vertical scan line sweeping across image
    if current.phase == "hold" then
        local frac = (now * 0.35) % 1
        local sx   = X + math.floor(iW * frac)
        local sc2  = CFG.colScan
        surface.SetDrawColor(sc2.r, sc2.g, sc2.b, math.floor(A * sc2.a / 255))
        surface.DrawLine(sx, Y, sx, Y + H)
        surface.SetDrawColor(sc2.r, sc2.g, sc2.b, math.floor(A * 0.07))
        surface.DrawRect(sx - 3, Y, 7, H)
    end

    -- ── Borders ───────────────────────────────
    local bc  = CFG.colBorder
    local bc2 = CFG.colBorderDim
    -- outer
    surface.SetDrawColor(bc.r, bc.g, bc.b, math.floor(A * 0.85))
    surface.DrawOutlinedRect(X, Y, W, H, 1)
    -- inner inset 2px
    surface.SetDrawColor(bc2.r, bc2.g, bc2.b, math.floor(A * 0.45))
    surface.DrawOutlinedRect(X+2, Y+2, W-4, H-4, 1)

    -- Divider: image | text
    surface.SetDrawColor(bc.r, bc.g, bc.b, math.floor(A * 0.9))
    surface.DrawLine(X + iW, Y, X + iW, Y + H)
    surface.SetDrawColor(bc2.r, bc2.g, bc2.b, math.floor(A * 0.35))
    surface.DrawLine(X + iW + 1, Y, X + iW + 1, Y + H)

    -- ── Red vertical bars (right side of panel) ──
    -- Matches the reference image: tall narrow red bars near right edge
    local barW     = math.max(math.floor(4 * sc), 2)
    local barH     = math.floor(H * 0.58)
    local barGap   = math.max(math.floor(5 * sc), 3)
    local numBars  = 5
    local barsW    = numBars * barW + (numBars - 1) * barGap
    local barAreaX = X + W - math.floor(26 * sc)   -- anchor from right
    local barTopY  = Y + math.floor(H * 0.2)

    for i = 1, numBars do
        local pulse = 0.65 + math.sin(RealTime() * 3.5 + i * 0.65) * 0.35
        local rb    = CFG.colRedBar
        surface.SetDrawColor(rb.r, rb.g, rb.b, math.floor(A * pulse))
        local bx = barAreaX + (i - 1) * (barW + barGap)
        surface.DrawRect(bx, barTopY, barW, barH)
        -- bright tip at top
        surface.SetDrawColor(255, 120, 100, math.floor(A * pulse * 0.45))
        surface.DrawRect(bx, barTopY, barW, math.max(math.floor(2 * sc), 1))
    end

    -- Small circle to the left of bars (matches the dot in the reference)
    local dotCX = barAreaX - math.floor(9 * sc)
    local dotCY = Y + math.floor(H * 0.5)
    local dotR  = math.max(math.floor(3 * sc), 2)
    local dp    = 0.5 + math.sin(RealTime() * 5) * 0.5
    local rb2   = CFG.colRedBar
    surface.SetDrawColor(rb2.r, rb2.g, rb2.b, math.floor(A * dp))
    surface.DrawRect(dotCX - dotR, dotCY - dotR, dotR * 2, dotR * 2)

    -- ── Corner brackets ───────────────────────
    local cs = math.floor(10 * sc)
    DrawCorner(X+1,   Y+1,   cs, false, false, CA(CFG.colCorner, A))
    DrawCorner(X+W-2, Y+1,   cs, true,  false, CA(CFG.colCorner, A))
    DrawCorner(X+1,   Y+H-2, cs, false, true,  CA(CFG.colCorner, A))
    DrawCorner(X+W-2, Y+H-2, cs, true,  true,  CA(CFG.colCorner, A))

    -- ── Text area ─────────────────────────────
    local tX  = X + iW + math.floor(8 * sc)
    local tW  = (barAreaX - math.floor(14 * sc)) - tX
    local tY  = Y + math.floor(7 * sc)

    -- Sender name
    draw.SimpleText(
        current.name:upper(),
        CFG.fontName,
        tX, tY,
        CA(CFG.colName, A),
        TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP
    )

    -- Rank (right-aligned within text area)
    draw.SimpleText(
        current.rank:upper(),
        CFG.fontLabel,
        tX + tW, tY + math.floor(2 * sc),
        CA(CFG.colDim, math.floor(A * 0.8)),
        TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP
    )

    -- Separator under name
    local sepY = tY + math.floor(16 * sc)
    surface.SetDrawColor(bc2.r, bc2.g, bc2.b, math.floor(A * 0.45))
    surface.DrawLine(tX, sepY, tX + tW, sepY)

    -- Message text
    local msgY  = sepY + math.floor(5 * sc)
    local lineH = math.floor(15 * sc)
    local lines = WrapText(current.msg, CFG.fontMsg, tW)

    local flicker = 1
    if current.phase == "hold" then
        flicker = 0.93 + math.sin(RealTime() * 55) * 0.035
    end

    for i, ln in ipairs(lines) do
        local ly = msgY + (i - 1) * lineH
        if ly > Y + H - math.floor(14 * sc) then break end
        draw.SimpleText(
            ln, CFG.fontMsg, tX, ly,
            CA(CFG.colText, math.floor(A * flicker)),
            TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP
        )
    end

    -- Bottom-left label
    local btY = Y + H - math.floor(11 * sc)
    draw.SimpleText(
        "INCOMING TRANSMISSION",
        CFG.fontSmall,
        tX, btY,
        CA(CFG.colDim, math.floor(A * 0.5)),
        TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP
    )
end)

-- ──────────────────────────────────────────────
--  Cleanup
-- ──────────────────────────────────────────────
hook.Add("ShutDown", "SW_Comms_Cleanup", function()
    queue   = {}
    current = nil
end)
