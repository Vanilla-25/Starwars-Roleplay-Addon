# SW_Comms — Star Wars Roleplay Communications Add-on

A cinematic, holographic broadcast system for Garry's Mod Star Wars RP servers.

---

## 📁 Folder Structure

```
sw_comms/
├── addon.txt
├── lua/
│   └── autorun/
│       ├── client/
│       │   └── cl_comms.lua      ← Client-side holographic HUD
│       └── server/
│           └── sv_comms.lua      ← Server-side command handler
├── materials/
│   └── sw_comms/
│       ├── avatar.png            ← YOUR custom image here (see below)
│       ├── avatar.vmt            ← Material definition (see below)
│       └── avatar.vtf            ← Converted texture (see below)
└── sound/
    └── sw_comms/
        └── transmission.wav      ← Optional sound effect (see below)
```

---

## ⚙️ Installation

1. Copy the `sw_comms/` folder into your server's `addons/` directory:
   ```
   garrysmod/addons/sw_comms/
   ```
2. Restart your server or run `lua_openscript_cl` / `lua_openscript` to reload.

---

## 🖼️ Adding Your Custom Image (Avatar / Hologram)

The UI supports a custom image shown in the left panel of the comms overlay (like the screenshot you provided of the Clone Trooper helmet).

### Step 1 — Prepare your PNG
- Recommended size: **256×256** or **512×512** pixels (square)
- Save it as `avatar.png`

### Step 2 — Convert to VTF/VMT
Use [VTFEdit](https://nemstools.github.io/pages/VTFLib-Download.html) (free tool):
1. Open VTFEdit → **File → Import** → select `avatar.png`
2. Settings: Format = `DXT5`, check "Generate Mipmaps"
3. **File → Save As** → save as `materials/sw_comms/avatar.vtf`
4. Create a file `materials/sw_comms/avatar.vmt` with this content:

```
"UnlitGeneric"
{
    "$basetexture" "sw_comms/avatar"
    "$translucent" "1"
    "$vertexalpha"  "1"
    "$vertexcolor"  "1"
}
```

### Step 3 — Workshop / FastDL
Make sure both `.vtf` and `.vmt` are included in your FastDL or Workshop content pack so clients download them automatically.

---

## 🔊 Sound Effect

Place a `.wav` file at:
```
sound/sw_comms/transmission.wav
```

Recommended: a short radio beep / Imperial comms blip (~0.5–1 second).  
Good free sources: [freesound.org](https://freesound.org) (search "radio transmission beep").

If the file is missing, the add-on falls back to a built-in GMod button sound automatically.

---

## 💬 Commands

| Command | Description |
|---|---|
| `/broadcast <message>` | Send a holographic transmission to all players |
| `/comms <message>` | Alias for `/broadcast` |
| `sw_comms_broadcast <message>` | Console command version (admins) |

---

## ⚙️ Configuration

Edit the top of each file to customise behaviour:

### `sv_comms.lua` — Server Config
```lua
local COMMS_CONFIG = {
    cooldown     = 10,      -- Seconds between broadcasts per player
    maxLength    = 200,     -- Max message character length
    adminOnly    = false,   -- Set true to restrict to admins only
    logToConsole = true,    -- Log all broadcasts to server console
}
```

### `cl_comms.lua` — Visual Config
```lua
local CFG = {
    fadeInTime  = 0.4,   -- Fade in duration (seconds)
    holdTime    = 6.0,   -- How long the UI stays visible
    fadeOutTime = 0.8,   -- Fade out duration (seconds)

    -- Colours — change these to reskin the hologram
    colPrimary  = Color(0, 210, 255),   -- Main cyan
    colAlert    = Color(255, 60, 60),   -- Red pulsing bars

    -- Sound
    sound       = "sw_comms/transmission.wav",  -- false to disable
}
```

---

## 🎨 Colour Themes

Swap `colPrimary` / `colSecondary` in `cl_comms.lua` for alternate faction colours:

| Faction | Primary | Secondary |
|---|---|---|
| Republic / GAR | `0, 210, 255` | `0, 140, 200` |
| Empire / ISB | `200, 200, 200` | `120, 120, 150` |
| Sith / Dark Side | `200, 0, 0` | `140, 0, 0` |
| Mandalorian | `200, 140, 0` | `140, 90, 0` |

---

## 📝 Notes

- Transmissions queue — if multiple broadcasts happen quickly, they display one after another.
- The UI is positioned in the **bottom-left** corner by default. Adjust `marginX` / `marginY` in `cl_comms.lua`.
- Text auto-wraps to fit the panel width.
- The scanning line animation only plays during the **hold** phase.
- Compatible with DarkRP, StarfallEx, and most RP frameworks.

---

## 📜 License

Free to use and modify for your server. Credit appreciated but not required.
