--[[
    F2 Ticket System — Shared Config
    PLACEMENT: lua/autorun/f2_tickets_shared.lua
    Runs on both realms. Only config — no net, no vgui.
]]

F2TicketConfig = {
    Categories = {
        { id="support",  label="Support",  icon="⚙", color=Color(100,160,255) },
        { id="question", label="Question", icon="?", color=Color(200,160,32)  },
        { id="report",   label="Report",   icon="⚠", color=Color(220,75,75)   },
        { id="appeal",   label="Appeal",   icon="♦", color=Color(55,210,115)  },
        { id="other",    label="Other",    icon="◈", color=Color(105,115,135) },
    },
    MaxOpenPerPlayer  = 3,
    MaxMessageLength  = 500,
    MaxSubjectLength  = 80,
    SaveFile          = "f2_tickets.json",

    -- SLA: ticket goes amber after this many seconds without ANY admin response
    SLA_WarnSeconds   = 300,   -- 5 minutes → amber
    -- SLA: ticket goes red after this many seconds without ANY admin response
    SLA_DangerSeconds = 600,   -- 10 minutes → red

    -- Typing indicator: how long (seconds) to keep showing "X is typing…"
    TypingTimeout     = 4,
}

print("[F2 Tickets] Shared config loaded.")