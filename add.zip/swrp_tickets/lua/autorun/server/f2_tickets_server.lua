--[[
    F2 Ticket System — Server
    PLACEMENT: lua/autorun/server/f2_tickets_server.lua
]]

if CLIENT then return end

-- ─── NET STRINGS ─────────────────────────────────────────────────────────────
util.AddNetworkString("F2T_Submit")
util.AddNetworkString("F2T_AdminAction")
util.AddNetworkString("F2T_OpenForm")
util.AddNetworkString("F2T_SyncAll")
util.AddNetworkString("F2T_Push")
util.AddNetworkString("F2T_Alert")
util.AddNetworkString("F2T_RatingPrompt")
util.AddNetworkString("F2T_RatingSubmit")
util.AddNetworkString("F2T_Typing")
util.AddNetworkString("F2T_StatsRequest")
util.AddNetworkString("F2T_StatsResponse")
util.AddNetworkString("F2T_OnlineAdmins")

-- ─── STATE ───────────────────────────────────────────────────────────────────
local Tickets    = {}   -- [id] = ticket table
local NextID     = 1
local Dirty      = false
local BroughtPos = {}   -- [steamid] = Vector, for Bring/Return

-- ─── HELPERS ─────────────────────────────────────────────────────────────────
local function IsAdm(p) return IsValid(p) and (p:IsAdmin() or p:IsSuperAdmin()) end
local function NewID()  local id = NextID; NextID = NextID + 1; return id end
local function Now()    return os.time() end

-- ─── PERSISTENCE ─────────────────────────────────────────────────────────────
local function Save() Dirty = true end

timer.Create("F2T_Save", 5, 0, function()
    if not Dirty then return end
    Dirty = false
    local out = { __next = NextID }
    for id, t in pairs(Tickets) do
        local s = {}
        for k, v in pairs(t) do
            if k == "pos" then
                s[k] = v and { x=v.x, y=v.y, z=v.z } or nil
            elseif k == "watchers" then
                local arr = {}
                for nick in pairs(v) do arr[#arr+1] = nick end
                s[k] = arr
            else
                s[k] = v
            end
        end
        out[tostring(id)] = s
    end
    file.Write(F2TicketConfig.SaveFile, util.TableToJSON(out, true))
end)

local function Load()
    if not file.Exists(F2TicketConfig.SaveFile, "DATA") then return end
    local raw = file.Read(F2TicketConfig.SaveFile, "DATA")
    if not raw or raw == "" then return end
    local ok, data = pcall(util.JSONToTable, raw)
    if not ok or not data then return end
    if data.__next then NextID = data.__next; data.__next = nil end
    for k, t in pairs(data) do
        local id = tonumber(k)
        if id then
            if t.pos then t.pos = Vector(t.pos.x, t.pos.y, t.pos.z) end
            t.log = t.log or {}
            -- Normalise watchers: JSON saves them as an array, we need a hash-set.
            -- Also handles the edge case where the field is already a set.
            local w = t.watchers
            if type(w) == "table" then
                local set = {}
                for ki, v in pairs(w) do
                    if type(ki) == "number" and type(v) == "string" then
                        set[v] = true   -- array form {1="nick",...}
                    elseif type(ki) == "string" then
                        set[ki] = true  -- set form already
                    end
                end
                t.watchers = set
            else
                t.watchers = {}
            end
            Tickets[id] = t
        end
    end
    print("[F2 Tickets] Loaded " .. table.Count(Tickets) .. " tickets.")
end
Load()

-- ─── WRITE TICKET (server → client) ──────────────────────────────────────────
local function WriteTicket(t, forAdmin)
    net.WriteUInt(t.id,                16)
    net.WriteString(t.sid           or "")
    net.WriteString(t.name          or "")
    net.WriteString(t.cat           or "")
    net.WriteString(t.subj          or "")
    net.WriteString(t.body          or "")
    net.WriteString(t.status        or "open")
    net.WriteString(t.claim         or "")
    net.WriteString(t.pri           or "medium")
    net.WriteFloat(t.created        or 0)
    net.WriteFloat(t.first_response or 0)
    net.WriteUInt(t.rating          or 0, 4)
    net.WriteString(t.rating_comment or "")

    -- Watchers: comma-separated nicks string
    local w = t.watchers
    if w then
        local arr = {}
        for nick in pairs(w) do arr[#arr+1] = nick end
        net.WriteString(#arr > 0 and table.concat(arr, ",") or "")
    else
        net.WriteString("")
    end

    -- Log: newest 200 entries; notes stripped for non-admins
    local log = {}
    for _, m in ipairs(t.log) do
        if forAdmin or not m.note then log[#log+1] = m end
    end
    local s = #log > 200 and (#log - 199) or 1
    net.WriteUInt(#log - s + 1, 16)
    for i = s, #log do
        local m = log[i]
        net.WriteString(m.who  or "")
        net.WriteString(m.text or "")
        net.WriteFloat(m.time  or 0)
        net.WriteBool(m.admin  or false)
        net.WriteBool(m.note   or false)
    end
end

local function SysMsg(t, text)
    -- Cache Now() once so both fields get the same timestamp
    local now = Now()
    t.log[#t.log+1] = { who="SYSTEM", text=text, time=now, admin=false, note=false }
    t.updated = now
end

-- ─── BROADCAST ───────────────────────────────────────────────────────────────
local function GetTicketRecipients(t)
    local admins, owner = {}, nil
    for _, p in ipairs(player.GetAll()) do
        if IsAdm(p) then
            admins[#admins+1] = p
        elseif p:SteamID() == t.sid then
            owner = p
        end
    end
    return admins, owner
end

local function PushOne(t)
    local admins, owner = GetTicketRecipients(t)
    if #admins > 0 then
        net.Start("F2T_Push"); WriteTicket(t, true);  net.Send(admins)
    end
    if IsValid(owner) then
        net.Start("F2T_Push"); WriteTicket(t, false); net.Send(owner)
    end
end

local function SyncAllTo(ply)
    local isAdm = IsAdm(ply)
    local sid   = ply:SteamID()
    local list  = {}
    for _, t in pairs(Tickets) do
        if isAdm or t.sid == sid then list[#list+1] = t end
    end
    net.Start("F2T_SyncAll")
    net.WriteUInt(#list, 16)
    for _, t in ipairs(list) do WriteTicket(t, isAdm) end
    net.Send(ply)
end

-- ─── JOIN / LEAVE HOOKS ──────────────────────────────────────────────────────
hook.Add("PlayerInitialSpawn", "F2T_JoinSync", function(ply)
    timer.Simple(3, function()
        if IsValid(ply) then SyncAllTo(ply) end
    end)
end)

hook.Add("PlayerDisconnected", "F2T_Leave", function(ply)
    if IsValid(ply) then BroughtPos[ply:SteamID()] = nil end
end)

-- ─── SUBMIT TICKET ───────────────────────────────────────────────────────────
net.Receive("F2T_Submit", function(_, ply)
    if not IsValid(ply) then return end

    local cat  = net.ReadString()
    local pri  = net.ReadString()
    local subj = string.sub(net.ReadString(), 1, F2TicketConfig.MaxSubjectLength)
    local body = string.sub(net.ReadString(), 1, F2TicketConfig.MaxMessageLength)

    if subj == "" or body == "" then
        ply:ChatPrint("[Tickets] Please fill in subject and description."); return
    end

    local sid  = ply:SteamID()
    local open = 0
    for _, t in pairs(Tickets) do
        if t.sid == sid and t.status ~= "closed" then
            open = open + 1
            if open >= F2TicketConfig.MaxOpenPerPlayer then
                ply:ChatPrint("[Tickets] You already have " .. open .. " open ticket(s)."); return
            end
        end
    end

    local validPri = { low=true, medium=true, high=true, urgent=true }
    if not validPri[pri] then pri = "medium" end

    local now  = Now()
    local name = ply:Nick()
    local t = {
        id             = NewID(),
        sid            = sid,
        name           = name,
        cat            = cat,
        subj           = subj,
        body           = body,
        pri            = pri,
        status         = "open",
        claim          = "",
        created        = now,
        updated        = now,
        first_response = 0,
        rating         = 0,
        rating_comment = "",
        watchers       = {},
        log            = {},
    }
    Tickets[t.id] = t
    SysMsg(t, name .. " opened this ticket.")

    local admins = {}
    for _, p in ipairs(player.GetAll()) do
        if IsAdm(p) then admins[#admins+1] = p end
    end
    if #admins > 0 then
        net.Start("F2T_Alert")
        net.WriteUInt(t.id, 16)
        net.WriteString(name)
        net.WriteString(subj)
        net.WriteString(pri)
        net.Send(admins)
    end

    PushOne(t)
    Save()
    ply:ChatPrint("[Tickets] Ticket #" .. t.id .. " submitted!")
    print("[F2T] #" .. t.id .. " opened by " .. name .. " — " .. subj)
end)

-- ─── ADMIN ACTIONS ───────────────────────────────────────────────────────────
net.Receive("F2T_AdminAction", function(_, ply)
    local action = net.ReadString()
    local id     = net.ReadUInt(16)
    local extra  = net.ReadString()

    local t = Tickets[id]
    if not t then return end

    -- Cache once — admin status won't change mid-handler
    local isAdm = IsAdm(ply)

    -- ── claim ──────────────────────────────────────────────────────────────
    if action == "claim" then
        if not isAdm then return end
        local nick = ply:Nick()
        t.status = "claimed"; t.claim = nick
        t.watchers = t.watchers or {}; t.watchers[nick] = true
        SysMsg(t, nick .. " claimed this ticket.")
        local owner = player.GetBySteamID(t.sid)
        if IsValid(owner) then
            owner:ChatPrint("[Tickets] Your ticket #" .. id .. " was claimed by " .. nick .. ".")
        end

    -- ── unclaim ────────────────────────────────────────────────────────────
    elseif action == "unclaim" then
        if not isAdm then return end
        SysMsg(t, t.claim .. " unclaimed this ticket.")
        t.status = "open"; t.claim = ""

    -- ── close ──────────────────────────────────────────────────────────────
    elseif action == "close" then
        if not isAdm and t.sid ~= ply:SteamID() then return end
        t.status = "closed"
        SysMsg(t, ply:Nick() .. " closed this ticket.")
        local owner = player.GetBySteamID(t.sid)
        if IsValid(owner) and owner ~= ply then
            owner:ChatPrint("[Tickets] Your ticket #" .. id .. " was closed by " .. ply:Nick() .. ".")
            net.Start("F2T_RatingPrompt"); net.WriteUInt(id,16); net.WriteString(t.subj or ""); net.Send(owner)
        end

    -- ── reopen ─────────────────────────────────────────────────────────────
    elseif action == "reopen" then
        if not isAdm then return end
        t.status = "open"; t.claim = ""
        SysMsg(t, ply:Nick() .. " reopened this ticket.")

    -- ── chat ───────────────────────────────────────────────────────────────
    elseif action == "chat" then
        if extra == "" then return end
        local isOwner = t.sid == ply:SteamID()
        if not isAdm and not isOwner then return end
        if isOwner and not isAdm and t.status == "closed" then
            ply:ChatPrint("[Tickets] This ticket is closed."); return
        end
        extra = string.sub(extra, 1, F2TicketConfig.MaxMessageLength)
        local now = Now()
        if isAdm and (t.first_response or 0) == 0 then t.first_response = now end
        t.log[#t.log+1] = { who=ply:Nick(), text=extra, time=now, admin=isAdm, note=false }
        t.updated = now

    -- ── note ───────────────────────────────────────────────────────────────
    elseif action == "note" then
        if not isAdm or extra == "" then return end
        extra = string.sub(extra, 1, F2TicketConfig.MaxMessageLength)
        local now = Now()
        t.log[#t.log+1] = { who=ply:Nick(), text="[NOTE] "..extra, time=now, admin=true, note=true }
        t.updated = now

    -- ── goto ───────────────────────────────────────────────────────────────
    elseif action == "goto" then
        if not isAdm then return end
        local owner = player.GetBySteamID(t.sid)
        if not IsValid(owner) then ply:ChatPrint("[Tickets] Player is not online."); return end
        ply:SetPos(owner:GetPos() + owner:GetForward() * 60 + Vector(0,0,10))
        SysMsg(t, ply:Nick() .. " teleported to " .. owner:Nick() .. ".")

    -- ── bring ──────────────────────────────────────────────────────────────
    elseif action == "bring" then
        if not isAdm then return end
        local owner = player.GetBySteamID(t.sid)
        if not IsValid(owner) then ply:ChatPrint("[Tickets] Player is not online."); return end
        BroughtPos[t.sid] = owner:GetPos()
        owner:SetPos(ply:GetPos() + ply:GetForward() * 60 + Vector(0,0,10))
        owner:ChatPrint("[Tickets] You have been brought to " .. ply:Nick() .. " for ticket #" .. id .. ".")
        SysMsg(t, ply:Nick() .. " brought " .. owner:Nick() .. ".")

    -- ── return ─────────────────────────────────────────────────────────────
    elseif action == "return" then
        if not isAdm then return end
        local owner = player.GetBySteamID(t.sid)
        if not IsValid(owner) then ply:ChatPrint("[Tickets] Player is not online."); return end
        local savedPos = BroughtPos[t.sid]
        if not savedPos then ply:ChatPrint("[Tickets] No saved position (were they brought first?)."); return end
        owner:SetPos(savedPos)
        BroughtPos[t.sid] = nil
        owner:ChatPrint("[Tickets] You have been returned to your previous location.")
        SysMsg(t, ply:Nick() .. " returned " .. owner:Nick() .. ".")

    -- ── join_ticket ────────────────────────────────────────────────────────
    elseif action == "join_ticket" then
        if not isAdm then return end
        local nick = ply:Nick()
        t.watchers = t.watchers or {}
        if t.watchers[nick] then
            ply:ChatPrint("[Tickets] You are already watching ticket #" .. id .. "."); return
        end
        t.watchers[nick] = true
        SysMsg(t, nick .. " joined this ticket.")

    -- ── leave_ticket ───────────────────────────────────────────────────────
    elseif action == "leave_ticket" then
        if not isAdm then return end
        t.watchers = t.watchers or {}
        t.watchers[ply:Nick()] = nil
        SysMsg(t, ply:Nick() .. " left this ticket.")

    -- ── transfer ───────────────────────────────────────────────────────────
    elseif action == "transfer" then
        if not isAdm or extra == "" then return end
        local target
        for _, p in ipairs(player.GetAll()) do
            if IsAdm(p) and p:Nick() == extra then target = p; break end
        end
        if not IsValid(target) then
            ply:ChatPrint("[Tickets] Admin '" .. extra .. "' is not online."); return
        end
        local tgtNick = target:Nick()
        t.claim = tgtNick; t.status = "claimed"
        t.watchers = t.watchers or {}; t.watchers[tgtNick] = true
        SysMsg(t, ply:Nick() .. " transferred ticket to " .. tgtNick .. ".")
        target:ChatPrint("[Tickets] Ticket #" .. id .. " transferred to you by " .. ply:Nick() .. ".")
        local owner = player.GetBySteamID(t.sid)
        if IsValid(owner) then
            owner:ChatPrint("[Tickets] Your ticket #" .. id .. " is now handled by " .. tgtNick .. ".")
        end

    else
        return  -- unknown action — do NOT call PushOne/Save
    end

    PushOne(t)
    Save()
end)

-- ─── RATING SUBMISSION ───────────────────────────────────────────────────────
net.Receive("F2T_RatingSubmit", function(_, ply)
    if not IsValid(ply) then return end
    local id      = net.ReadUInt(16)
    local stars   = net.ReadUInt(4)
    local comment = string.sub(net.ReadString(), 1, 200)
    local t = Tickets[id]
    if not t or t.sid ~= ply:SteamID() then return end
    if (t.rating or 0) ~= 0 then return end  -- already rated; also guards nil
    stars = math.Clamp(stars, 1, 5)
    t.rating         = stars
    t.rating_comment = comment
    SysMsg(t, ply:Nick() .. " rated this ticket " .. stars .. "/5"
        .. (comment ~= "" and (' — "' .. comment .. '"') or "") .. ".")
    PushOne(t)
    Save()
    ply:ChatPrint("[Tickets] Thanks for your feedback!")
end)

-- ─── TYPING INDICATOR ────────────────────────────────────────────────────────
net.Receive("F2T_Typing", function(_, ply)
    if not IsValid(ply) then return end
    local id     = net.ReadUInt(16)
    local typing = net.ReadBool()
    local t = Tickets[id]
    if not t then return end
    local isAdm   = IsAdm(ply)
    local isOwner = t.sid == ply:SteamID()
    if not isAdm and not isOwner then return end

    local recipients = {}
    for _, p in ipairs(player.GetAll()) do
        if p ~= ply and (IsAdm(p) or p:SteamID() == t.sid) then
            recipients[#recipients+1] = p
        end
    end
    if #recipients == 0 then return end
    net.Start("F2T_Typing")
    net.WriteUInt(id, 16)
    net.WriteString(ply:Nick())
    net.WriteBool(typing)
    net.Send(recipients)
end)

-- ─── ADMIN STATS ─────────────────────────────────────────────────────────────
net.Receive("F2T_StatsRequest", function(_, ply)
    if not IsAdm(ply) then return end

    local adminStats = {}
    local totalOpen, totalClaimed, totalClosed = 0, 0, 0
    local totalRated, ratingSum = 0, 0
    local perDay   = {}
    local cutoff14 = Now() - 14 * 86400   -- only show last 14 days in chart

    for _, t in pairs(Tickets) do
        local st = t.status
        if     st == "open"    then totalOpen    = totalOpen    + 1
        elseif st == "claimed" then totalClaimed = totalClaimed + 1
        elseif st == "closed"  then totalClosed  = totalClosed  + 1
        end

        local r = t.rating or 0
        if r > 0 then totalRated = totalRated + 1; ratingSum = ratingSum + r end

        -- Per-admin stats: detect "X closed this ticket." SYSTEM messages
        for _, m in ipairs(t.log or {}) do
            if m.who == "SYSTEM" then
                local nick = string.match(m.text, "^(.+) closed this ticket")
                if nick then
                    local as = adminStats[nick]
                    if not as then
                        as = {closed=0,respTime=0,respCount=0,rating=0,ratingCount=0}
                        adminStats[nick] = as
                    end
                    as.closed = as.closed + 1
                    if (t.first_response or 0) > 0 and (t.created or 0) > 0 then
                        as.respTime  = as.respTime  + (t.first_response - t.created)
                        as.respCount = as.respCount + 1
                    end
                    if r > 0 then
                        as.rating      = as.rating      + r
                        as.ratingCount = as.ratingCount + 1
                    end
                end
            end
        end

        -- Per-day (last 14 days only to bound the array)
        local created = t.created or 0
        if created >= cutoff14 then
            local day = os.date("%Y-%m-%d", created)
            perDay[day] = (perDay[day] or 0) + 1
        end
    end

    local adminArr = {}
    for nick, s in pairs(adminStats) do
        adminArr[#adminArr+1] = {
            nick      = nick,
            closed    = s.closed,
            avgResp   = s.respCount   > 0 and math.floor(s.respTime / s.respCount)             or 0,
            avgRating = s.ratingCount > 0 and math.floor((s.rating / s.ratingCount) * 10) / 10 or 0,
        }
    end
    table.sort(adminArr, function(a,b) return a.closed > b.closed end)

    local perDayArr = {}
    for day, count in pairs(perDay) do perDayArr[#perDayArr+1] = {day=day,count=count} end
    table.sort(perDayArr, function(a,b) return a.day < b.day end)

    net.Start("F2T_StatsResponse")
    net.WriteString(util.TableToJSON({
        totalOpen    = totalOpen,
        totalClaimed = totalClaimed,
        totalClosed  = totalClosed,
        totalRated   = totalRated,
        avgRating    = totalRated > 0 and math.floor((ratingSum / totalRated) * 10) / 10 or 0,
        admins       = adminArr,
        perDay       = perDayArr,
    }))
    net.Send(ply)
end)

-- ─── ONLINE ADMINS ───────────────────────────────────────────────────────────
net.Receive("F2T_OnlineAdmins", function(_, ply)
    if not IsAdm(ply) then return end
    local nicks = {}
    for _, p in ipairs(player.GetAll()) do
        if IsAdm(p) and p ~= ply then nicks[#nicks+1] = p:Nick() end
    end
    net.Start("F2T_OnlineAdmins")
    net.WriteUInt(#nicks, 8)
    for _, n in ipairs(nicks) do net.WriteString(n) end
    net.Send(ply)
end)

-- ─── FULL SYNC REQUEST ───────────────────────────────────────────────────────
net.Receive("F2T_SyncAll", function(_, ply) SyncAllTo(ply) end)

-- ─── !TICKET CHAT COMMAND ────────────────────────────────────────────────────
hook.Add("PlayerSay", "F2T_TicketCmd", function(ply, text)
    local sub = string.match(text, "^!ticket%s*(.*)")
    if not sub then return end
    net.Start("F2T_OpenForm")
    net.WriteString(string.sub(sub, 1, F2TicketConfig.MaxSubjectLength))
    net.Send(ply)
    return ""
end)

print("[F2 Tickets] Server loaded.")