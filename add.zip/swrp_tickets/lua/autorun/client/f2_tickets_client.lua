--[[
    F2 Ticket System — Client
    PLACEMENT: lua/autorun/client/f2_tickets_client.lua

    Features:
      • F6            — players: open form  |  admins: toggle manager
      • !ticket       — open form (subject prefilled from text after command)
      • REQUEST ADMIN — F2 slot menu calls _G.F2Ticket_OpenForm()
      • Player HUD    — your open tickets shown top-left
      • Admin HUD     — pulsing alert when unclaimed tickets exist
      • Admin panel   — search bar, stats bar, unread badges, age timer,
                        quick-reply templates, claim timer, player info header,
                        note vs chat toggle, goto player button
      • Player popup  — floating chat bubble when admin replies, with typing indicator
      • Notifications — routed through F2Notify if loaded, else own renderer
      • Ticket history tab  — per-player closed ticket history
      • Admin stats page    — closed/response time/avg rating per admin + per-day chart
      • SLA timer           — how long since creation with no admin response (amber/red)
      • Ticket rating       — 1–5 star prompt on close, shown in detail header
      • Typing indicator    — "X is typing…" shown in chat log area
      • Ticket transfer     — assign claimed ticket to another online admin
      • Join / Leave ticket — any admin can join or leave as a watcher
      • Bring / Return      — bring owner to you, return them when done
]]

if SERVER then return end

-- ─── THEME ───────────────────────────────────────────────────────────────────
local T = {
    Bg      = Color(12,  14,  18),
    Panel   = Color(18,  21,  27),
    Panel2  = Color(23,  27,  34),
    Card    = Color(28,  33,  42),
    CardSel = Color(32,  44,  64),
    Border  = Color(42,  52,  68),
    Text    = Color(218, 224, 235),
    Dim     = Color(105, 120, 145),
    Faint   = Color(60,  74,  92),
    Green   = Color(55,  210, 115),
    Danger  = Color(220, 75,  75),
    Blue    = Color(100, 160, 255),
    Amber   = Color(220, 175, 40),
    Purple  = Color(160, 110, 255),
    Teal    = Color(40,  200, 185),
}

-- Shorthand draw helpers
local function FA(c,a)               return ColorAlpha(c,a) end
local function RR(r,x,y,w,h,c)      draw.RoundedBox(r,x,y,w,h,c) end
local function Rect(x,y,w,h,c)      draw.RoundedBox(0,x,y,w,h,c) end
local function Bord(x,y,w,h,c)      surface.SetDrawColor(c); surface.DrawOutlinedRect(x,y,w,h,1) end
local function Txt(t,f,x,y,c,ax,ay) draw.SimpleText(t,f,x,y,c,ax or 0,ay or 0) end
local function Accent()              return _G.F2SlotAccentColor and _G.F2SlotAccentColor() or Color(220,160,32) end

-- ─── FONTS ───────────────────────────────────────────────────────────────────
local function MakeFonts()
    surface.CreateFont("TK_Title", {font="Roboto",size=15,weight=800})
    surface.CreateFont("TK_Label", {font="Roboto",size=11,weight=700})
    surface.CreateFont("TK_Body",  {font="Roboto",size=11,weight=400})
    surface.CreateFont("TK_Small", {font="Roboto",size=10,weight=600})
    surface.CreateFont("TK_Tiny",  {font="Roboto",size=9, weight=400})
    surface.CreateFont("TK_Bold",  {font="Roboto",size=10,weight=700})
    surface.CreateFont("TK_ID",    {font="Roboto",size=11,weight=800})
    surface.CreateFont("TK_Big",   {font="Roboto",size=22,weight=800})
    surface.CreateFont("TK_Stats", {font="Roboto",size=18,weight=800})
end
MakeFonts()
hook.Add("Initialize",          "F2T_Fonts", MakeFonts)
hook.Add("OnScreenSizeChanged", "F2T_Fonts", MakeFonts)

-- ─── LOOKUP TABLES ───────────────────────────────────────────────────────────
local PRI = {
    {id="low",    label="Low",    col=Color(105,120,145)},
    {id="medium", label="Medium", col=Color(100,160,255)},
    {id="high",   label="High",   col=Color(220,160,32) },
    {id="urgent", label="Urgent", col=Color(220,75,75)  },
}
-- Fast lookup maps built once
local PRI_MAP = {}
for _, p in ipairs(PRI) do PRI_MAP[p.id] = p end

local CAT_MAP = {}  -- rebuilt when F2TicketConfig is available
local function RefreshCatMap()
    CAT_MAP = {}
    if F2TicketConfig then
        for _, c in ipairs(F2TicketConfig.Categories) do CAT_MAP[c.id] = c end
    end
end
RefreshCatMap()
hook.Add("Initialize", "F2T_CatMap", RefreshCatMap)

local function GetPri(id) return PRI_MAP[id] or PRI[2] end
local function GetCat(id)
    return CAT_MAP[id] or {id=id, label=id, icon="?", color=T.Dim}
end
local function StatusCol(s)
    if s == "open"    then return T.Green end
    if s == "claimed" then return T.Blue  end
    return T.Dim
end

-- ─── QUICK-REPLY TEMPLATES ───────────────────────────────────────────────────
local TEMPLATES = {
    "Please wait — looking into this now.",
    "Could you provide more details?",
    "This has been resolved. Please let us know if the issue persists.",
    "Please contact a senior admin for this issue.",
    "We cannot assist with this request.",
    "Your ticket has been noted. We will follow up shortly.",
}

-- ─── STATE ───────────────────────────────────────────────────────────────────
local Tickets      = {}
local AdminPanel   = nil
local TicketForm   = nil
local PlayerPopup  = nil
local LastSeen     = {}   -- [id] = log count when last viewed
local TypingState  = {}   -- [ticketID] = { who=string, expires=CurTime() }
local OnlineAdmins = {}   -- cache for transfer dropdown

-- ─── TIME FORMATTING ─────────────────────────────────────────────────────────
local function FmtAge(ts)
    if not ts or ts == 0 then return "?" end
    local s = os.time() - ts
    if s < 60    then return s .. "s" end
    if s < 3600  then return math.floor(s/60) .. "m" end
    if s < 86400 then return math.floor(s/3600) .. "h" end
    return math.floor(s/86400) .. "d"
end
local function FmtTime(ts)
    if not ts or ts == 0 then return "" end
    return os.date("%H:%M", ts)
end
local function FmtSecs(s)
    if s < 60   then return s .. "s" end
    if s < 3600 then return math.floor(s/60) .. "m " .. (s%60) .. "s" end
    return math.floor(s/3600) .. "h " .. math.floor((s%3600)/60) .. "m"
end

-- ─── SLA ─────────────────────────────────────────────────────────────────────
local function SLAInfo(t)
    if t.status == "closed" then return nil, nil end
    local fr = t.first_response or 0
    if fr > 0 then
        return T.Green, "Responded in " .. FmtSecs(fr - (t.created or fr))
    end
    local cfg    = F2TicketConfig or {}
    local warn   = cfg.SLA_WarnSeconds   or 300
    local danger = cfg.SLA_DangerSeconds or 600
    local waited = os.time() - (t.created or os.time())
    local age    = FmtAge(t.created)   -- compute once, reuse in label
    if waited >= danger then return T.Danger, "No response for " .. age end
    if waited >= warn   then return T.Amber,  "Waiting " .. age end
    return T.Dim, "Waiting " .. age
end

-- ─── NOTIFICATION SYSTEM ─────────────────────────────────────────────────────
local _nstack = {}
-- Notification type → Color (plain values, not functions)
local _ntypeCol = { [0]=nil, [1]=T.Green, [2]=T.Amber, [3]=T.Danger, [4]=T.Blue }

local function Notify(msg, sub, ntype)
    ntype = ntype or 0
    if _G.F2Notify then _G.F2Notify.Push(msg, sub or "", ntype); return end
    _nstack[#_nstack+1] = {msg=msg, sub=sub or "", ntype=ntype, born=CurTime()}
    while #_nstack > 5 do table.remove(_nstack, 1) end
    surface.PlaySound("buttons/button15.wav")
end

hook.Add("HUDPaint", "F2T_Notify", function()
    if _G.F2Notify then _nstack = {}; return end
    if #_nstack == 0 then return end
    local sw, sh, now = ScrW(), ScrH(), CurTime()
    local NW, LIFE, FADE = 300, 5, 0.4
    local y = sh - 80
    for i = #_nstack, 1, -1 do
        local n   = _nstack[i]
        local age = now - n.born
        if age > LIFE + FADE then table.remove(_nstack, i); goto cont end
        local hasSub = n.sub ~= ""
        local h   = hasSub and 64 or 50
        y = y - h - 4
        local al  = age > LIFE and math.Round(255 * (1-(age-LIFE)/FADE)) or 255
        local ac  = _ntypeCol[n.ntype] or Accent()
        RR(5, sw-NW-14, y, NW, h, FA(T.Card,al))
        surface.SetDrawColor(FA(ac,al)); surface.DrawRect(sw-NW-14,y,3,h)
        Bord(sw-NW-14, y, NW, h, FA(T.Border, math.Round(al*0.8)))
        local frac = math.Clamp(1-age/LIFE, 0, 1)
        surface.SetDrawColor(FA(ac, math.Round(al*0.5)))
        surface.DrawRect(sw-NW-11, y+h-2, math.Round((NW-3)*frac), 2)
        local ty = hasSub and (y+13) or (y+h/2)
        Txt(n.msg, "TK_Label", sw-NW-2, ty, FA(T.Text,al), 0, 1)
        if hasSub then Txt(n.sub, "TK_Tiny", sw-NW-2, y+29, FA(T.Dim, math.Round(al*0.85)), 0, 1) end
        ::cont::
    end
end)

-- ─── READ TICKET FROM NET ────────────────────────────────────────────────────
local function ReadTicket()
    local t = {}
    t.id             = net.ReadUInt(16)
    t.sid            = net.ReadString()
    t.name           = net.ReadString()
    t.cat            = net.ReadString()
    t.subj           = net.ReadString()
    t.body           = net.ReadString()
    t.status         = net.ReadString()
    t.claim          = net.ReadString()
    t.pri            = net.ReadString()
    t.created        = net.ReadFloat()
    t.first_response = net.ReadFloat()
    t.rating         = net.ReadUInt(4)
    t.rating_comment = net.ReadString()

    -- Watchers: comma-separated → hash-set
    local ws = net.ReadString()
    t.watchers = {}
    if ws ~= "" then
        for nick in string.gmatch(ws, "[^,]+") do t.watchers[nick] = true end
    end

    -- Log entries
    t.log = {}
    local lc = net.ReadUInt(16)
    for _ = 1, lc do
        t.log[#t.log+1] = {
            who   = net.ReadString(),
            text  = net.ReadString(),
            time  = net.ReadFloat(),
            admin = net.ReadBool(),
            note  = net.ReadBool(),
        }
    end
    return t
end

-- ─── NET RECEIVERS ───────────────────────────────────────────────────────────
net.Receive("F2T_SyncAll", function()
    Tickets = {}
    local count = net.ReadUInt(16)
    for _ = 1, count do
        local t = ReadTicket(); Tickets[t.id] = t
    end
    if IsValid(AdminPanel) then AdminPanel:Refresh() end
end)

net.Receive("F2T_Push", function()
    local t    = ReadTicket()
    local prev = Tickets[t.id]
    Tickets[t.id] = t

    -- Show popup to ticket owner when an admin sends a new message
    local ply = LocalPlayer()
    if IsValid(ply) and t.sid == ply:SteamID()
    and not ply:IsAdmin() and not ply:IsSuperAdmin() then
        local prevLog = prev and #prev.log or 0
        for i = prevLog+1, #t.log do
            local m = t.log[i]
            if m.who ~= "SYSTEM" and m.admin then
                OpenPlayerPopup(t, m); break
            end
        end
    end
    if IsValid(AdminPanel) then AdminPanel:Refresh() end
end)

net.Receive("F2T_Alert", function()
    local id  = net.ReadUInt(16)
    local nm  = net.ReadString()
    local sub = net.ReadString()
    local pri = net.ReadString()
    local nt  = ({low=0,medium=0,high=2,urgent=3})[pri] or 0
    Notify("NEW TICKET #"..id.." ["..string.upper(pri).."]", nm..": "..string.sub(sub,1,38), nt)
    if IsValid(AdminPanel) then AdminPanel:Refresh() end
end)

net.Receive("F2T_OpenForm", function()
    local pre = net.ReadString()
    OpenTicketForm(pre ~= "" and pre or nil)
end)

net.Receive("F2T_Typing", function()
    local id     = net.ReadUInt(16)
    local who    = net.ReadString()
    local typing = net.ReadBool()
    if typing then
        TypingState[id] = { who=who, expires=CurTime() + (F2TicketConfig and F2TicketConfig.TypingTimeout or 4) }
    else
        TypingState[id] = nil
    end
    -- Nudge any open UI that cares about this ticket
    if IsValid(PlayerPopup) then PlayerPopup:InvalidateLayout() end
    if IsValid(AdminPanel)  then AdminPanel:Refresh() end
end)

net.Receive("F2T_OnlineAdmins", function()
    OnlineAdmins = {}
    local n = net.ReadUInt(8)
    for _ = 1, n do OnlineAdmins[#OnlineAdmins+1] = net.ReadString() end
end)

net.Receive("F2T_RatingPrompt", function()
    OpenRatingPrompt(net.ReadUInt(16), net.ReadString())
end)

net.Receive("F2T_StatsResponse", function()
    local raw    = net.ReadString()
    local ok, data = pcall(util.JSONToTable, raw)
    if ok and data and IsValid(AdminPanel) and AdminPanel.ShowStats then
        AdminPanel:ShowStats(data)
    end
end)

-- ─── HELPERS ─────────────────────────────────────────────────────────────────
local function IsAdm()
    local p = LocalPlayer()
    return IsValid(p) and (p:IsAdmin() or p:IsSuperAdmin())
end

local function MakeBtn(parent, label, x, y, w, h, acFn, onClick)
    local btn = vgui.Create("DButton", parent)
    btn:SetSize(w, h); btn:SetPos(x, y); btn:SetText("")
    local hov, lt = 0, CurTime()
    btn.Think = function(s)
        local dt = CurTime()-lt; lt = CurTime()
        hov = math.Approach(hov, s:IsHovered() and 1 or 0, dt*14)
    end
    btn.Paint = function(s, bw, bh)
        local ac = acFn()
        RR(4, 0, 0, bw, bh, FA(ac, math.Round(Lerp(hov,20,60))))
        Bord(0, 0, bw, bh, FA(ac, math.Round(Lerp(hov,80,220))))
        Txt(label, "TK_Label", bw/2, bh/2, FA(T.Text, math.Round(Lerp(hov,200,255))), 1, 1)
    end
    btn.DoClick = onClick
    return btn
end

local function MakeEntry(parent, x, y, w, h, placeholder, multiline)
    local e = vgui.Create("DTextEntry", parent)
    e:SetSize(w, h); e:SetPos(x, y)
    e:SetFont("TK_Body")
    e:SetPlaceholderText(placeholder or "")
    if multiline then e:SetMultiline(true) end
    e.Paint = function(self, ew, eh)
        RR(4, 0, 0, ew, eh, T.Card)
        Bord(0, 0, ew, eh, FA(self:IsEditing() and Accent() or T.Border, self:IsEditing() and 160 or 70))
        self:DrawTextEntryText(T.Text, FA(Accent(),120), T.Text)
        if self:GetValue() == "" then
            Txt(self:GetPlaceholderText(), "TK_Body", 8, eh/2, FA(T.Dim,110), 0, 1)
        end
    end
    return e
end

-- ─── RATING PROMPT ───────────────────────────────────────────────────────────
function OpenRatingPrompt(ticketID, subj)
    local sw, sh = ScrW(), ScrH()
    local RW, RH = 360, 220
    local frame  = vgui.Create("DFrame")
    frame:SetSize(RW, RH); frame:SetPos((sw-RW)/2, (sh-RH)/2)
    frame:SetTitle(""); frame:SetDraggable(true); frame:ShowCloseButton(false)
    frame:MakePopup()

    local fadeT = CurTime()
    frame.Paint = function(self, w, h)
        local al = math.min(255, math.Round((CurTime()-fadeT)/0.15*255))
        RR(6,0,0,w,h, FA(T.Bg,al))
        Bord(0,0,w,h, FA(T.Border, math.Round(al*0.8)))
        surface.SetDrawColor(FA(Accent(),al)); surface.DrawRect(0,0,w,2)
        Rect(0,0,w,40, FA(T.Panel,al))
        Txt("RATE YOUR EXPERIENCE","TK_Title",14,20,FA(T.Text,al),0,1)
        Txt("Ticket: "..string.sub(subj or "",1,36),"TK_Tiny",14,34,FA(T.Dim,al))
    end

    local selStars = 0
    local starY    = 52
    local starX    = RW/2 - 5*9   -- centre 5 × 18px buttons

    for i = 1, 5 do
        local idx = i
        local btn = vgui.Create("DButton", frame)
        btn:SetSize(18,18); btn:SetPos(starX+(idx-1)*20, starY); btn:SetText("")
        btn.Paint = function(self, w, h)
            local filled = idx <= selStars
            local hov    = self:IsHovered()
            Txt(filled and "★" or "☆", "TK_Label", w/2, h/2,
                FA(filled and T.Amber or (hov and T.Amber or T.Faint), filled and 230 or (hov and 180 or 100)), 1, 1)
        end
        btn.DoClick = function() selStars = idx end
    end

    local starLabels = {"","Poor","Fair","Good","Great","Excellent"}
    local sLbl = vgui.Create("DLabel", frame)
    sLbl:SetPos(0, starY+22); sLbl:SetSize(RW, 14)
    sLbl:SetFont("TK_Tiny"); sLbl:SetContentAlignment(5)
    local _prevStars = -1
    sLbl.Think = function(self)
        if selStars ~= _prevStars then
            _prevStars = selStars
            self:SetText(starLabels[selStars+1] or "")
            self:SetTextColor(FA(T.Amber,200))
        end
    end

    local commentEntry = MakeEntry(frame, 10, starY+42, RW-20, 30, "Optional comment…")

    MakeBtn(frame, "SKIP",   10,        RH-44, RW/2-14, 34, function() return T.Faint end, function()
        frame:Remove()
    end)
    MakeBtn(frame, "SUBMIT", RW/2+4,    RH-44, RW/2-14, 34, Accent, function()
        if selStars == 0 then Notify("Please select a star rating.","",3); return end
        net.Start("F2T_RatingSubmit")
        net.WriteUInt(ticketID, 16)
        net.WriteUInt(selStars, 4)
        net.WriteString(string.sub(string.Trim(commentEntry:GetValue()), 1, 200))
        net.SendToServer()
        frame:Remove()
        Notify("Thanks for your feedback!","",1)
    end)
end

-- ─── PLAYER REPLY POPUP ──────────────────────────────────────────────────────
function OpenPlayerPopup(t, latestMsg)
    if IsValid(PlayerPopup) then PlayerPopup:Remove() end

    local sw, sh = ScrW(), ScrH()
    local PW, PH = 360, 280
    local frame  = vgui.Create("DFrame")
    frame:SetSize(PW, PH); frame:SetPos(sw-PW-20, sh-PH-80)
    frame:SetTitle(""); frame:SetDraggable(true); frame:ShowCloseButton(false)
    frame:MakePopup()
    PlayerPopup = frame

    Notify("Admin replied to your ticket #"..t.id, latestMsg.who..": "..string.sub(latestMsg.text,1,40), 0)

    local fadeT = CurTime()
    local sc    = StatusCol(t.status)
    frame.Paint = function(self, w, h)
        local al = math.min(255, math.Round((CurTime()-fadeT)/0.12*255))
        RR(6,0,0,w,h, FA(T.Bg,al))
        Bord(0,0,w,h, FA(T.Border, math.Round(al*0.8)))
        surface.SetDrawColor(FA(Accent(),al)); surface.DrawRect(0,0,w,2)
        Rect(0,0,w,38, FA(T.Panel,al))
        surface.SetDrawColor(FA(T.Border, math.Round(al*0.4))); surface.DrawLine(0,38,w,38)
        Txt("YOUR TICKET #"..t.id, "TK_Label",12,19, FA(T.Text,al), 0,1)
        Txt(string.upper(t.status)..(t.claim ~= "" and "  ·  "..t.claim or ""),
            "TK_Tiny", w-10, 19, FA(sc,al), 2, 1)
    end

    local xBtn = vgui.Create("DButton", frame)
    xBtn:SetSize(26,26); xBtn:SetPos(PW-32,6); xBtn:SetText("")
    xBtn.Paint    = function(self,w,h)
        if self:IsHovered() then RR(4,0,0,w,h,FA(T.Danger,60)) end
        Txt("✕","TK_Small",w/2,h/2,FA(self:IsHovered() and T.Danger or T.Dim,200),1,1)
    end
    xBtn.DoClick  = function() frame:Remove() end

    local logScroll = vgui.Create("DScrollPanel", frame)
    logScroll:SetPos(6,44); logScroll:SetSize(PW-12, PH-104)
    logScroll:GetVBar():SetWide(3)
    logScroll.Paint = function(self,w,h) RR(3,0,0,w,h,FA(T.Card,120)) end

    local cv = logScroll:GetCanvas()
    local ly = 4
    for _, m in ipairs(t.log) do
        if m.who ~= "SYSTEM" then
            local lbl = vgui.Create("DLabel", cv)
            lbl:SetPos(6, ly); lbl:SetSize(PW-28, 14)
            lbl:SetFont("TK_Tiny")
            lbl:SetTextColor(m.admin and FA(T.Blue,230) or T.Text)
            lbl:SetText(FmtTime(m.time).."  ["..m.who.."]  "..m.text)
            lbl:SetWrap(true); lbl:SetAutoStretchVertical(true)
            lbl:SizeToContents()
            ly = ly + lbl:GetTall() + 2  -- BUG FIX: use actual label height, not flat 16
        end
    end
    cv:SetTall(ly + 4)

    -- Typing indicator
    local typingLbl = vgui.Create("DLabel", frame)
    typingLbl:SetPos(8, PH-66); typingLbl:SetSize(PW-16, 12)
    typingLbl:SetFont("TK_Tiny")
    local _lastTypingTxt = ""
    typingLbl.Think = function(self)
        local ts  = TypingState[t.id]
        local txt = (ts and CurTime() < ts.expires) and (ts.who .. " is typing…") or ""
        if txt ~= _lastTypingTxt then
            _lastTypingTxt = txt
            self:SetText(txt)
            self:SetTextColor(FA(T.Dim,180))
            if txt == "" and ts then TypingState[t.id] = nil end
        end
    end

    local replyEntry = MakeEntry(frame, 6, PH-50, PW-62, 34, "Reply to admin...")
    local _lastTyping = false
    replyEntry.OnChange = function(self)
        local has = self:GetValue() ~= ""
        if has ~= _lastTyping then
            _lastTyping = has
            net.Start("F2T_Typing"); net.WriteUInt(t.id,16); net.WriteBool(has); net.SendToServer()
        end
    end

    local function SendReply()
        local msg = string.Trim(replyEntry:GetValue())
        if msg == "" then return end
        net.Start("F2T_AdminAction"); net.WriteString("chat")
        net.WriteUInt(t.id,16); net.WriteString(msg); net.SendToServer()
        net.Start("F2T_Typing"); net.WriteUInt(t.id,16); net.WriteBool(false); net.SendToServer()
        replyEntry:SetValue(""); _lastTyping = false
    end
    replyEntry.OnEnter = function() SendReply() end
    MakeBtn(frame, "SEND", PW-52, PH-50, 46, 34, Accent, SendReply)
end

-- ─── TICKET SUBMISSION FORM ──────────────────────────────────────────────────
function OpenTicketForm(prefill)
    if IsValid(TicketForm) then TicketForm:Remove() end

    local sw, sh = ScrW(), ScrH()
    local FW, FH = 480, 460
    local frame  = vgui.Create("DFrame")
    frame:SetSize(FW, FH); frame:SetPos((sw-FW)/2, (sh-FH)/2)
    frame:SetTitle(""); frame:SetDraggable(true); frame:ShowCloseButton(false)
    frame:MakePopup()
    TicketForm = frame

    local fadeT = CurTime()
    frame.Paint = function(self, w, h)
        local al = math.min(255, math.Round((CurTime()-fadeT)/0.15*255))
        RR(6,0,0,w,h, FA(T.Bg,al))
        Bord(0,0,w,h, FA(T.Border, math.Round(al*0.8)))
        surface.SetDrawColor(FA(Accent(),al)); surface.DrawRect(0,0,w,2)
        Rect(0,0,w,44, FA(T.Panel,al))
        surface.SetDrawColor(FA(T.Border, math.Round(al*0.4))); surface.DrawLine(0,44,w,44)
        Txt("REQUEST ADMIN","TK_Title",16,22,FA(T.Text,al),0,1)
        Txt("Fill in the form below and click Submit.","TK_Tiny",16,35,FA(T.Dim,al))
    end

    local xBtn = vgui.Create("DButton", frame)
    xBtn:SetSize(30,30); xBtn:SetPos(FW-38,7); xBtn:SetText("")
    xBtn.Paint   = function(self,w,h)
        if self:IsHovered() then RR(4,0,0,w,h,FA(T.Danger,60)) end
        Txt("✕","TK_Label",w/2,h/2,FA(self:IsHovered() and T.Danger or T.Dim,200),1,1)
    end
    xBtn.DoClick = function() frame:Remove() end

    local Y, PAD = 54, 14
    local function Lbl(text, y)
        local l = vgui.Create("DLabel", frame)
        l:SetPos(PAD, y); l:SetSize(FW-PAD*2, 14)
        l:SetFont("TK_Bold"); l:SetTextColor(FA(T.Dim,200)); l:SetText(text)
    end

    -- Category buttons
    Lbl("CATEGORY", Y); Y = Y + 16
    local selCat = F2TicketConfig and F2TicketConfig.Categories[1].id or "support"
    local cats   = F2TicketConfig and F2TicketConfig.Categories or {}
    local catW   = math.floor((FW-PAD*2-(#cats-1)*5) / math.max(#cats,1))
    for i, cat in ipairs(cats) do
        local c  = cat
        local bx = PAD + (i-1)*(catW+5)
        local btn = vgui.Create("DButton", frame)
        btn:SetSize(catW,30); btn:SetPos(bx,Y); btn:SetText("")
        local hov, lt = 0, CurTime()
        btn.Think = function(s)
            local dt = CurTime()-lt; lt = CurTime()
            hov = math.Approach(hov, s:IsHovered() and 1 or 0, dt*14)
        end
        btn.Paint = function(s, w, h)
            local sel = selCat == c.id
            RR(4,0,0,w,h, sel and FA(c.color,35) or FA(T.Card, math.Round(Lerp(hov,70,150))))
            Bord(0,0,w,h, FA(sel and c.color or T.Border, sel and 180 or math.Round(Lerp(hov,40,100))))
            if sel then surface.SetDrawColor(FA(c.color,200)); surface.DrawRect(0,0,w,2) end
            Txt(c.icon,               "TK_Bold", w/2, h/2-5, FA(sel and c.color or T.Dim, math.Round(Lerp(hov,140,220))), 1,1)
            Txt(string.upper(c.label),"TK_Tiny", w/2, h/2+6, FA(sel and c.color or T.Dim, math.Round(Lerp(hov,120,200))), 1,1)
        end
        btn.DoClick = function() selCat = c.id end
    end
    Y = Y + 36

    -- Priority buttons
    Lbl("PRIORITY", Y); Y = Y + 16
    local selPri = "medium"
    local priW   = math.floor((FW-PAD*2-(#PRI-1)*5) / #PRI)
    for i, pri in ipairs(PRI) do
        local p  = pri
        local bx = PAD + (i-1)*(priW+5)
        local btn = vgui.Create("DButton", frame)
        btn:SetSize(priW,26); btn:SetPos(bx,Y); btn:SetText("")
        local hov, lt = 0, CurTime()
        btn.Think = function(s)
            local dt = CurTime()-lt; lt = CurTime()
            hov = math.Approach(hov, s:IsHovered() and 1 or 0, dt*14)
        end
        btn.Paint = function(s, w, h)
            local sel = selPri == p.id
            RR(3,0,0,w,h, sel and FA(p.col,40) or FA(T.Card, math.Round(Lerp(hov,60,130))))
            Bord(0,0,w,h, FA(sel and p.col or T.Border, sel and 180 or math.Round(Lerp(hov,30,90))))
            if sel then surface.SetDrawColor(FA(p.col,200)); surface.DrawRect(0,0,w,2) end
            Txt(string.upper(p.label),"TK_Tiny",w/2,h/2,FA(sel and p.col or T.Dim, math.Round(Lerp(hov,140,230))),1,1)
        end
        btn.DoClick = function() selPri = p.id end
    end
    Y = Y + 32

    -- Subject
    Lbl("SUBJECT", Y); Y = Y + 16
    local subjEntry = MakeEntry(frame, PAD, Y, FW-PAD*2, 30, "Brief summary of your issue...")
    if prefill and prefill ~= "" then subjEntry:SetValue(prefill) end
    Y = Y + 36

    -- Description
    Lbl("DESCRIPTION", Y); Y = Y + 16
    local bodyEntry = MakeEntry(frame, PAD, Y, FW-PAD*2, 96, "Describe your issue in detail...", true)
    Y = Y + 102

    -- Character counter (only updates when text length actually changes)
    local cLbl = vgui.Create("DLabel", frame)
    cLbl:SetPos(PAD, Y); cLbl:SetSize(FW-PAD*2, 14)
    cLbl:SetFont("TK_Tiny"); cLbl:SetTextColor(FA(T.Faint,200))
    local _lastLen = -1
    cLbl.Think = function(self)
        local l = #bodyEntry:GetValue()
        if l ~= _lastLen then
            _lastLen = l
            self:SetText(l .. " / " .. (F2TicketConfig and F2TicketConfig.MaxMessageLength or 500))
        end
    end
    Y = Y + 18

    local BH = 34
    local BW = math.floor((FW-PAD*2-8)/2)
    MakeBtn(frame, "CANCEL",            PAD,       Y, BW, BH, function() return T.Faint end, function() frame:Remove() end)
    MakeBtn(frame, "▶  SUBMIT TICKET",  PAD+BW+8,  Y, BW, BH, Accent, function()
        local subj = string.Trim(subjEntry:GetValue())
        local body = string.Trim(bodyEntry:GetValue())
        if subj == "" then Notify("Please enter a subject.","",3); return end
        if body == "" then Notify("Please enter a description.","",3); return end
        net.Start("F2T_Submit")
        net.WriteString(selCat); net.WriteString(selPri)
        net.WriteString(subj);   net.WriteString(body)
        net.SendToServer()
        Notify("Ticket submitted!", "An admin will assist you shortly.", 1)
        frame:Remove()
    end)
end

-- ─── ADMIN TICKET MANAGER ────────────────────────────────────────────────────
function OpenAdminPanel()
    if IsValid(AdminPanel) then AdminPanel:Remove(); AdminPanel = nil; return end

    local sw, sh = ScrW(), ScrH()
    local PW = math.min(sw-40, 1060)
    local PH = math.min(sh-40, 720)

    local frame = vgui.Create("DFrame")
    frame:SetSize(PW, PH); frame:SetPos((sw-PW)/2, (sh-PH)/2)
    frame:SetTitle(""); frame:SetDraggable(true); frame:ShowCloseButton(false)
    frame:MakePopup()
    AdminPanel = frame
    frame.OnRemove = function() AdminPanel = nil end

    -- Request full sync once on open
    timer.Simple(0, function()
        if IsValid(frame) then net.Start("F2T_SyncAll"); net.SendToServer() end
    end)

    local fadeT = CurTime()
    frame.Paint = function(self, w, h)
        local al = math.min(255, math.Round((CurTime()-fadeT)/0.15*255))
        RR(6,0,0,w,h, FA(T.Bg,al))
        Bord(0,0,w,h, FA(T.Border, math.Round(al*0.8)))
        surface.SetDrawColor(FA(Accent(),al)); surface.DrawRect(0,0,w,2)
        Rect(0,0,w,46, FA(T.Panel,al))
        surface.SetDrawColor(FA(T.Border, math.Round(al*0.4))); surface.DrawLine(0,46,w,46)
        Txt("TICKET MANAGER","TK_Title",14,23,FA(T.Text,al),0,1)
        Txt("F6 to close","TK_Tiny",w-14,23,FA(T.Dim,al),2,1)
    end

    local xBtn = vgui.Create("DButton", frame)
    xBtn:SetSize(30,30); xBtn:SetPos(PW-38,8); xBtn:SetText("")
    xBtn.Paint   = function(self,w,h)
        if self:IsHovered() then RR(4,0,0,w,h,FA(T.Danger,60)) end
        Txt("✕","TK_Label",w/2,h/2,FA(self:IsHovered() and T.Danger or T.Dim,200),1,1)
    end
    xBtn.DoClick = function() frame:Remove() end

    -- ── STATS BAR ────────────────────────────────────────────────────────────
    -- Counts cached so Paint doesn't iterate Tickets every frame
    local statCounts = {open=0, claimed=0, closed=0}
    local function RefreshStatCounts()
        statCounts.open = 0; statCounts.claimed = 0; statCounts.closed = 0
        for _, t in pairs(Tickets) do
            local s = t.status
            if statCounts[s] then statCounts[s] = statCounts[s] + 1 end
        end
    end
    RefreshStatCounts()

    local statBar = vgui.Create("DPanel", frame)
    statBar:SetPos(8,52); statBar:SetSize(PW-16, 44)
    statBar.Paint = function(self, w, h)
        local defs = {
            {label="OPEN",    val=statCounts.open,    col=T.Green},
            {label="CLAIMED", val=statCounts.claimed, col=T.Blue },
            {label="CLOSED",  val=statCounts.closed,  col=T.Dim  },
        }
        local sw2 = math.floor((w - #defs) / #defs)
        for i, d in ipairs(defs) do
            local bx = (i-1)*(sw2+1)
            RR(i==1 and 4 or 0, bx,0,sw2,h, FA(T.Card,180))
            if i==#defs then RR(4,bx,0,sw2,h,FA(T.Card,180)) end
            surface.SetDrawColor(FA(d.col,160)); surface.DrawRect(bx,0,3,h)
            Txt(tostring(d.val), "TK_Stats", bx+sw2/2, h/2-4, FA(d.col,230), 1,1)
            Txt(d.label,         "TK_Tiny",  bx+sw2/2, h-10,  FA(T.Dim,200), 1,1)
        end
    end

    -- ── VIEW TABS ────────────────────────────────────────────────────────────
    local activeView = "tickets"
    local viewBtns   = {}
    local viewDefs   = {
        {id="tickets", label="TICKETS"},
        {id="stats",   label="STATS"},
        {id="history", label="HISTORY"},
    }

    local ticketView  = vgui.Create("DPanel", frame)
    local statsView   = vgui.Create("DPanel", frame)
    local historyView = vgui.Create("DPanel", frame)

    local CONTENT_Y = 132
    local CONTENT_H = PH - CONTENT_Y - 8

    local function SetViewSize(v)
        v:SetPos(8, CONTENT_Y); v:SetSize(PW-16, CONTENT_H)
        v.Paint = function() end
    end
    SetViewSize(ticketView)
    SetViewSize(statsView)
    SetViewSize(historyView)

    local function SwitchView(id)
        activeView = id
        ticketView:SetVisible(id=="tickets")
        statsView:SetVisible(id=="stats")
        historyView:SetVisible(id=="history")
        for _, b in ipairs(viewBtns) do b:InvalidateLayout() end
        if id == "stats" then
            net.Start("F2T_StatsRequest"); net.SendToServer()
        end
    end

    -- ── FILTER TABS ──────────────────────────────────────────────────────────
    local filterStatus = "open"
    local searchText   = ""
    local filters = {"open","claimed","closed","all"}
    for i, f in ipairs(filters) do
        local ff = f
        local fbtn = vgui.Create("DButton", frame)
        fbtn:SetSize(68,22); fbtn:SetPos(8+(i-1)*74, 102); fbtn:SetText("")
        local fh, fl = 0, CurTime()
        fbtn.Think = function(s)
            local dt = CurTime()-fl; fl = CurTime()
            fh = math.Approach(fh, s:IsHovered() and 1 or 0, dt*14)
        end
        fbtn.Paint = function(s, w, h)
            local sel = filterStatus == ff
            RR(3,0,0,w,h, sel and FA(Accent(),30) or FA(T.Card, math.Round(Lerp(fh,60,130))))
            Bord(0,0,w,h, FA(sel and Accent() or T.Border, sel and 160 or math.Round(Lerp(fh,30,90))))
            if sel then surface.SetDrawColor(FA(Accent(),200)); surface.DrawRect(0,0,w,2) end
            Txt(string.upper(ff),"TK_Tiny",w/2,h/2,FA(sel and Accent() or T.Dim, math.Round(Lerp(fh,150,230))),1,1)
        end
        fbtn.DoClick = function()
            filterStatus = ff
            if IsValid(AdminPanel) then AdminPanel:Refresh() end
        end
    end

    -- ── VIEW SWITCHER TABS ───────────────────────────────────────────────────
    for i, vd in ipairs(viewDefs) do
        local vid  = vd
        local vbtn = vgui.Create("DButton", frame)
        vbtn:SetSize(72,22); vbtn:SetPos(PW-8-(#viewDefs-i+1)*78, 102); vbtn:SetText("")
        local vh, vl = 0, CurTime()
        vbtn.Think = function(s)
            local dt = CurTime()-vl; vl = CurTime()
            vh = math.Approach(vh, s:IsHovered() and 1 or 0, dt*14)
        end
        vbtn.Paint = function(s, w, h)
            local sel = activeView == vid.id
            local col = T.Teal
            RR(3,0,0,w,h, sel and FA(col,30) or FA(T.Card, math.Round(Lerp(vh,60,130))))
            Bord(0,0,w,h, FA(sel and col or T.Border, sel and 160 or math.Round(Lerp(vh,30,90))))
            if sel then surface.SetDrawColor(FA(col,200)); surface.DrawRect(0,0,w,2) end
            Txt(vid.label,"TK_Tiny",w/2,h/2,FA(sel and col or T.Dim, math.Round(Lerp(vh,150,230))),1,1)
        end
        vbtn.DoClick = function() SwitchView(vid.id) end
        viewBtns[#viewBtns+1] = vbtn
    end

    -- Search bar
    local searchEntry = MakeEntry(frame, 8+#filters*74+4, 102,
        PW-8-#filters*74-4-#viewDefs*78-12, 22, "Search tickets…")
    searchEntry.OnChange = function(self)
        searchText = string.lower(self:GetValue())
        if IsValid(AdminPanel) then AdminPanel:Refresh() end
    end

    -- ════════════════════════════════════════════════════════════════════════
    -- ── TICKETS VIEW ─────────────────────────────────────────────────────────
    -- ════════════════════════════════════════════════════════════════════════
    local LIST_W   = 290
    local DETAIL_X = LIST_W + 8
    local DETAIL_W = (PW-16) - DETAIL_X

    local listScroll = vgui.Create("DScrollPanel", ticketView)
    listScroll:SetPos(0,0); listScroll:SetSize(LIST_W, CONTENT_H)
    listScroll:GetVBar():SetWide(4)
    listScroll.Paint = function(self,w,h) RR(4,0,0,w,h,FA(T.Panel,200)); Bord(0,0,w,h,FA(T.Border,70)) end

    local detail = vgui.Create("DPanel", ticketView)
    detail:SetPos(DETAIL_X,0); detail:SetSize(DETAIL_W, CONTENT_H)
    detail.Paint = function(self,w,h) RR(4,0,0,w,h,FA(T.Panel,200)); Bord(0,0,w,h,FA(T.Border,70)) end

    local noSelLbl = vgui.Create("DLabel", detail)
    noSelLbl:SetSize(DETAIL_W, CONTENT_H); noSelLbl:SetPos(0,0)
    noSelLbl:SetFont("TK_Label"); noSelLbl:SetTextColor(FA(T.Dim,80))
    noSelLbl:SetContentAlignment(5); noSelLbl:SetText("Select a ticket to view details")

    local selID      = nil
    local detailKids = {}

    local function ClearDetail()
        for _, c in ipairs(detailKids) do if IsValid(c) then c:Remove() end end
        detailKids = {}
        noSelLbl:SetVisible(true)
    end

    -- ── DETAIL PANEL ─────────────────────────────────────────────────────────
    local function BuildDetail(id)
        ClearDetail()
        local t = Tickets[id]; if not t then return end
        noSelLbl:SetVisible(false)
        LastSeen[id] = #t.log

        local DW  = DETAIL_W
        local cy  = 10
        local cat = GetCat(t.cat)
        local pri = GetPri(t.pri)
        local sc  = StatusCol(t.status)

        -- Player info header
        local hdrPanel = vgui.Create("DPanel", detail)
        hdrPanel:SetPos(8,cy); hdrPanel:SetSize(DW-16, 74)
        hdrPanel.Paint = function(self, w, h)
            RR(4,0,0,w,h, FA(T.Card,180))
            surface.SetDrawColor(FA(cat.color,200)); surface.DrawRect(0,0,3,h)
            Bord(0,0,w,h, FA(T.Border,70))
            -- Avatar initials
            local initials = string.sub(t.name or "?", 1, 1):upper()
            RR(4,8,10,48,48, FA(cat.color,50)); Bord(8,10,48,48, FA(cat.color,120))
            Txt(initials,"TK_Big",32,34, FA(cat.color,220),1,1)
            -- Name / SteamID
            Txt(t.name or "Unknown","TK_Title",66,12,T.Text)
            Txt(t.sid  or "",       "TK_Tiny", 66,28,FA(T.Dim,180))
            -- Watchers
            local wList = {}
            for nick in pairs(t.watchers or {}) do wList[#wList+1] = nick end
            Txt(#wList>0 and ("Watchers: "..table.concat(wList,", ")) or "No watchers",
                "TK_Tiny",66,42,FA(T.Faint,160))
            -- Status chip
            Txt(string.upper(t.status)..(t.claim ~= "" and "  ·  "..t.claim or ""),
                "TK_Small",66,58,FA(sc,220))
            -- Age + SLA (right side)
            local slaCol, slaLabel = SLAInfo(t)
            Txt("Open for "..FmtAge(t.created),"TK_Small",w-10,12,FA(T.Dim,180),2,1)
            if slaCol and slaLabel then Txt(slaLabel,"TK_Small",w-10,26,FA(slaCol,210),2,1) end
            -- Rating stars
            if (t.rating or 0) > 0 then
                Txt("Rating:","TK_Tiny",w-10,42,FA(T.Dim,150),2,1)
                local sx = w - 10 - 5*12
                for i = 1, 5 do
                    Txt(i<=t.rating and "★" or "☆","TK_Small",
                        sx+(i-1)*12,58,FA(i<=t.rating and T.Amber or T.Faint, i<=t.rating and 220 or 80),0,1)
                end
            end
            -- Category + priority chips
            RR(3,w-90,28,38,16,FA(cat.color,25)); Bord(w-90,28,38,16,FA(cat.color,100))
            Txt(string.upper(cat.label),"TK_Tiny",w-71,36,FA(cat.color,200),1,1)
            RR(3,w-48,28,40,16,FA(pri.col,25));   Bord(w-48,28,40,16,FA(pri.col,100))
            Txt(string.upper(pri.label),"TK_Tiny",w-28,36,FA(pri.col,200),1,1)
        end
        detailKids[#detailKids+1] = hdrPanel
        cy = cy + 82

        -- Subject
        local subjLbl = vgui.Create("DLabel", detail)
        subjLbl:SetPos(10,cy); subjLbl:SetSize(DW-20,18)
        subjLbl:SetFont("TK_Label"); subjLbl:SetTextColor(T.Text); subjLbl:SetText(t.subj or "")
        detailKids[#detailKids+1] = subjLbl; cy = cy + 20

        -- Body
        local bodyLbl = vgui.Create("DLabel", detail)
        bodyLbl:SetPos(10,cy); bodyLbl:SetSize(DW-20, 16*(math.Clamp(math.ceil(#(t.body or "")/60),1,3)))
        bodyLbl:SetFont("TK_Tiny"); bodyLbl:SetTextColor(FA(T.Dim,220)); bodyLbl:SetText(t.body or "")
        bodyLbl:SetWrap(true); bodyLbl:SetAutoStretchVertical(true)
        detailKids[#detailKids+1] = bodyLbl; cy = cy + bodyLbl:GetTall() + 6

        -- Divider
        local div = vgui.Create("DPanel", detail)
        div:SetPos(8,cy); div:SetSize(DW-16,1)
        div.Paint = function(self,w,h) Rect(0,0,w,h,FA(T.Border,80)) end
        detailKids[#detailKids+1] = div; cy = cy + 8

        -- ── ACTION BUTTONS ────────────────────────────────────────────────────
        local BTN_H, BTN_G = 24, 5
        local ply   = LocalPlayer()
        local myNick = IsValid(ply) and ply:Nick() or ""

        local function SendAction(action, extra)
            net.Start("F2T_AdminAction"); net.WriteString(action)
            net.WriteUInt(t.id,16); net.WriteString(extra or ""); net.SendToServer()
        end

        -- Row helper: places buttons left-to-right, returns next Y
        local function Row(buttons, startY)
            local bx = 10
            for _, def in ipairs(buttons) do
                local label, bw, colFn, action, extra, cond = unpack(def)
                if cond == nil or cond then
                    local btn = MakeBtn(detail, label, bx, startY, bw, BTN_H, colFn, function()
                        if type(action) == "function" then action()
                        else SendAction(action, extra or "") end
                    end)
                    detailKids[#detailKids+1] = btn
                    bx = bx + bw + BTN_G
                end
            end
            return startY + BTN_H + 7
        end

        -- Row 1: Status
        cy = Row({
            {"CLAIM",   64, function() return T.Blue   end, "claim",   "", t.status=="open"                        },
            {"UNCLAIM", 78, function() return T.Amber  end, "unclaim", "", t.status=="claimed" and t.claim==myNick  },
            {"CLOSE",   64, function() return T.Danger end, "close",   "", t.status~="closed"                       },
            {"REOPEN",  70, function() return T.Green  end, "reopen",  "", t.status=="closed"                       },
        }, cy)

        -- Row 2: Teleport
        cy = Row({
            {"GOTO",   58, function() return T.Purple end, "goto",   ""},
            {"BRING",  58, function() return T.Teal   end, "bring",  ""},
            {"RETURN", 64, function() return T.Amber  end, "return", ""},
        }, cy)

        -- Row 3: Watchers + Transfer
        local isWatching = (t.watchers or {})[myNick]
        cy = Row({
            {"JOIN",     52, function() return T.Green  end, "join_ticket",  "", not isWatching},
            {"LEAVE",    52, function() return T.Danger end, "leave_ticket", "", isWatching    },
            {"TRANSFER", 78, function() return T.Blue   end, function()
                net.Start("F2T_OnlineAdmins"); net.SendToServer()
                timer.Simple(0.3, function()
                    if #OnlineAdmins == 0 then Notify("No other admins online.","",2); return end
                    local menu = DermaMenu()
                    for _, nick in ipairs(OnlineAdmins) do
                        local n = nick
                        menu:AddOption(n, function() SendAction("transfer", n) end)
                    end
                    menu:Open()
                end)
            end, ""},
        }, cy)

        -- Divider
        local div2 = vgui.Create("DPanel", detail)
        div2:SetPos(8,cy); div2:SetSize(DW-16,1)
        div2.Paint = function(self,w,h) Rect(0,0,w,h,FA(T.Border,80)) end
        detailKids[#detailKids+1] = div2; cy = cy + 6

        -- ── CHAT LOG ──────────────────────────────────────────────────────────
        local BOTTOM_ROW_H = 34
        local TYPING_H     = 14
        local LOG_H = CONTENT_H - cy - BOTTOM_ROW_H - TYPING_H - 14

        local logScroll = vgui.Create("DScrollPanel", detail)
        logScroll:SetPos(8,cy); logScroll:SetSize(DW-16, LOG_H)
        logScroll:GetVBar():SetWide(3)
        logScroll.Paint = function(self,w,h) RR(3,0,0,w,h,FA(T.Card,120)) end
        detailKids[#detailKids+1] = logScroll

        local function RebuildLog()
            logScroll:Clear()
            local cv = logScroll:GetCanvas()
            local ly = 4
            for _, m in ipairs(t.log) do
                local isSys  = m.who == "SYSTEM"
                local isNote = m.note
                local col = isSys  and FA(T.Faint,180)
                          or isNote and FA(T.Purple,200)
                          or m.admin and FA(T.Blue,230)
                          or T.Text
                if isNote then
                    local bg2 = vgui.Create("DPanel", cv)
                    bg2:SetPos(2,ly-2); bg2:SetSize(DW-24,14)
                    bg2.Paint = function(self,w,h) RR(2,0,0,w,h,FA(T.Purple,14)) end
                end
                local lbl = vgui.Create("DLabel", cv)
                lbl:SetPos(6,ly); lbl:SetSize(DW-28,14)
                lbl:SetFont("TK_Tiny"); lbl:SetTextColor(col)
                lbl:SetText(FmtTime(m.time).."  "..(isSys and "" or ("["..m.who.."]  "))..m.text)
                lbl:SetWrap(true); lbl:SetAutoStretchVertical(true)
                lbl:SizeToContents()
                ly = ly + lbl:GetTall() + 2  -- BUG FIX: use actual height not flat 16
            end
            cv:SetTall(ly + 4)
        end
        RebuildLog()
        cy = cy + LOG_H + 4

        -- Typing indicator (only redraws text when state changes)
        local typingLbl = vgui.Create("DLabel", detail)
        typingLbl:SetPos(10,cy); typingLbl:SetSize(DW-20, TYPING_H)
        typingLbl:SetFont("TK_Tiny")
        local _lastTypingTxt = ""
        typingLbl.Think = function(self)
            local ts  = TypingState[t.id]
            local txt = (ts and CurTime() < ts.expires) and (ts.who .. " is typing…") or ""
            if txt ~= _lastTypingTxt then
                _lastTypingTxt = txt
                self:SetText(txt); self:SetTextColor(FA(T.Dim,200))
                if txt == "" and ts then TypingState[t.id] = nil end
            end
        end
        detailKids[#detailKids+1] = typingLbl
        cy = cy + TYPING_H + 2

        -- ── BOTTOM ROW ────────────────────────────────────────────────────────
        local chatMode = "chat"
        local TOGGLE_W, TMPL_W = 54, 26

        local toggle = vgui.Create("DButton", detail)
        toggle:SetSize(TOGGLE_W, BOTTOM_ROW_H); toggle:SetPos(8,cy); toggle:SetText("")
        toggle.Paint = function(self, w, h)
            local isNote = chatMode == "note"
            local col    = isNote and T.Purple or Accent()
            RR(3,0,0,w,h,FA(col,30)); Bord(0,0,w,h,FA(col,120))
            Txt(isNote and "NOTE" or "CHAT","TK_Bold",w/2,h/2,FA(col,230),1,1)
        end
        toggle.DoClick = function() chatMode = chatMode=="chat" and "note" or "chat"; toggle:InvalidateLayout() end
        detailKids[#detailKids+1] = toggle

        local tmplBtn = vgui.Create("DButton", detail)
        tmplBtn:SetSize(TMPL_W, BOTTOM_ROW_H); tmplBtn:SetPos(8+TOGGLE_W+4, cy); tmplBtn:SetText("")
        tmplBtn.Paint = function(self,w,h)
            RR(3,0,0,w,h,FA(T.Card,180)); Bord(0,0,w,h,FA(T.Border,80))
            Txt("▾","TK_Label",w/2,h/2,FA(T.Dim,200),1,1)
        end
        detailKids[#detailKids+1] = tmplBtn

        local entryX = 8 + TOGGLE_W + 4 + TMPL_W + 4
        local entryW = DW - entryX - 52 - 8
        local chatEntry = MakeEntry(detail, entryX, cy, entryW, BOTTOM_ROW_H, "Type a reply…")
        detailKids[#detailKids+1] = chatEntry

        local _lastTyping = false
        chatEntry.OnChange = function(self)
            local has = self:GetValue() ~= ""
            if has ~= _lastTyping then
                _lastTyping = has
                net.Start("F2T_Typing"); net.WriteUInt(t.id,16); net.WriteBool(has); net.SendToServer()
            end
        end

        tmplBtn.DoClick = function()
            local menu = DermaMenu()
            for _, tpl in ipairs(TEMPLATES) do
                menu:AddOption(tpl, function() chatEntry:SetValue(tpl); chatEntry:RequestFocus() end)
            end
            menu:Open()
        end

        local function SendChat()
            local msg = string.Trim(chatEntry:GetValue())
            if msg == "" then return end
            net.Start("F2T_AdminAction"); net.WriteString(chatMode)
            net.WriteUInt(t.id,16); net.WriteString(msg); net.SendToServer()
            net.Start("F2T_Typing"); net.WriteUInt(t.id,16); net.WriteBool(false); net.SendToServer()
            chatEntry:SetValue(""); _lastTyping = false
        end
        chatEntry.OnEnter = function() SendChat() end
        detailKids[#detailKids+1] = MakeBtn(detail,"SEND",DW-50,cy,42,BOTTOM_ROW_H,Accent,SendChat)
    end

    -- ── LIST ─────────────────────────────────────────────────────────────────
    local priOrder = {urgent=0, high=1, medium=2, low=3}
    local ITM_H    = 68

    local function RebuildList()
        listScroll:Clear()
        local canvas = listScroll:GetCanvas()
        local sorted = {}
        for _, t in pairs(Tickets) do sorted[#sorted+1] = t end
        table.sort(sorted, function(a, b)
            local pa = priOrder[a.pri or "low"] or 3
            local pb = priOrder[b.pri or "low"] or 3
            if pa ~= pb then return pa < pb end
            return (a.created or 0) > (b.created or 0)
        end)

        local ly, shown = 4, 0
        for _, t in ipairs(sorted) do
            if filterStatus == "all" or t.status == filterStatus then
                local matchSearch = true
                if searchText ~= "" then
                    local hay = string.lower((t.name or "").." "..(t.subj or "").." #"..t.id)
                    matchSearch = string.find(hay, searchText, 1, true) ~= nil
                end
                if matchSearch then
                    local tt     = t
                    local pri    = GetPri(t.pri)
                    local sc     = StatusCol(t.status)
                    local unread = math.max(0, #t.log - (LastSeen[t.id] or 0))
                    local slaCol = SLAInfo(t)   -- only need colour, discard label

                    local itm = vgui.Create("DButton", canvas)
                    itm:SetSize(LIST_W-10, ITM_H); itm:SetPos(4,ly); itm:SetText("")
                    local hov, ht = 0, CurTime()
                    itm.Think = function(s)
                        local dt = CurTime()-ht; ht = CurTime()
                        hov = math.Approach(hov, s:IsHovered() and 1 or 0, dt*14)
                    end
                    itm.Paint = function(s, w, h)
                        local sel = selID == tt.id
                        RR(4,0,0,w,h, sel and FA(T.CardSel,255) or FA(T.Card, math.Round(Lerp(hov,60,140))))
                        surface.SetDrawColor(FA(pri.col,220)); surface.DrawRect(0,0,3,h)
                        Bord(0,0,w,h, FA(sel and Accent() or T.Border, sel and 160 or math.Round(Lerp(hov,30,80))))
                        Txt("#"..tt.id,                   "TK_ID",    10,12, FA(sc,230))
                        Txt(tt.name,                      "TK_Label", 10,28, T.Text)
                        local sub = string.sub(tt.subj or "",1,24)..(#(tt.subj or "")>24 and "…" or "")
                        Txt(sub,                          "TK_Tiny",  10,44, FA(T.Dim,200))
                        Txt(string.upper(tt.status),      "TK_Tiny",  w-8,12, FA(sc,200),2,1)
                        Txt(string.upper(tt.pri or ""),   "TK_Tiny",  w-8,24, FA(pri.col,180),2,1)
                        if slaCol and tt.status~="closed" and (tt.first_response or 0)==0 then
                            surface.SetDrawColor(FA(slaCol,200)); surface.DrawRect(w-8,38,6,6)
                        end
                        Txt(FmtAge(tt.created),           "TK_Tiny",  w-16,38, FA(T.Faint,180),2,1)
                        if unread > 0 then
                            local badge = tostring(unread)
                            local bw    = math.max(18, #badge*7+6)
                            RR(9, w-bw-6, h-18, bw, 14, FA(Accent(),220))
                            Txt(badge,"TK_Tiny",w-bw/2-6,h-11,T.Bg,1,1)
                        end
                    end
                    itm.DoClick = function() selID = tt.id; BuildDetail(tt.id); RebuildList() end
                    ly = ly + ITM_H + 4; shown = shown + 1
                end
            end
        end

        if shown == 0 then
            local nl = vgui.Create("DLabel", canvas)
            nl:SetPos(8,8); nl:SetSize(LIST_W-20,20); nl:SetFont("TK_Label")
            nl:SetTextColor(FA(T.Dim,110))
            local q = filterStatus == "all" and "" or filterStatus.." "
            nl:SetText("No "..q.."tickets"..(searchText~="" and ' matching "'..searchText..'"' or "."))
        end
    end

    RebuildList()

    frame.Refresh = function(self)
        RefreshStatCounts()   -- keep stat bar up to date
        if activeView == "tickets" then
            RebuildList()
            if selID and Tickets[selID] then BuildDetail(selID) end
        elseif activeView == "history" then
            BuildHistory()
        elseif activeView == "stats" then
            net.Start("F2T_StatsRequest"); net.SendToServer()
        end
    end

    -- ════════════════════════════════════════════════════════════════════════
    -- ── STATS VIEW ───────────────────────────────────────────────────────────
    -- ════════════════════════════════════════════════════════════════════════
    local statsScroll = vgui.Create("DScrollPanel", statsView)
    statsScroll:SetPos(0,0); statsScroll:SetSize(PW-16, CONTENT_H)
    statsScroll:GetVBar():SetWide(4)
    statsScroll.Paint = function(self,w,h) RR(4,0,0,w,h,FA(T.Panel,200)); Bord(0,0,w,h,FA(T.Border,70)) end

    -- Loading label lives in the scroll's initial canvas
    local initStatsCanvas = statsScroll:GetCanvas()
    local statsLoadingLbl = vgui.Create("DLabel", initStatsCanvas)
    statsLoadingLbl:SetPos(0,20); statsLoadingLbl:SetSize(PW-16,30)
    statsLoadingLbl:SetFont("TK_Label"); statsLoadingLbl:SetTextColor(FA(T.Dim,120))
    statsLoadingLbl:SetContentAlignment(5); statsLoadingLbl:SetText("Loading stats…")

    frame.ShowStats = function(self, data)
        -- Re-fetch canvas: DScrollPanel may create a new one after Clear()
        local cv  = statsScroll:GetCanvas()
        cv:Clear()

        local sw2 = PW - 16
        local cy2 = 10

        -- Summary row
        local summaryPanel = vgui.Create("DPanel", cv)
        summaryPanel:SetPos(10,cy2); summaryPanel:SetSize(sw2-20,56)
        summaryPanel.Paint = function(self, w, h)
            RR(4,0,0,w,h,FA(T.Card,200)); Bord(0,0,w,h,FA(T.Border,80))
            local defs = {
                {label="OPEN",       val=data.totalOpen,    col=T.Green },
                {label="CLAIMED",    val=data.totalClaimed, col=T.Blue  },
                {label="CLOSED",     val=data.totalClosed,  col=T.Dim   },
                {label="AVG RATING", val=(data.avgRating or 0)>0
                    and string.format("%.1f★",data.avgRating) or "N/A", col=T.Amber},
            }
            local cw = math.floor(w / #defs)
            for i, d in ipairs(defs) do
                local bx = (i-1)*cw
                surface.SetDrawColor(FA(d.col,120)); surface.DrawRect(bx,0,2,h)
                Txt(tostring(d.val),"TK_Stats",bx+cw/2,h/2-5,FA(d.col,220),1,1)
                Txt(d.label,       "TK_Tiny", bx+cw/2,h-10,  FA(T.Dim,200),1,1)
            end
        end
        cy2 = cy2 + 66

        -- Per-admin table header
        local tHdr = vgui.Create("DPanel", cv)
        tHdr:SetPos(10,cy2); tHdr:SetSize(sw2-20,20)
        tHdr.Paint = function(self, w, h)
            Rect(0,0,w,h,FA(T.Panel2,220))
            Txt("ADMIN",        "TK_Bold",10,     h/2,FA(T.Dim,200),0,1)
            Txt("CLOSED",       "TK_Bold",w*0.45, h/2,FA(T.Dim,200),1,1)
            Txt("AVG RESPONSE", "TK_Bold",w*0.65, h/2,FA(T.Dim,200),1,1)
            Txt("AVG RATING",   "TK_Bold",w*0.85, h/2,FA(T.Dim,200),1,1)
        end
        cy2 = cy2 + 22

        for i, a in ipairs(data.admins or {}) do
            local ad  = a
            local row = vgui.Create("DPanel", cv)
            row:SetPos(10,cy2); row:SetSize(sw2-20,28)
            row.Paint = function(self, w, h)
                RR(3,0,0,w,h,FA(i%2==0 and T.Card or T.Panel2,180))
                Bord(0,0,w,h,FA(T.Border,40))
                Txt(ad.nick or "?",                                        "TK_Label",10,    h/2,T.Text,0,1)
                Txt(tostring(ad.closed or 0),                              "TK_Body", w*0.45,h/2,FA(T.Green,220),1,1)
                Txt((ad.avgResp   or 0)>0 and FmtSecs(ad.avgResp)   or "—","TK_Body", w*0.65,h/2,FA(T.Blue,200),1,1)
                Txt((ad.avgRating or 0)>0 and string.format("%.1f",ad.avgRating).."★" or "—",
                    "TK_Body",w*0.85,h/2,FA(T.Amber,200),1,1)
            end
            cy2 = cy2 + 30
        end
        if #(data.admins or {}) == 0 then
            local nl = vgui.Create("DLabel", cv)
            nl:SetPos(10,cy2); nl:SetSize(sw2-20,24)
            nl:SetFont("TK_Label"); nl:SetTextColor(FA(T.Dim,100)); nl:SetText("No admin data yet.")
            cy2 = cy2 + 28
        end
        cy2 = cy2 + 14

        -- Per-day bar chart
        local days = data.perDay or {}
        if #days > 0 then
            local chartH = 80
            local chartPanel = vgui.Create("DPanel", cv)
            chartPanel:SetPos(10,cy2); chartPanel:SetSize(sw2-20, chartH+24)
            chartPanel.Paint = function(self, w, h)
                RR(4,0,0,w,h,FA(T.Card,180)); Bord(0,0,w,h,FA(T.Border,70))
                Txt("TICKETS / DAY (LAST 14)","TK_Bold",8,10,FA(T.Dim,200))
                local maxC = 1
                for _, d in ipairs(days) do if d.count > maxC then maxC = d.count end end
                local barW = math.floor((w-16) / #days) - 2
                for i, d in ipairs(days) do
                    local bh = math.Round((d.count/maxC)*(chartH-24))
                    local bx = 8 + (i-1)*(barW+2)
                    local by = chartH - bh
                    RR(2, bx,by,barW,bh, FA(Accent(),180))
                    Txt(tostring(d.count),"TK_Tiny",bx+barW/2,by-10,FA(T.Dim,160),1,1)
                    Txt(string.sub(d.day,6),"TK_Tiny",bx+barW/2,h-10,FA(T.Faint,140),1,1)
                end
            end
            cy2 = cy2 + chartH + 38
        end

        cv:SetTall(cy2 + 20)
    end

    -- ════════════════════════════════════════════════════════════════════════
    -- ── HISTORY VIEW ─────────────────────────────────────────────────────────
    -- ════════════════════════════════════════════════════════════════════════
    local histSearchEntry = MakeEntry(historyView, 0, 0, PW-16, 26, "Search by player name or SteamID…")
    local histText        = ""
    -- OnChange wired after BuildHistory is defined (forward-reference fix)

    local histScroll = vgui.Create("DScrollPanel", historyView)
    histScroll:SetPos(0,32); histScroll:SetSize(PW-16, CONTENT_H-32)
    histScroll:GetVBar():SetWide(4)
    histScroll.Paint = function(self,w,h) RR(4,0,0,w,h,FA(T.Panel,200)); Bord(0,0,w,h,FA(T.Border,70)) end

    local function BuildHistory()
        histScroll:Clear()
        local canvas = histScroll:GetCanvas()

        -- Group closed tickets by SteamID
        local byPlayer = {}
        for _, t in pairs(Tickets) do
            if t.status == "closed" then
                local pd = byPlayer[t.sid]
                if not pd then
                    pd = {name=t.name, sid=t.sid, tickets={}}
                    byPlayer[t.sid] = pd
                end
                pd.tickets[#pd.tickets+1] = t
            end
        end

        local playerList = {}
        for _, pd in pairs(byPlayer) do playerList[#playerList+1] = pd end
        table.sort(playerList, function(a,b) return #a.tickets > #b.tickets end)

        local ly, shown = 4, 0

        for _, pd in ipairs(playerList) do
            if histText ~= "" then
                local hay = string.lower(pd.name .. " " .. pd.sid)
                if not string.find(hay, histText, 1, true) then goto skip end
            end

            -- Player header row
            local phdr = vgui.Create("DPanel", canvas)
            phdr:SetPos(4,ly); phdr:SetSize((PW-16)-8, 30)
            local pname  = pd.name
            local psid   = pd.sid
            local pcount = #pd.tickets
            phdr.Paint = function(self, w, h)
                RR(4,0,0,w,h,FA(T.Card,220)); Bord(0,0,w,h,FA(T.Border,100))
                surface.SetDrawColor(FA(T.Amber,180)); surface.DrawRect(0,0,3,h)
                Txt(pname, "TK_Label",10,  h/2, T.Text,0,1)
                Txt(psid,  "TK_Tiny", 140, h/2, FA(T.Dim,160),0,1)
                Txt(pcount.." closed ticket"..(pcount~=1 and "s" or ""),
                    "TK_Small",(PW-16)-12,h/2,FA(T.Amber,180),2,1)
            end
            ly = ly + 32

            -- Sort tickets newest-first (sort the source slice directly)
            table.sort(pd.tickets, function(a,b) return (a.created or 0) > (b.created or 0) end)

            for _, t in ipairs(pd.tickets) do
                local tt  = t
                local row = vgui.Create("DButton", canvas)
                row:SetPos(14,ly); row:SetSize((PW-16)-18, 40); row:SetText("")
                local hov, ht = 0, CurTime()
                row.Think = function(s)
                    local dt = CurTime()-ht; ht = CurTime()
                    hov = math.Approach(hov, s:IsHovered() and 1 or 0, dt*14)
                end
                row.Paint = function(s, w, h)
                    local pri = GetPri(tt.pri)
                    RR(3,0,0,w,h, FA(T.Panel2, math.Round(Lerp(hov,180,240))))
                    Bord(0,0,w,h, FA(T.Border, math.Round(Lerp(hov,40,90))))
                    surface.SetDrawColor(FA(pri.col,160)); surface.DrawRect(0,0,2,h)
                    Txt("#"..tt.id,                     "TK_ID",   8, 12, FA(T.Dim,220))
                    Txt(string.sub(tt.subj or "",1,44), "TK_Body", 28,12, T.Text)
                    Txt(string.upper(tt.cat or ""),     "TK_Tiny", 28,28, FA(GetCat(tt.cat).color,180))
                    Txt(FmtTime(tt.created).." · "..FmtAge(tt.created).." ago",
                        "TK_Tiny",w-8,12,FA(T.Faint,180),2,1)
                    if (tt.rating or 0) > 0 then
                        for i = 1, 5 do
                            Txt(i<=tt.rating and "★" or "☆","TK_Tiny",
                                w-8-(5-i)*11,28, FA(i<=tt.rating and T.Amber or T.Faint, i<=tt.rating and 210 or 80),2,1)
                        end
                    end
                end
                row.DoClick = function()
                    selID = tt.id
                    SwitchView("tickets")
                    filterStatus = "closed"
                    BuildDetail(tt.id)
                    RebuildList()
                end
                ly = ly + 42
            end
            ly = ly + 6; shown = shown + 1
            ::skip::
        end

        if shown == 0 then
            local nl = vgui.Create("DLabel", canvas)
            nl:SetPos(8,8); nl:SetSize((PW-16)-16,24)
            nl:SetFont("TK_Label"); nl:SetTextColor(FA(T.Dim,100))
            nl:SetText("No closed tickets found"..(histText~="" and ' matching "'..histText..'"' or "."))
        end
        canvas:SetTall(ly + 10)
    end

    -- Wire up search AFTER BuildHistory is defined (forward-reference fix)
    histSearchEntry.OnChange = function(self)
        histText = string.lower(self:GetValue()); BuildHistory()
    end

    BuildHistory()
    SwitchView("tickets")
end

-- ─── PLAYER HUD STRIP ────────────────────────────────────────────────────────
hook.Add("HUDPaint", "F2T_PlayerStrip", function()
    if IsAdm() then return end
    local ply = LocalPlayer()
    if not IsValid(ply) then return end
    local sid = ply:SteamID()
    local y   = 10
    for _, t in pairs(Tickets) do
        if t.sid == sid and t.status ~= "closed" then
            local pri = GetPri(t.pri)
            local sc  = StatusCol(t.status)
            RR(4,10,y,270,46, FA(T.Panel2,220))
            surface.SetDrawColor(FA(pri.col,200)); surface.DrawRect(10,y,3,46)
            Bord(10,y,270,46,FA(T.Border,100))
            Txt("#"..t.id,              "TK_ID",    22, y+14, FA(sc,230),0,1)
            Txt(string.sub(t.subj or "",1,26),"TK_Label",44,y+14,T.Text,0,1)
            Txt(string.upper(t.status)..(t.claim~="" and "  ·  "..t.claim or ""),
                "TK_Tiny",44,y+29,FA(sc,200),0,1)
            Txt(FmtAge(t.created),"TK_Tiny",274,y+14,FA(T.Faint,180),2,1)
            y = y + 52
        end
    end
end)

-- ─── ADMIN HUD INDICATOR ─────────────────────────────────────────────────────
hook.Add("HUDPaint", "F2T_AdminHUD", function()
    if not IsAdm() then return end
    -- Single pass: count open and urgent together
    local open, urgent = 0, 0
    for _, t in pairs(Tickets) do
        if t.status == "open" then
            open = open + 1
            if t.pri == "urgent" then urgent = urgent + 1 end
        end
    end
    if open == 0 then return end
    local col   = urgent > 0 and T.Danger or T.Amber
    local pulse = math.abs(math.sin(CurTime()*(urgent>0 and 4 or 2.5)))*0.45+0.55
    RR(4,10,10,240,34,FA(T.Panel2,220))
    surface.SetDrawColor(FA(col, math.Round(200*pulse))); surface.DrawRect(10,10,3,34)
    Bord(10,10,240,34,FA(col, math.Round(100*pulse)))
    local label = urgent>0
        and ("⚠  "..urgent.." URGENT  ·  "..open.." OPEN")
        or  ("⚠  "..open.." OPEN TICKET"..(open~=1 and "S" or ""))
    Txt(label,"TK_Label",20,27,FA(T.Text,230),0,1)
    Txt("F6 ▶","TK_Tiny",244,27,FA(T.Dim,180),2,1)
end)

-- ─── F6 KEYBIND ──────────────────────────────────────────────────────────────
local _f6Down = false
hook.Add("Think", "F2T_F6", function()
    local down = input.IsKeyDown(KEY_F6)
    if down and not _f6Down then
        if IsAdm() then
            OpenAdminPanel()
        else
            if IsValid(TicketForm) then TicketForm:Remove() else OpenTicketForm() end
        end
    end
    _f6Down = down
end)

-- ─── GLOBALS (for external callers) ──────────────────────────────────────────
_G.F2Ticket_OpenForm  = OpenTicketForm
_G.F2Ticket_OpenAdmin = OpenAdminPanel

print("[F2 Tickets] Client loaded.")