AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include("shared.lua")

-- Named pose sequences for citizen-type models
local POSE_SEQUENCES = {
    ["idle"]             = {"idle_all_01", "idle01"},
    ["hands_hips"]       = {"idle_angry", "idle_all_02"},
    ["hands_behind"]     = {"idle_worried", "idle_all_03"},
    ["hands_front"]      = {"idle_all_04", "guardlookaround"},
    ["sit_cross_legged"] = {"sit", "sitchair", "sitting"},
    ["at_ease"]          = {"at_ease", "idle_all_01"},
}

local function ApplyPose(ent, poseName)
    local seqs = POSE_SEQUENCES[poseName] or POSE_SEQUENCES["idle"]
    for _, seqName in ipairs(seqs) do
        local seq = ent:LookupSequence(seqName)
        if seq and seq >= 0 then
            ent:SetSequence(seq)
            ent:SetCycle(0)
            ent:SetPlaybackRate(1)
            return seq
        end
    end
    -- Fallback
    local fallback = ent:SelectWeightedSequence(ACT_IDLE) or 0
    ent:SetSequence(fallback)
    return fallback
end

function ENT:Initialize()
    local model = (REQUISITION and REQUISITION.Options.VendorModel) or "models/npc/citizen/citizenmedic_01.mdl"
    self:SetModel(model)
    self:SetMoveType(MOVETYPE_NONE)
    self:SetSolid(SOLID_VPHYSICS)
    self:PhysicsInit(SOLID_VPHYSICS)
    self:SetUseType(SIMPLE_USE)
    self:SetNWBool("REQ_Vendor", true)

    local phys = self:GetPhysicsObject()
    if IsValid(phys) then phys:EnableMotion(false) end

    self:ResetSequenceInfo()
    local pose = (REQUISITION and REQUISITION.Options.VendorPose) or "idle"
    ApplyPose(self, pose)
end

function ENT:Think()
    self:FrameAdvance()
    self:NextThink(CurTime())
    return true
end

function ENT:Use(activator, caller)
    if not IsValid(activator) or not activator:IsPlayer() then return end
    local opt = {}
    for k, v in pairs(REQUISITION.Options) do
        opt[k] = (type(v) == "table" and v.r) and {r=v.r, g=v.g, b=v.b} or v
    end
    net.Start("REQ_SyncOptions");  net.WriteString(util.TableToJSON(opt)); net.Send(activator)
    net.Start("REQ_SyncVehicles"); net.WriteString(util.TableToJSON(REQUISITION.Vehicles)); net.Send(activator)
    net.Start("REQ_OpenMenu");     net.Send(activator)
end

function ENT:PhysgunPickup(ply)
    return REQUISITION.CanGrant(ply)
end

function ENT:OnRemove() end
