include("shared.lua")

function ENT:Draw()
    self:DrawModel()
end
function ENT:DrawTranslucent() end

hook.Add("PostDrawOpaqueRenderables", "REQ_VendorSign", function()
    local lp = LocalPlayer()
    if not IsValid(lp) then return end

    for _, ent in ipairs(ents.FindByClass("sent_requisition_vendor")) do
        if not IsValid(ent) then continue end

        local entPos  = ent:GetPos()
        local signPos = entPos + Vector(0, 0, 88)
        local dist    = lp:GetPos():Distance(entPos)
        if dist > 600 then continue end

        local alpha = 255
        if dist > 450 then
            alpha = math.Clamp(math.Remap(dist, 450, 600, 255, 0), 0, 255)
        end

        -- Standard GMod billboard: faces the viewer, stays upright
        local ang = Angle(0, EyeAngles().y - 90, 90)

        local opts   = REQUISITION and REQUISITION.Options or {}
        local ac     = opts.OverheadAccent or Color(56, 140, 230)
        if type(ac)=="table" and ac.r then ac=Color(ac.r,ac.g,ac.b) end
        local prefix = opts.PrefixText or "REQ"

        local bg   = Color( 8, 10, 14, math.floor(alpha * 0.92))
        local bord = Color(40, 60, 90, alpha)
        local txt0 = Color(230,235,245,alpha)
        local txt2 = Color( 80,110,150,alpha)

        cam.Start3D2D(signPos, ang, 0.08)
            -- Main background
            surface.SetDrawColor(bg)
            surface.DrawRect(-230, -40, 460, 80)

            -- Accent top bar
            surface.SetDrawColor(ac.r, ac.g, ac.b, alpha)
            surface.DrawRect(-230, -40, 460, 3)

            -- Corner brackets
            local cs = 12
            surface.SetDrawColor(ac.r, ac.g, ac.b, alpha)
            -- TL
            surface.DrawRect(-230,-40,cs,2); surface.DrawRect(-230,-40,2,cs)
            -- TR
            surface.DrawRect(230-cs,-40,cs,2); surface.DrawRect(228,-40,2,cs)
            -- BL
            surface.DrawRect(-230,38,cs,2); surface.DrawRect(-230,28,2,cs)
            -- BR
            surface.DrawRect(230-cs,38,cs,2); surface.DrawRect(228,28,2,cs)

            -- [PREFIX] tag
            surface.SetDrawColor(ac.r, ac.g, ac.b, math.floor(alpha*0.15))
            surface.DrawRect(-226, -36, 72, 30)
            draw.SimpleText("["..prefix.."]","DermaDefaultBold",
                -190, -20, Color(ac.r,ac.g,ac.b,alpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

            -- Title
            draw.SimpleText("REQUISITION", "DermaLarge",
                10, -10, txt0, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

            -- Vertical divider
            surface.SetDrawColor(bord)
            surface.DrawRect(-148, -28, 1, 56)

            -- Hint
            draw.SimpleText("PRESS  E  TO  OPEN", "DermaDefault",
                10, 16, txt2, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        cam.End3D2D()
    end
end)
