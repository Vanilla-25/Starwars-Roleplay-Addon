ENT.Type      = "anim"
ENT.Base      = "base_gmodentity"
ENT.PrintName = "Requisition Vendor"
ENT.Author    = "Requisition"
ENT.Category  = "Requisition"
ENT.Spawnable = true
ENT.AdminOnly = true
