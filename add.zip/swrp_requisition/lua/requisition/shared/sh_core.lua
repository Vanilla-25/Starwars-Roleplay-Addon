-- Requisition / Shared
REQUISITION = REQUISITION or {}
REQUISITION.Version = "1.0.0"

REQUISITION.Options = REQUISITION.Options or {
    VendorModel       = "models/npc/citizen/citizenmedic_01.mdl",
    ConfigCommand     = "vrconfig",
    SaveCommand       = "vrsave",
    OverheadAccent    = Color(100, 180, 255),
    PrefixText        = "REQ",
    PrefixColor       = Color(255, 60, 60),
    AutoDenyTime      = 20,
    MaxVehiclesGlobal = 0,
    SpawnpointRadius  = 300,
    VendorPose        = "idle",  -- idle|hands_hips|hands_behind|hands_front|sit_cross_legged|at_ease
}

REQUISITION.Vehicles        = REQUISITION.Vehicles        or {}
REQUISITION.Vendors         = REQUISITION.Vendors         or {}
REQUISITION.Spawns          = REQUISITION.Spawns          or {}  -- named spawn points
REQUISITION.Requests        = REQUISITION.Requests        or {}
REQUISITION.PendingRequests = REQUISITION.PendingRequests or {}

if SERVER then
    util.AddNetworkString("REQ_OpenMenu")
    util.AddNetworkString("REQ_OpenAdminMenu")
    util.AddNetworkString("REQ_RequestVehicle")   -- now includes spawnKey
    util.AddNetworkString("REQ_GrantRequest")
    util.AddNetworkString("REQ_DenyRequest")
    util.AddNetworkString("REQ_SyncOptions")
    util.AddNetworkString("REQ_SyncVehicles")
    util.AddNetworkString("REQ_SyncVendors")
    util.AddNetworkString("REQ_SyncSpawns")
    util.AddNetworkString("REQ_SaveOptions")
    util.AddNetworkString("REQ_SaveVehicle")
    util.AddNetworkString("REQ_AddVehicle")
    util.AddNetworkString("REQ_DeleteVehicle")
    util.AddNetworkString("REQ_SaveVendors")
    util.AddNetworkString("REQ_SaveSpawns")
    util.AddNetworkString("REQ_StoreVehicle")     -- player stores (removes) their vehicle
    util.AddNetworkString("REQ_SyncActiveVehicles") -- tells client which vehicles they own
    util.AddNetworkString("REQ_Notify")
    util.AddNetworkString("REQ_PendingRequests")
end

function REQUISITION.GenerateKey()
    return "veh_" .. math.random(100000,999999) .. "_" .. os.time()
end

function REQUISITION.CanGrant(ply)
    if not IsValid(ply) then return false end
    if ply:IsAdmin() or ply:IsSuperAdmin() then return true end
    if MRS and MRS.GetRank then
        if (MRS.GetRank(ply) or 0) >= (REQUISITION.Options.GrantRank or 3) then return true end
    end
    if NRS and NRS.GetRank then
        if (NRS.GetRank(ply) or 0) >= (REQUISITION.Options.GrantRank or 3) then return true end
    end
    return false
end

function REQUISITION.CanRequest(ply, vehicleKey)
    if not IsValid(ply) then return false end
    if REQUISITION.CanGrant(ply) then return true end
    local vData = REQUISITION.Vehicles[vehicleKey]
    if not vData then return false end
    if not vData.EnableRequests then return false end
    local teams = vData.RequestTeams
    if not teams or #teams == 0 then return true end
    local job = ply.getDarkRPVar and ply:getDarkRPVar("job") or team.GetName(ply:Team())
    for _, t in ipairs(teams) do
        if t == job then return true end
    end
    return false
end
