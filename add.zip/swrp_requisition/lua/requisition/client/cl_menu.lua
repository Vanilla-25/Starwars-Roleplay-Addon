-- Requisition / Player Menu  – Clean flat list UI
REQUISITION.ActiveVehicles = REQUISITION.ActiveVehicles or {}
REQUISITION.Spawns         = REQUISITION.Spawns         or {}

-- ─────────────────────────────────────────────────────────────────────────────
-- THEME
-- ─────────────────────────────────────────────────────────────────────────────
REQ_T = {
    bg0     = Color( 28,  30,  36),   -- window / panel bg
    bg1     = Color( 36,  39,  46),   -- row bg
    bg2     = Color( 44,  48,  58),   -- row hover
    bg3     = Color( 52,  58,  70),   -- header strip
    line    = Color( 55,  62,  78),   -- dividers
    accent  = Color( 94, 160, 255),   -- blue – category headers / buttons
    green   = Color( 72, 199, 142),   -- free / success
    amber   = Color(240, 185,  70),   -- price
    red     = Color(220,  75,  75),   -- danger
    text0   = Color(230, 234, 245),   -- primary
    text1   = Color(165, 178, 210),   -- secondary
    text2   = Color( 95, 112, 148),   -- muted
    textD   = Color( 55,  65,  90),   -- disabled
    -- compat aliases for cl_admin
    border  = Color( 55,  62,  78),
    textDis = Color( 55,  65,  90),
    accentDim = Color( 40,  90, 180),
}

-- ─────────────────────────────────────────────────────────────────────────────
-- SHARED DRAW / VGUI HELPERS  (used by cl_admin too via globals)
-- ─────────────────────────────────────────────────────────────────────────────

function REQ_DrawPanel(x,y,w,h,col,r)
    draw.RoundedBox(r or 0, x, y, w, h, col)
end
function REQ_DrawLabel(t,f,x,y,c,ax,ay)
    draw.SimpleText(t, f, x, y, c, ax or TEXT_ALIGN_LEFT, ay or TEXT_ALIGN_TOP)
end
function REQ_DrawCorners(x,y,w,h,col,sz)
    sz=sz or 8; surface.SetDrawColor(col.r,col.g,col.b,col.a or 255)
    surface.DrawRect(x,y,sz,1);      surface.DrawRect(x,y,1,sz)
    surface.DrawRect(x+w-sz,y,sz,1); surface.DrawRect(x+w-1,y,1,sz)
    surface.DrawRect(x,y+h-1,sz,1);  surface.DrawRect(x,y+h-sz,1,sz)
    surface.DrawRect(x+w-sz,y+h-1,sz,1); surface.DrawRect(x+w-1,y+h-sz,1,sz)
end
function REQ_DrawBorder(x,y,w,h,col)
    surface.SetDrawColor(col.r,col.g,col.b,col.a or 255)
    surface.DrawRect(x,y,w,1); surface.DrawRect(x,y+h-1,w,1)
    surface.DrawRect(x,y,1,h); surface.DrawRect(x+w-1,y,1,h)
end

function REQ_MkPanel(parent,x,y,w,h)
    local p=vgui.Create("DPanel",parent); p:SetPos(x,y); p:SetSize(w,h); p.Paint=function()end; return p
end
function REQ_MkScroll(parent,x,y,w,h)
    local s=vgui.Create("DScrollPanel",parent); s:SetPos(x,y); s:SetSize(w,h)
    local sb=s:GetVBar(); sb:SetWide(4)
    sb.Paint=function(sl,sw,sh) REQ_DrawPanel(0,0,sw,sh,REQ_T.bg0) end
    sb.btnUp.Paint=function()end; sb.btnDown.Paint=function()end
    sb.btnGrip.Paint=function(sl,sw,sh) REQ_DrawPanel(0,0,sw,sh,Color(REQ_T.accent.r,REQ_T.accent.g,REQ_T.accent.b,120)) end
    return s
end
function REQ_MkLabel(parent,text,x,y,w,h,font,col)
    local l=vgui.Create("DLabel",parent); l:SetPos(x,y); l:SetSize(w or 200,h or 20)
    l:SetText(text or ""); l:SetFont(font or "DermaDefault"); l:SetTextColor(col or REQ_T.text1); return l
end
function REQ_MkButton(parent,text,x,y,w,h,style)
    local btn=vgui.Create("DButton",parent); btn:SetPos(x,y); btn:SetSize(w,h)
    btn:SetText(""); btn._label=text; btn._style=style or "default"
    btn.Paint=function(s,sw,sh)
        local hov=s:IsHovered(); local dwn=s:IsDown(); local dis=not s:IsEnabled()
        local st=s._style
        if dis then
            REQ_DrawPanel(0,0,sw,sh,REQ_T.bg1,3)
            REQ_DrawLabel(s._label,"DermaDefaultBold",sw/2,sh/2,REQ_T.textD,TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
            return
        end
        if st=="primary" then
            local bg=dwn and Color(50,110,200) or hov and Color(120,185,255) or REQ_T.accent
            REQ_DrawPanel(0,0,sw,sh,bg,3)
            REQ_DrawLabel(s._label,"DermaDefaultBold",sw/2,sh/2,Color(10,15,30),TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
        elseif st=="danger" then
            local bg=dwn and Color(160,40,40) or hov and Color(240,90,90) or REQ_T.red
            REQ_DrawPanel(0,0,sw,sh,bg,3)
            REQ_DrawLabel(s._label,"DermaDefaultBold",sw/2,sh/2,REQ_T.text0,TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
        elseif st=="link" then
            -- text-only styled like the screenshot's "Request" label
            REQ_DrawLabel(s._label,"DermaDefault",sw/2,sh/2,hov and REQ_T.text0 or REQ_T.accent,TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
        else
            REQ_DrawPanel(0,0,sw,sh,hov and REQ_T.bg2 or REQ_T.bg1,3)
            REQ_DrawBorder(0,0,sw,sh,hov and REQ_T.accent or REQ_T.line)
            REQ_DrawLabel(s._label,"DermaDefault",sw/2,sh/2,hov and REQ_T.text0 or REQ_T.text1,TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
        end
    end
    return btn
end
function REQ_MkEntry(parent,val,x,y,w,h)
    local te=vgui.Create("DTextEntry",parent); te:SetPos(x,y); te:SetSize(w,h or 28)
    te:SetText(tostring(val or "")); te:SetFont("DermaDefault")
    te:SetTextColor(REQ_T.text0); te:SetCursorColor(REQ_T.accent)
    te.Paint=function(s,sw,sh)
        REQ_DrawPanel(0,0,sw,sh,REQ_T.bg1,3)
        REQ_DrawBorder(0,0,sw,sh,s:HasFocus() and REQ_T.accent or REQ_T.line)
        s:DrawTextEntryText(REQ_T.text0,REQ_T.accent,REQ_T.text0)
    end
    return te
end
function REQ_MkCheckbox(parent,label,x,y,checked)
    local row=REQ_MkPanel(parent,x,y,220,26); local cb=vgui.Create("DCheckBox",row)
    cb:SetPos(0,4); cb:SetSize(18,18); cb:SetValue(checked~=false)
    cb.Paint=function(s,sw,sh)
        REQ_DrawPanel(0,0,sw,sh,REQ_T.bg1,3)
        REQ_DrawBorder(0,0,sw,sh,s:GetChecked() and REQ_T.accent or REQ_T.line)
        if s:GetChecked() then REQ_DrawLabel("✓","DermaDefaultBold",sw/2,sh/2,REQ_T.accent,TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER) end
    end
    REQ_MkLabel(row,label,24,4,190,18,"DermaDefault",REQ_T.text1); return cb
end

function REQ_MkFrame(title,w,h)
    local frame=vgui.Create("DFrame"); frame:SetTitle(""); frame:SetSize(w,h); frame:Center()
    frame:MakePopup(); frame:SetDraggable(true)
    local HB=32
    frame.Paint=function(s,sw,sh)
        REQ_DrawPanel(0,0,sw,sh,REQ_T.bg0,4)
        REQ_DrawPanel(0,0,sw,HB,REQ_T.bg3)
        surface.SetDrawColor(REQ_T.line.r,REQ_T.line.g,REQ_T.line.b,255)
        surface.DrawRect(0,HB,sw,1)
        REQ_DrawLabel("Requisition","DermaDefault",8,HB/2,REQ_T.text1,TEXT_ALIGN_LEFT,TEXT_ALIGN_CENTER)
        if title and title~="" then
            REQ_DrawLabel("—  "..title,"DermaDefault",90,HB/2,REQ_T.text2,TEXT_ALIGN_LEFT,TEXT_ALIGN_CENTER)
        end
    end
    local xb=vgui.Create("DButton",frame); xb:SetPos(w-26,6); xb:SetSize(20,20); xb:SetText("")
    xb.Paint=function(s,sw,sh)
        if s:IsHovered() then REQ_DrawPanel(0,0,sw,sh,REQ_T.red,3) end
        REQ_DrawLabel("X","DermaDefault",sw/2,sh/2,s:IsHovered() and REQ_T.text0 or REQ_T.text1,TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
    end
    xb.DoClick=function() frame:Remove() end
    return frame,HB
end

-- ─────────────────────────────────────────────────────────────────────────────
-- SPAWN PICKER
-- ─────────────────────────────────────────────────────────────────────────────
function OpenSpawnPicker(onPick)
    local spawns=REQUISITION.Spawns or {}; if #spawns==0 then onPick(""); return end
    local pw=420; local ph=math.Clamp(80+#spawns*52,140,480)
    local frame,HB=REQ_MkFrame("Select Deployment Point",pw,ph)
    local scroll=REQ_MkScroll(frame,0,HB+1,pw,ph-HB-1); local cnv=scroll:GetCanvas(); local y=0
    for _,sp in ipairs(spawns) do
        local row=REQ_MkPanel(cnv,0,y,pw,48); y=y+49
        row.Paint=function(s,sw,sh)
            REQ_DrawPanel(0,0,sw,sh,s:IsHovered() and REQ_T.bg2 or REQ_T.bg1)
            surface.SetDrawColor(REQ_T.line.r,REQ_T.line.g,REQ_T.line.b,255); surface.DrawRect(0,sh-1,sw,1)
        end
        REQ_MkLabel(row,sp.name or "Unnamed",14,8,pw-160,18,"DermaDefaultBold",REQ_T.text0)
        local pos=sp.pos or {}
        REQ_MkLabel(row,string.format("%.0f, %.0f, %.0f",pos[1] or 0,pos[2] or 0,pos[3] or 0),14,28,pw-160,14,"DermaDefault",REQ_T.text2)
        local pb=REQ_MkButton(row,"Deploy",pw-100,(48-26)/2,88,26,"primary")
        pb.DoClick=function() frame:Remove(); onPick(sp.key or "") end
    end
    cnv:SetSize(pw,y)
end

-- ─────────────────────────────────────────────────────────────────────────────
-- VEHICLE DETAIL POPUP  (opens when Request is clicked on a row)
-- ─────────────────────────────────────────────────────────────────────────────
local function OpenVehicleDetail(key, vd)
    local pw, ph = 580, 400
    local frame, HB = REQ_MkFrame(string.upper(vd.Name or key), pw, ph)

    -- Left: model preview
    local PREV_W = 260
    local mdlPanel = vgui.Create("DModelPanel", frame)
    mdlPanel:SetPos(0,HB); mdlPanel:SetSize(PREV_W, ph-HB)
    mdlPanel:SetModel("models/buggy.mdl"); mdlPanel:SetFOV(50)
    mdlPanel.LayoutEntity = function() end
    mdlPanel.Paint = function(s,sw,sh)
        REQ_DrawPanel(0,0,sw,sh,REQ_T.bg0)
        vgui.GetControlTable("DModelPanel").Paint(s,sw,sh)
        for i=0,40 do
            surface.SetDrawColor(REQ_T.bg0.r,REQ_T.bg0.g,REQ_T.bg0.b,math.floor(i/40*180))
            surface.DrawRect(0,sh-i-1,sw,1)
        end
    end
    local function FitModel(mdlPath)
        if not mdlPath or mdlPath=="" or not file.Exists(mdlPath,"GAME") then mdlPath="models/buggy.mdl" end
        mdlPanel:SetModel(mdlPath)
        timer.Simple(0,function()
            if not IsValid(mdlPanel) then return end
            local ent=mdlPanel.Entity; if not IsValid(ent) then return end
            local mn,mx=ent:GetRenderBounds()
            local sz=math.max(math.abs(mn.x)+math.abs(mx.x),math.abs(mn.y)+math.abs(mx.y),math.abs(mn.z)+math.abs(mx.z),40)
            mdlPanel:SetCamPos(Vector(sz,sz,sz*0.5)); mdlPanel:SetLookAt(Vector(0,0,(mn.z+mx.z)*0.5))
        end)
    end
    FitModel(vd.Model)

    -- Vertical divider
    local vdiv=REQ_MkPanel(frame,PREV_W,HB,1,ph-HB)
    vdiv.Paint=function(s,sw,sh) surface.SetDrawColor(REQ_T.line.r,REQ_T.line.g,REQ_T.line.b,255); surface.DrawRect(0,0,sw,sh) end

    -- Right: info
    local RX=PREV_W+1; local RW=pw-RX
    local info=REQ_MkPanel(frame,RX,HB,RW,ph-HB)
    info.Paint=function(s,sw,sh) REQ_DrawPanel(0,0,sw,sh,REQ_T.bg0) end

    local iy=16
    REQ_MkLabel(info,vd.Name or key,14,iy,RW-28,22,"DermaLarge",REQ_T.text0); iy=iy+28
    REQ_MkLabel(info,(vd.Category or ""):upper(),14,iy,RW-28,16,"DermaDefault",REQ_T.accent); iy=iy+24

    local price=vd.Price or 0
    local prow=REQ_MkPanel(info,14,iy,RW-28,20)
    prow.Paint=function(s,sw,sh)
        REQ_DrawLabel("Price","DermaDefault",0,0,REQ_T.text2)
        REQ_DrawLabel(price>0 and("$"..price) or "Free","DermaDefault",sw,0,price>0 and REQ_T.amber or REQ_T.green,TEXT_ALIGN_RIGHT)
    end
    iy=iy+28

    surface_div = REQ_MkPanel(info,14,iy,RW-28,1)
    surface_div.Paint=function(s,sw,sh) surface.SetDrawColor(REQ_T.line.r,REQ_T.line.g,REQ_T.line.b,255); surface.DrawRect(0,0,sw,sh) end
    iy=iy+10

    REQ_MkLabel(info,"Skin",14,iy,50,16,"DermaDefault",REQ_T.text2); iy=iy+18
    local skinCb=vgui.Create("DComboBox",info); skinCb:SetPos(14,iy); skinCb:SetSize(RW-28,26); iy=iy+34
    skinCb:SetFont("DermaDefault"); skinCb:SetTextColor(REQ_T.text0)
    skinCb:AddChoice("Default",0)
    if vd.Skins then for _,sk in ipairs(vd.Skins) do skinCb:AddChoice(sk.Name or "Skin",sk.SkinID or 0) end end
    skinCb:ChooseOptionID(1)
    skinCb.Paint=function(s,sw,sh)
        REQ_DrawPanel(0,0,sw,sh,REQ_T.bg1,3)
        REQ_DrawBorder(0,0,sw,sh,s:IsHovered() and REQ_T.accent or REQ_T.line)
        REQ_DrawLabel(s:GetOptionText(s:GetSelectedID()) or "Default","DermaDefault",8,sh/2,REQ_T.text0,TEXT_ALIGN_LEFT,TEXT_ALIGN_CENTER)
        REQ_DrawLabel("▾","DermaDefault",sw-14,sh/2,REQ_T.text2,TEXT_ALIGN_LEFT,TEXT_ALIGN_CENTER)
    end

    REQ_MkLabel(info,"Loadout",14,iy,60,16,"DermaDefault",REQ_T.text2); iy=iy+18
    local loCb=vgui.Create("DComboBox",info); loCb:SetPos(14,iy); loCb:SetSize(RW-28,26); iy=iy+34
    loCb:SetFont("DermaDefault"); loCb:SetTextColor(REQ_T.text0)
    loCb:AddChoice("None","")
    if vd.Loadouts then for _,lo in ipairs(vd.Loadouts) do loCb:AddChoice(lo.Name or "Loadout",lo.Name or "") end end
    loCb:ChooseOptionID(1)
    loCb.Paint=skinCb.Paint

    -- Request button pinned to bottom
    local reqBtn=REQ_MkButton(info,price>0 and("Request  ·  $"..price) or "Request Vehicle",14,ph-HB-50,RW-28,36,"primary")
    reqBtn.DoClick=function()
        local skinID=tonumber(skinCb:GetOptionData(skinCb:GetSelectedID())) or 0
        local loadout=loCb:GetOptionText(loCb:GetSelectedID()) or ""
        if loadout=="None" then loadout="" end
        frame:Remove()
        local spawns=REQUISITION.Spawns or {}
        if #spawns==0 then
            net.Start("REQ_RequestVehicle"); net.WriteString(key); net.WriteUInt(skinID,8); net.WriteString(loadout); net.WriteString(""); net.SendToServer()
        else
            OpenSpawnPicker(function(spawnKey)
                net.Start("REQ_RequestVehicle"); net.WriteString(key); net.WriteUInt(skinID,8); net.WriteString(loadout); net.WriteString(spawnKey); net.SendToServer()
            end)
        end
    end
end

-- ─────────────────────────────────────────────────────────────────────────────
-- MAIN PLAYER MENU  – flat table list matching the screenshot
-- ─────────────────────────────────────────────────────────────────────────────

local PW, PH = 700, 520

function REQUISITION.OpenPlayerMenu()
    if IsValid(REQUISITION.PlayerFrame) then REQUISITION.PlayerFrame:Remove() end

    local frame, HB = REQ_MkFrame("", PW, PH)
    REQUISITION.PlayerFrame = frame

    local BODY_Y = HB + 1
    local BOTTOM_H = 44   -- "Return Current Vehicle" bar

    -- ── Vehicle list (scrollable) ─────────────────────────────────────────
    local scroll = REQ_MkScroll(frame, 0, BODY_Y, PW, PH - BODY_Y - BOTTOM_H)

    -- Build the list
    local function BuildList()
        for _, c in ipairs(scroll:GetCanvas():GetChildren()) do c:Remove() end

        -- Group by category
        local cats = {}; local catOrder = {}
        for key, vd in pairs(REQUISITION.Vehicles) do
            if not vd or not vd.Name then continue end
            local cat = vd.Category or "Other"
            if not cats[cat] then cats[cat] = {}; table.insert(catOrder, cat) end
            table.insert(cats[cat], {key=key, data=vd})
        end
        table.sort(catOrder)
        for _, list in pairs(cats) do
            table.sort(list, function(a,b) return (a.data.Name or "") < (b.data.Name or "") end)
        end

        local cnv = scroll:GetCanvas()
        local y   = 0
        local ROW_H  = 44
        local CAT_H  = 32

        for _, catName in ipairs(catOrder) do
            -- Category header row (blue centered text)
            local catRow = REQ_MkPanel(cnv, 0, y, PW, CAT_H)
            catRow.Paint = function(s,sw,sh)
                REQ_DrawPanel(0,0,sw,sh,REQ_T.bg0)
                surface.SetDrawColor(REQ_T.line.r,REQ_T.line.g,REQ_T.line.b,255)
                surface.DrawRect(0,sh-1,sw,1)
                REQ_DrawLabel(catName,"DermaDefaultBold",sw/2,sh/2,REQ_T.accent,TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
            end
            y = y + CAT_H

            for _, vi in ipairs(cats[catName]) do
                local key = vi.key; local vd = vi.data
                local row = REQ_MkPanel(cnv, 0, y, PW, ROW_H)
                row.Paint = function(s,sw,sh)
                    REQ_DrawPanel(0,0,sw,sh, s:IsHovered() and REQ_T.bg2 or REQ_T.bg1)
                    surface.SetDrawColor(REQ_T.line.r,REQ_T.line.g,REQ_T.line.b,255)
                    surface.DrawRect(0,sh-1,sw,1)
                end
                y = y + ROW_H

                -- Left: vehicle name
                REQ_MkLabel(row, vd.Name or key, 14, 0, PW*0.45, ROW_H, "DermaDefault", REQ_T.text0)
                :SetContentAlignment(4)  -- left, vertical center

                -- Middle: category text
                local catLbl = REQ_MkLabel(row, vd.Category or "", PW*0.45, 0, PW*0.3, ROW_H, "DermaDefault", REQ_T.text2)
                catLbl:SetContentAlignment(5)  -- center

                -- Right: "Request" link button
                local reqBtn = REQ_MkButton(row, "Request", PW*0.75, 0, PW*0.22, ROW_H, "link")
                reqBtn:SetContentAlignment(6)
                reqBtn.DoClick = function()
                    OpenVehicleDetail(key, vd)
                end
            end
        end

        -- Empty state
        if y == 0 then
            local ep = REQ_MkPanel(cnv, 0, 0, PW, 80)
            ep.Paint = function(s,sw,sh)
                REQ_DrawLabel("No vehicles configured. Ask an admin to add some.", "DermaDefault", sw/2, sh/2, REQ_T.text2, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            end
            y = 80
        end

        cnv:SetSize(PW, y)
    end

    BuildList()

    -- ── Bottom bar ────────────────────────────────────────────────────────
    local bottomY = PH - BOTTOM_H
    local bottomBar = REQ_MkPanel(frame, 0, bottomY, PW, BOTTOM_H)
    bottomBar.Paint = function(s,sw,sh)
        REQ_DrawPanel(0,0,sw,sh, REQ_T.bg0)
        surface.SetDrawColor(REQ_T.line.r,REQ_T.line.g,REQ_T.line.b,255)
        surface.DrawRect(0,0,sw,1)
    end

    -- "Return Current Vehicle" button (centered, like the screenshot)
    local active = REQUISITION.ActiveVehicles or {}
    local retLabel = #active > 0 and "Return Current Vehicle" or "No Active Vehicles"
    local retBtn = REQ_MkButton(bottomBar, retLabel, 0, 0, PW, BOTTOM_H, "default")
    retBtn:SetEnabled(#active > 0)
    retBtn.Paint = function(s,sw,sh)
        local en = s:IsEnabled()
        local hov = s:IsHovered()
        if not en then
            REQ_DrawLabel(s._label,"DermaDefault",sw/2,sh/2,REQ_T.textD,TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER); return
        end
        if hov then REQ_DrawPanel(0,0,sw,sh,REQ_T.bg2) end
        REQ_DrawLabel(s._label,"DermaDefault",sw/2,sh/2,hov and REQ_T.text0 or REQ_T.text1,TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
    end
    retBtn.DoClick = function()
        -- Store the first active vehicle
        local av = REQUISITION.ActiveVehicles or {}
        if #av > 0 then
            net.Start("REQ_StoreVehicle"); net.WriteInt(av[1].entIndex, 32); net.SendToServer()
            frame:Remove()
        end
    end

    -- Expose refresh for cl_core
    frame.RefreshActive = function()
        local av = REQUISITION.ActiveVehicles or {}
        retBtn._label = #av > 0 and "Return Current Vehicle" or "No Active Vehicles"
        retBtn:SetEnabled(#av > 0)
    end
end
