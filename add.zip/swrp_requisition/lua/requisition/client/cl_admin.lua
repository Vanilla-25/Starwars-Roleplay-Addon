-- Requisition / Admin Menu – Tactical UI
-- Relies on helpers defined in cl_menu.lua (T, MkFrame, MkPanel, etc.)

local AW, AH = 1000, 680
local NAV_W  = 180

-- ─────────────────────────────────────────────────────────────────────────────
-- ADMIN MENU
-- ─────────────────────────────────────────────────────────────────────────────

function REQUISITION.OpenAdminMenu()
    if IsValid(REQUISITION.AdminFrame) then REQUISITION.AdminFrame:Remove() end
    hook.Remove("REQ_VehiclesUpdated", "AdminPanel_VehRefresh")

    local frame, HB = REQ_MkFrame("ADMIN — CONFIGURATION", AW, AH)
    REQUISITION.AdminFrame = frame
    frame.OnRemove = function() hook.Remove("REQ_VehiclesUpdated","AdminPanel_VehRefresh") end

    -- ── Side nav ──────────────────────────────────────────────────────────────
    local navPanel = REQ_MkPanel(frame, 0, HB, NAV_W, AH-HB)
    navPanel.Paint = function(s,sw,sh)
        REQ_DrawPanel(0,0,sw,sh, REQ_T.bg1)
        surface.SetDrawColor(REQ_T.border); surface.DrawRect(sw-1,0,1,sh)
    end

    local CX, CW, CH = NAV_W, AW-NAV_W, AH-HB
    local curSection  = nil
    local navBtns     = {}

    local function ShowSec(panel, id)
        if IsValid(curSection) then curSection:SetVisible(false) end
        panel:SetVisible(true); curSection = panel
        for _, nb in ipairs(navBtns) do nb._active = (nb._sid == id) end
    end

    local function MkNavBtn(label, icon, sid, y)
        local btn = vgui.Create("DButton", navPanel)
        btn:SetPos(0, y); btn:SetSize(NAV_W, 48)
        btn:SetText(""); btn._sid = sid; btn._active = false; btn._label = label; btn._icon = icon
        btn.Paint = function(s, sw, sh)
            local act = s._active; local hov = s:IsHovered()
            REQ_DrawPanel(0,0,sw,sh, act and REQ_T.bg3 or hov and REQ_T.bg2 or REQ_T.bg1)
            if act then
                surface.SetDrawColor(REQ_T.accent)
                surface.DrawRect(0,0,3,sh)
            end
            REQ_DrawLabel(s._icon, "DermaDefaultBold", 16, sh/2, act and REQ_T.accent or REQ_T.text2, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
            REQ_DrawLabel(s._label, "DermaDefaultBold", 36, sh/2, act and REQ_T.text0 or REQ_T.text1, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
            surface.SetDrawColor(REQ_T.border); surface.DrawRect(6, sh-1, sw-12, 1)
        end
        table.insert(navBtns, btn)
        return btn
    end

    -- ── Helper to create a content section ───────────────────────────────────
    local function MkSection()
        local sec = REQ_MkPanel(frame, CX, HB, CW, CH)
        sec:SetVisible(false)
        sec.Paint = function(s,sw,sh) REQ_DrawPanel(0,0,sw,sh, REQ_T.bg0) end
        return sec
    end

    local function SectionHeader(parent, title, subtitle)
        local hdr = REQ_MkPanel(parent, 0, 0, CW, 56)
        hdr.Paint = function(s,sw,sh)
            REQ_DrawPanel(0,0,sw,sh, REQ_T.bg1)
            surface.SetDrawColor(REQ_T.border); surface.DrawRect(0,sh-1,sw,1)
            REQ_DrawLabel(title, "DermaLarge", 20, 14, REQ_T.text0)
            if subtitle then REQ_DrawLabel(subtitle, "DermaDefault", 20, 36, REQ_T.text2) end
        end
        return hdr
    end

    -- ══════════════════════════════════════════════════════════════════════════
    -- REQUESTS
    -- ══════════════════════════════════════════════════════════════════════════
    local secReq = MkSection()
    SectionHeader(secReq, "PENDING REQUESTS", "Vehicle requests awaiting approval")

    local reqScroll = REQ_MkScroll(secReq, 12, 68, CW-24, CH-76)

    function frame:RefreshRequests()
        reqScroll:Clear()
        local cnv  = reqScroll:GetCanvas()
        local list = REQUISITION.PendingRequests or {}
        local y    = 8

        if #list == 0 then
            local ep = REQ_MkPanel(cnv, CW/2-180, 60, 360, 90)
            ep.Paint = function(s,sw,sh)
                REQ_DrawPanel(0,0,sw,sh,REQ_T.bg2); REQ_DrawCorners(0,0,sw,sh,REQ_T.border,8)
                REQ_DrawLabel("NO PENDING REQUESTS","DermaDefaultBold",sw/2,34,REQ_T.text2,TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
                REQ_DrawLabel("All clear, commander","DermaDefault",sw/2,56,REQ_T.textDis,TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
            end
            cnv:SetSize(CW-24,200); return
        end

        for _, req in ipairs(list) do
            local rowH = 72
            local row = REQ_MkPanel(cnv, 0, y, CW-24, rowH)
            row.Paint = function(s,sw,sh)
                REQ_DrawPanel(0,0,sw,sh, REQ_T.bg2)
                surface.SetDrawColor(REQ_T.amber); surface.DrawRect(0,0,3,sh)
                REQ_DrawCorners(0,0,sw,sh,REQ_T.border,5)
                local elapsed = os.time()-(req.timestamp or os.time())
                REQ_DrawLabel("● PENDING  "..elapsed.."s","DermaDefault",sw-180,14,REQ_T.amber,TEXT_ALIGN_LEFT,TEXT_ALIGN_TOP)
            end
            y = y + rowH + 6

            REQ_MkLabel(row, req.playerName or "Unknown", 14, 10, CW-360, 20, "DermaDefaultBold", REQ_T.text0)
            REQ_MkLabel(row, "Requesting: "..(req.vehicleName or "Unknown"), 14, 32, CW-360, 18, "DermaDefault", REQ_T.text1)

            local gb = REQ_MkButton(row, "✓  GRANT", CW-24-224, (rowH-34)/2, 108, 34, true)
            gb.DoClick = function()
                net.Start("REQ_GrantRequest"); net.WriteString(req.id); net.SendToServer()
            end
            local db = REQ_MkButton(row, "✕  DENY", CW-24-108, (rowH-34)/2, 100, 34)
            db.Paint = function(s,sw,sh)
                REQ_DrawPanel(0,0,sw,sh, s:IsHovered() and Color(200,50,50) or Color(140,35,35))
                REQ_DrawLabel(s._label,"DermaDefaultBold",sw/2,sh/2,REQ_T.text0,TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
            end
            db.DoClick = function()
                net.Start("REQ_DenyRequest"); net.WriteString(req.id); net.SendToServer()
            end
        end
        cnv:SetSize(CW-24, y+8)
    end
    frame:RefreshRequests()

    -- ══════════════════════════════════════════════════════════════════════════
    -- OPTIONS
    -- ══════════════════════════════════════════════════════════════════════════
    local secOpt = MkSection()
    SectionHeader(secOpt, "SYSTEM OPTIONS", "Global configuration settings")

    local optScroll = REQ_MkScroll(secOpt, 12, 68, CW-24, CH-76)
    local oc = optScroll:GetCanvas()
    local oy = 12

    local function OLbl(txt)
        REQ_MkLabel(oc, txt, 4, oy, CW-32, 16, "DermaDefault", REQ_T.text2)
        oy = oy + 20
    end
    local function OEntry(v)
        local e = REQ_MkEntry(oc, v, 4, oy, CW-32, 28)
        oy = oy + 36
        return e
    end
    local function ODivider()
        local d = REQ_MkPanel(oc, 4, oy, CW-32, 1)
        d.Paint = function(s,sw,sh) surface.SetDrawColor(REQ_T.border); surface.DrawRect(0,0,sw,sh) end
        oy = oy + 14
    end

    OLbl("VENDOR MODEL PATH"); local eVM = OEntry(REQUISITION.Options.VendorModel or "")
    OLbl("CONFIG COMMAND (without !)"); local eCC = OEntry(REQUISITION.Options.ConfigCommand or "vrconfig")
    OLbl("SAVE COMMAND (without !)"); local eSC = OEntry(REQUISITION.Options.SaveCommand or "vrsave")
    ODivider()
    OLbl("PREFIX TEXT"); local ePT = OEntry(REQUISITION.Options.PrefixText or "REQ")
    ODivider()
    OLbl("AUTO-DENY TIME (seconds, 0 = disabled)"); local eAD = OEntry(tostring(REQUISITION.Options.AutoDenyTime or 20))
    OLbl("MAX VEHICLES GLOBAL (0 = unlimited)"); local eMV = OEntry(tostring(REQUISITION.Options.MaxVehiclesGlobal or 0))
    OLbl("SPAWN RADIUS (fallback random)"); local eSR = OEntry(tostring(REQUISITION.Options.SpawnpointRadius or 300))
    OLbl("VENDOR POSE  (idle | hands_hips | hands_behind | hands_front | sit_cross_legged | at_ease)")
    local ePose = OEntry(REQUISITION.Options.VendorPose or "idle")
    oy = oy + 8

    local saveOpt = REQ_MkButton(oc, "SAVE OPTIONS", 4, oy, CW-32, 40, true)
    oy = oy + 52
    oc:SetSize(CW-24, oy)

    saveOpt.DoClick = function()
        local opts = {
            VendorModel       = eVM:GetValue(),
            ConfigCommand     = eCC:GetValue(),
            SaveCommand       = eSC:GetValue(),
            PrefixText        = ePT:GetValue(),
            AutoDenyTime      = tonumber(eAD:GetValue()) or 20,
            MaxVehiclesGlobal = tonumber(eMV:GetValue()) or 0,
            SpawnpointRadius  = tonumber(eSR:GetValue()) or 300,
            VendorPose        = ePose:GetValue(),
            OverheadAccent    = REQUISITION.Options.OverheadAccent,
            PrefixColor       = REQUISITION.Options.PrefixColor,
        }
        net.Start("REQ_SaveOptions"); net.WriteString(util.TableToJSON(opts)); net.SendToServer()
    end

    -- ══════════════════════════════════════════════════════════════════════════
    -- VEHICLES
    -- ══════════════════════════════════════════════════════════════════════════
    local secVeh = MkSection()
    SectionHeader(secVeh, "VEHICLE REGISTRY", "Manage available requisition vehicles")

    local VEH_LIST_W = 300
    local VEH_EDIT_X = VEH_LIST_W + 1

    -- Left list
    local vListScroll = REQ_MkScroll(secVeh, 0, 56, VEH_LIST_W, CH-56)
    vListScroll.Paint = function(s,sw,sh)
        REQ_DrawPanel(0,0,sw,sh,REQ_T.bg1)
        surface.SetDrawColor(REQ_T.border); surface.DrawRect(sw-1,0,1,sh)
    end

    -- Right editor
    local vEditScroll = REQ_MkScroll(secVeh, VEH_EDIT_X, 56, CW-VEH_EDIT_X, CH-56)

    local editKey = nil
    local function ClearEditor()
        for _, c in ipairs(vEditScroll:GetCanvas():GetChildren()) do c:Remove() end
    end

    local function RefreshVehicleList()
        for _, c in ipairs(vListScroll:GetCanvas():GetChildren()) do c:Remove() end
        local cnv = vListScroll:GetCanvas()
        local LW  = VEH_LIST_W
        local y   = 6

        local addBtn = REQ_MkButton(cnv, "+  ADD VEHICLE", 6, y, LW-12, 34, true)
        y = y + 40
        addBtn.DoClick = function()
            editKey = nil; ClearEditor()
            REQUISITION.BuildVehicleEditor(vEditScroll, nil, nil, RefreshVehicleList)
        end

        for key, vd in SortedPairs(REQUISITION.Vehicles) do
            if not vd then continue end
            local rowH = 54
            local row = REQ_MkPanel(cnv, 6, y, LW-12, rowH)
            row.Paint = function(s,sw,sh)
                local sel = (editKey == key); local hov = s:IsHovered()
                REQ_DrawPanel(0,0,sw,sh, sel and REQ_T.bg3 or hov and REQ_T.bg2 or REQ_T.bg1)
                surface.SetDrawColor(sel and REQ_T.accent or REQ_T.border); surface.DrawRect(0,0,2,sh)
                surface.SetDrawColor(REQ_T.border); surface.DrawRect(0,sh-1,sw,1)
                REQ_DrawLabel(vd.Name or key,"DermaDefaultBold",10,10,sel and REQ_T.text0 or REQ_T.text1)
                REQ_DrawLabel((vd.Category or ""):upper(),"DermaDefault",10,30,REQ_T.text2)
                REQ_DrawLabel("›","DermaLarge",sw-14,sh/2,sel and REQ_T.accent or REQ_T.border,TEXT_ALIGN_LEFT,TEXT_ALIGN_CENTER)
            end
            y = y + rowH + 2

            local click = vgui.Create("DButton", row)
            click:SetPos(0,0); click:SetSize(LW-12, rowH); click:SetText(""); click.Paint=function()end
            click.DoClick = function()
                editKey = key; ClearEditor()
                REQUISITION.BuildVehicleEditor(vEditScroll, key, table.Copy(vd), RefreshVehicleList)
            end
        end
        cnv:SetSize(LW, y+6)
    end

    function REQUISITION.BuildVehicleEditor(sp, key, vd, onSave)
        vd = vd or {}
        local cnv = sp:GetCanvas()
        local EW  = CW - VEH_EDIT_X - 16
        local ey  = 12

        local function EL(txt)
            REQ_MkLabel(cnv, txt, 8, ey, EW, 16, "DermaDefault", REQ_T.text2)
            ey = ey + 20
        end
        local function EE(v)
            local e = REQ_MkEntry(cnv, v, 8, ey, EW, 28)
            ey = ey + 36
            return e
        end
        local function EDivider()
            local d = REQ_MkPanel(cnv, 8, ey, EW, 1)
            d.Paint=function(s,sw,sh) surface.SetDrawColor(REQ_T.border); surface.DrawRect(0,0,sw,sh) end
            ey = ey + 14
        end

        EL("NAME  *"); local eName = EE(vd.Name)
        EL("CATEGORY  *"); local eCat = EE(vd.Category)
        EL("ENTITY CLASS  *  (e.g. lvs_fakehover_iftx)"); local eCls = EE(vd.Class)
        EL("PREVIEW MODEL PATH  (e.g. models/LVS/fakehover/iftx.mdl)"); local eMdl = EE(vd.Model)
        EDivider()
        EL("PRICE  (0 = free)"); local ePri = EE(tostring(vd.Price or 0))
        EL("MAX AMOUNT  (0 = unlimited)"); local eMax = EE(tostring(vd.MaxAmount or 0))
        EDivider()

        -- Enable requests checkbox
        local cbPanel = REQ_MkPanel(cnv, 8, ey, EW, 28); ey = ey + 36
        cbPanel.Paint = function() end
        local cb = vgui.Create("DCheckBox", cbPanel)
        cb:SetPos(0,5); cb:SetSize(18,18); cb:SetValue(vd.EnableRequests ~= false)
        cb.Paint = function(s,sw,sh)
            REQ_DrawPanel(0,0,sw,sh,REQ_T.bg2)
            surface.SetDrawColor(s:GetChecked() and REQ_T.accent or REQ_T.border)
            surface.DrawRect(0,sh-1,sw,1); surface.DrawRect(0,0,1,sh)
            surface.DrawRect(sw-1,0,1,sh); surface.DrawRect(0,0,sw,1)
            if s:GetChecked() then REQ_DrawLabel("✓","DermaDefaultBold",sw/2,sh/2,REQ_T.accent,TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER) end
        end
        REQ_MkLabel(cbPanel,"ENABLE REQUEST SYSTEM",22,5,EW-30,18,"DermaDefaultBold",REQ_T.text1)

        EL("AUTHORISED JOBS  (comma-separated job names — multiple allowed, blank = anyone)")
        local eTeams = EE(table.concat(vd.RequestTeams or {}, ", "))
        ey = ey + 4

        -- Save / Cancel buttons
        local saveB  = REQ_MkButton(cnv, key and "SAVE CHANGES" or "ADD VEHICLE", 8, ey, EW/2-6, 40, true)
        local cancelB = REQ_MkButton(cnv, "CANCEL", EW/2+6, ey, EW/2-6, 40)
        ey = ey + 48

        if key then
            local delB = REQ_MkButton(cnv, "DELETE VEHICLE", 8, ey, EW, 36)
            delB.Paint = function(s,sw,sh)
                REQ_DrawPanel(0,0,sw,sh, s:IsHovered() and Color(200,50,50) or Color(140,35,35))
                REQ_DrawLabel(s._label,"DermaDefaultBold",sw/2,sh/2,REQ_T.text0,TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
            end
            ey = ey + 44
            delB.DoClick = function()
                net.Start("REQ_DeleteVehicle"); net.WriteString(key); net.SendToServer()
                ClearEditor(); editKey = nil
                timer.Simple(0.6, function() if IsValid(frame) then RefreshVehicleList() end end)
            end
        end

        cnv:SetSize(EW+16, ey+12)
        cancelB.DoClick = function() ClearEditor(); editKey = nil end

        saveB.DoClick = function()
            local teams = {}
            for t in string.gmatch(eTeams:GetValue(), "[^,]+") do
                local tr = string.Trim(t)
                if tr ~= "" then table.insert(teams, tr) end
            end
            local nd = {
                Name=eName:GetValue(), Category=eCat:GetValue(), Class=eCls:GetValue(),
                Model=eMdl:GetValue(), Price=tonumber(ePri:GetValue()) or 0,
                MaxAmount=tonumber(eMax:GetValue()) or 0, EnableRequests=cb:GetChecked(),
                RequestTeams=teams, DefaultSkin=vd.DefaultSkin or 0,
                Skins=vd.Skins or {}, Loadouts=vd.Loadouts or {},
            }
            if nd.Name=="" or nd.Class=="" then
                chat.AddText(REQ_T.red,"[REQ] Name and Class are required."); return
            end
            if key then
                nd.Key=key; net.Start("REQ_SaveVehicle"); net.WriteString(util.TableToJSON(nd)); net.SendToServer()
            else
                net.Start("REQ_AddVehicle"); net.WriteString(util.TableToJSON(nd)); net.SendToServer()
            end
            ClearEditor(); editKey = nil
            if onSave then timer.Simple(0.8, function() if IsValid(frame) then onSave() end end) end
        end
    end

    RefreshVehicleList()
    hook.Add("REQ_VehiclesUpdated","AdminPanel_VehRefresh",function()
        if IsValid(frame) then RefreshVehicleList() end
    end)

    -- ══════════════════════════════════════════════════════════════════════════
    -- VENDORS
    -- ══════════════════════════════════════════════════════════════════════════
    local secVen = MkSection()
    SectionHeader(secVen, "VENDOR PLACEMENT", "Manage vendor NPC positions")

    REQ_MkLabel(secVen,"Walk to the desired position, then click Add. Type !vrsave to persist to disk.",16,66,CW-32,18,"DermaDefault",REQ_T.text2)

    local addVBtn  = REQ_MkButton(secVen,"ADD VENDOR AT MY POSITION",16,96,280,36,true)
    local clrVBtn  = REQ_MkButton(secVen,"CLEAR ALL VENDORS",308,96,180,36)
    clrVBtn.Paint = function(s,sw,sh)
        REQ_DrawPanel(0,0,sw,sh, s:IsHovered() and Color(180,50,50) or REQ_T.bg2)
        REQ_DrawCorners(0,0,sw,sh, s:IsHovered() and REQ_T.red or REQ_T.border,5)
        REQ_DrawLabel(s._label,"DermaDefaultBold",sw/2,sh/2,REQ_T.text1,TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
    end

    addVBtn.DoClick = function()
        local lp=LocalPlayer(); local p,a=lp:GetPos(),lp:GetAngles()
        local vens=table.Copy(REQUISITION.Vendors or {})
        table.insert(vens,{pos={p.x,p.y,p.z},ang={a.p,a.y,a.r}})
        net.Start("REQ_SaveVendors"); net.WriteString(util.TableToJSON(vens)); net.SendToServer()
    end
    clrVBtn.DoClick = function()
        net.Start("REQ_SaveVendors"); net.WriteString(util.TableToJSON({})); net.SendToServer()
    end

    local venCountLbl = REQ_MkLabel(secVen,"",16,140,CW-32,18,"DermaDefault",REQ_T.text2)
    net.Receive("REQ_SyncVendors",function()  -- local refresh
        if IsValid(venCountLbl) then
            venCountLbl:SetText(string.format("%d vendor(s) placed. Type !vrsave to save.", #(REQUISITION.Vendors or {})))
        end
    end)

    -- ══════════════════════════════════════════════════════════════════════════
    -- SPAWNS
    -- ══════════════════════════════════════════════════════════════════════════
    local secSpn = MkSection()
    SectionHeader(secSpn,"SPAWN POINTS","Named vehicle deployment locations")

    REQ_MkLabel(secSpn,"Walk to a deployment position, name it, then click Add.",16,66,CW-32,18,"DermaDefault",REQ_T.text2)

    local spawnNameEntry = REQ_MkEntry(secSpn,"e.g. Hangar Bay 1",16,92,240,28)
    local addSpnBtn  = REQ_MkButton(secSpn,"ADD SPAWN POINT HERE",264,92,220,28,true)

    local spawnScroll = REQ_MkScroll(secSpn, 12, 132, CW-24, CH-140)

    local function RefreshSpawns()
        spawnScroll:Clear()
        local cnv    = spawnScroll:GetCanvas()
        local spawns = REQUISITION.Spawns or {}
        local y      = 8

        if #spawns == 0 then
            local ep = REQ_MkPanel(cnv, CW/2-200, 40, 400, 80)
            ep.Paint = function(s,sw,sh)
                REQ_DrawPanel(0,0,sw,sh,REQ_T.bg2); REQ_DrawCorners(0,0,sw,sh,REQ_T.border,8)
                REQ_DrawLabel("NO SPAWN POINTS CONFIGURED","DermaDefaultBold",sw/2,30,REQ_T.text2,TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
                REQ_DrawLabel("Add one above to enable spawn selection","DermaDefault",sw/2,52,REQ_T.textDis,TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
            end
            cnv:SetSize(CW-24,160); return
        end

        for i, sp in ipairs(spawns) do
            local rowH = 64
            local row  = REQ_MkPanel(cnv, 0, y, CW-24, rowH)
            row.Paint = function(s,sw,sh)
                REQ_DrawPanel(0,0,sw,sh,REQ_T.bg2)
                surface.SetDrawColor(REQ_T.accent); surface.DrawRect(0,0,2,sh)
                REQ_DrawCorners(0,0,sw,sh,REQ_T.border,5)
            end
            y = y + rowH + 6

            REQ_MkLabel(row, sp.name or ("Spawn "..i), 14, 10, CW-280, 20, "DermaDefaultBold", REQ_T.text0)
            local pos = sp.pos or {}
            REQ_MkLabel(row, string.format("X: %.0f  Y: %.0f  Z: %.0f", pos[1] or 0, pos[2] or 0, pos[3] or 0),
                    14, 32, CW-280, 16, "DermaDefault", REQ_T.text2)

            local delBtn = REQ_MkButton(row,"REMOVE",CW-24-120,(rowH-30)/2,112,30)
            delBtn.Paint = function(s,sw,sh)
                REQ_DrawPanel(0,0,sw,sh, s:IsHovered() and Color(180,50,50) or REQ_T.bg3)
                REQ_DrawCorners(0,0,sw,sh, s:IsHovered() and REQ_T.red or REQ_T.border, 4)
                REQ_DrawLabel(s._label,"DermaDefaultBold",sw/2,sh/2,REQ_T.text1,TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
            end
            delBtn.DoClick = function()
                table.remove(REQUISITION.Spawns, i)
                net.Start("REQ_SaveSpawns"); net.WriteString(util.TableToJSON(REQUISITION.Spawns)); net.SendToServer()
                RefreshSpawns()
            end
        end
        cnv:SetSize(CW-24, y+8)
    end
    RefreshSpawns()

    addSpnBtn.DoClick = function()
        local name = string.Trim(spawnNameEntry:GetValue())
        if name == "" or name == "e.g. Hangar Bay 1" then
            name = "Spawn "..(#(REQUISITION.Spawns or {})+1)
        end
        local lp = LocalPlayer(); local p,a = lp:GetPos(), lp:GetAngles()
        local key = "spn_"..math.random(10000,99999).."_"..os.time()
        local spns = table.Copy(REQUISITION.Spawns or {})
        table.insert(spns, {key=key, name=name, pos={p.x,p.y,p.z}, ang={a.p,a.y,a.r}})
        REQUISITION.Spawns = spns
        net.Start("REQ_SaveSpawns"); net.WriteString(util.TableToJSON(spns)); net.SendToServer()
        spawnNameEntry:SetValue("")
        RefreshSpawns()
    end

    -- ── Nav setup ─────────────────────────────────────────────────────────────
    local navDefs = {
        {id="req",  label="REQUESTS",  icon="!",  panel=secReq},
        {id="opt",  label="OPTIONS",   icon="⚙",  panel=secOpt},
        {id="veh",  label="VEHICLES",  icon="▶",  panel=secVeh},
        {id="ven",  label="VENDORS",   icon="◈",  panel=secVen},
        {id="spn",  label="SPAWNS",    icon="◎",  panel=secSpn},
    }

    local ny = 12
    for _, nd in ipairs(navDefs) do
        local nb = MkNavBtn(nd.label, nd.icon, nd.id, ny)
        nb.DoClick = function() ShowSec(nd.panel, nd.id) end
        ny = ny + 52
    end

    ShowSec(secReq, "req")
end
