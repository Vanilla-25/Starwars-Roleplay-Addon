-- Requisition / Client Core
include("requisition/shared/sh_core.lua")

net.Receive("REQ_SyncOptions", function()
    local opts = util.JSONToTable(net.ReadString()) or {}
    for k, v in pairs(opts) do
        REQUISITION.Options[k] = (type(v)=="table" and v.r) and Color(v.r,v.g,v.b,255) or v
    end
end)

net.Receive("REQ_SyncVehicles", function()
    REQUISITION.Vehicles = util.JSONToTable(net.ReadString()) or {}
    if REQUISITION._MenuPending then
        REQUISITION._MenuPending = nil
        REQUISITION.OpenPlayerMenu()
    end
    hook.Call("REQ_VehiclesUpdated")
end)

net.Receive("REQ_SyncVendors", function()
    REQUISITION.Vendors = util.JSONToTable(net.ReadString()) or {}
end)

net.Receive("REQ_SyncSpawns", function()
    REQUISITION.Spawns = util.JSONToTable(net.ReadString()) or {}
end)

net.Receive("REQ_SyncActiveVehicles", function()
    REQUISITION.ActiveVehicles = util.JSONToTable(net.ReadString()) or {}
    -- Refresh menu if open
    if IsValid(REQUISITION.PlayerFrame) and REQUISITION.PlayerFrame.RefreshActive then
        REQUISITION.PlayerFrame:RefreshActive()
    end
end)

net.Receive("REQ_Notify", function()
    local msg  = net.ReadString()
    local kind = net.ReadString()
    local col  = kind=="success" and Color(50,220,50) or kind=="error" and Color(255,80,80) or Color(100,200,255)
    local pc   = REQUISITION.Options.PrefixColor or Color(255,60,60)
    if type(pc)=="table" and pc.r then pc=Color(pc.r,pc.g,pc.b) end
    chat.AddText(pc, "["..(REQUISITION.Options.PrefixText or "REQ").."] ", col, msg)
    surface.PlaySound("buttons/button14.wav")
end)

net.Receive("REQ_PendingRequests", function()
    REQUISITION.PendingRequests = util.JSONToTable(net.ReadString()) or {}
    if IsValid(REQUISITION.AdminFrame) and REQUISITION.AdminFrame.RefreshRequests then
        REQUISITION.AdminFrame:RefreshRequests()
    end
end)

net.Receive("REQ_OpenMenu", function()
    if next(REQUISITION.Vehicles) ~= nil then
        REQUISITION.OpenPlayerMenu()
    else
        REQUISITION._MenuPending = true
    end
end)

net.Receive("REQ_OpenAdminMenu", function()
    REQUISITION.OpenAdminMenu()
end)
