-- Requisition / Server
include("requisition/shared/sh_core.lua")

local DATA_DIR   = "requisition/"
local OPT_FILE   = DATA_DIR .. "options.json"
local VEH_FILE   = DATA_DIR .. "vehicles.json"
local VEN_FILE   = DATA_DIR .. "vendors.json"
local SPN_FILE   = DATA_DIR .. "spawns.json"
local REQ_COUNT  = 0

-- ── Persistence ───────────────────────────────────────────────────────────────

local function EnsureDir()
    if not file.IsDir(DATA_DIR, "DATA") then file.CreateDir(DATA_DIR) end
end
local function SaveJSON(path, tbl) EnsureDir(); file.Write(path, util.TableToJSON(tbl, true)) end
local function LoadJSON(path)
    if not file.Exists(path, "DATA") then return {} end
    return util.JSONToTable(file.Read(path, "DATA") or "") or {}
end
local function SaveOptions()
    local t = {}
    for k, v in pairs(REQUISITION.Options) do
        t[k] = (type(v)=="table" and v.r) and {r=v.r,g=v.g,b=v.b} or v
    end
    SaveJSON(OPT_FILE, t)
end
local function SaveVehicles() SaveJSON(VEH_FILE, REQUISITION.Vehicles) end
local function SaveVendors()  SaveJSON(VEN_FILE, REQUISITION.Vendors)  end
local function SaveSpawns()   SaveJSON(SPN_FILE, REQUISITION.Spawns)   end

-- ── Sync helpers ──────────────────────────────────────────────────────────────

local function SyncOpts(ply)
    local t = {}
    for k, v in pairs(REQUISITION.Options) do
        t[k] = (type(v)=="table" and v.r) and {r=v.r,g=v.g,b=v.b} or v
    end
    net.Start("REQ_SyncOptions"); net.WriteString(util.TableToJSON(t)); net.Send(ply)
end
local function SyncVehs(ply)
    net.Start("REQ_SyncVehicles"); net.WriteString(util.TableToJSON(REQUISITION.Vehicles)); net.Send(ply)
end
local function SyncVens(ply)
    net.Start("REQ_SyncVendors"); net.WriteString(util.TableToJSON(REQUISITION.Vendors)); net.Send(ply)
end
local function SyncSpawns(ply)
    net.Start("REQ_SyncSpawns"); net.WriteString(util.TableToJSON(REQUISITION.Spawns)); net.Send(ply)
end
local function BroadcastAll()
    local vStr = util.TableToJSON(REQUISITION.Vehicles)
    local nStr = util.TableToJSON(REQUISITION.Vendors)
    local sStr = util.TableToJSON(REQUISITION.Spawns)
    local function sendOpt(c)
        local t = {}
        for k,v in pairs(REQUISITION.Options) do t[k]=(type(v)=="table" and v.r) and {r=v.r,g=v.g,b=v.b} or v end
        net.Start("REQ_SyncOptions"); net.WriteString(util.TableToJSON(t)); net.Send(c)
    end
    for _, ply in ipairs(player.GetAll()) do
        sendOpt(ply)
        net.Start("REQ_SyncVehicles"); net.WriteString(vStr); net.Send(ply)
        net.Start("REQ_SyncVendors");  net.WriteString(nStr); net.Send(ply)
        net.Start("REQ_SyncSpawns");   net.WriteString(sStr); net.Send(ply)
    end
end
local function Notify(ply, msg, t)
    net.Start("REQ_Notify"); net.WriteString(msg); net.WriteString(t or "info"); net.Send(ply)
end

-- Sync the list of active vehicles owned by this player
local function SyncActiveVehicles(ply)
    local list = {}
    for _, e in ipairs(ents.GetAll()) do
        if IsValid(e) and e:GetNWBool("REQ_Requisitioned", false) then
            local owner = e:GetNWEntity("REQ_Owner", NULL)
            if owner == ply then
                local key  = e:GetNWString("REQ_VehicleKey", "")
                local vd   = REQUISITION.Vehicles[key] or {}
                table.insert(list, {
                    entIndex = e:EntIndex(),
                    key      = key,
                    name     = vd.Name or key,
                })
            end
        end
    end
    net.Start("REQ_SyncActiveVehicles")
    net.WriteString(util.TableToJSON(list))
    net.Send(ply)
end

-- ── Vendor spawning ───────────────────────────────────────────────────────────

local SpawnedVendors = {}
local function RemoveVendors()
    for _, e in ipairs(SpawnedVendors) do if IsValid(e) then e:Remove() end end
    SpawnedVendors = {}
end
local function SpawnVendors()
    RemoveVendors()
    local model = REQUISITION.Options.VendorModel or "models/npc/citizen/citizenmedic_01.mdl"
    for _, vd in ipairs(REQUISITION.Vendors) do
        local pos = Vector(vd.pos[1], vd.pos[2], vd.pos[3])
        local ang = Angle(vd.ang[1], vd.ang[2], vd.ang[3])
        local ent = ents.Create("sent_requisition_vendor")
        if IsValid(ent) then
            ent:SetModel(model)
            ent:SetPos(pos)
            ent:SetAngles(ang)
            ent:Spawn()
            ent:Activate()
            table.insert(SpawnedVendors, ent)
        end
    end
end

-- ── Vehicle spawning ──────────────────────────────────────────────────────────

-- Find spawn position: use named spawn point if given, otherwise random near player
local function GetSpawnPos(ply, spawnKey)
    -- Named spawn point
    if spawnKey and spawnKey ~= "" then
        for _, sp in ipairs(REQUISITION.Spawns) do
            if sp.key == spawnKey then
                return Vector(sp.pos[1], sp.pos[2], sp.pos[3]),
                       Angle(sp.ang[1], sp.ang[2], sp.ang[3])
            end
        end
    end
    -- Random position near player
    local radius = math.max(REQUISITION.Options.SpawnpointRadius or 300, 150)
    local plPos  = ply:GetPos()
    for _ = 1, 8 do
        local a   = math.random(0, 360)
        local d   = math.random(120, radius)
        local off = Vector(math.cos(math.rad(a))*d, math.sin(math.rad(a))*d, 100)
        local tr  = util.TraceLine({
            start  = plPos + off,
            endpos  = plPos + off - Vector(0,0,600),
            mask   = MASK_SOLID_BRUSHONLY,
        })
        if tr.Hit then return tr.HitPos + Vector(0,0,10), Angle(0, ply:GetAngles().y, 0) end
    end
    return plPos + ply:GetAngles():Forward() * 250 + Vector(0,0,60),
           Angle(0, ply:GetAngles().y, 0)
end

local function DoSpawn(ply, vehicleKey, skinID, loadout, spawnKey)
    local vd = REQUISITION.Vehicles[vehicleKey]
    if not vd then Notify(ply,"Vehicle data not found.","error"); return end

    if (REQUISITION.Options.MaxVehiclesGlobal or 0) > 0 then
        local cnt = 0
        for _, e in ipairs(ents.GetAll()) do
            if IsValid(e) and e:GetNWBool("REQ_Requisitioned",false) then cnt=cnt+1 end
        end
        if cnt >= REQUISITION.Options.MaxVehiclesGlobal then
            Notify(ply,"Global vehicle limit reached.","error"); return
        end
    end

    if (vd.MaxAmount or 0) > 0 then
        local cnt = 0
        for _, e in ipairs(ents.GetAll()) do
            if IsValid(e) and e:GetNWString("REQ_VehicleKey","") == vehicleKey then cnt=cnt+1 end
        end
        if cnt >= vd.MaxAmount then Notify(ply,"Max of this vehicle already active.","error"); return end
    end

    local price = vd.Price or 0
    if price > 0 and ply.getDarkRPVar then
        if (ply:getDarkRPVar("money") or 0) < price then
            Notify(ply,"Cannot afford $"..price..".","error"); return
        end
        ply:addMoney(-price)
    end

    local veh = ents.Create(vd.Class)
    if not IsValid(veh) then
        Notify(ply,"Failed to spawn '"..tostring(vd.Class).."'. Check the class name.","error")
        print("[Requisition] Bad class: "..tostring(vd.Class))
        return
    end

    local pos, ang = GetSpawnPos(ply, spawnKey)
    veh:SetPos(pos)
    veh:SetAngles(ang)
    veh:SetNWBool("REQ_Requisitioned", true)
    veh:SetNWString("REQ_VehicleKey", vehicleKey)
    veh:SetNWEntity("REQ_Owner", ply)
    veh:Spawn()
    veh:Activate()
    veh:SetSkin(tonumber(skinID) or vd.DefaultSkin or 0)

    if loadout and loadout ~= "" and vd.Loadouts then
        for _, lo in ipairs(vd.Loadouts) do
            if lo.Name == loadout and lo.Bodygroups then
                for bg, val in pairs(lo.Bodygroups) do
                    local bgNum  = tonumber(bg)
                    local valNum = tonumber(val)
                    if bgNum and valNum then
                        -- Clamp to valid bodygroup range
                        local maxBg = veh:GetNumBodyGroups() - 1
                        if bgNum >= 0 and bgNum <= maxBg then
                            veh:SetBodygroup(bgNum, valNum)
                        end
                    end
                end
                break
            end
        end
    end

    Notify(ply, vd.Name.." has been spawned!", "success")
    for _, p in ipairs(player.GetAll()) do
        if REQUISITION.CanGrant(p) and p ~= ply then
            Notify(p, ply:Nick().." received a "..vd.Name..".", "info")
        end
    end

    -- Update player's active vehicle list
    timer.Simple(0.1, function() if IsValid(ply) then SyncActiveVehicles(ply) end end)
end

-- ── Pending requests ──────────────────────────────────────────────────────────

local function BroadcastRequests()
    local list = {}
    for id, req in pairs(REQUISITION.Requests) do
        if IsValid(req.ply) then
            table.insert(list, {
                id          = id,
                playerName  = req.ply:Nick(),
                vehicleName = (REQUISITION.Vehicles[req.vehicleKey] or {}).Name or req.vehicleKey,
                timestamp   = req.timestamp,
            })
        end
    end
    local json = util.TableToJSON(list)
    for _, p in ipairs(player.GetAll()) do
        if REQUISITION.CanGrant(p) then
            net.Start("REQ_PendingRequests"); net.WriteString(json); net.Send(p)
        end
    end
end

-- ── Net receivers ─────────────────────────────────────────────────────────────

net.Receive("REQ_OpenMenu", function(_, ply)
    SyncOpts(ply)
    SyncVehs(ply)
    SyncSpawns(ply)
    SyncActiveVehicles(ply)
end)

net.Receive("REQ_OpenAdminMenu", function(_, ply)
    if not REQUISITION.CanGrant(ply) then return end
    SyncOpts(ply); SyncVehs(ply); SyncVens(ply); SyncSpawns(ply)
    BroadcastRequests()
end)

-- REQ_RequestVehicle now includes spawnKey
net.Receive("REQ_RequestVehicle", function(_, ply)
    local key      = net.ReadString()
    local skin     = net.ReadUInt(8)
    local loadout  = net.ReadString()
    local spawnKey = net.ReadString()   -- may be ""

    if not REQUISITION.CanRequest(ply, key) then
        Notify(ply,"You are not permitted to request this vehicle.","error"); return
    end

    if REQUISITION.CanGrant(ply) then
        DoSpawn(ply, key, skin, loadout, spawnKey); return
    end

    local hasGrantor = false
    for _, p in ipairs(player.GetAll()) do
        if p ~= ply and REQUISITION.CanGrant(p) then hasGrantor=true; break end
    end
    if not hasGrantor then DoSpawn(ply, key, skin, loadout, spawnKey); return end

    REQ_COUNT = REQ_COUNT + 1
    local id  = "req_" .. REQ_COUNT
    REQUISITION.Requests[id] = { ply=ply, vehicleKey=key, skin=skin, loadout=loadout, spawnKey=spawnKey, timestamp=os.time() }
    local vName = (REQUISITION.Vehicles[key] or {}).Name or key
    Notify(ply,"Request for "..vName.." submitted.","info")
    for _, p in ipairs(player.GetAll()) do
        if REQUISITION.CanGrant(p) then
            Notify(p, ply:Nick().." is requesting a "..vName..". Open !vrconfig.","info")
        end
    end
    BroadcastRequests()
    local delay = REQUISITION.Options.AutoDenyTime or 0
    if delay > 0 then
        timer.Simple(delay, function()
            if REQUISITION.Requests[id] then
                local req = REQUISITION.Requests[id]
                REQUISITION.Requests[id] = nil
                if IsValid(req.ply) then Notify(req.ply,"Request timed out.","error") end
                BroadcastRequests()
            end
        end)
    end
end)

net.Receive("REQ_GrantRequest", function(_, ply)
    if not REQUISITION.CanGrant(ply) then return end
    local id  = net.ReadString()
    local req = REQUISITION.Requests[id]
    if not req then Notify(ply,"Request not found.","error"); return end
    REQUISITION.Requests[id] = nil
    if IsValid(req.ply) then
        DoSpawn(req.ply, req.vehicleKey, req.skin, req.loadout, req.spawnKey)
        Notify(ply,"Granted to "..req.ply:Nick()..".","success")
    else
        Notify(ply,"Player left.","error")
    end
    BroadcastRequests()
end)

net.Receive("REQ_DenyRequest", function(_, ply)
    if not REQUISITION.CanGrant(ply) then return end
    local id  = net.ReadString()
    local req = REQUISITION.Requests[id]
    if not req then Notify(ply,"Request not found.","error"); return end
    REQUISITION.Requests[id] = nil
    if IsValid(req.ply) then Notify(req.ply,"Your request was denied.","error") end
    Notify(ply,"Request denied.","info")
    BroadcastRequests()
end)

-- Player stores (removes) their vehicle
net.Receive("REQ_StoreVehicle", function(_, ply)
    local entIdx = net.ReadInt(32)
    local ent    = ents.GetByIndex(entIdx)
    if not IsValid(ent) then Notify(ply,"Vehicle not found.","error"); return end
    if not ent:GetNWBool("REQ_Requisitioned", false) then Notify(ply,"That is not a requisitioned vehicle.","error"); return end
    local owner = ent:GetNWEntity("REQ_Owner", NULL)
    if owner ~= ply and not REQUISITION.CanGrant(ply) then
        Notify(ply,"That is not your vehicle.","error"); return
    end
    local vName = ent:GetNWString("REQ_VehicleKey","")
    local vd    = REQUISITION.Vehicles[vName]
    ent:Remove()
    Notify(ply, (vd and vd.Name or "Vehicle").." has been stored.", "success")
    timer.Simple(0.1, function() if IsValid(ply) then SyncActiveVehicles(ply) end end)
end)

net.Receive("REQ_SaveOptions", function(_, ply)
    if not REQUISITION.CanGrant(ply) then return end
    local opts = util.JSONToTable(net.ReadString()) or {}
    for k, v in pairs(opts) do
        REQUISITION.Options[k] = (type(v)=="table" and v.r) and Color(v.r,v.g,v.b) or v
    end
    SaveOptions(); BroadcastAll(); SpawnVendors()
    Notify(ply,"Options saved.","success")
end)

net.Receive("REQ_AddVehicle", function(_, ply)
    if not REQUISITION.CanGrant(ply) then return end
    local vd  = util.JSONToTable(net.ReadString()) or {}
    local key = REQUISITION.GenerateKey()
    REQUISITION.Vehicles[key] = vd
    SaveVehicles(); BroadcastAll()
    Notify(ply,"Vehicle added.","success")
end)

net.Receive("REQ_SaveVehicle", function(_, ply)
    if not REQUISITION.CanGrant(ply) then return end
    local vd  = util.JSONToTable(net.ReadString()) or {}
    local key = vd.Key or REQUISITION.GenerateKey()
    vd.Key = nil
    REQUISITION.Vehicles[key] = vd
    SaveVehicles(); BroadcastAll()
    Notify(ply,"Vehicle saved.","success")
end)

net.Receive("REQ_DeleteVehicle", function(_, ply)
    if not REQUISITION.CanGrant(ply) then return end
    local key = net.ReadString()
    REQUISITION.Vehicles[key] = nil
    SaveVehicles(); BroadcastAll()
    Notify(ply,"Vehicle deleted.","success")
end)

net.Receive("REQ_SaveVendors", function(_, ply)
    if not REQUISITION.CanGrant(ply) then return end
    REQUISITION.Vendors = util.JSONToTable(net.ReadString()) or {}
    SaveVendors(); SpawnVendors(); BroadcastAll()
    Notify(ply,"Vendors saved.","success")
end)

-- Save spawn points
net.Receive("REQ_SaveSpawns", function(_, ply)
    if not REQUISITION.CanGrant(ply) then return end
    REQUISITION.Spawns = util.JSONToTable(net.ReadString()) or {}
    SaveSpawns(); BroadcastAll()
    Notify(ply,"Spawn points saved.","success")
end)

-- ── Chat commands ─────────────────────────────────────────────────────────────

hook.Add("PlayerSay", "REQ_Chat", function(ply, text)
    local cmd = string.lower(string.Trim(text))
    local cfg = "!" .. string.lower(REQUISITION.Options.ConfigCommand or "vrconfig")
    local sav = "!" .. string.lower(REQUISITION.Options.SaveCommand   or "vrsave")
    if cmd == cfg then
        if REQUISITION.CanGrant(ply) then
            SyncOpts(ply); SyncVehs(ply); SyncVens(ply); SyncSpawns(ply); BroadcastRequests()
            net.Start("REQ_OpenAdminMenu"); net.Send(ply)
        else Notify(ply,"No permission.","error") end
        return ""
    elseif cmd == sav then
        if REQUISITION.CanGrant(ply) then
            local vendors = {}
            for _, e in ipairs(SpawnedVendors) do
                if IsValid(e) then
                    local p, a = e:GetPos(), e:GetAngles()
                    table.insert(vendors, {pos={p.x,p.y,p.z}, ang={a.p,a.y,a.r}})
                end
            end
            REQUISITION.Vendors = vendors
            SaveVendors(); BroadcastAll()
            Notify(ply,"Saved "..#vendors.." vendor(s).","success")
        end
        return ""
    end
end)

-- ── Init ─────────────────────────────────────────────────────────────────────

hook.Add("Initialize", "REQ_Init", function()
    EnsureDir()
    local opts = LoadJSON(OPT_FILE)
    for k, v in pairs(opts) do
        REQUISITION.Options[k] = (type(v)=="table" and v.r) and Color(v.r,v.g,v.b) or v
    end
    REQUISITION.Vehicles = LoadJSON(VEH_FILE)
    REQUISITION.Vendors  = LoadJSON(VEN_FILE)
    REQUISITION.Spawns   = LoadJSON(SPN_FILE)

    if not next(REQUISITION.Vehicles) then
        REQUISITION.Vehicles["veh_default_iftx"] = {
            Name="IFT-X", Category="Tanks", Class="lvs_fakehover_iftx",
            Model="models/LVS/fakehover/iftx.mdl",
            Price=0, MaxAmount=0, EnableRequests=true, RequestTeams={},
            DefaultSkin=0, Skins={}, Loadouts={},
        }
        SaveVehicles()
        print("[Requisition] Default vehicle IFT-X seeded.")
    end

    timer.Simple(2, SpawnVendors)
end)

hook.Add("PlayerInitialSpawn", "REQ_NewPlayer", function(ply)
    timer.Simple(2, function()
        if not IsValid(ply) then return end
        SyncOpts(ply); SyncVehs(ply); SyncSpawns(ply)
        if REQUISITION.CanGrant(ply) then SyncVens(ply); BroadcastRequests() end
    end)
end)
