-- Requisition - single autorun entry point

AddCSLuaFile("requisition/shared/sh_core.lua")
AddCSLuaFile("requisition/client/cl_core.lua")
AddCSLuaFile("requisition/client/cl_menu.lua")
AddCSLuaFile("requisition/client/cl_admin.lua")

if SERVER then
    include("requisition/shared/sh_core.lua")
    include("requisition/server/sv_core.lua")
end
if CLIENT then
    include("requisition/shared/sh_core.lua")
    include("requisition/client/cl_core.lua")
    include("requisition/client/cl_menu.lua")
    include("requisition/client/cl_admin.lua")
end
