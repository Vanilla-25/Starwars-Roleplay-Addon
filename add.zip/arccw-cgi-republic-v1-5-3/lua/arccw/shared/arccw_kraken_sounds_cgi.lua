sound.Add( {
    name = "ArcCW_Kraken.Ironsight",
    channel = CHAN_ITEM + 6,
    volume = 0.5,
    level = 70,
    pitch = {90, 115},
    sound = {
        "weapon_hand/ads/0242-00001a48.mp3",
        "weapon_hand/ads/0242-00001a47.mp3",
        "weapon_hand/ads/0242-00001a46.mp3",
        "weapon_hand/ads/0242-00001a45.mp3",
        "weapon_hand/ads/0242-00001a44.mp3",
        "weapon_hand/ads/0242-00001a43.mp3",
        "weapon_hand/ads/0242-00001a42.mp3",
        "weapon_hand/ads/0242-00001a41.mp3",
        "weapon_hand/ads/0242-00001a40.mp3",
        "weapon_hand/ads/0242-0000195e.mp3",
        "weapon_hand/ads/0242-0000195d.mp3",
        "weapon_hand/ads/0242-0000195c.mp3",
        "weapon_hand/ads/0242-0000192e.mp3",
    }
} )

sound.Add( {
    name = "ArcCW_Kraken.Overheat",
    channel = CHAN_WEAPON + 6,
    volume = 0.5,
    level = 70,
    pitch = {90, 115},
    sound = {
        "shared/overheat/overheat_1.wav",
        "shared/overheat/overheat_2.wav",
        "shared/overheat/overheat_3.wav",
        "shared/overheat/overheat_4.wav",
        "shared/overheat/overheat_5.wav",
        "shared/overheat/overheat_6.wav",
        "shared/overheat/overheat_7.wav",
        "shared/overheat/overheat_8.wav",
        "shared/overheat/overheat_9.wav",
        "shared/overheat/overheat_10.wav",
        "shared/overheat/overheat_11.wav",
        "shared/overheat/overheat_12.wav",
        "shared/overheat/overheat_13.wav",
        "shared/overheat/overheat_14.wav",
        "shared/overheat/overheat_15.wav",
        "shared/overheat/overheat_16.wav",
        "shared/overheat/overheat_17.wav",
        "shared/overheat/overheat_18.wav",
        "shared/overheat/overheat_19.wav",
        "shared/overheat/overheat_20.wav",
        "shared/overheat/overheat_21.wav",
    }
} )

sound.Add( {
    name = "ArcCW_Kraken.OverheatFix",
    channel = CHAN_WEAPON + 6,
    volume = 0.5,
    level = 70,
    pitch = {90, 115},
    sound = {
        "shared/overheat/overheat_replenished_1.wav",
        "shared/overheat/overheat_replenished_2.wav",
        "shared/overheat/overheat_replenished_3.wav",
        "shared/overheat/overheat_replenished_4.wav",
        "shared/overheat/overheat_replenished_5.wav",
    }
} )

sound.Add( {
    name = "ArcCW_Kraken.OverheatReplenished",
    channel = CHAN_WEAPON + 6,
    volume = 0.5,
    level = 70,
    pitch = {90, 115},
    sound = {
        "shared/overheat/overheat_replenished_1.wav",
        "shared/overheat/overheat_replenished_2.wav",
        "shared/overheat/overheat_replenished_3.wav",
        "shared/overheat/overheat_replenished_4.wav",
        "shared/overheat/overheat_replenished_5.wav",
    }
} )

sound.Add( {
    name = "ArcCW_Kraken.OverheatWarn",
    channel = CHAN_ITEM + 6,
    volume = 0.5,
    level = 70,
    pitch = {90, 115},
    sound = {
        "shared/overheat/overheat_warning_1.wav",
        "shared/overheat/overheat_warning_2.wav",
        "shared/overheat/overheat_warning_3.wav",
        "shared/overheat/overheat_warning_4.wav",
        "shared/overheat/overheat_warning_5.wav",
    }
} )

-- Weapons
sound.Add( {
    name = "ARCCW_Kraken.SW_B2HAND",
    channel = CHAN_WEAPON or 1,
    volume = 0.5,
    level = 75,
    pitch = {95, 105},
    sound = {
        "kraken/cgi/republic/b2/sw01_weapons_blasters_e5-b2_laser_close_var_01_01.wav",
        "kraken/cgi/republic/b2/sw01_weapons_blasters_e5-b2_laser_close_var_01_02.wav",
        "kraken/cgi/republic/b2/sw01_weapons_blasters_e5-b2_laser_close_var_01_03.wav",
        "kraken/cgi/republic/b2/sw01_weapons_blasters_e5-b2_laser_close_var_01_04.wav",
        "kraken/cgi/republic/b2/sw01_weapons_blasters_e5-b2_laser_close_var_01_05.wav",
        "kraken/cgi/republic/b2/sw01_weapons_blasters_e5-b2_laser_close_var_01_05.wav",
    }
} )
sound.Add( {
    name = "ARCCW_Kraken.SW_HEALINGDARTS",
    channel = CHAN_WEAPON or 1,
    volume = 0.5,
    level = 75,
    pitch = {95, 105},
    sound = {
        "kraken/cgi/republic/heal/combatheal_var_01.mp3",
        "kraken/cgi/republic/heal/combatheal_var_02.mp3",
        "kraken/cgi/republic/heal/combatheal_var_03.mp3",
        "kraken/cgi/republic/heal/combatheal_var_04.mp3",
        "kraken/cgi/republic/heal/combatheal_var_05.mp3",
        "kraken/cgi/republic/heal/combatheal_var_06.mp3",
        "kraken/cgi/republic/heal/combatheal_var_07.mp3",
        "kraken/cgi/republic/heal/combatheal_var_08.mp3",
    }
} )
sound.Add( {
    name = "ARCCW_Kraken.SW_E5C",
    channel = CHAN_WEAPON or 1,
    volume = 0.5,
    level = 75,
    pitch = {95, 105},
    sound = {
        "kraken/cgi/republic/e5c/sw02_weapons_blasters_e-5c_laser_close_var_02_01.wav",
        "kraken/cgi/republic/e5c/sw02_weapons_blasters_e-5c_laser_close_var_02_02.wav",
        "kraken/cgi/republic/e5c/sw02_weapons_blasters_e-5c_laser_close_var_02_03.wav",
        "kraken/cgi/republic/e5c/sw02_weapons_blasters_e-5c_laser_close_var_02_04.wav",
        "kraken/cgi/republic/e5c/sw02_weapons_blasters_e-5c_laser_close_var_02_05.wav",
        "kraken/cgi/republic/e5c/sw02_weapons_blasters_e-5c_laser_close_var_02_06.wav",
        "kraken/cgi/republic/e5c/sw02_weapons_blasters_e-5c_laser_close_var_02_07.wav",
    }
} )
sound.Add( {
    name = "ARCCW_Kraken.SW_E5C_DISTANT",
    channel = ArcCW.CHAN_DISTANT or 136,
    volume = 0.5,
    level = 100,
    pitch = {95, 105},
    sound = {
        "kraken/cgi/republic/e5c/sw02_weapons_blasters_e-5c_laser_distant_var_01_01.wav",
        "kraken/cgi/republic/e5c/sw02_weapons_blasters_e-5c_laser_distant_var_01_02.wav",
        "kraken/cgi/republic/e5c/sw02_weapons_blasters_e-5c_laser_distant_var_01_03.wav",
        "kraken/cgi/republic/e5c/sw02_weapons_blasters_e-5c_laser_distant_var_01_04.wav",
        "kraken/cgi/republic/e5c/sw02_weapons_blasters_e-5c_laser_distant_var_01_05.wav",
        "kraken/cgi/republic/e5c/sw02_weapons_blasters_e-5c_laser_distant_var_01_06.wav",
    }
} )
sound.Add( {
    name = "ARCCW_Kraken.SW_E5S",
    channel = CHAN_WEAPON or 1,
    volume = 0.5,
    level = 75,
    pitch = {95, 105},
    sound = {
        "kraken/cgi/republic/e5s/sw02_weapons_blasters_e5s_laser_close_var_01_01.wav",
        "kraken/cgi/republic/e5s/sw02_weapons_blasters_e5s_laser_close_var_01_02.wav",
        "kraken/cgi/republic/e5s/sw02_weapons_blasters_e5s_laser_close_var_01_03.wav",
        "kraken/cgi/republic/e5s/sw02_weapons_blasters_e5s_laser_close_var_01_04.wav",
        "kraken/cgi/republic/e5s/sw02_weapons_blasters_e5s_laser_close_var_01_05.wav",
    }
} )
sound.Add( {
    name = "ARCCW_Kraken.SW_SB2",
    channel = CHAN_WEAPON or 1,
    volume = 0.5,
    level = 75,
    pitch = {95, 105},
    sound = {
        "kraken/cgi/republic/sb2/sb2.wav",
        "kraken/cgi/republic/sb2/sb2.wav",
        "kraken/cgi/republic/sb2/sb2.wav",
        "kraken/cgi/republic/sb2/sb2.wav",
    }
} )
sound.Add( {
    name = "ARCCW_Kraken.SW_E5BX",
    channel = CHAN_WEAPON or 1,
    volume = 0.5,
    level = 75,
    pitch = {95, 105},
    sound = {
        "kraken/cgi/republic/e-5/sw02_weapons_blasters_e5_bx_laser_close_var_01_01.wav",
        "kraken/cgi/republic/e-5/sw02_weapons_blasters_e5_bx_laser_close_var_01_02.wav",
        "kraken/cgi/republic/e-5/sw02_weapons_blasters_e5_bx_laser_close_var_01_03.wav",
        "kraken/cgi/republic/e-5/sw02_weapons_blasters_e5_bx_laser_close_var_01_04.wav",
        "kraken/cgi/republic/e-5/sw02_weapons_blasters_e5_bx_laser_close_var_01_05.wav",
    }
} )
sound.Add( {
    name = "ARCCW_Kraken.SW_RG4D",
    channel = CHAN_WEAPON or 1,
    volume = 0.5,
    level = 75,
    pitch = {95, 105},
    sound = {
        "kraken/cgi/republic/rg-4d/sw02_weapons_blasters_rg-4d_laser_close_var_01_01.wav",
        "kraken/cgi/republic/rg-4d/sw02_weapons_blasters_rg-4d_laser_close_var_01_02.wav",
        "kraken/cgi/republic/rg-4d/sw02_weapons_blasters_rg-4d_laser_close_var_01_03.wav",
        "kraken/cgi/republic/rg-4d/sw02_weapons_blasters_rg-4d_laser_close_var_01_04.wav",
        "kraken/cgi/republic/rg-4d/sw02_weapons_blasters_rg-4d_laser_close_var_01_05.wav",
        "kraken/cgi/republic/rg-4d/sw02_weapons_blasters_rg-4d_laser_close_var_01_06.wav",
        "kraken/cgi/republic/rg-4d/sw02_weapons_blasters_rg-4d_laser_close_var_01_07.wav",
        "kraken/cgi/republic/rg-4d/sw02_weapons_blasters_rg-4d_laser_close_var_01_08.wav",
        "kraken/cgi/republic/rg-4d/sw02_weapons_blasters_rg-4d_laser_close_var_01_09.wav",
        "kraken/cgi/republic/rg-4d/sw02_weapons_blasters_rg-4d_laser_close_var_01_10.wav",
        "kraken/cgi/republic/rg-4d/sw02_weapons_blasters_rg-4d_laser_close_var_01_11.wav",
        "kraken/cgi/republic/rg-4d/sw02_weapons_blasters_rg-4d_laser_close_var_01_12.wav",
    }
} )
sound.Add( {
    name = "ARCCW_Kraken.SW_E5",
    channel = CHAN_WEAPON or 1,
    volume = 0.5,
    level = 75,
    pitch = {95, 105},
    sound = {
        "kraken/cgi/republic/e-5/sw02_weapons_blasters_e5_laser_close_var_04_01.wav",
        "kraken/cgi/republic/e-5/sw02_weapons_blasters_e5_laser_close_var_04_02.wav",
        "kraken/cgi/republic/e-5/sw02_weapons_blasters_e5_laser_close_var_04_03.wav",
        "kraken/cgi/republic/e-5/sw02_weapons_blasters_e5_laser_close_var_04_04.wav",
        "kraken/cgi/republic/e-5/sw02_weapons_blasters_e5_laser_close_var_04_05.wav",
        "kraken/cgi/republic/e-5/sw02_weapons_blasters_e5_laser_close_var_04_06.wav",
    }
} )
sound.Add( {
    name = "ARCCW_Kraken.SW_E5_Distant",
    channel = ArcCW.CHAN_DISTANT or 136,
    volume = 0.5,
    level = 75,
    pitch = {95, 105},
    sound = {
        "kraken/cgi/republic/e-5/sw02_weapons_blasters_e5_laser_distant_var_01_01.wav",
        "kraken/cgi/republic/e-5/sw02_weapons_blasters_e5_laser_distant_var_01_02.wav",
        "kraken/cgi/republic/e-5/sw02_weapons_blasters_e5_laser_distant_var_01_03.wav",
        "kraken/cgi/republic/e-5/sw02_weapons_blasters_e5_laser_distant_var_01_04.wav",
        "kraken/cgi/republic/e-5/sw02_weapons_blasters_e5_laser_distant_var_01_05.wav",
        "kraken/cgi/republic/e-5/sw02_weapons_blasters_e5_laser_distant_var_01_06.wav",
    }
} )
sound.Add( {
    name = "ARCCW_Kraken.SW_DC15SA",
    channel = CHAN_WEAPON or 1,
    volume = 0.5,
    level = 75,
    pitch = {95, 105},
    sound = {
        "kraken/cgi/republic/dc15sa/dc15sa.wav",
        "kraken/cgi/republic/dc15sa/dc15sa.wav",
        "kraken/cgi/republic/dc15sa/dc15sa.wav",
        "kraken/cgi/republic/dc15sa/dc15sa.wav",
    }
} )
sound.Add( {
    name = "ARCCW_Kraken.SW_E9",
    channel = CHAN_WEAPON or 1,
    volume = 0.5,
    level = 75,
    pitch = {95, 105},
    sound = {
        "kraken/cgi/republic/e-series/e11.wav",
        "kraken/cgi/republic/e-series/e11.wav",
        "kraken/cgi/republic/e-series/e11.wav",
        "kraken/cgi/republic/e-series/e11.wav",
        "kraken/cgi/republic/e-series/e11.wav",
        "kraken/cgi/republic/e-series/e11.wav",
    }
} )

sound.Add( {
    name = "ARCCW_Kraken.SW_DC17M_SNIPER",
    channel = CHAN_WEAPON or 1,
    volume = 0.5,
    level = 75,
    pitch = {95, 105},
    sound = {
        "kraken/cgi/republic/dc17m_sniper_fire0.wav",
        "kraken/cgi/republic/dc17m_sniper_fire0.wav",
        "kraken/cgi/republic/dc17m_sniper_fire0.wav",
        "kraken/cgi/republic/dc17m_sniper_fire0.wav",
        "kraken/cgi/republic/dc17m_sniper_fire0.wav",
        "kraken/cgi/republic/dc17m_sniper_fire0.wav",
    }
} )
sound.Add( {
    name = "ARCCW_Kraken.SW_DC17",
    channel = CHAN_WEAPON or 1,
    volume = 0.5,
    level = 75,
    pitch = {95, 105},
    sound = {
        "kraken/cgi/republic/dc17/sw02_weapons_blasters_dc17_laser_close_var_07_01.wav",
        "kraken/cgi/republic/dc17/sw02_weapons_blasters_dc17_laser_close_var_07_02.wav",
        "kraken/cgi/republic/dc17/sw02_weapons_blasters_dc17_laser_close_var_07_03.wav",
        "kraken/cgi/republic/dc17/sw02_weapons_blasters_dc17_laser_close_var_07_04.wav",
        "kraken/cgi/republic/dc17/sw02_weapons_blasters_dc17_laser_close_var_07_05.wav",
        "kraken/cgi/republic/dc17/sw02_weapons_blasters_dc17_laser_close_var_07_06.wav",
        "kraken/cgi/republic/dc17/sw02_weapons_blasters_dc17_laser_close_var_07_07.wav",
        "kraken/cgi/republic/dc17/sw02_weapons_blasters_dc17_laser_close_var_07_08.wav",
        "kraken/cgi/republic/dc17/sw02_weapons_blasters_dc17_laser_close_var_07_09.wav"
    }
} )


sound.Add( {
    name = "ARCCW_Kraken.SW_DC17MS_Close",
    channel = CHAN_WEAPON or 1,
    level = 75,
    volume = 0.5,
    pitch = {80,100},
    sound = {
        "kraken/cgi/republic/dc17m_sniper_fire0.wav",
        "kraken/cgi/republic/dc17m_sniper_fire0.wav",
    }
} )

sound.Add( {
    name = "ARCCW_Kraken.SW_DC17MS_Distant",
    channel = ArcCW.CHAN_DISTANT or 136,
    level = 100,
    pitch = {80,110},
    volume = 0.5,
    sound = {
        "kraken/cgi/republic/dc17m_sniper_fire0.wav",
        "kraken/cgi/republic/dc17m_sniper_fire0.wav",
    }
} )

sound.Add( {
    name = "ARCCW_Kraken.SW_DC17M_Close",
    channel = CHAN_WEAPON or 1,
    level = 75,
    volume = 0.5,
    pitch = {80,100},
    sound = {
        "kraken/cgi/republic/dc17m/sw02_weapons_blasters_dc17m_laser_close_var_01_01.wav",
        "kraken/cgi/republic/dc17m/sw02_weapons_blasters_dc17m_laser_close_var_01_02.wav",
        "kraken/cgi/republic/dc17m/sw02_weapons_blasters_dc17m_laser_close_var_01_03.wav",
        "kraken/cgi/republic/dc17m/sw02_weapons_blasters_dc17m_laser_close_var_01_04.wav",
        "kraken/cgi/republic/dc17m/sw02_weapons_blasters_dc17m_laser_close_var_01_05.wav",
        "kraken/cgi/republic/dc17m/sw02_weapons_blasters_dc17m_laser_close_var_01_06.wav",
        "kraken/cgi/republic/dc17m/sw02_weapons_blasters_dc17m_laser_close_var_01_07.wav",
        "kraken/cgi/republic/dc17m/sw02_weapons_blasters_dc17m_laser_close_var_01_08.wav",
        "kraken/cgi/republic/dc17m/sw02_weapons_blasters_dc17m_laser_close_var_01_09.wav",
    }
} )

sound.Add( {
    name = "ARCCW_Kraken.SW_DC17M_Distant",
    channel = ArcCW.CHAN_DISTANT or 136,
    level = 100,
    pitch = {80,110},
    volume = 0.5,
    sound = {
        "kraken/cgi/republic/dc17m/sw02_weapons_blasters_dc17m_laser_distant_var_01_01.wav",
        "kraken/cgi/republic/dc17m/sw02_weapons_blasters_dc17m_laser_distant_var_01_02.wav",
        "kraken/cgi/republic/dc17m/sw02_weapons_blasters_dc17m_laser_distant_var_01_03.wav",
        "kraken/cgi/republic/dc17m/sw02_weapons_blasters_dc17m_laser_distant_var_01_04.wav",
        "kraken/cgi/republic/dc17m/sw02_weapons_blasters_dc17m_laser_distant_var_01_05.wav",
        "kraken/cgi/republic/dc17m/sw02_weapons_blasters_dc17m_laser_distant_var_01_06.wav",
        "kraken/cgi/republic/dc17m/sw02_weapons_blasters_dc17m_laser_distant_var_01_07.wav",
        "kraken/cgi/republic/dc17m/sw02_weapons_blasters_dc17m_laser_distant_var_01_08.wav",
        "kraken/cgi/republic/dc17m/sw02_weapons_blasters_dc17m_laser_distant_var_01_09.wav",
    }
} )

sound.Add( {
    name = "ARCCW_Kraken.SW_DC15A",
    channel = CHAN_WEAPON or 1,
    volume = 0.5,
    level = 75,
    pitch = {95, 105},
    sound = {
        "kraken/cgi/republic/dc15/sw02_weapons_blasters_dc15_laser_close_var_03_01.wav",
        "kraken/cgi/republic/dc15/sw02_weapons_blasters_dc15_laser_close_var_03_02.wav",
        "kraken/cgi/republic/dc15/sw02_weapons_blasters_dc15_laser_close_var_03_03.wav",
        "kraken/cgi/republic/dc15/sw02_weapons_blasters_dc15_laser_close_var_03_04.wav",
        "kraken/cgi/republic/dc15/sw02_weapons_blasters_dc15_laser_close_var_03_05.wav",
        "kraken/cgi/republic/dc15/sw02_weapons_blasters_dc15_laser_close_var_03_06.wav",
        "kraken/cgi/republic/dc15/sw02_weapons_blasters_dc15_laser_close_var_03_07.wav",
        "kraken/cgi/republic/dc15/sw02_weapons_blasters_dc15_laser_close_var_03_08.wav",
        "kraken/cgi/republic/dc15/sw02_weapons_blasters_dc15_laser_close_var_03_09.wav"
    }
} )

sound.Add( {
    name = "ARCCW_Kraken.SW_DC15S",
    channel = CHAN_WEAPON or 1,
    volume = 0.5,
    level = 75,
    pitch = {95, 105},
    sound = {
        "kraken/cgi/republic/e11/sw02_weapons_blasters_e11_laser_close_var_08_01.wav",
        "kraken/cgi/republic/e11/sw02_weapons_blasters_e11_laser_close_var_08_02.wav",
        "kraken/cgi/republic/e11/sw02_weapons_blasters_e11_laser_close_var_08_03.wav",
        "kraken/cgi/republic/e11/sw02_weapons_blasters_e11_laser_close_var_08_04.wav",
        "kraken/cgi/republic/e11/sw02_weapons_blasters_e11_laser_close_var_08_05.wav",
        "kraken/cgi/republic/e11/sw02_weapons_blasters_e11_laser_close_var_08_06.wav",
        "kraken/cgi/republic/e11/sw02_weapons_blasters_e11_laser_close_var_08_07.wav",
        "kraken/cgi/republic/e11/sw02_weapons_blasters_e11_laser_close_var_08_08.wav",
        "kraken/cgi/republic/e11/sw02_weapons_blasters_e11_laser_close_var_08_09.wav"
    }
} )

sound.Add( {
    name = "ARCCW_Kraken.SW_DC15S_Distant",
    channel = ArcCW.CHAN_DISTANT or 136,
    level = 100,
    pitch = {80,110},
    volume = 0.5,
    sound = {
        "kraken/cgi/republic/e11/sw02_weapons_blasters_e11_laser_distant_var_06_01.wav",
        "kraken/cgi/republic/e11/sw02_weapons_blasters_e11_laser_distant_var_06_02.wav",
        "kraken/cgi/republic/e11/sw02_weapons_blasters_e11_laser_distant_var_06_03.wav",
        "kraken/cgi/republic/e11/sw02_weapons_blasters_e11_laser_distant_var_06_04.wav",
        "kraken/cgi/republic/e11/sw02_weapons_blasters_e11_laser_distant_var_06_05.wav",
        "kraken/cgi/republic/e11/sw02_weapons_blasters_e11_laser_distant_var_06_06.wav",
        "kraken/cgi/republic/e11/sw02_weapons_blasters_e11_laser_distant_var_06_07.wav",
        "kraken/cgi/republic/e11/sw02_weapons_blasters_e11_laser_distant_var_06_08.wav",
        "kraken/cgi/republic/e11/sw02_weapons_blasters_e11_laser_distant_var_06_09.wav"
    }
} )

sound.Add( {
    name = "ARCCW_Kraken.SW_DC15X",
    channel = CHAN_WEAPON or 1,
    volume = 0.5,
    level = 75,
    pitch = {95, 105},
    sound = {
        "kraken/cgi/republic/dlt19x/sw02_weapons_blaster_dlt19x_laser_close_var_01_01.wav",
        "kraken/cgi/republic/dlt19x/sw02_weapons_blaster_dlt19x_laser_close_var_01_02.wav",
        "kraken/cgi/republic/dlt19x/sw02_weapons_blaster_dlt19x_laser_close_var_01_03.wav",
        "kraken/cgi/republic/dlt19x/sw02_weapons_blaster_dlt19x_laser_close_var_01_04.wav",
    }
} )

sound.Add( {
    name = "ARCCW_Kraken.SW_DLT19_Close",
    channel = CHAN_WEAPON or 1,
    level = 75,
    volume = 0.6,
    pitch = {80,100},
    sound = {
        "kraken/cgi/republic/dlt19/sw02_weapons_blasters_dlt19_laser_close_var_02_01.wav",
        "kraken/cgi/republic/dlt19/sw02_weapons_blasters_dlt19_laser_close_var_02_02.wav",
        "kraken/cgi/republic/dlt19/sw02_weapons_blasters_dlt19_laser_close_var_02_03.wav",
        "kraken/cgi/republic/dlt19/sw02_weapons_blasters_dlt19_laser_close_var_02_04.wav",
        "kraken/cgi/republic/dlt19/sw02_weapons_blasters_dlt19_laser_close_var_02_05.wav",
        "kraken/cgi/republic/dlt19/sw02_weapons_blasters_dlt19_laser_close_var_02_06.wav",
        "kraken/cgi/republic/dlt19/sw02_weapons_blasters_dlt19_laser_close_var_02_07.wav",
        "kraken/cgi/republic/dlt19/sw02_weapons_blasters_dlt19_laser_close_var_02_08.wav",
        "kraken/cgi/republic/dlt19/sw02_weapons_blasters_dlt19_laser_close_var_02_09.wav",
    }
} )

sound.Add( {
    name = "ARCCW_Kraken.SW_DLT19_Distant",
    channel = ArcCW.CHAN_DISTANT or 136,
    level = 100,
    pitch = {80,110},
    volume = 0.6,
    sound = {
        "kraken/cgi/republic/dlt19/sw02_weapons_blasters_dlt19_laser_distant_var_04_01.wav",
        "kraken/cgi/republic/dlt19/sw02_weapons_blasters_dlt19_laser_distant_var_04_02.wav",
        "kraken/cgi/republic/dlt19/sw02_weapons_blasters_dlt19_laser_distant_var_04_03.wav",
        "kraken/cgi/republic/dlt19/sw02_weapons_blasters_dlt19_laser_distant_var_04_04.wav",
        "kraken/cgi/republic/dlt19/sw02_weapons_blasters_dlt19_laser_distant_var_04_05.wav",
        "kraken/cgi/republic/dlt19/sw02_weapons_blasters_dlt19_laser_distant_var_04_06.wav",
        "kraken/cgi/republic/dlt19/sw02_weapons_blasters_dlt19_laser_distant_var_04_07.wav",
        "kraken/cgi/republic/dlt19/sw02_weapons_blasters_dlt19_laser_distant_var_04_08.wav",
    }
} )


sound.Add( {
    name = "ARCCW_Kraken.SW_DC15X_Distant",
    channel = ArcCW.CHAN_DISTANT or 136,
    level = 100,
    pitch = {80,110},
    volume = 0.5,
    sound = {
        "kraken/cgi/republic/dlt19x/sw02_weapons_blaster_dlt19x_laser_distant_var_01_01.wav",
        "kraken/cgi/republic/dlt19x/sw02_weapons_blaster_dlt19x_laser_distant_var_01_02.wav",
        "kraken/cgi/republic/dlt19x/sw02_weapons_blaster_dlt19x_laser_distant_var_01_04.wav",
        "kraken/cgi/republic/dlt19x/sw02_weapons_blaster_dlt19x_laser_distant_var_01_03.wav",
    }
} )

sound.Add( {
    name = "ARCCW_Kraken.SW_DC15SA",
    channel = CHAN_WEAPON or 1,
    volume = 0.5,
    level = 75,
    pitch = {95, 105},
    sound = {
        "kraken/cgi/republic/dc15sa/dc15sa.wav",
        "kraken/cgi/republic/dc15sa/dc15sa.wav",
    }
} )

sound.Add( {
    name = "ARCCW_Kraken.SW_DC15SA_Distant",
    channel = ArcCW.CHAN_DISTANT or 136,
    level = 100,
    pitch = {80,110},
    volume = 0.5,
    sound = {
        "kraken/cgi/republic/dc15sa/dc15sa.wav",
        "kraken/cgi/republic/dc15sa/dc15sa.wav",
    }
} )

sound.Add( {
    name = "ARCCW_Kraken.SW_DP23",
    channel = CHAN_WEAPON or 1,
    volume = 0.5,
    level = 75,
    pitch = {95, 105},
    sound = {
        "kraken/cgi/republic/dp23.wav",
        "kraken/cgi/republic/dp23.wav",
        "kraken/cgi/republic/dp23.wav",
        "kraken/cgi/republic/dp23.wav",
    }
} )

sound.Add( {
    name = "ARCCW_Kraken.SW_DP23_Distant",
    channel = ArcCW.CHAN_DISTANT or 136,
    level = 100,
    pitch = {80,110},
    volume = 0.5,
    sound = {
        "kraken/cgi/republic/scattergun/sw02_weapons_blaster_scattergun_altfire_laser_distant_var_02_05.wav",
        "kraken/cgi/republic/scattergun/sw02_weapons_blaster_scattergun_altfire_laser_distant_var_02_04.wav",
        "kraken/cgi/republic/scattergun/sw02_weapons_blaster_scattergun_altfire_laser_distant_var_02_03.wav",
        "kraken/cgi/republic/scattergun/sw02_weapons_blaster_scattergun_altfire_laser_distant_var_02_02.wav",
        "kraken/cgi/republic/scattergun/sw02_weapons_blaster_scattergun_altfire_laser_distant_var_02_01.wav",
    }
} )

sound.Add( {
    name = "ARCCW_Kraken.SW_Z6",
    channel = CHAN_WEAPON or 1,
    volume = 0.5,
    level = 75,
    pitch = {95, 105},
    sound = {
        "kraken/cgi/republic/z6rotaryblaster/sw02_blasters_z6rotaryblaster_laser_close_var_01_01.wav",
        "kraken/cgi/republic/z6rotaryblaster/sw02_blasters_z6rotaryblaster_laser_close_var_01_02.wav",
        "kraken/cgi/republic/z6rotaryblaster/sw02_blasters_z6rotaryblaster_laser_close_var_01_03.wav",
        "kraken/cgi/republic/z6rotaryblaster/sw02_blasters_z6rotaryblaster_laser_close_var_01_04.wav",
        "kraken/cgi/republic/z6rotaryblaster/sw02_blasters_z6rotaryblaster_laser_close_var_01_05.wav",
        "kraken/cgi/republic/z6rotaryblaster/sw02_blasters_z6rotaryblaster_laser_close_var_01_06.wav",
        "kraken/cgi/republic/z6rotaryblaster/sw02_blasters_z6rotaryblaster_laser_close_var_01_07.wav",
        "kraken/cgi/republic/z6rotaryblaster/sw02_blasters_z6rotaryblaster_laser_close_var_01_08.wav",

    }
} )

sound.Add( {
    name = "ARCCW_Kraken.SW_Z6_Distant",
    channel = ArcCW.CHAN_DISTANT or 136,
    level = 100,
    pitch = {80,110},
    volume = 0.5,
    sound = {
        "kraken/cgi/republic/z6rotaryblaster/sw02_blasters_z6rotaryblaster_laser_distant_var_01_01.wav",
        "kraken/cgi/republic/z6rotaryblaster/sw02_blasters_z6rotaryblaster_laser_distant_var_01_02.wav",
        "kraken/cgi/republic/z6rotaryblaster/sw02_blasters_z6rotaryblaster_laser_distant_var_01_03.wav",
        "kraken/cgi/republic/z6rotaryblaster/sw02_blasters_z6rotaryblaster_laser_distant_var_01_04.wav",
        "kraken/cgi/republic/z6rotaryblaster/sw02_blasters_z6rotaryblaster_laser_distant_var_01_05.wav",
        "kraken/cgi/republic/z6rotaryblaster/sw02_blasters_z6rotaryblaster_laser_distant_var_01_06.wav",
        "kraken/cgi/republic/z6rotaryblaster/sw02_blasters_z6rotaryblaster_laser_distant_var_01_07.wav",
        "kraken/cgi/republic/z6rotaryblaster/sw02_blasters_z6rotaryblaster_laser_distant_var_01_08.wav", 
    }
} )


sound.Add( {
    name = "ARCCW_Kraken.SW_DC17_Close",
    channel = CHAN_WEAPON or 1,
    level = 75,
    volume = 0.5,
    pitch = {80,100},
    sound = {
        "kraken/cgi/republic/dc17//sw02_weapons_blasters_dc17_laser_close_var_07_01.wav",
        "kraken/cgi/republic/dc17//sw02_weapons_blasters_dc17_laser_close_var_07_02.wav",
        "kraken/cgi/republic/dc17//sw02_weapons_blasters_dc17_laser_close_var_07_03.wav",
        "kraken/cgi/republic/dc17//sw02_weapons_blasters_dc17_laser_close_var_07_04.wav",
        "kraken/cgi/republic/dc17//sw02_weapons_blasters_dc17_laser_close_var_07_05.wav",
        "kraken/cgi/republic/dc17//sw02_weapons_blasters_dc17_laser_close_var_07_06.wav",
        "kraken/cgi/republic/dc17//sw02_weapons_blasters_dc17_laser_close_var_07_07.wav",
        "kraken/cgi/republic/dc17//sw02_weapons_blasters_dc17_laser_close_var_07_08.wav",
        "kraken/cgi/republic/dc17//sw02_weapons_blasters_dc17_laser_close_var_07_09.wav",
        "kraken/cgi/republic/dc17//sw02_weapons_blasters_dc17_laser_close_var_07_10.wav",
        "kraken/cgi/republic/dc17//sw02_weapons_blasters_dc17_laser_close_var_07_11.wav",
        "kraken/cgi/republic/dc17//sw02_weapons_blasters_dc17_laser_close_var_07_12.wav",
        "kraken/cgi/republic/dc17//sw02_weapons_blasters_dc17_laser_close_var_07_13.wav",
        "kraken/cgi/republic/dc17//sw02_weapons_blasters_dc17_laser_close_var_07_14.wav",
        "kraken/cgi/republic/dc17//sw02_weapons_blasters_dc17_laser_close_var_07_15.wav",
        "kraken/cgi/republic/dc17//sw02_weapons_blasters_dc17_laser_close_var_07_16.wav",
    }
} )

sound.Add( {
    name = "ARCCW_Kraken.SW_DC17_Distant",
    channel = ArcCW.CHAN_DISTANT or 136,
    level = 100,
    pitch = {80,110},
    volume = 0.5,
    sound = {
        "kraken/cgi/republic/dc17//sw02_weapons_blasters_dc17_laser_distant_var_01_01.wav",
        "kraken/cgi/republic/dc17//sw02_weapons_blasters_dc17_laser_distant_var_01_02.wav",
        "kraken/cgi/republic/dc17//sw02_weapons_blasters_dc17_laser_distant_var_01_03.wav",
        "kraken/cgi/republic/dc17//sw02_weapons_blasters_dc17_laser_distant_var_01_04.wav",
        "kraken/cgi/republic/dc17//sw02_weapons_blasters_dc17_laser_distant_var_01_05.wav",
        "kraken/cgi/republic/dc17//sw02_weapons_blasters_dc17_laser_distant_var_01_06.wav",
        "kraken/cgi/republic/dc17//sw02_weapons_blasters_dc17_laser_distant_var_01_07.wav",
        "kraken/cgi/republic/dc17//sw02_weapons_blasters_dc17_laser_distant_var_01_08.wav"
    }
} )
sound.Add( {
    name = "ARCCW_Kraken.SW_WESTAR",
    channel = CHAN_WEAPON or 1,
    volume = 0.5,
    level = 75,
    pitch = {95, 105},
    sound = {
        "kraken/cgi/republic/m5/m5.wav",
        "kraken/cgi/republic/m5/m5.wav",
        "kraken/cgi/republic/m5/m5.wav",
        "kraken/cgi/republic/m5/m5.wav",
    }
} )
sound.Add( {
    name = "ARCCW_Kraken.SW_WESTAR_Distant",
    channel = ArcCW.CHAN_DISTANT or 136,
    level = 100,
    pitch = {80,110},
    sound = {
        "kraken/cgi/republic/m5/m5.wav",
        "kraken/cgi/republic/m5/m5.wav",
        "kraken/cgi/republic/m5/m5.wav",
        "kraken/cgi/republic/m5/m5.wav",
    }
} )

sound.Add( {
    name = "ARCCW_Kraken.SW_X8_Close",
    channel = CHAN_WEAPON or 1,
    level = 75,
    volume = 0.6,
    pitch = {80,100},
    sound = {
        "kraken/cgi/republic/x8/sw02_weapons_blasters_x8_laser_close_var_01_01.wav",
        "kraken/cgi/republic/x8/sw02_weapons_blasters_x8_laser_close_var_01_02.wav",
        "kraken/cgi/republic/x8/sw02_weapons_blasters_x8_laser_close_var_01_03.wav",
        "kraken/cgi/republic/x8/sw02_weapons_blasters_x8_laser_close_var_01_04.wav",
        "kraken/cgi/republic/x8/sw02_weapons_blasters_x8_laser_close_var_01_05.wav",
        "kraken/cgi/republic/x8/sw02_weapons_blasters_x8_laser_close_var_01_06.wav",
    }
} )

sound.Add( {
    name = "ARCCW_Kraken.SW_X8_Distant",
    channel = ArcCW.CHAN_DISTANT or 136,
    level = 75,
    pitch = {80,110},
    volume = 0.6,
    sound = {
        "kraken/cgi/republic/x8/sw02_weapons_blasters_x8_laser_distant_var_01_01.wav",
        "kraken/cgi/republic/x8/sw02_weapons_blasters_x8_laser_distant_var_01_02.wav",
        "kraken/cgi/republic/x8/sw02_weapons_blasters_x8_laser_distant_var_01_03.wav",
        "kraken/cgi/republic/x8/sw02_weapons_blasters_x8_laser_distant_var_01_04.wav",
        "kraken/cgi/republic/x8/sw02_weapons_blasters_x8_laser_distant_var_01_05.wav",
        "kraken/cgi/republic/x8/sw02_weapons_blasters_x8_laser_distant_var_01_06.wav",
    }
} )

sound.Add( {
    name = "ARCCW_Kraken.SW_E11D_Close",
    channel = CHAN_WEAPON or 1,
    level = 75,
    volume = 0.6,
    pitch = {80,100},
    sound = {
        "kraken/cgi/republic/e-11d/sw02_weapons_blasters_e-11d_laser_close_var_01_01.wav",
        "kraken/cgi/republic/e-11d/sw02_weapons_blasters_e-11d_laser_close_var_01_02.wav",
        "kraken/cgi/republic/e-11d/sw02_weapons_blasters_e-11d_laser_close_var_01_03.wav",
        "kraken/cgi/republic/e-11d/sw02_weapons_blasters_e-11d_laser_close_var_01_04.wav",
        "kraken/cgi/republic/e-11d/sw02_weapons_blasters_e-11d_laser_close_var_01_05.wav",
        "kraken/cgi/republic/e-11d/sw02_weapons_blasters_e-11d_laser_close_var_01_06.wav",
    }
} )

sound.Add( {
    name = "ARCCW_Kraken.SW_E11D_Distant",
    channel = ArcCW.CHAN_DISTANT or 136,
    level = 75,
    pitch = {80,110},
    volume = 0.6,
    sound = {
        "kraken/cgi/republic/e-11d/sw02_weapons_blasters_e-11d_laser_distant_var_01_02.wav",
        "kraken/cgi/republic/e-11d/sw02_weapons_blasters_e-11d_laser_distant_var_01_02.wav",
        "kraken/cgi/republic/e-11d/sw02_weapons_blasters_e-11d_laser_distant_var_01_03.wav",
        "kraken/cgi/republic/e-11d/sw02_weapons_blasters_e-11d_laser_distant_var_01_04.wav",
        "kraken/cgi/republic/e-11d/sw02_weapons_blasters_e-11d_laser_distant_var_01_05.wav",
        "kraken/cgi/republic/e-11d/sw02_weapons_blasters_e-11d_laser_distant_var_01_06.wav",
    }
} )
