AddCSLuaFile()

SWEP.Base = "arccw_masita_base_updated"
SWEP.Spawnable = true

SWEP.Slot = 3

SWEP.Category = "[ArcCW] Kraken's CGI Essentials - Republic"
SWEP.Credits = "Kraken (Discord: @elbestiamasita)"
SWEP.PrintName = "Akimbo DC-17"
SWEP.Trivia_Class = "Blaster, Handblaster"
SWEP.Trivia_Desc = "The DC-17 repeater hand blaster was the Grand Army of the Republic's standard sidearm. It was reliable, powerful for its size, and commonly issued to officers and vehicle crews."
SWEP.Trivia_Manufacturer = "BlastTech Industries"
SWEP.Trivia_Calibre = "Laser Bolt"
SWEP.Trivia_Mechanism = "Condensed Tibanna-Gas"
SWEP.Trivia_Country = "Galactic Republic"
SWEP.IconOverride = "entities/arccw/kraken/cgi/17_dual.png"

SWEP.DefaultBodygroups = "000000000000"
SWEP.MirrorVMWM = false
SWEP.NoHideLeftHandInCustomization = true
SWEP.UseHands = true
SWEP.ViewModel = "models/kraken/cgi/v_cgi_dc17_akimbo.mdl"
SWEP.WorldModel = "models/kraken/cgi/world/w_cgi_dc17.mdl"

SWEP.ViewModelFOV = 65

SWEP.HideViewmodel = false
SWEP.WorldModelOffset = {
    pos = Vector(0, 0, 0),
    ang = Angle(0, 0, 0),
    bone = "ValveBiped.Bip01_R_Hand",
    scale = 0.09
}

SWEP.BodyDamageMults = {
    [HITGROUP_HEAD] = 2,
    [HITGROUP_CHEST] = 1.25,
    [HITGROUP_STOMACH] = 1.1,
    [HITGROUP_LEFTARM] = 1,
    [HITGROUP_RIGHTARM] = 1,
    [HITGROUP_LEFTLEG] = 0.75,
    [HITGROUP_RIGHTLEG] = 0.75,
}

-- DAMAGE (based on your sheet)
SWEP.Damage = 36
SWEP.DamageMin = 32
SWEP.RangeMin = 25
SWEP.Range = 100
SWEP.Penetration = 8
SWEP.DamageType = DMG_BULLET
SWEP.MuzzleVelocity = 2000

SWEP.TracerNum = 1
SWEP.TracerCol = Color(0,129,250)
SWEP.TracerWidth = 1
SWEP.Tracer = "new_tracer_blue"
SWEP.HullSize = 0.3

SWEP.AmmoPerShot = 1
SWEP.ChamberSize = 0
SWEP.Primary.ClipSize = 40

-- RECOIL (reduced to match recoil score idea)
SWEP.Recoil = 0.6
SWEP.RecoilSide = 0
SWEP.RecoilRise = 0.4
SWEP.Sway = 0.25

SWEP.RecoilPunch = 1
SWEP.RecoilVMShake = 1
SWEP.VisualRecoilMult = 1

-- FIRE RATE (380 RPM)
SWEP.Delay = 80 / 380

SWEP.Num = 1
SWEP.Firemode = 1
SWEP.Firemodes = {
    {
        Mode = 1,
    },
    {
        Mode = -3,
        PostBurstDelay = 0.1,
        RunawayBurst = false,
        Mult_RPM = 2,
    },
    {
        Mode = 0,
    }
}

local s = "ArcCW_Kraken.OverheatWarn"
local p = {
    [5] = 70,
    [4] = 70,
    [3] = 70,
    [2] = 80,
    [1] = 90,
    [0] = 100,
}

SWEP.Hook_AddShootSound = function(wep, data)
    local pitch = p[wep:Clip1()]
    if pitch then
        wep:MyEmitSound(s, 100, pitch, 0.5, CHAN_AUTO)
    end
end

-- ACCURACY
SWEP.AccuracyMOA = 2
SWEP.HipDispersion = 120
SWEP.MoveDispersion = 160
SWEP.JumpDispersion = 220

SWEP.SpeedMult = 0.955
SWEP.SightedSpeedMult = 0.75
SWEP.SightTime = 0.35
SWEP.ShootSpeedMult = 0.9

SWEP.Primary.Ammo = "ar2"
SWEP.ShootVol = 100
SWEP.ShootPitch = 90
SWEP.ShootPitchVariation = 0.2

SWEP.ShootSound = "ARCCW_Kraken.SW_DC17"
SWEP.DistantShootSound = "ARCCW_Kraken.SW_DC17_Distant"
SWEP.DistantShootSoundSilenced = "ArcCW_Kraken.SW_Silenced_Distant"
SWEP.ShootSoundSilenced = "ArcCW_Kraken.SW_Silenced"

SWEP.NoFlash = nil
SWEP.MuzzleEffect = false
SWEP.FastMuzzleEffect = false
SWEP.GMMuzzleEffect = false
SWEP.MuzzleFlashColor = Color(0,129,250)

SWEP.HasHoloHUD1 = true
SWEP.IronSightStruct = {
    Pos = Vector(0,0,0),
    Ang = Angle(0,0,0),
    Magnification = 1.1,
    SwitchToSound = "ArcCW_Kraken.Ironsight",
    SwitchFromSound = "ArcCW_Kraken.Ironsight",
    ViewModelFOV = 50,
}

SWEP.HoldtypeHolstered = "normal"
SWEP.HoldtypeActive = "duel"
SWEP.HoldtypeSights = "duel"
SWEP.HoltypeCustomize = "normal"
SWEP.AnimShoot = ACT_HL2MP_GESTURE_RANGE_ATTACK_DUEL

SWEP.SprintPos = Vector(0,-20,-10)
SWEP.SprintAng = Angle(35,0,0)

SWEP.CustomizePos = Vector(0,0,0)
SWEP.CustomizeAng = Angle(0,0,0)

SWEP.CrouchPos = Vector(0,-5.226,1)
SWEP.CrouchAng = Angle(0,0,0)

SWEP.ActivePos = Vector(0,-4,-1)
SWEP.ActiveAng = Angle(0,0,0)

SWEP.BarrelOffsetSighted = Vector(0,0,-1)
SWEP.BarrelOffsetHip = Vector(2,0,-2)

SWEP.HolsterPos = Vector(0,0,0)
SWEP.HolsterAng = Vector(-30,0,0)

SWEP.BarrelLength = 25

SWEP.Attachments = {
    {
        PrintName = "Energization",
        DefaultAttName = "Standard",
        Slot = {"ammo","special_ammo"}
    },
    {
        PrintName = "Mode",
        DefaultAttName = "None",
        Slot = {"sw_mode","sw_mode_pistol"},
    },
    {
        PrintName = "Perk",
        DefaultAttName = "None",
        Slot = "perk",
    },
    {
        PrintName = "Internal Modifications",
        DefaultAttName = "None",
        Slot = {"uc_fg"},
    },
}

SWEP.Animations = {
    ["idle"] = { Source = "idle" },
    ["bash"] = { Source = "bash" },
    ["idle_iron"] = { Source = "idle" },

    ["fire"] = {
        Source = {"shoot_l","shoot_r"},
        Mult = 1,
    },

    ["fire_iron"] = {
        Source = {"shoot_l","shoot_r"},
        Mult = 1,
    },

    ["reload"] = {
        Source = "reload",
        TPAnim = ACT_HL2MP_GESTURE_RELOAD_SMG1,
        LHIK = true,
        SoundTable = {
            {s = "ArcCW_Kraken.Overheat", t = 1/30},
            {s = "ArcCW_Kraken.OverheatReplenished", t = 25/30},
        },
    },

    ["draw"] = {
        Source = "draw",
        SoundTable = {
            {
                s = "arccw/kraken/empire/draw_pistol.wav",
                p = 100,
                v = 100,
                t = 0.1,
                c = CHAN_ITEM,
            },
        }
    },

    ["holster"] = {
        Source = "holster",
        SoundTable = {
            {
                s = "arccw/kraken/empire/draw_pistol.wav",
                p = 100,
                v = 100,
                t = 0.1,
                c = CHAN_ITEM,
            },
        }
    },

    ["enter_inspect"] = {
        Source = "lookat01",
        Mult = 2,
    },

    ["idle_inspect"] = {
        Source = "lookat01",
        Mult = 2,
    },
}