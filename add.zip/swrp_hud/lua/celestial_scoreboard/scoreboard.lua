-- ============================================================
-- H2O Networks Scoreboard - ANIMATED EDITION
-- ============================================================

surface.CreateFont("Helix_Title",    { font = "Purista Medium", size = 28, weight = 800 })
surface.CreateFont("Helix_Header",   { font = "Purista Medium", size = 13, weight = 700 })
surface.CreateFont("Helix_Row",      { font = "Purista Medium", size = 13, weight = 500 })
surface.CreateFont("Helix_Small",    { font = "Purista Medium", size = 14, weight = 400 })
surface.CreateFont("Helix_Logo",     { font = "Purista Medium", size = 14, weight = 900 })
surface.CreateFont("Helix_Rank",     { font = "Purista Medium", size = 11, weight = 600 })
surface.CreateFont("Helix_RankName", { font = "Purista Medium", size = 13, weight = 700 })

local COL_BG        = Color(18, 18, 20, 245)
local COL_HEADER_BG = Color(40, 40, 46, 255)
local COL_ACCENT    = Color(105, 211, 255)
local COL_DIVIDER   = Color(60, 60, 68, 255)
local COL_TEXT      = Color(255, 255, 255, 255)
local COL_SUBTEXT   = Color(160, 160, 170, 255)

-- ============================================================
-- LOGO
-- ============================================================
local LOGO_MAT  = Material("h2o/h2o_lego.png", "noclamp smooth")
local LOGO_SIZE = 135

-- ============================================================
-- BUBBLE PARTICLES
-- ============================================================
local BUBBLES     = {}
local BUBBLE_INIT = false

local function InitBubbles(w, h)
    BUBBLES = {}
    for i = 1, 40 do
        BUBBLES[i] = {
            x     = math.random(0, w),
            y     = math.random(0, h),
            spd   = math.random(18, 55) * 0.1,
            sway  = math.random(5, 22) * 0.01,
            swayT = math.random(0, 628) * 0.01,
            swayW = math.random(8, 32) * 0.1,
            r     = math.random(2, 7),
            al    = math.random(18, 52),
            pulse = math.random(0, 628) * 0.01,
        }
    end
    BUBBLE_INIT = true
end

local function DrawBubble(cx, cy, r, col)
    local steps = math.max(8, math.floor(r * 3.5))
    local prev_x, prev_y
    surface.SetDrawColor(col)
    for s = 0, steps do
        local a  = (s / steps) * math.pi * 2
        local nx = cx + math.cos(a) * r
        local ny = cy + math.sin(a) * r
        if prev_x then
            surface.DrawLine(math.Round(prev_x), math.Round(prev_y), math.Round(nx), math.Round(ny))
        end
        prev_x, prev_y = nx, ny
    end
    -- specular highlight
    surface.SetDrawColor(Color(col.r, col.g, col.b, math.min(col.a, math.Round(col.a * 0.55))))
    surface.DrawRect(math.Round(cx - r * 0.35), math.Round(cy - r * 0.35), 1, 1)
end

local function DrawBubbles(w, h, masterAlpha)
    local dt = FrameTime()
    for _, b in ipairs(BUBBLES) do
        b.swayT = b.swayT + dt * b.sway
        b.pulse = b.pulse + dt * 0.9
        b.x     = b.x + math.sin(b.swayT) * b.swayW * dt
        b.y     = b.y - b.spd * dt
        if b.y < -b.r * 2 then
            b.y = h + b.r
            b.x = math.random(0, w)
        end
        local pulse = (math.sin(b.pulse) + 1) * 0.5
        local al    = math.Round(b.al * masterAlpha * (0.5 + 0.5 * pulse))
        DrawBubble(
            math.Round(b.x), math.Round(b.y), b.r,
            Color(
                math.min(255, COL_ACCENT.r + 30),
                math.min(255, COL_ACCENT.g + 10),
                math.min(255, COL_ACCENT.b + 5),
                al
            )
        )
    end
end

local JOB_COLORS = {
    { match = "501st",         color = Color(42,  68,  123), category = "501st Legion"           },
    { match = "212th",         color = Color(205, 150,  64), category = "212th Attack Battalion" },
    { match = "republic navy", color = Color(247, 54,  186), category = "Republic Navy"          },
    { match = "coruscant guard", color = Color(180, 40,  40),  category = "Coruscant Guard"      },
    { match = "jedi",          color = Color(238, 134, 232), category = "Jedi Order"             },
    { match = "clone",         color = Color(140, 140, 140), category = "Clone Troopers"         },
    { match = "high command",  color = Color(29, 41, 90),    category = "High Command"           },
    { match = "null class",    color = Color(0, 0, 0),       category = "Null Class"             },
}
local COL_ROW_DEFAULT = Color(42, 42, 48, 255)

-- ============================================================
-- Helpers
-- ============================================================
local function Lerp3(t, a, b)
    return Color(
        Lerp(t, a.r, b.r),
        Lerp(t, a.g, b.g),
        Lerp(t, a.b, b.b),
        Lerp(t, a.a or 255, b.a or 255)
    )
end

local function GetJobEntry(ply)
    if not IsValid(ply) then return nil end
    local jobName = ""
    if ply.getDarkRPVar then
        local job = ply:getDarkRPVar("job")
        if job then jobName = job end
    end
    if jobName == "" then jobName = team.GetName(ply:Team()) or "" end
    local lower = jobName:lower()
    for _, entry in ipairs(JOB_COLORS) do
        if lower:find(entry.match, 1, true) then return entry end
    end
    return nil
end

local function GetRowColor(ply)
    local e = GetJobEntry(ply)
    return e and e.color or COL_ROW_DEFAULT
end

local function GetCategory(ply)
    local e = GetJobEntry(ply)
    if e then return e.category end
    if IsValid(ply) and ply.getDarkRPVar then
        local job = ply:getDarkRPVar("job")
        if job and job ~= "" then return job end
    end
    return team.GetName(ply:Team()) or ""
end

local function GetPlayerRank(ply)
    if not IsValid(ply) then return "" end
    local rank = ply:GetNWString("SWRP_Rank", "")
    if rank == "" and ply.getDarkRPVar then
        rank = ply:getDarkRPVar("job") or ""
    end
    return rank
end

local function GetXPRank(ply)
    if not IsValid(ply) then return 0 end
    local lvl = ply:GetNWInt("sp_level", -1)
    if lvl >= 0 then return lvl end
    local legacy = ply:GetNWInt("xp_rank", -1)
    if legacy >= 0 then return legacy end
    return math.max(1, math.floor(ply:Frags() / 5) + 1)
end

local function GetRevives(ply)
    if not IsValid(ply) then return 0 end
    return ply:GetNWInt("revives", 0)
end

local function GetUsergroup(ply)
    if not IsValid(ply) then return "User" end
    local ug = ply:GetUserGroup() or "user"
    return ug:sub(1, 1):upper() .. ug:sub(2)
end

local function GetPingColor(ping)
    if ping < 60  then return Color(80, 210, 120) end
    if ping < 120 then return Color(230, 190, 60) end
    return Color(220, 70, 70)
end

local MANAGEMENT_GROUPS = {
    ["owner"] = true, ["co-owner"] = true, ["coowner"] = true,
    ["founder"] = true, ["head admin"] = true, ["headadmin"] = true,
    ["head-admin"] = true, ["head developer"] = true,
    ["head dev"] = true, ["headdev"] = true,
}

local function GetStaffAndManagementCounts()
    local staff, management = 0, 0
    for _, p in ipairs(player.GetAll()) do
        if IsValid(p) then
            local ug = (p:GetUserGroup() or ""):lower()
            if MANAGEMENT_GROUPS[ug] then
                management = management + 1
            elseif p:IsAdmin() then
                staff = staff + 1
            end
        end
    end
    return staff, management
end

local function GetPlayerListKey()
    local plys = player.GetAll()
    table.sort(plys, function(a, b)
        if a == LocalPlayer() then return true  end
        if b == LocalPlayer() then return false end
        return GetXPRank(a) > GetXPRank(b)
    end)
    local parts = {}
    for _, p in ipairs(plys) do
        if IsValid(p) then parts[#parts + 1] = tostring(p:UserID()) end
    end
    return table.concat(parts, ",")
end

-- ============================================================
-- Layout
-- ============================================================
local COLS = {
    { label = "Rank / Name", w = 300 },
    { label = "Regiment",    w = 220 },
    { label = "Level",       w = 80  },
    { label = "Kills",       w = 70  },
    { label = "Revives",     w = 80  },
    { label = "Usergroup",   w = 110 },
    { label = "Ping",        w = 70  },
    { label = "",            w = 44  },
}

local PAD        = 15
local WIN_W      = PAD * 8
for _, c in ipairs(COLS) do WIN_W = WIN_W + c.w end
local WIN_H      = 750
local TITLEBAR_H = 80
local HEADER_H   = 37
local ROW_H      = 36
local CORNER     = 10

-- ============================================================
-- Panel
-- ============================================================
local _panel = nil

local function BuildScoreboard()
    if IsValid(_panel) then _panel:Remove() end

    local frame = vgui.Create("DFrame")
    frame:SetSize(WIN_W, WIN_H)
    frame:Center()
    frame:SetTitle("")
    frame:ShowCloseButton(false)
    frame:SetDraggable(true)
    frame:SetVisible(false)
    _panel = frame

    frame._openAnim   = 0
    frame._accentFill = 0
    frame._bubbleAlpha = 0  -- fades in with the panel

    -- Initialise bubbles sized to the panel
    InitBubbles(WIN_W, WIN_H)

    frame.Paint = function(s, w, h)
        local anim        = frame._openAnim
        local slideOffset = Lerp(anim, -18, 0)

        -- Outer glow
        draw.RoundedBox(CORNER + 2, 0, slideOffset, w, h, Color(255, 255, 255, math.floor(14 * anim)))

        -- Main background
        draw.RoundedBox(CORNER, 2, 2 + slideOffset, w - 4, h - 5, Color(COL_BG.r, COL_BG.g, COL_BG.b, math.floor(245 * anim)))

        -- ── BUBBLE PARTICLES ──────────────────────────────────────────────
        -- Clip bubbles to the panel's rounded rect area so they don't bleed
        -- outside the scoreboard edges.
        render.SetScissorRect(2, 2 + math.Round(slideOffset), w - 2, h - 3, true)
        frame._bubbleAlpha = math.min(frame._bubbleAlpha + FrameTime() * 1.4, 0.65)
        if anim > 0.1 then
            DrawBubbles(w, h + math.abs(slideOffset), frame._bubbleAlpha * anim)
        end
        render.SetScissorRect(0, 0, 0, 0, false)
        -- ─────────────────────────────────────────────────────────────────

        -- Teal animated accent line under titlebar
        local accentW = math.floor(frame._accentFill * (w - 4))
        if accentW > 0 then
            surface.SetDrawColor(COL_ACCENT.r, COL_ACCENT.g, COL_ACCENT.b, math.floor(220 * anim))
            surface.DrawRect(2, TITLEBAR_H + slideOffset, accentW, 2)
        end

        -- Logo
        if LOGO_MAT and not LOGO_MAT:IsError() then
            surface.SetMaterial(LOGO_MAT)
            surface.SetDrawColor(255, 255, 255, math.floor(255 * anim))
            surface.DrawTexturedRect(PAD, slideOffset + (TITLEBAR_H - LOGO_SIZE) / 2.5, LOGO_SIZE, LOGO_SIZE)
        end

        -- Title
        draw.SimpleText("H2O Networks", "Helix_Title", w / 2, slideOffset + TITLEBAR_H / 2 + 2, Color(255, 255, 255, math.floor(255 * anim)), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

        -- Close x
        draw.SimpleText("x", "Helix_Title", w - PAD + 8, slideOffset + TITLEBAR_H / 7 + 2, Color(160, 160, 160, math.floor(200 * anim)), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)

        -- Server info
        local staffCount, mgmtCount = GetStaffAndManagementCounts()
        local ix  = w - 160
        local iy  = slideOffset + 10
        local alp = math.floor(220 * anim)
        local function infoLine(txt)
            draw.SimpleText(txt, "Helix_Small", ix, iy, Color(COL_SUBTEXT.r, COL_SUBTEXT.g, COL_SUBTEXT.b, alp), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
            iy = iy + 16
        end
        infoLine("Staff Online: "      .. staffCount)
        infoLine("Management Online: " .. mgmtCount)
        infoLine("Players Online: "    .. #player.GetAll() .. " / " .. game.MaxPlayers())
        infoLine("Map: "               .. game.GetMap())

        -- Header bar
        local hY = slideOffset + TITLEBAR_H + 4
        draw.RoundedBox(0, PAD, hY, w - PAD * 2, HEADER_H, Color(COL_HEADER_BG.r, COL_HEADER_BG.g, COL_HEADER_BG.b, math.floor(255 * anim)))

        -- Teal bottom border on header
        surface.SetDrawColor(COL_ACCENT.r, COL_ACCENT.g, COL_ACCENT.b, math.floor(100 * anim))
        surface.DrawRect(PAD, hY + HEADER_H - 1, w - PAD * 2, 1)

        -- Column labels + dividers
        local hx = PAD
        for i, col in ipairs(COLS) do
            local cx = (i == 1) and (hx + 46) or (hx + col.w / 2)
            local al = (i == 1) and TEXT_ALIGN_LEFT or TEXT_ALIGN_CENTER
            draw.SimpleText(col.label, "Helix_Header", cx, hY + HEADER_H / 2, Color(COL_SUBTEXT.r, COL_SUBTEXT.g, COL_SUBTEXT.b, math.floor(255 * anim)), al, TEXT_ALIGN_CENTER)
            if i < #COLS then
                surface.SetDrawColor(COL_DIVIDER.r, COL_DIVIDER.g, COL_DIVIDER.b, math.floor(50 * anim))
                surface.DrawLine(hx + col.w, hY + 6, hx + col.w, hY + HEADER_H - 6)
            end
            hx = hx + col.w
        end
    end

    -- Close button
    local closeBtn = vgui.Create("DButton", frame)
    closeBtn:SetText("")
    closeBtn:SetSize(30, 30)
    closeBtn:SetPos(WIN_W - PAD - 10, TITLEBAR_H / 9.5 - 15)
    closeBtn.Paint   = function() end
    closeBtn.DoClick = function() frame:SetVisible(false) end

    -- Scroll panel
    local scrollY = TITLEBAR_H + HEADER_H + 6
    local scroll  = vgui.Create("DScrollPanel", frame)
    scroll:SetPos(PAD, scrollY)
    scroll:SetSize(WIN_W - PAD * 2, WIN_H - scrollY - PAD)

    local sbar = scroll:GetVBar()
    sbar:SetWide(4)
    function sbar:Paint(w2, h2)        draw.RoundedBox(2, 0, 0, w2, h2, Color(30, 30, 35, 200)) end
    function sbar.btnUp:Paint()   end
    function sbar.btnDown:Paint() end
    function sbar.btnGrip:Paint(w2, h2)
        local pulse = math.abs(math.sin(CurTime() * 2)) * 40 + 180
        draw.RoundedBox(2, 1, 0, w2 - 2, h2, Color(COL_ACCENT.r, COL_ACCENT.g, COL_ACCENT.b, pulse))
    end

    local INNER_W = WIN_W - PAD * 2 - 4

    local mutedPlayers = {}
    local rowData   = {}
    local lastKey   = ""
    local rowColors = {}

    local function RebuildRows()
        scroll:Clear()
        rowData = {}

        local plys = player.GetAll()
        table.sort(plys, function(a, b)
            if a == LocalPlayer() then return true  end
            if b == LocalPlayer() then return false end
            return GetXPRank(a) > GetXPRank(b)
        end)

        local totalPlys = #plys
        local spawnTime = CurTime()

        for idx, ply in ipairs(plys) do
            if not IsValid(ply) then continue end

            local sid      = ply:SteamID()
            rowColors[sid] = GetRowColor(ply)
            local isFirst  = (idx == 1)
            local isLast   = (idx == totalPlys)
            local isSelf   = (ply == LocalPlayer())
            local stagger  = (idx - 1) * 0.045

            local pingVal = ply:Ping()
            rowData[sid]  = {
                name      = ply:Nick(),
                rank      = GetPlayerRank(ply),
                regiment  = GetCategory(ply),
                xprank    = tostring(GetXPRank(ply)),
                kills     = tostring(ply:Frags()),
                revives   = tostring(GetRevives(ply)),
                usergroup = GetUsergroup(ply),
                ping      = tostring(pingVal),
                pingColor = GetPingColor(pingVal),
            }

            local row = vgui.Create("DPanel", scroll)
            row:SetSize(INNER_W, ROW_H)
            row:Dock(TOP)
            row:DockMargin(0, 1, 0, 0)

            local av = vgui.Create("AvatarImage", row)
            av:SetSize(28, 28)
            av:SetPos(6, (ROW_H - 28) / 2)
            av:SetPlayer(ply, 32)

            local hoverAmt = 0

            row.Paint = function(s, w, h)
                local t  = CurTime()
                local dt = FrameTime()

                local elapsed = (t - spawnTime) - stagger
                local rowAnim = math.Clamp(elapsed / 0.22, 0, 1)
                local eased   = rowAnim * rowAnim * (3 - 2 * rowAnim)

                local mx, my = s:CursorPos()
                local isHov  = mx >= 0 and mx <= w and my >= 0 and my <= h
                hoverAmt     = Lerp(dt * 10, hoverAmt, isHov and 1 or 0)

                local rowColor   = rowColors[sid] or COL_ROW_DEFAULT
                local hoverColor = Color(
                    math.min(rowColor.r + 35, 255),
                    math.min(rowColor.g + 35, 255),
                    math.min(rowColor.b + 35, 255)
                )
                local bg = Lerp3(hoverAmt, rowColor, hoverColor)
                bg.a = math.floor(255 * eased)

                if isFirst and isLast then
                    draw.RoundedBox(6, 0, 0, w, h, bg)
                elseif isFirst then
                    draw.RoundedBoxEx(6, 0, 0, w, h, bg, true, true, false, false)
                elseif isLast then
                    draw.RoundedBoxEx(6, 0, 0, w, h, bg, false, false, true, true)
                else
                    draw.RoundedBox(0, 0, 0, w, h, bg)
                end

                if isSelf then
                    local pulse = math.abs(math.sin(t * 1.8)) * 0.35 + 0.65
                    surface.SetDrawColor(COL_ACCENT.r, COL_ACCENT.g, COL_ACCENT.b, math.floor(220 * pulse * eased))
                    surface.DrawRect(0, 0, 3, h)
                    surface.SetDrawColor(COL_ACCENT.r, COL_ACCENT.g, COL_ACCENT.b, math.floor(15 * pulse * eased))
                    surface.DrawRect(0, 0, w, h)
                end

                if hoverAmt > 0.01 then
                    surface.SetDrawColor(255, 255, 255, math.floor(8 * hoverAmt * eased))
                    surface.DrawRect(0, 0, w, h)
                    surface.SetDrawColor(255, 255, 255, math.floor(60 * hoverAmt * eased))
                    surface.DrawRect(0, 0, 2, h)
                end

                surface.SetDrawColor(0, 0, 0, math.floor(50 * eased))
                surface.DrawLine(0, h - 1, w, h - 1)

                local textAlpha = math.floor(255 * eased)
                local cur = rowData[sid]
                if not cur then return end

                local x = 0
                for i, col in ipairs(COLS) do
                    local tx = (i == 1) and (x + 42) or (x + col.w / 2)
                    local al = (i == 1) and TEXT_ALIGN_LEFT or TEXT_ALIGN_CENTER

                    if i == 1 then
                        local midY = h / 2
                        if cur.rank and cur.rank ~= "" and cur.rank ~= "Unknown" then
                            draw.SimpleText(cur.rank, "Helix_Rank",     tx, midY - 8, Color(255, 255, 255, math.floor(180 * eased)), al, TEXT_ALIGN_CENTER)
                            draw.SimpleText(cur.name, "Helix_RankName", tx, midY + 5, Color(255, 255, 255, textAlpha), al, TEXT_ALIGN_CENTER)
                        else
                            draw.SimpleText(cur.name, "Helix_Row", tx, midY, Color(255, 255, 255, textAlpha), al, TEXT_ALIGN_CENTER)
                        end
                    elseif i == 2 then
                        draw.SimpleText(cur.regiment or "",  "Helix_Row", tx, h / 2, Color(255, 255, 255, textAlpha), al, TEXT_ALIGN_CENTER)
                    elseif i == 3 then
                        draw.SimpleText(cur.xprank or "",    "Helix_Row", tx, h / 2, Color(255, 255, 255, textAlpha), al, TEXT_ALIGN_CENTER)
                    elseif i == 4 then
                        draw.SimpleText(cur.kills or "",     "Helix_Row", tx, h / 2, Color(255, 255, 255, textAlpha), al, TEXT_ALIGN_CENTER)
                    elseif i == 5 then
                        draw.SimpleText(cur.revives or "",   "Helix_Row", tx, h / 2, Color(255, 255, 255, textAlpha), al, TEXT_ALIGN_CENTER)
                    elseif i == 6 then
                        draw.SimpleText(cur.usergroup or "", "Helix_Row", tx, h / 2, Color(255, 255, 255, textAlpha), al, TEXT_ALIGN_CENTER)
                    elseif i == 7 then
                        draw.SimpleText(cur.ping, "Helix_Row", tx, h / 2, Color(cur.pingColor.r, cur.pingColor.g, cur.pingColor.b, textAlpha), al, TEXT_ALIGN_CENTER)
                    end

                    x = x + col.w
                end

                -- ── Mute button icon ──────────────────────────────────────────
                if not isSelf then
                    local muted   = mutedPlayers[sid] or false
                    local btnSize = 18
                    local btnX    = w - 30
                    local btnY    = (h - btnSize) / 2
                    local cx      = btnX + btnSize / 2
                    local cy      = btnY + btnSize / 2

                    local mx2, my2 = s:CursorPos()
                    local btnHov   = mx2 >= btnX - 4 and mx2 <= btnX + btnSize + 4
                                 and my2 >= btnY - 4 and my2 <= btnY + btnSize + 4

                    local bgAlpha = btnHov and 80 or 40
                    local bgCol   = muted and Color(220, 70, 70, math.floor(bgAlpha * eased))
                                          or  Color(255, 255, 255, math.floor(bgAlpha * eased))
                    draw.RoundedBox(10, btnX - 3, btnY - 3, btnSize + 6, btnSize + 6, bgCol)

                    local iconA = math.floor(textAlpha)
                    local iconR, iconG, iconB = 255, 255, 255
                    if muted then iconR, iconG, iconB = 220, 70, 70 end
                    surface.SetDrawColor(iconR, iconG, iconB, iconA)

                    local bx, by = cx - 6, cy - 3
                    surface.DrawRect(bx, by, 5, 6)
                    surface.DrawLine(bx + 4, by,     cx + 3, cy - 6)
                    surface.DrawLine(bx + 4, by + 6, cx + 3, cy + 6)
                    surface.DrawLine(cx + 3, cy - 6, cx + 3, cy + 6)

                    if not muted then
                        surface.DrawLine(cx + 4, cy - 3, cx + 7, cy - 5)
                        surface.DrawLine(cx + 7, cy - 5, cx + 7, cy + 5)
                        surface.DrawLine(cx + 7, cy + 5, cx + 4, cy + 3)
                    else
                        surface.SetDrawColor(220, 70, 70, iconA)
                        surface.DrawLine(btnX,           btnY,           btnX + btnSize, btnY + btnSize)
                        surface.DrawLine(btnX + btnSize, btnY,           btnX,           btnY + btnSize)
                    end
                end
            end

            row.DoClick = function()
                if not IsValid(ply) or isSelf then return end
                local mx, my  = row:CursorPos()
                local btnSize = 18
                local btnX    = row:GetWide() - 30
                local btnY    = (ROW_H - btnSize) / 2
                if mx >= btnX - 4 and mx <= btnX + btnSize + 4
                and my >= btnY - 4 and my <= btnY + btnSize + 4 then
                    mutedPlayers[sid] = not (mutedPlayers[sid] or false)
                    ply:SetMuted(mutedPlayers[sid])
                end
            end

            row.DoRightClick = function()
                if not IsValid(ply) or isSelf then return end
                local sid64 = ply:SteamID64()
                local menu  = DermaMenu()
                if sid64 and sid64 ~= "" then
                    menu:AddOption("Copy SteamID64", function()
                        SetClipboardText(sid64)
                    end):SetIcon("icon16/user_go.png")
                    menu:AddOption("View Steam Profile", function()
                        gui.OpenURL("https://steamcommunity.com/profiles/" .. sid64)
                    end):SetIcon("icon16/world_go.png")
                end
                menu:Open()
            end
        end
    end

    local function UpdateData()
        for sid, d in pairs(rowData) do
            local ply = player.GetBySteamID(sid)
            if IsValid(ply) then
                local ping  = ply:Ping()
                d.name      = ply:Nick()
                d.rank      = GetPlayerRank(ply)
                d.regiment  = GetCategory(ply)
                d.xprank    = tostring(GetXPRank(ply))
                d.kills     = tostring(ply:Frags())
                d.revives   = tostring(GetRevives(ply))
                d.usergroup = GetUsergroup(ply)
                d.ping      = tostring(ping)
                d.pingColor = GetPingColor(ping)
                rowColors[sid] = GetRowColor(ply)
            end
        end
    end

    frame.Think = function(s)
        local t  = CurTime()
        local dt = FrameTime()

        if frame._openAnim < 1 then
            frame._openAnim = math.min(1, frame._openAnim + dt * 4.5)
        end
        if frame._accentFill < 1 then
            frame._accentFill = math.min(1, frame._accentFill + dt * 3)
        end

        if not frame._nextListCheck or t > frame._nextListCheck then
            local key = GetPlayerListKey()
            if key ~= lastKey then
                lastKey = key
                RebuildRows()
            end
            frame._nextListCheck = t + 1.5
        end

        if not frame._nextData or t > frame._nextData then
            UpdateData()
            frame._nextData = t + 0.5
        end
    end

    RebuildRows()
end

hook.Add("ScoreboardShow", "Helix_Show", function()
    if not IsValid(_panel) then BuildScoreboard() end
    _panel._openAnim   = 0
    _panel._accentFill = 0
    _panel._bubbleAlpha = 0
    _panel:SetVisible(true)
    _panel:MakePopup()
    _panel:SetKeyboardInputEnabled(false)
    return true
end)

hook.Add("ScoreboardHide", "Helix_Hide", function()
    if IsValid(_panel) then _panel:SetVisible(false) end
    return true
end)

concommand.Add("scoreboard_refresh", function()
    if IsValid(_panel) then _panel._nextListCheck = 0 end
end)