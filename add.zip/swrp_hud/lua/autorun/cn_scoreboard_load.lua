-- Celestial Networks Scoreboard - Shared Loader
-- Ensures the file is sent to clients when running on a server
AddCSLuaFile("celestial_scoreboard/scoreboard.lua")

-- Share the Skill Points shared file so the scoreboard can use
-- SKILLPOINTS.GetLevelFromXP and friends on the client side.
AddCSLuaFile("skillpoints/shared/sh_skillpoints.lua")

if CLIENT then
    include("skillpoints/shared/sh_skillpoints.lua")
    include("celestial_scoreboard/scoreboard.lua")
end