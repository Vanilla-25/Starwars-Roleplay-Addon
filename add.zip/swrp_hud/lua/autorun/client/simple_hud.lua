-- ============================================
--  Simple HUD by Vanilla
--  Reviewed: bugs fixed, optimised, dead code documented
-- ============================================

local BAR_W = 340
local BAR_H = 12
local SKEW  = -20

-- NOTE: safeSkew inside DrawTrap will always equal SKEW given BAR_W = 340.
-- The clamp is kept as a safety net if BAR_W or SKEW are ever changed.

local XP_BAR_W = 340
local XP_BAR_H = 8
local XP_GAP   = 6

surface.CreateFont("HUD_HP_Text", {
    font      = "ubunturegular",
    size      = 18,
    weight    = 400,
    antialias = true,
})

surface.CreateFont("HUD_XP_Text", {
    font      = "ubunturegular",
    size      = 12,
    weight    = 400,
    antialias = true,
})

-- FIX: initialise to nil so we can lazy-snap on first frame,
-- avoiding a false 100→actualHP lerp when a player spawns below 100 HP.
local smoothHP = nil

local function DrawTrap(x, y, w, h, skew, col)
    if w <= 0 then return end

    surface.SetDrawColor(col)
    draw.NoTexture()

    local safeSkew = math.Clamp(skew, -w * 0.5, w * 0.5)

    surface.DrawPoly({
        { x = x + safeSkew,     y = y },
        { x = x + w - safeSkew, y = y },
        { x = x + w,            y = y + h },
        { x = x,                y = y + h },
    })
end

hook.Add("HUDPaint", "SciFiHealthBar", function()
    local ply = LocalPlayer()
    if not IsValid(ply) then return end

    local hp    = math.max(ply:Health(), 0)
    local maxhp = math.max(ply:GetMaxHealth(), 1)
    local sw, sh = ScrW(), ScrH()

    -- FIX: snap to actual HP on the very first frame instead of lerping from 100.
    if smoothHP == nil then smoothHP = hp end
    smoothHP = Lerp(FrameTime() * 6, smoothHP, hp)

    local x = (sw - BAR_W) * 0.5
    local y = sh - 55

    -- Background
    DrawTrap(x - 4, y - 4, BAR_W + 10, BAR_H + 8, SKEW - 6, Color(0, 0, 0, 255))
    DrawTrap(x,     y,     BAR_W,       BAR_H,     SKEW,     Color(71, 71, 71, 255))

    local frac  = math.Clamp(smoothHP / maxhp, 0, 1)
    local fillW = BAR_W * frac

    local r = 40 + (1 - frac) * 180
    local g = 144 * frac
    local b = 183 * frac

    local pulse = 0
    if frac < 0.3 then
        pulse = math.Clamp(math.sin(CurTime() * 6) * 20, -20, 20)
    end

    DrawTrap(x, y, fillW, BAR_H, SKEW, Color(
        math.Clamp(r + pulse, 0, 255),
        math.Clamp(g,          0, 255),
        math.Clamp(b,          0, 255),
        255
    ))

    -- FIX: skip the glow draw when HP is above 30% — at alpha=40 it is
    -- invisible and wastes a polygon call every frame.
    if frac < 0.3 then
        DrawTrap(x, y, fillW, BAR_H, SKEW, Color(r, g, b, 40))
    end

    draw.SimpleText(
        hp,
        "HUD_HP_Text",
        sw * 0.5,
        y + BAR_H * 0.5,
        Color(255, 255, 255),
        TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER
    )

    -- ── XP Bar ───────────────────────────────────────────
    local xp_x = (sw - XP_BAR_W) * 0.5
    local xp_y = y + BAR_H + XP_GAP

    local xpCurrent  = ply:GetNWInt("sp_xp_current",  0)
    local xpRequired = math.max(ply:GetNWInt("sp_xp_required", 1), 1)
    local rankCur    = ply:GetNWInt("sp_level", 1)
    local rankNext   = rankCur + 1

    -- FIX: removed the "if xpCurrent >= xpRequired then xpCurrent = 0" block.
    -- It caused the bar to silently display 0% at level-up boundaries where
    -- the server legitimately sends xpCurrent == xpRequired.
    -- math.Clamp on xpFraction below already handles any transient overshoot.

    local xpFraction = math.Clamp(xpCurrent / xpRequired, 0, 1)
    local xpFill     = XP_BAR_W * xpFraction

    -- Background
    surface.SetDrawColor(71, 71, 71, 220)
    surface.DrawRect(xp_x, xp_y, XP_BAR_W, XP_BAR_H)

    -- Fill
    surface.SetDrawColor(255, 255, 255, 230)
    surface.DrawRect(xp_x, xp_y, xpFill, XP_BAR_H)

    -- FIX: clamp shine to the filled region only, and guard the left edge
    -- so it never draws into the empty/grey portion of the bar.
    if xpFill > 0 then
        local shineW    = 40
        local shineCycle = (CurTime() * 100) % xpFill
        local shineLeft  = xp_x + shineCycle - shineW * 0.5

        -- Only draw if the shine rect is at least partially inside the fill.
        if shineCycle + shineW * 0.5 > 0 then
            -- Clamp left edge so it never spills left of the bar.
            local drawLeft = math.max(shineLeft, xp_x)
            local drawW    = math.min(shineLeft + shineW, xp_x + xpFill) - drawLeft
            if drawW > 0 then
                surface.SetDrawColor(255, 255, 255, 40)
                surface.DrawRect(drawLeft, xp_y, drawW, XP_BAR_H)
            end
        end
    end

    -- Outline drawn last so it sits on top of shine (correct z-order).
    surface.SetDrawColor(30, 30, 30, 255)
    surface.DrawOutlinedRect(xp_x, xp_y, XP_BAR_W, XP_BAR_H)

    local text_y = xp_y + XP_BAR_H + 4

    draw.SimpleText("RANK " .. rankCur,  "HUD_XP_Text", xp_x,              text_y, color_white, TEXT_ALIGN_LEFT)
    draw.SimpleText(xpCurrent .. "XP / " .. xpRequired .. "XP",
                                          "HUD_XP_Text", sw * 0.5,          text_y, color_white, TEXT_ALIGN_CENTER)
    draw.SimpleText("RANK " .. rankNext, "HUD_XP_Text", xp_x + XP_BAR_W,  text_y, color_white, TEXT_ALIGN_RIGHT)
end)

local hide = {
    ["CHudHealth"]        = true,
    ["CHudBattery"]       = true,
    ["CHudAmmo"]          = true,
    ["CHudSecondaryAmmo"] = true,
}

hook.Add("HUDShouldDraw", "SWRP_HideDefaultHUD", function(name)
    if hide[name] then return false end
end)