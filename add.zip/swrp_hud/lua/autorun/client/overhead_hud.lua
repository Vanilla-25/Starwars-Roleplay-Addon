-- Overhead HUD - Clone Wars Style
-- Displays: Rank + Name | Health Bar | Category

surface.CreateFont("OverheadHUD_Title", {
    font = "Purista-SemiBold",
    size = 21,
    weight = 650,
    antialias = true,
    shadow = true
})

surface.CreateFont("OverheadHUD_Category", {
    font = "Purista-MediumItalic",
    size = 18,
    weight = 700,
    antialias = true,
    shadow = true
})

local OVERHEAD_DISTANCE = 150

local function GetLookingAtPlayer()
    local lp = LocalPlayer()
    if not IsValid(lp) then return nil end

    local trace = util.TraceLine({
        start = lp:EyePos(),
        endpos = lp:EyePos() + lp:GetAimVector() * OVERHEAD_DISTANCE,
        filter = lp,
        mask = MASK_SHOT_HULL,
    })

    if IsValid(trace.Entity) and trace.Entity:IsPlayer() then
        return trace.Entity
    end
    return nil
end

local function DrawHealthBar(x, y, w, h, percent)
    local r = 20 -- Corner radius
    
    -- Background (dark gray)
    draw.RoundedBox(r, x, y, w, h, Color(40, 40, 40, 220))
    
    -- Health fill (bright green)
    if percent > 0 then
        local fillW = math.max(w * percent, 4)
        draw.RoundedBox(r, x, y, fillW, h, Color(100, 255, 100, 255))
    end
    

end

local function GetJobColor(ply)
    -- DarkRP team color
    if ply.getDarkRPVar then
        local job = ply:getDarkRPVar("job")
        if job then
            for _, v in pairs(RPExtraTeams or {}) do
                if v.name == job then
                    return v.color or Color(255, 105, 180) -- Pink fallback
                end
            end
        end
    end

    -- Fallback: use the player's team color
    local teamColor = team.GetColor(ply:Team())
    if teamColor then return teamColor end

    return Color(255, 105, 180) -- Bright pink
end

local function CreateOverheadPanel(ply)
    if not IsValid(ply) then return end

    local name = ply:Name()
    local hp = ply:Health()
    local maxHP = ply:GetMaxHealth()
    
    -- Get rank from SWRP system
    local rank = ply:GetNWString("SWRP_Rank", "")
    
    -- If no SWRP rank, try to get from DarkRP
    if rank == "" and ply.getDarkRPVar then
        rank = ply:getDarkRPVar("job") or ""
    end
    
    -- Combine rank and name
    local displayName = ""
    if rank ~= "" and rank ~= "Unknown" then
        displayName = rank .. " " .. name
    else
        displayName = name
    end

    -- Get job/category
    local jobName = "Unknown"
    if ply.getDarkRPVar then
        jobName = ply:getDarkRPVar("job") or "Unknown"
    elseif ply.getJob then
        jobName = ply:getJob() or "Unknown"
    elseif ply.GetJob then
        jobName = ply:GetJob() or "Unknown"
    end

    local jobColor = GetJobColor(ply)

    local headPos = ply:GetPos() + Vector(0, 0, 85)
    local screenPos = headPos:ToScreen()

    if screenPos.x < 0 or screenPos.x > ScrW() or
       screenPos.y < 0 or screenPos.y > ScrH() then
        return
    end

    local cx = screenPos.x
    
    -- Calculate text widths first
    surface.SetFont("OverheadHUD_Title")
    local nameWidth = surface.GetTextSize(displayName)
    
    surface.SetFont("OverheadHUD_Category")
    local jobWidth = surface.GetTextSize(jobName)
    
    -- Use the wider of the two for the background
    local maxTextWidth = math.max(nameWidth, jobWidth)
    local barWidth = maxTextWidth + 40  -- Add padding
    
    local barHeight = 10
    local startY = screenPos.y - 60
    
    -- Draw top line: Rank + Name (White)
    surface.SetFont("OverheadHUD_Title")
    surface.SetTextColor(255, 255, 255, 255)
    surface.SetTextPos(cx - nameWidth/2, startY)
    surface.DrawText(displayName)
    
    -- Draw health bar (Green)
    local barX = cx - barWidth/2
    local barY = startY + 28
    local healthPct = math.Clamp(hp / maxHP, 0, 1)
    
    DrawHealthBar(barX, barY, barWidth, barHeight, healthPct)
    
    -- Draw bottom line: Category (Pink/Job Color)
    surface.SetFont("OverheadHUD_Category")
    surface.SetTextColor(jobColor.r, jobColor.g, jobColor.b, 255)
    surface.SetTextPos(cx - jobWidth/2, barY + barHeight + 6)
    surface.DrawText(jobName)
    
    -- Optional: Add a subtle glow effect when health is high
    if healthPct > 0.7 then
        surface.SetDrawColor(100, 255, 100, 30)
        surface.DrawOutlinedRect(barX - 1, barY - 1, barWidth + 2, barHeight + 2, 1)
    end
end

hook.Add("HUDPaint", "OverheadHUD", function()
    local target = GetLookingAtPlayer()
    if IsValid(target) and target ~= LocalPlayer() then
        CreateOverheadPanel(target)
    end
end)