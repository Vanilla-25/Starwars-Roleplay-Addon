--[[
    F2 Slot System - Shared Config
    ================================
    Runs on BOTH client and server via autorun/.
    Job names and commands pulled directly from your jobs file.
]]

F2SlotConfig = {}

F2SlotConfig.RespawnMenuDelay = 1.5
F2SlotConfig.OpenOnFirstJoin  = false

F2SlotConfig.Theme = {
    Primary     = Color(26,  28,  32),
    Secondary   = Color(34,  38,  44),
    Accent      = Color(82,  205, 145), -- soft green, matches client accent
    AccentJedi  = Color(204, 178,  88),
    AccentEvent = Color(204,  96,  96),
    Locked      = Color(118, 124, 136),
    Text        = Color(232, 236, 244),
    TextDim     = Color(150, 158, 176),
    Success     = Color(82,  205, 145),
    Danger      = Color(210,  90,  90),
}

F2SlotConfig.Slots = {

    [1] = {
        label       = "Clone Trooper",
        description = "Your primary regiment assignment.",
        type        = "regiment",
        whitelist   = false,
        default_job = "Clone_Cadet",
        icon        = "f2_slots/icon_clone.png",
        color       = Color(76, 150, 210), -- softer regiment blue
    },

    [2] = {
        label       = "Jedi Order",
        description = "Your Jedi character. Requires whitelist access.",
        type        = "jedi",
        whitelist   = true,
        default_job = "Jedi_Youngling",
        icon        = "f2_slots/icon_jedi.png",
        color       = Color(204, 178, 88), -- softer jedi gold
    },

    [3] = {
        label       = "Event Character",
        description = "Your event character slot. Requires whitelist access.",
        type        = "event",
        whitelist   = true,
        default_job = "Event_Character",
        icon        = "f2_slots/icon_event.png",
        color       = Color(204, 96, 96), -- softened event red
    },

    [4] = {
        label       = "VIP Character",
        description = "Your VIP or secondary event character slot. Requires whitelist access.",
        type        = "generic",
        whitelist   = true,
        default_job = "Clone_Cadet",
        icon        = "f2_slots/icon_generic.png",
        color       = Color(100, 115, 135),
    },

}

F2SlotConfig.RegimentJobMap = {

    -- ── Clone Trooper (base) ─────────────────────────────────────────────────
    ["Clone Cadet"]              = "Clone_Cadet",
    ["Clone Trooper Enlisted"]   = "Clone_Trooper_Enlisted",
    ["Clone Trooper NCO"]        = "Clone_Trooper_NCO",
    ["Clone Trooper Officer"]    = "Clone_Trooper_Officer",
    ["Clone Trooper Command"]    = "Clone_Trooper_Command",

    -- ── 501st Legion ─────────────────────────────────────────────────────────
    ["501st Enlisted"]           = "501st_trooper_enlisted",
    ["501st NCO"]                = "501st_trooper_nco",
    ["501st Officer"]            = "501st_trooper_officer",
    ["501st Command"]            = "501st_trooper_command",

    -- ── 501st Airborne
    ["501st Airborne Enlisted"] = "501st_airborne_enlisted",
    ["501st Airborne NCO"]      = "501st_airborne_nco",
    ["501st Airborne Officer"]  = "501st_airborne_officer",
    ["501st Airborne Command"]  = "501st_airborne_command",


    -- ── 501st Combat Medics
    ["501st Combat Medic Enlisted"] = "501st_medic_enlisted",
    ["501st Combat Medic NCO"]      = "501st_medic_nco",
    ["501st Combat Medic Officer"]  = "501st_medic_officer",
    ["501st Combat Medic Command"]  = "501st_medic_command",

    -- ── 212th Attack Battalion ────────────────────────────────────────────────
    ["212th Enlisted"]           = "enlisted_trooper_212th",
    ["212th NCO"]                = "nco_trooper_212th",
    ["212th Officer"]            = "officer_trooper_212th",
    ["212th Command"]            = "cody_212th",

    -- ── 212th Combat Medics ───────────────────────────────────────────────────
    ["212th Combat Medic Enlisted"] = "enlisted_medic_212th",
    ["212th Combat Medic NCO"]      = "nco_medic_212th",
    ["212th Combat Medic Officer"]  = "officer_medic_212th",

    -- ── 212th ARF ─────────────────────────────────────────────────────────────
    ["212th ARF Enlisted"]       = "arf_enlisted_212th",
    ["212th ARF NCO"]            = "arf_nco_212th",
    ["212th ARF Officer"]        = "arf_officer_212th",

    -- ── Republic Navy ─────────────────────────────────────────────────────────
    ["Republic Navy Enlisted"]   = "Republic_Navy_ELD",
    ["Republic Navy NCO"]        = "Republic_Navy_NCO",
    ["Republic Navy Officer"]    = "Republic_Navy_OF",
    ["Republic Navy Command"]    = "Republic_Navy_CAM",

    -- ── Coruscant Guard ─────────────────────────
    ["CG Enlisted"]        = "cg_enlisted",
    ["CG NCO"]             = "cg_nco",
    ["CG Officer"]         = "cg_officer",
    ["CG Command"]         = "cg_command",

    ["CG Medic"]           = "cg_medic",
    ["CG Medic Officer"]   = "cg_medic_officer",

    ["CG Riot"]            = "cg_riot",
    ["CG Riot Officer"]    = "cg_riot_officer",

    ["CG Tracker"]         = "cg_tracker",
    ["CG Tracker Officer"] = "cg_tracker_officer",

    -- ── Jedi Order ────────────────────────────────────────────────────────────
    ["Jedi Youngling"]           = "Jedi_Youngling",
    ["Jedi Padawan"]             = "Jedi_Padawan",
    ["Jedi Knight"]              = "Jedi_Knight",
    ["Jedi Master"]              = "Jedi_Master",
    ["Jedi Council"]             = "Jedi_Council",

    -- ── Republic high Command ─────────────────────────────────────────────────
    ["Republic high Command"]    = "Republic_High_Command",

    -- ── Null Class ARC ────────────────────────────────────────────────────────
    ["Null Class ARC"]    = "Null_Class_Ordo",
    ["Null Class ARC"]    = "Null_Class_Aden",
    ["Null Class ARC"]    = "Null_Class_Jaing",
    ["Null Class ARC"]    = "Null_Class_Mereel",
    ["Null Class ARC"]    = "Null_Class_Komrk",
    ["Null Class ARC"]    = "Null_Class_Prudii",


    -- ── Event Character ───────────────────────────────────────────────────────
    ["Event Character"]          = "Event_Character",

    -- ── Republic Senate ───────────────────────────────────────────────────────
    ["Republic Senate"]          = "Republic_Senate",
}

F2SlotConfig.Regiments = {

    {
        id    = "clone_base",
        label = "Clone Trooper",
        model = "models/player/soldier_stripped.mdl",
        color = Color(0, 170, 255),
        icon  = "⚔",
        cats  = {
            {
                label = "Core",
                jobs  = {
                    { name = "Clone Cadet",            cmd = "Clone_Cadet"            },
                    { name = "Clone Trooper Enlisted",  cmd = "Clone_Trooper_Enlisted" },
                    { name = "Clone Trooper NCO",       cmd = "Clone_Trooper_NCO"      },
                    { name = "Clone Trooper Officer",   cmd = "Clone_Trooper_Officer"  },
                    { name = "Clone Trooper Command",   cmd = "Clone_Trooper_Command"  },
                },
            },
        },
    },

    {
        id    = "501st",
        label = "501st Legion",
        model = "models/player/soldier_stripped.mdl",
        color = Color(30, 120, 220),
        icon  = "★",
        cats  = {
            {
                label = "Troopers",
                jobs  = {
                    { name = "501st Enlisted", cmd = "501st_trooper_enlisted" },
                    { name = "501st NCO",      cmd = "501st_trooper_nco"      },
                    { name = "501st Officer",  cmd = "501st_trooper_officer"  },
                    { name = "501st Command",  cmd = "501st_trooper_command"  },
                },
            },
            {
                label = "Airborne",
                jobs  = {
                    { name = "501st Airborne Enlisted", cmd = "501st_airborne_enlisted" },
                    { name = "501st Airborne NCO",      cmd = "501st_airborne_nco"      },
                    { name = "501st Airborne Officer",  cmd = "501st_airborne_officer"  },
                    { name = "501st Airborne Command",  cmd = "501st_airborne_command"  },
                },
            },
            {
                label = "Combat Medics",
                jobs  = {
                    { name = "501st Combat Medic Enlisted", cmd = "501st_medic_enlisted" },
                    { name = "501st Combat Medic NCO",      cmd = "501st_medic_nco"      },
                    { name = "501st Combat Medic Officer",  cmd = "501st_medic_officer"  },
                    { name = "501st Combat Medic Command",  cmd = "501st_medic_command"  },
                },
            },
        },
    },

    {
        id    = "212th",
        label = "212th Attack Battalion",
        model = "models/player/soldier_stripped.mdl",
        color = Color(220, 140, 20),
        icon  = "◆",
        cats  = {
            {
                label = "Troopers",
                jobs  = {
                    { name = "212th Enlisted", cmd = "enlisted_trooper_212th" },
                    { name = "212th NCO",      cmd = "nco_trooper_212th"      },
                    { name = "212th Officer",  cmd = "officer_trooper_212th"  },
                    { name = "212th Command",  cmd = "cody_212th"             },
                },
            },
            {
                label = "Combat Medics",
                jobs  = {
                    { name = "212th Combat Medic Enlisted", cmd = "enlisted_medic_212th" },
                    { name = "212th Combat Medic NCO",      cmd = "nco_medic_212th"      },
                    { name = "212th Combat Medic Officer",  cmd = "officer_medic_212th"  },
                },
            },
            {
                label = "ARF Troopers",
                jobs  = {
                    { name = "212th ARF Enlisted", cmd = "arf_enlisted_212th" },
                    { name = "212th ARF NCO",      cmd = "arf_nco_212th"      },
                    { name = "212th ARF Officer",  cmd = "arf_officer_212th"  },
                },
            },
        },
    },

    {
        id    = "navy",
        label = "Republic Navy",
        model = "models/player/soldier_stripped.mdl",
        color = Color(60, 180, 200),
        icon  = "⛵",
        cats  = {
            {
                label = "Navy",
                jobs  = {
                    { name = "Republic Navy Enlisted", cmd = "Republic_Navy_ELD" },
                    { name = "Republic Navy NCO",      cmd = "Republic_Navy_NCO" },
                    { name = "Republic Navy Officer",  cmd = "Republic_Navy_OF"  },
                    { name = "Republic Navy Command",  cmd = "Republic_Navy_CAM" },
                },
            },
        },
    },

{
    id    = "cg",
    label = "Coruscant Guard",
    model = "models/aussiwozzi/cgi/base/cg_trooper.mdl",
    color = Color(180, 40, 40),
    icon  = "🛑",
    cats  = {
        {
            label = "Troopers",
            jobs  = {
                { name = "CG Enlisted", cmd = "cg_enlisted" },
                { name = "CG NCO",      cmd = "cg_nco"      },
                { name = "CG Officer",  cmd = "cg_officer"  },
                { name = "CG Command",  cmd = "cg_command"  },
            },
        },

        {
            label = "Medics",
            jobs  = {
                { name = "CG Medic",         cmd = "cg_medic"         },
                { name = "CG Medic Officer", cmd = "cg_medic_officer" },
            },
        },

        {
            label = "Riot",
            jobs  = {
                { name = "CG Riot",         cmd = "cg_riot"         },
                { name = "CG Riot Officer", cmd = "cg_riot_officer" },
            },
        },

        {
            label = "Tracker",
            jobs  = {
                { name = "CG Tracker",         cmd = "cg_tracker"         },
                { name = "CG Tracker Officer", cmd = "cg_tracker_officer" },
            },
        },
    },
},

    {
        id    = "jedi",
        label = "Jedi Order",
        model = "models/player/soldier_stripped.mdl",
        color = Color(200, 160, 32),
        icon  = "✦",
        cats  = {
            {
                label = "Jedi",
                jobs  = {
                    { name = "Jedi Youngling", cmd = "Jedi_Youngling" },
                    { name = "Jedi Padawan",   cmd = "Jedi_Padawan"  },
                    { name = "Jedi Knight",    cmd = "Jedi_Knight"   },
                    { name = "Jedi Master",    cmd = "Jedi_Master"   },
                    { name = "Jedi Council",   cmd = "Jedi_Council"  },
                },
            },
        },
    },

    {
        id    = "event",
        label = "Event Character",
        model = "models/player/soldier_stripped.mdl",
        color = Color(180, 40, 40),
        icon  = "★",
        cats  = {
            {
                label = "Event",
                jobs  = {
                    { name = "Event Character", cmd = "Event_Character" },
                },
            },
        },
    },

    {
        id    = "senate",
        label = "Republic Senate",
        model = "models/player/soldier_stripped.mdl",
        color = Color(180, 40, 40),
        icon  = "★",
        cats  = {
            {
                label = "Senate",
                jobs  = {
                    { name = "Republic Senate", cmd = "Republic_Senate" },
                },
            },
        },
    },

    {
        id    = "high command",
        label = "High Command",
        model = "models/player/soldier_stripped.mdl",
        color = Color(180, 40, 40),
        icon  = "★",
        cats  = {
            {
                label = "High Command",
                jobs  = {
                    { name = "Republic High Command", cmd = "Republic_High_Command" },
                },
            },
        },
    },

    {
        id    = "null class",
        label = "Null Class ARC",
        model = "models/player/soldier_stripped.mdl",
        color = Color(180, 40, 40),
        icon  = "<3",
        cats  = {
            {
                label = "Null Class",
                jobs  = {
                    { name = "Null Class Ordo", cmd = "Null_Class_Ordo" },
                    { name = "Null Class Aden", cmd = "Null_Class_Aden" },
                    { name = "Null Class Jaing", cmd = "Null_Class_Jaing" },
                    { name = "Null Class Mereel", cmd = "Null_Class_Mereel" },
                    { name = "Null Class Komrk", cmd = "Null_Class_Komrk" },
                    { name = "Null Class Prudii", cmd = "Null_Class_Prudii" },
                },
            },
        },
    },

}