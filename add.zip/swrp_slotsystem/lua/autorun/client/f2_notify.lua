--[[
    F2 Notification System  v4
    ==========================
    Visual language matches the F2 slot menu cards exactly:
      - T.Card background, T.Border outline, rounded 6px
      - 2px top type stripe (same as slot cards)
      - 3px left accent bar
      - Roboto fonts at the same weights as F2
    Stacks vertically centred on the right edge of the screen.

    USAGE:
        F2Notify.Push(msg, sub, ntype)

        Types:  F2Notify.TYPE.INFO    (0) – accent colour  [default]
                F2Notify.TYPE.SUCCESS (1) – green
                F2Notify.TYPE.WARN    (2) – amber
                F2Notify.TYPE.ERROR   (3) – red
                F2Notify.TYPE.SYSTEM  (4) – blue

    SERVER API:
        F2Notify.Send(ply, msg, sub, ntype)
        F2Notify.Broadcast(msg, sub, ntype)
]]

F2Notify = F2Notify or {}
F2Notify.TYPE = { INFO=0, SUCCESS=1, WARN=2, ERROR=3, SYSTEM=4 }

-- ─── SERVER ───────────────────────────────────────────────────────────────────
if SERVER then
    util.AddNetworkString("F2Notify_Push")
    function F2Notify.Send(ply, msg, sub, ntype)
        if not IsValid(ply) then return end
        net.Start("F2Notify_Push")
            net.WriteString(msg or "")
            net.WriteString(sub or "")
            net.WriteUInt(ntype or 0, 4)
        net.Send(ply)
    end
    function F2Notify.Broadcast(msg, sub, ntype)
        net.Start("F2Notify_Push")
            net.WriteString(msg or "")
            net.WriteString(sub or "")
            net.WriteUInt(ntype or 0, 4)
        net.Broadcast()
    end
    return
end

-- ══════════════════════════════════════════════════════════════════════════════
-- CLIENT
-- ══════════════════════════════════════════════════════════════════════════════

-- ─── THEME  (neutral grey + soft green, mirrors slot menu) ───────────────────
local T = {
    Bg        = Color(24,  26,  30),
    Panel     = Color(30,  32,  38),
    Panel2    = Color(36,  38,  46),
    Card      = Color(44,  48,  58),
    CardHov   = Color(52,  56,  68),
    Border    = Color(70,  76,  88),
    BorderDim = Color(52,  58,  70),
    Text      = Color(232, 236, 244),
    Dim       = Color(150, 158, 176),
    Faint     = Color(100, 108, 124),
}
local function FA(c,a) return ColorAlpha(c,a) end

-- Accent colour — reads live from F2 if loaded, otherwise from cookie
local function GetAccent()
    if _G.F2SlotAccentColor then return _G.F2SlotAccentColor() end
    local h = cookie.GetNumber("f2_accentH", 0) % 360
    local s = cookie.GetNumber("f2_accentS", 0.85)
    local v = cookie.GetNumber("f2_accentV", 0.90)
    local c = v*s; local x = c*(1-math.abs((h/60)%2-1)); local m = v-c
    local r,g,b
    if     h<60  then r,g,b=c,x,0  elseif h<120 then r,g,b=x,c,0
    elseif h<180 then r,g,b=0,c,x  elseif h<240 then r,g,b=0,x,c
    elseif h<300 then r,g,b=x,0,c  else               r,g,b=c,0,x end
    return Color((r+m)*255,(g+m)*255,(b+m)*255)
end

-- Per-type accent colours, matching F2 slot / whitelist type colours
local TYPE_COL = {
    [0] = function() return GetAccent()           end,  -- INFO:    accent (soft green by default)
    [1] = function() return Color(82,  205, 145)  end,  -- SUCCESS: soft green
    [2] = function() return Color(232, 186,  96)  end,  -- WARN:    warm amber
    [3] = function() return Color(210,  90,  90)  end,  -- ERROR:   softened danger red
    [4] = function() return Color(112, 178, 236)  end,  -- SYSTEM:  muted blue
}
local TYPE_SND = {
    [0]="buttons/button15.wav", [1]="buttons/button17.wav",
    [2]="buttons/button10.wav", [3]="buttons/button11.wav",
    [4]="buttons/button14.wav",
}

-- ─── FONTS  (same as F2 slot menu) ────────────────────────────────────────────
local function MakeFonts()
    surface.CreateFont("F2N_Head",  { font="Roboto", size=12, weight=700 })
    surface.CreateFont("F2N_Sub",   { font="Roboto", size=10, weight=400 })
    surface.CreateFont("F2N_Badge", { font="Roboto", size=9,  weight=700 })
end
MakeFonts()
hook.Add("Initialize",          "F2Notify_Fonts", MakeFonts)
hook.Add("OnScreenSizeChanged", "F2Notify_Fonts", MakeFonts)

-- ─── LAYOUT ───────────────────────────────────────────────────────────────────
local N_W       = 280    -- card width
local N_H       = 50     -- card height, no subtitle
local N_H_TALL  = 66     -- card height, with subtitle
local N_PAD_R   = 16     -- gap from right screen edge
local N_GAP     = 6      -- gap between stacked cards
local N_LIFE    = 5.0    -- seconds before fade
local N_FADEIN  = 0.18   -- slide-in seconds
local N_FADEOUT = 0.45   -- fade-out seconds
local N_SLIDE   = 32     -- px to slide from right on entry
local MAX_N     = 5

-- ─── STATE ────────────────────────────────────────────────────────────────────
local _stack = {}

-- ─── PUSH ─────────────────────────────────────────────────────────────────────
function F2Notify.Push(msg, sub, ntype)
    ntype = ntype or 0; sub = sub or ""
    -- Collapse identical back-to-back pushes
    if #_stack > 0 then
        local last = _stack[#_stack]
        if last.msg==msg and last.sub==sub and last.ntype==ntype then
            last.count  = (last.count or 1) + 1
            last.born   = CurTime()
            last.slideT = CurTime()
            return
        end
    end
    while #_stack >= MAX_N do table.remove(_stack, 1) end
    table.insert(_stack, {
        msg=msg, sub=sub, ntype=ntype,
        born=CurTime(), slideT=CurTime(), count=1,
    })
    surface.PlaySound(TYPE_SND[ntype] or TYPE_SND[0])
end

net.Receive("F2Notify_Push", function()
    F2Notify.Push(net.ReadString(), net.ReadString(), net.ReadUInt(4))
end)

-- ─── DRAW HELPERS ─────────────────────────────────────────────────────────────
local function RR(r,x,y,w,h,c) draw.RoundedBox(r,x,y,w,h,c) end
local function R(x,y,w,h,c)    draw.RoundedBox(0,x,y,w,h,c) end
local function Txt(t,f,x,y,c,ax,ay) draw.SimpleText(t,f,x,y,c,ax or 0,ay or 0) end

-- ─── PAINT ────────────────────────────────────────────────────────────────────
hook.Add("HUDPaint", "F2Notify_Draw", function()
    if #_stack == 0 then return end

    local sw, sh = ScrW(), ScrH()
    local now    = CurTime()

    -- Total height of all visible cards so we can centre the stack
    local totalH = 0
    for _, n in ipairs(_stack) do
        if now - n.born <= N_LIFE + N_FADEOUT then
            totalH = totalH + ((n.sub ~= "") and N_H_TALL or N_H) + N_GAP
        end
    end
    totalH = math.max(totalH - N_GAP, 0)

    -- Vertically centred on the right edge
    local curY  = sh/2 - totalH/2
    local baseX = sw - N_W - N_PAD_R

    for i, n in ipairs(_stack) do
        local age = now - n.born
        if age > N_LIFE + N_FADEOUT then goto cont end

        local ac     = TYPE_COL[n.ntype] and TYPE_COL[n.ntype]() or GetAccent()
        local hasSub = n.sub ~= ""
        local h      = hasSub and N_H_TALL or N_H

        -- Alpha
        local alpha = 255
        if age > N_LIFE then
            alpha = math.Clamp(math.Round(255*(1-(age-N_LIFE)/N_FADEOUT)), 0, 255)
        end

        -- Slide in from right (ease-out cubic)
        local sp   = math.Clamp((now-n.slideT)/N_FADEIN, 0, 1)
        local ease = 1-(1-sp)^3
        local x    = baseX + N_SLIDE*(1-ease)
        local y    = curY

        -- ── Card base  (T.Card, same as slot cards) ───────────────────────
        RR(6, x, y, N_W, h, FA(T.Card, alpha))

        -- ── Top 2px type stripe  (identical to slot card top stripe) ──────
        surface.SetDrawColor(FA(ac, math.Round(alpha * 0.90)))
        surface.DrawRect(x, y, N_W, 2)
        -- Round the very top-left and top-right corners of the stripe
        surface.SetDrawColor(FA(T.Card, alpha))
        surface.DrawRect(x, y, 2, 2)
        surface.DrawRect(x+N_W-2, y, 2, 2)

        -- ── Left 3px accent bar ────────────────────────────────────────────
        surface.SetDrawColor(FA(ac, math.Round(alpha * 0.90)))
        surface.DrawRect(x, y+2, 3, h-2)

        -- ── Outer border  (T.Border, same weight as slot cards) ───────────
        surface.SetDrawColor(FA(T.Border, math.Round(alpha * 0.90)))
        surface.DrawOutlinedRect(x, y, N_W, h, 1)

        -- ── Inner border tint from accent (same as selected slot card) ────
        surface.SetDrawColor(FA(ac, math.Round(alpha * 0.18)))
        surface.DrawOutlinedRect(x+1, y+1, N_W-2, h-2, 1)

        -- ── Draining progress bar along the bottom ────────────────────────
        local frac = math.Clamp(1 - age/N_LIFE, 0, 1)
        local barW = math.Round((N_W - 3) * frac)
        -- track
        surface.SetDrawColor(FA(T.BorderDim, math.Round(alpha * 0.50)))
        surface.DrawRect(x+3, y+h-2, N_W-3, 2)
        -- fill
        if barW > 0 then
            surface.SetDrawColor(FA(ac, math.Round(alpha * 0.65)))
            surface.DrawRect(x+3, y+h-2, barW, 2)
        end

        -- ── Text ──────────────────────────────────────────────────────────
        local txtX = x + 12
        if hasSub then
            Txt(n.msg, "F2N_Head", txtX, y+14,  FA(T.Text, alpha),                  0, 1)
            Txt(n.sub, "F2N_Sub",  txtX, y+32,  FA(T.Dim, math.Round(alpha*0.85)),  0, 1)
        else
            Txt(n.msg, "F2N_Head", txtX, y+h/2, FA(T.Text, alpha), 0, 1)
        end

        -- ── Duplicate count badge ─────────────────────────────────────────
        if n.count and n.count > 1 then
            local bW = 26; local bX = x+N_W-bW-8; local bY = y+h/2-8
            RR(3, bX, bY, bW, 16, FA(ac, math.Round(alpha*0.20)))
            surface.SetDrawColor(FA(ac, math.Round(alpha*0.55)))
            surface.DrawOutlinedRect(bX, bY, bW, 16, 1)
            Txt("×"..n.count, "F2N_Badge", bX+bW/2, bY+8, FA(T.Text, alpha), 1, 1)
        end

        curY = curY + h + N_GAP
        ::cont::
    end

    -- Purge expired
    for i = #_stack, 1, -1 do
        if now - _stack[i].born > N_LIFE + N_FADEOUT then
            table.remove(_stack, i)
        end
    end
end)

-- ─── CLICK TO DISMISS ─────────────────────────────────────────────────────────
hook.Add("GUIMousePressed", "F2Notify_Dismiss", function(mc)
    if mc ~= MOUSE_LEFT then return end
    local mx, my = gui.MouseX(), gui.MouseY()
    local sw, sh = ScrW(), ScrH()
    local now    = CurTime()
    local totalH = 0
    for _, n in ipairs(_stack) do
        if now - n.born <= N_LIFE + N_FADEOUT then
            totalH = totalH + ((n.sub ~= "") and N_H_TALL or N_H) + N_GAP
        end
    end
    local curY  = sh/2 - math.max(totalH-N_GAP, 0)/2
    local baseX = sw - N_W - N_PAD_R
    for i, n in ipairs(_stack) do
        local age = now - n.born
        if age > N_LIFE + N_FADEOUT then goto skip end
        local h    = (n.sub ~= "") and N_H_TALL or N_H
        local sp   = math.Clamp((now-n.slideT)/N_FADEIN,0,1)
        local ease = 1-(1-sp)^3
        local x    = baseX + N_SLIDE*(1-ease)
        if mx>=x and mx<=x+N_W and my>=curY and my<=curY+h then
            _stack[i].born = now - N_LIFE; return
        end
        curY = curY + h + N_GAP
        ::skip::
    end
end)

-- ─── BRIDGES ──────────────────────────────────────────────────────────────────
if not _G.PushNotif then
    _G.PushNotif = function(msg, sub, ntype) F2Notify.Push(msg, sub, ntype) end
end
hook.Add("DarkRPNotify", "F2Notify_DRP", function(ply, text, t, len)
    local m={[0]=0,[1]=3,[2]=1,[3]=2}; F2Notify.Push(text,"",m[t] or 0); return true
end)
hook.Add("AddNotify", "F2Notify_Add", function(text, t, len)
    local m={[0]=0,[1]=3,[2]=1,[3]=2}; F2Notify.Push(text,"",m[t] or 0); return true
end)

print("[F2 Notify] v4 loaded.")