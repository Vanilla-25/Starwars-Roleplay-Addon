--[[
    F2 Slot System - Whitelist Client
    ==================================
    Admin manager:  !wl  or  !wlmanager  in chat
    Visual language matches the F2 slot menu exactly:
      • Same blur + light overlay background
      • Same flat top bar with tab buttons
      • Same card/border/colour palette
      • Same accent colour (reads from slot menu cookie)
]]

if not F2SlotConfig then
    error("[F2 WL] F2SlotConfig nil — load f2_slots_shared.lua first."); return
end

-- ─── ACCENT — reads slot menu cookie, falls back to blue ─────────────────────
local function HSV(h,s,v)
    h=h%360; local c=v*s; local x=c*(1-math.abs((h/60)%2-1)); local m=v-c; local r,g,b
    if h<60 then r,g,b=c,x,0 elseif h<120 then r,g,b=x,c,0 elseif h<180 then r,g,b=0,c,x
    elseif h<240 then r,g,b=0,x,c elseif h<300 then r,g,b=x,0,c else r,g,b=c,0,x end
    return Color((r+m)*255,(g+m)*255,(b+m)*255)
end
local function Accent()
    if _G.F2SlotAccentColor then return _G.F2SlotAccentColor() end
    return HSV(cookie.GetNumber("f2_accentH",210), cookie.GetNumber("f2_accentS",0.75), cookie.GetNumber("f2_accentV",0.90))
end

-- ─── THEME — identical to slot menu ──────────────────────────────────────────
local T = {
    Bar      = Color( 34,  36,  40, 235),
    BarSel   = Color( 48,  52,  60, 255),
    Card     = Color( 44,  48,  56, 210),
    CardHov  = Color( 54,  58,  68, 230),
    Overlay  = Color(  8,  10,  14, 120),
    Border   = Color( 70,  76,  90, 140),
    Text     = Color(230, 232, 238),
    Dim      = Color(155, 160, 175),
    Faint    = Color( 90,  95, 110),
    Success  = Color( 52, 211, 153),
    Danger   = Color(220,  70,  70),
    DangerBg = Color( 50,  18,  18),
    Warn     = Color(232, 186,  96),
    -- slot type colours
    regiment = Color( 70, 130, 200),
    jedi     = Color(190, 160,  55),
    event    = Color(200,  80,  80),
    generic  = Color(110, 116, 135),
    clone    = Color( 70, 150, 210),
}
local function FA(c,a) return ColorAlpha(c,a) end
local function TC(t)   return T[t] or T.generic end

-- ─── FONTS ────────────────────────────────────────────────────────────────────
local function MakeFonts()
    surface.CreateFont("WL_TopTab",  {font="Roboto", size=13, weight=700, antialias=true})
    surface.CreateFont("WL_TopInfo", {font="Roboto", size=11, weight=600, antialias=true})
    surface.CreateFont("WL_TopSub",  {font="Roboto", size=10, weight=400, antialias=true})
    surface.CreateFont("WL_Title",   {font="Roboto", size=15, weight=800, antialias=true})
    surface.CreateFont("WL_Sect",    {font="Roboto", size=11, weight=700, antialias=true})
    surface.CreateFont("WL_Small",   {font="Roboto", size=11, weight=400, antialias=true})
    surface.CreateFont("WL_Sub",     {font="Roboto", size=10, weight=400, antialias=true})
    surface.CreateFont("WL_SubBold", {font="Roboto", size=10, weight=700, antialias=true})
    surface.CreateFont("WL_Mono",    {font="Courier New", size=10, weight=400, antialias=true})
    surface.CreateFont("WL_Badge",   {font="Roboto", size=9,  weight=800, antialias=true})
end
MakeFonts()
hook.Add("Initialize",          "F2WL_Fonts",  MakeFonts)
hook.Add("OnScreenSizeChanged", "F2WL_Fonts2", MakeFonts)

-- ─── DRAW HELPERS ─────────────────────────────────────────────────────────────
local function Rect(x,y,w,h,c)      draw.RoundedBox(0,x,y,w,h,c) end
local function RRct(r,x,y,w,h,c)    draw.RoundedBox(r,x,y,w,h,c) end
local function Txt(t,f,x,y,c,ax,ay) draw.SimpleText(t,f,x,y,c,ax or 0,ay or 0) end
local function Bord(x,y,w,h,c)      surface.SetDrawColor(c); surface.DrawOutlinedRect(x,y,w,h,1) end

local blurMat = Material("pp/blurscreen")
local function DrawBlur(panel, amount, passes)
    local bx,by = panel:LocalToScreen(0,0)
    surface.SetDrawColor(255,255,255,255)
    surface.SetMaterial(blurMat)
    for i=1,passes do
        blurMat:SetFloat("$blur",(i/passes)*amount)
        blurMat:Recompute()
        render.UpdateScreenEffectTexture()
        surface.DrawTexturedRect(-bx,-by,ScrW(),ScrH())
    end
end

-- ─── STATE ────────────────────────────────────────────────────────────────────
local WLData      = {}
local WLReceived  = false
local WLPanel     = nil
local RebuildFn   = nil
local PendingOpen = false
local ActiveTab   = "list"

-- ─── NET RECEIVERS ────────────────────────────────────────────────────────────
net.Receive("F2WL_OpenManager", function()
    timer.Simple(0, OpenWLManager)
end)

net.Receive("F2WL_SendList", function()
    WLData = {}; WLReceived = true
    local count = net.ReadUInt(16)
    for i=1,count do
        table.insert(WLData,{
            steamid    = net.ReadString(),
            slot_index = net.ReadUInt(4),
            granted_by = net.ReadString(),
            granted_at = net.ReadUInt(32),
            slot_type  = net.ReadString(),
            saved_job  = net.ReadString(),
            online     = net.ReadBool(),
            nick       = net.ReadString(),
            activeSlot = net.ReadUInt(4),
        })
    end
    if RebuildFn then RebuildFn()
    elseif PendingOpen then PendingOpen=false; timer.Simple(0,OpenWLManager) end
end)

net.Receive("F2WL_Result", function()
    local ok  = net.ReadBool()
    local msg = net.ReadString()
    if _G.PushNotif then PushNotif(msg, ok and "Done." or "Failed.", ok and 1 or 3)
    else chat.AddText(ok and T.Success or T.Danger, "[F2 WL] "..msg) end
end)

-- ─── SHARED WIDGET HELPERS ────────────────────────────────────────────────────

-- Standard button matching slot menu deploy/action button style
local function MakeBtn(parent, x, y, w, h, label, colFn, fn)
    local b = vgui.Create("DButton", parent)
    b:SetPos(x,y); b:SetSize(w,h); b:SetText(""); b:SetCursor("hand")
    local hA,lt = 0,CurTime()
    b.Think = function(self) local dt=CurTime()-lt; lt=CurTime(); hA=math.Approach(hA,self:IsHovered() and 1 or 0,dt*14) end
    b.Paint = function(self,bw,bh)
        local ac = type(colFn)=="function" and colFn() or colFn
        RRct(4,0,0,bw,bh,FA(T.Card,math.Round(Lerp(hA,180,230))))
        surface.SetDrawColor(FA(ac,math.Round(Lerp(hA,80,200)))); surface.DrawOutlinedRect(0,0,bw,bh,1)
        surface.SetDrawColor(FA(ac,math.Round(Lerp(hA,120,255)))); surface.DrawRect(0,0,3,bh)
        Txt(label,"WL_Sect",bw/2,bh/2,FA(T.Text,math.Round(Lerp(hA,185,255))),1,1)
    end
    b.DoClick = fn
    return b
end

-- Text entry styled like slot menu search bar
local function MakeEntry(parent, x, y, w, h, placeholder)
    local bg = vgui.Create("DPanel",parent)
    bg:SetPos(x,y); bg:SetSize(w,h)
    bg.Paint = function(self,bw,bh)
        RRct(4,0,0,bw,bh,FA(T.Card,200))
        surface.SetDrawColor(FA(T.Border,130)); surface.DrawOutlinedRect(0,0,bw,bh,1)
        surface.SetDrawColor(FA(Accent(),100)); surface.DrawRect(0,bh-1,bw,1)
    end
    local e = vgui.Create("DTextEntry",bg)
    e:SetPos(8,4); e:SetSize(w-16,h-8)
    e:SetFont("WL_Small"); e:SetTextColor(T.Text)
    e:SetPaintBackground(false)
    e:SetPlaceholderText(placeholder or "")
    e:SetPlaceholderColor(T.Faint)
    bg.GetValue  = function() return e:GetValue() end
    bg.SetValue  = function(s,v) e:SetValue(v) end
    bg.OnChange  = nil
    e.OnChange   = function(self) if bg.OnChange then bg.OnChange(self:GetValue()) end end
    bg._entry = e
    return bg
end

-- ─── JOB PICKER (3-column dropdown) ──────────────────────────────────────────
local function OpenJobPicker(anchor, onPick, accentCol)
    if IsValid(_G._F2WL_JobPicker) then _G._F2WL_JobPicker:Remove() end
    if not F2SlotConfig.Regiments or #F2SlotConfig.Regiments==0 then return end

    local ac = accentCol or Accent()
    local ax,ay = anchor:LocalToScreen(0,anchor:GetTall())
    local sw2,sh2 = ScrW(),ScrH()
    local PW,PH = 660,320
    local px = math.Clamp(ax,8,sw2-PW-8)
    local py = math.Clamp(ay+4,8,sh2-PH-8)

    local picker = vgui.Create("DPanel")
    picker:SetSize(PW,PH); picker:SetPos(px,py)
    picker:MakePopup(); picker:SetMouseInputEnabled(true); picker:SetKeyboardInputEnabled(false)
    _G._F2WL_JobPicker = picker
    picker.Paint = function(self,w,h)
        RRct(4,0,0,w,h,T.Bar)
        surface.SetDrawColor(ac); surface.DrawRect(0,0,w,2)
        Bord(0,0,w,h,FA(T.Border,200))
    end
    picker.Think = function(self)
        if input.IsMouseDown(MOUSE_LEFT) then
            local mx,my=gui.MouseX(),gui.MouseY(); local px2,py2=self:GetPos(); local pw2,ph2=self:GetSize()
            if mx<px2 or mx>px2+pw2 or my<py2 or my>py2+ph2 then self:Remove() end
        end
    end

    local COL_W=math.floor(PW/3); local BODY_H=PH-28; local SBAR=4; local IH,IPAD=32,4

    -- Column headers
    for i,lbl in ipairs({"REGIMENT","CATEGORY","JOB"}) do
        local hp=vgui.Create("DPanel",picker); hp:SetSize(COL_W-1,26); hp:SetPos((i-1)*COL_W,0)
        hp.Paint=function(self,w,h)
            Rect(0,0,w,h,T.BarSel)
            Txt(lbl,"WL_Badge",10,h/2,FA(ac,200),0,1)
            surface.SetDrawColor(FA(T.Border,100)); surface.DrawRect(0,h-1,w,1)
            if i<3 then surface.SetDrawColor(FA(T.Border,80)); surface.DrawRect(w-1,0,1,h) end
        end
    end

    local function MakeScrollCol(ci)
        local sp=vgui.Create("DScrollPanel",picker)
        sp:SetPos((ci-1)*COL_W,26); sp:SetSize(COL_W,BODY_H)
        local vb=sp:GetVBar(); vb:SetWide(SBAR)
        vb.Paint=function(s,w,h) RRct(2,0,0,w,h,FA(T.Border,60)) end
        vb.btnUp.Paint=function() end; vb.btnDown.Paint=function() end
        vb.btnGrip.Paint=function(s,w,h) RRct(2,0,0,w,h,FA(ac,150)) end
        sp.Paint=function(s,w,h)
            Rect(0,0,w,h,FA(T.Card,180))
            if ci<3 then surface.SetDrawColor(FA(T.Border,80)); surface.DrawRect(w-1,0,1,h) end
        end
        return sp
    end
    local regCol=MakeScrollCol(1); local catCol=MakeScrollCol(2); local jobCol=MakeScrollCol(3)

    local function MakeItem(parent,lbl,sub,col,onClick)
        local btn=vgui.Create("DButton",parent)
        btn:SetSize(COL_W-SBAR-IPAD*2,IH); btn:Dock(TOP); btn:DockMargin(IPAD,2,IPAD,0); btn:SetText("")
        local hA,lt,sel=0,CurTime(),false
        btn.SetSelected=function(s,v) sel=v end
        btn.Think=function(self) local dt=CurTime()-lt; lt=CurTime(); hA=math.Approach(hA,self:IsHovered() and 1 or 0,dt*14) end
        btn.Paint=function(self,w,h)
            if sel then
                RRct(4,0,0,w,h,FA(ac,20))
                Bord(0,0,w,h,FA(ac,140))
                surface.SetDrawColor(ac); surface.DrawRect(0,0,3,h)
            elseif hA>0 then
                RRct(4,0,0,w,h,FA(T.CardHov,math.Round(hA*100)))
            end
            Txt(lbl,"WL_Small",10,sub and h/2-6 or h/2,FA(T.Text,math.Round(Lerp(hA,190,255))),0,1)
            if sub then Txt(sub,"WL_Sub",10,h/2+5,FA(col or T.Dim,150),0,1) end
        end
        btn.DoClick=onClick
        return btn
    end

    local regBtns,catBtns,jobBtns={},{},{}
    local function PopJobs(cat)
        for _,b in ipairs(jobBtns) do if IsValid(b) then b:Remove() end end; jobBtns={}
        for _,job in ipairs(cat.jobs or {}) do
            local j=job
            table.insert(jobBtns,MakeItem(jobCol,j.name,j.cmd,T.Dim,function()
                onPick(j.cmd); picker:Remove()
            end))
        end
    end
    local function PopCats(reg)
        for _,b in ipairs(catBtns) do if IsValid(b) then b:Remove() end end; catBtns={}
        for _,b in ipairs(jobBtns) do if IsValid(b) then b:Remove() end end; jobBtns={}
        local tc=TC(string.lower(reg.label or "generic"))
        for _,cat in ipairs(reg.cats or {}) do
            local cc=cat; local btn
            btn=MakeItem(catCol,cc.label or "?",tostring(#(cc.jobs or {})).." jobs",tc,function()
                for _,b2 in ipairs(catBtns) do if IsValid(b2) then b2:SetSelected(false) end end
                btn:SetSelected(true); PopJobs(cc)
            end); table.insert(catBtns,btn)
        end
    end
    for _,reg in ipairs(F2SlotConfig.Regiments) do
        local r=reg; local tc=TC(string.lower(r.label or "generic"))
        local jc=0; for _,cat in ipairs(r.cats or {}) do for _ in ipairs(cat.jobs or {}) do jc=jc+1 end end
        local btn
        btn=MakeItem(regCol,r.label or "?",#(r.cats or {}).." cats · "..jc.." jobs",tc,function()
            for _,b2 in ipairs(regBtns) do if IsValid(b2) then b2:SetSelected(false) end end
            btn:SetSelected(true); PopCats(r)
        end); table.insert(regBtns,btn)
    end
end

-- ═════════════════════════════════════════════════════════════════════════════
-- ADMIN WHITELIST MANAGER
-- ═════════════════════════════════════════════════════════════════════════════
function OpenWLManager()
    if not IsValid(LocalPlayer()) then return end
    if not LocalPlayer():IsAdmin() then
        chat.AddText(T.Danger,"[F2 WL] Admins only."); return
    end
    if IsValid(WLPanel) then WLPanel:MakePopup(); return end

    net.Start("F2WL_RequestList"); net.SendToServer()
    if not WLReceived then PendingOpen=true; return end

    local sw,sh = ScrW(),ScrH()

    -- ── Full-screen overlay — identical to slot menu frame ────────────────────
    local overlay = vgui.Create("DFrame")
    overlay:SetSize(sw,sh); overlay:SetPos(0,0)
    overlay:SetTitle(""); overlay:ShowCloseButton(false)
    overlay:SetDraggable(false); overlay:SetSizable(false)
    overlay:MakePopup(); overlay:SetAlpha(0)
    WLPanel = overlay

    overlay.Paint = function(self,w,h)
        DrawBlur(self,6,3)
        Rect(0,0,w,h,T.Overlay)
    end
    local fadeT=CurTime()
    overlay.Think = function(self)
        self:SetAlpha(math.min(255,math.Round((CurTime()-fadeT)/0.15*255)))
    end
    overlay.OnKeyCodeTyped = function(self,key)
        if key==KEY_ESCAPE and (CurTime()-fadeT)>0.2 then self:Remove() end
    end
    overlay.OnRemoved = function()
        WLPanel=nil; RebuildFn=nil; PendingOpen=false; ActiveTab="list"
    end

    local ok,err = pcall(function()

    -- ── Window dimensions — fixed floating panel ──────────────────────────────
    local MW     = math.min(sw-80, 1060)
    local MH     = math.min(sh-80,  640)
    local MX     = math.floor((sw-MW)/2)
    local MY     = math.floor((sh-MH)/2)
    local TOP_H  = 46
    local BOT_H  = 44
    local PAD    = 12
    local LEFT_W = math.floor(MW * 0.64)
    local RIGHT_W= MW - LEFT_W
    local BODY_H = MH - TOP_H - BOT_H

    -- Main window container
    local main = vgui.Create("DPanel", overlay)
    main:SetSize(MW, MH); main:SetPos(MX, MY)
    main.Paint = function(self,w,h)
        draw.RoundedBox(6, 4, 6, w, h, Color(0,0,0,120))
        RRct(6, 0, 0, w, h, Color(28,30,35,250))
        Bord(0, 0, w, h, FA(T.Border,200))
    end
    main.OnMousePressed = function() end

    -- ── HEADER ────────────────────────────────────────────────────────────────
    local topbar = vgui.Create("DPanel", main)
    topbar:SetSize(MW, TOP_H); topbar:SetPos(0, 0)
    topbar.Paint = function(self,w,h)
        RRct(6, 0, 0, w, TOP_H+8, T.Bar)
        surface.SetDrawColor(Accent()); surface.DrawRect(0, h-2, w, 2)
        surface.SetDrawColor(FA(T.Border,100)); surface.DrawRect(0, h-1, w, 1)
        Txt("Whitelist Manager", "WL_Title",  14, h/2-5, T.Text)
        Txt("slot access control","WL_TopSub", 14, h/2+7, FA(Accent(),160))
        Txt("ESC", "WL_TopSub", w-12, h/2, FA(T.Faint,130), 2, 1)
    end

    local TABS = {
        {id="list",  label="Whitelist"},
        {id="grant", label="Grant Access"},
    }
    local TAB_W = 110
    local tabsX  = 190
    for i,tab in ipairs(TABS) do
        local t=tab
        local btn=vgui.Create("DButton",topbar)
        btn:SetSize(TAB_W,TOP_H); btn:SetPos(tabsX+(i-1)*TAB_W,0); btn:SetText("")
        local hov,lt=0,CurTime()
        btn.Think=function(self) local dt=CurTime()-lt; lt=CurTime(); hov=math.Approach(hov,self:IsHovered() and 1 or 0,dt*14) end
        btn.Paint=function(self,w,h)
            local sel=(ActiveTab==t.id)
            if sel then
                Rect(0,0,w,h,T.BarSel)
                surface.SetDrawColor(Accent()); surface.DrawRect(0,h-2,w,2)
                Txt(t.label,"WL_TopTab",w/2,h/2,T.Text,1,1)
            else
                if hov>0 then Rect(0,0,w,h,FA(T.CardHov,math.Round(hov*80))) end
                Txt(t.label,"WL_TopTab",w/2,h/2,FA(T.Dim,math.Round(Lerp(hov,180,240))),1,1)
            end
        end
        btn.DoClick=function() ActiveTab=t.id end
    end

    local rfBtn=vgui.Create("DButton",topbar)
    rfBtn:SetSize(86,TOP_H); rfBtn:SetPos(tabsX+#TABS*TAB_W+4,0); rfBtn:SetText("")
    local rfH,rfL=0,CurTime()
    rfBtn.Think=function(self) local dt=CurTime()-rfL; rfL=CurTime(); rfH=math.Approach(rfH,self:IsHovered() and 1 or 0,dt*14) end
    rfBtn.Paint=function(self,w,h)
        if rfH>0 then Rect(0,0,w,h,FA(T.CardHov,math.Round(rfH*80))) end
        Txt("↺  Refresh","WL_TopTab",w/2,h/2,FA(T.Dim,math.Round(Lerp(rfH,160,230))),1,1)
    end
    rfBtn.DoClick=function() net.Start("F2WL_RequestList"); net.SendToServer(); if RebuildFn then RebuildFn() end end

    local closeBtn=vgui.Create("DButton",topbar)
    closeBtn:SetSize(42,TOP_H); closeBtn:SetPos(MW-42,0); closeBtn:SetText("")
    local cH,cL=0,CurTime()
    closeBtn.Think=function(self) local dt=CurTime()-cL; cL=CurTime(); cH=math.Approach(cH,self:IsHovered() and 1 or 0,dt*14) end
    closeBtn.Paint=function(self,w,h)
        if cH>0 then RRct(6,0,0,w,h+8,FA(T.DangerBg,math.Round(cH*200))) end
        Txt("✕","WL_Title",w/2,h/2,FA(cH>0 and T.Danger or T.Dim,math.Round(Lerp(cH,160,255))),1,1)
    end
    closeBtn.DoClick=function() overlay:Remove() end

    -- ── FOOTER / STATS ────────────────────────────────────────────────────────
    local botBar=vgui.Create("DPanel",main)
    botBar:SetSize(MW,BOT_H); botBar:SetPos(0,MH-BOT_H)
    botBar.Paint=function(self,w,h)
        RRct(6, 0, -8, w, h+8, T.Bar)
        surface.SetDrawColor(FA(T.Border,100)); surface.DrawRect(0,0,w,1)
        local total,online=0,0
        for _,row in ipairs(WLData) do total=total+1; if row.online then online=online+1 end end
        local uniq={}; for _,row in ipairs(WLData) do uniq[row.steamid]=true end
        local players=0; for _ in pairs(uniq) do players=players+1 end
        local function Badge(label,val,col,bx)
            RRct(4,bx,h/2-11,62,22,FA(T.Card,200))
            surface.SetDrawColor(FA(T.Border,100)); surface.DrawOutlinedRect(bx,h/2-11,62,22,1)
            surface.SetDrawColor(FA(col,200)); surface.DrawRect(bx,h/2-11,2,22)
            Txt(label,"WL_Sub",bx+8,h/2-3,FA(T.Dim,175))
            Txt(tostring(val),"WL_SubBold",bx+8,h/2+5,col)
        end
        Badge("Players",players,Accent(),  10)
        Badge("Entries",total,  Accent(),  80)
        Badge("Online", online, online>0 and T.Success or T.Dim, 150)
    end

    -- ── BODY ──────────────────────────────────────────────────────────────────
    local contentY = TOP_H
    local contentH = BODY_H

    local leftPanel=vgui.Create("DPanel",main)
    leftPanel:SetSize(LEFT_W,BODY_H); leftPanel:SetPos(0,contentY)
    leftPanel.Paint=function(self,w,h)
        Rect(0,0,w,h,FA(T.Card,80))
        surface.SetDrawColor(FA(T.Border,80)); surface.DrawRect(w-1,0,1,h)
    end

    local rightPanel=vgui.Create("DPanel",main)
    rightPanel:SetSize(RIGHT_W,BODY_H); rightPanel:SetPos(LEFT_W,contentY)
    rightPanel.Paint=function(self,w,h) Rect(0,0,w,h,FA(T.Bar,180)) end

    -- ── RIGHT: Stats card ─────────────────────────────────────────────────────
    local statsCard=vgui.Create("DPanel",rightPanel)
    statsCard:SetSize(RIGHT_W-PAD*2,130); statsCard:SetPos(PAD,PAD)
    statsCard.Paint=function(self,w,h)
        RRct(4,0,0,w,h,FA(T.Card,220))
        surface.SetDrawColor(Accent()); surface.DrawRect(0,0,w,2)
        Bord(0,0,w,h,FA(T.Border,120))
        Txt("OVERVIEW","WL_Sect",14,12,FA(T.Dim,180))
        surface.SetDrawColor(FA(T.Border,80)); surface.DrawRect(8,26,w-16,1)
        -- Count stats
        local total,online=0,0
        for _,row in ipairs(WLData) do total=total+1; if row.online then online=online+1 end end
        local uniq={}; for _,row in ipairs(WLData) do uniq[row.steamid]=true end
        local players=0; for _ in pairs(uniq) do players=players+1 end
        local slotCounts={}; for _,row in ipairs(WLData) do slotCounts[row.slot_index]=(slotCounts[row.slot_index] or 0)+1 end
        local stats={
            {"Players",  tostring(players), T.Text},
            {"Entries",  tostring(total),   FA(Accent(),220)},
            {"Online",   tostring(online),  online>0 and T.Success or T.Dim},
            {"Slot 2",   tostring(slotCounts[2] or 0), T.regiment},
            {"Slot 3",   tostring(slotCounts[3] or 0), T.event},
        }
        for i,s in ipairs(stats) do
            local ry=32+(i-1)*18
            Txt(s[1],"WL_Small",14,ry,FA(T.Dim,180))
            Txt(s[2],"WL_SubBold",w-14,ry,s[3],2)
        end
    end

    -- ── RIGHT: Slot type legend ───────────────────────────────────────────────
    local legendCard=vgui.Create("DPanel",rightPanel)
    legendCard:SetSize(RIGHT_W-PAD*2,90); legendCard:SetPos(PAD,PAD+138)
    legendCard.Paint=function(self,w,h)
        RRct(4,0,0,w,h,FA(T.Card,200))
        surface.SetDrawColor(FA(T.Border,100)); surface.DrawRect(0,0,w,2)
        Bord(0,0,w,h,FA(T.Border,100))
        Txt("SLOT TYPES","WL_Sect",14,12,FA(T.Dim,180))
        surface.SetDrawColor(FA(T.Border,80)); surface.DrawRect(8,26,w-16,1)
        local types={{"regiment","Regiment"},{"jedi","Jedi"},{"event","Event"},{"clone","Clone"},{"generic","Generic"}}
        local cols=math.ceil(#types/2)
        for i,tv in ipairs(types) do
            local col2=TC(tv[1])
            local col_i=(i-1)%cols; local row_i=math.floor((i-1)/cols)
            local tx=14+col_i*math.floor((w-14)/cols); local ty=34+row_i*20
            surface.SetDrawColor(col2); surface.DrawRect(tx,ty+3,8,8)
            Txt(tv[2],"WL_Sub",tx+12,ty+7,FA(col2,200),0,1)
        end
    end

    -- ── RIGHT: Quick help card ────────────────────────────────────────────────
    local helpCard=vgui.Create("DPanel",rightPanel)
    helpCard:SetSize(RIGHT_W-PAD*2,76); helpCard:SetPos(PAD,PAD+238)
    helpCard.Paint=function(self,w,h)
        RRct(4,0,0,w,h,FA(T.Card,160))
        Bord(0,0,w,h,FA(T.Border,80))
        Txt("QUICK HELP","WL_Sect",14,12,FA(T.Dim,160))
        surface.SetDrawColor(FA(T.Border,60)); surface.DrawRect(8,26,w-16,1)
        local tips={"Use Grant Access tab to add entries","Click slot badge on a row to cycle slots","✕ S# buttons revoke that specific slot"}
        for i,tip in ipairs(tips) do Txt("· "..tip,"WL_Sub",14,28+i*14,FA(T.Dim,155)) end
    end

    -- ── LEFT: Search bar ──────────────────────────────────────────────────────
    local SRCH_H=40; local SRCH_Y=8
    local searchBg=MakeEntry(leftPanel,PAD,SRCH_Y,LEFT_W-PAD*2,SRCH_H-4,"Search player, SteamID, or job…")

    -- ── LEFT: Column header ───────────────────────────────────────────────────
    local COL_H=24; local COL_Y=SRCH_Y+SRCH_H+2
    local COLS={
        {label="PLAYER",    frac=0.30},
        {label="SLOT",      frac=0.07},
        {label="TYPE",      frac=0.10},
        {label="SAVED JOB", frac=0.22},
        {label="GRANTED BY",frac=0.14},
        {label="ACTIONS",   frac=0.17},
    }
    local colHdr=vgui.Create("DPanel",leftPanel)
    colHdr:SetPos(PAD,COL_Y); colHdr:SetSize(LEFT_W-PAD*2,COL_H)
    colHdr.Paint=function(self,w,h)
        Rect(0,0,w,h,FA(T.BarSel,220))
        surface.SetDrawColor(FA(T.Border,100)); surface.DrawRect(0,h-1,w,1)
        local cx=8
        for _,col in ipairs(COLS) do
            Txt(col.label,"WL_Badge",cx,h/2,FA(Accent(),200),0,1)
            cx=cx+math.floor(w*col.frac)
        end
    end

    -- ── LEFT: Scroll list ─────────────────────────────────────────────────────
    local LIST_Y=COL_Y+COL_H+2
    local LIST_H=contentH-LIST_Y-4
    local LIST_W=LEFT_W-PAD*2
    local ROW_H=50
    local SBAR=4

    local scrollOuter=vgui.Create("DPanel",leftPanel)
    scrollOuter:SetPos(PAD,LIST_Y); scrollOuter:SetSize(LIST_W,LIST_H)
    scrollOuter:SetMouseInputEnabled(true); scrollOuter:NoClipping(false)
    scrollOuter.Paint=function() end

    local canvasW=LIST_W-SBAR-2
    local canvas=vgui.Create("DPanel",scrollOuter)
    canvas:SetSize(canvasW,LIST_H); canvas:SetPos(0,0); canvas.Paint=function() end

    local sbar=vgui.Create("DVScrollBar",scrollOuter)
    sbar:SetSize(SBAR,LIST_H); sbar:SetPos(LIST_W-SBAR,0)
    sbar.Paint=function(s,w,h) RRct(2,0,0,w,h,FA(T.Border,60)) end
    sbar.btnUp.Paint=function() end; sbar.btnDown.Paint=function() end
    sbar.btnGrip.Paint=function(s,w,h) RRct(2,0,0,w,h,FA(Accent(),150)) end
    scrollOuter.OnMouseWheeled=function(self,d) sbar:AddScroll(-d*3) end
    sbar.OnValueChanged=function(self,val) if IsValid(canvas) then canvas:SetPos(0,-math.Round(val)) end end

    -- ── ROW BUILDER ───────────────────────────────────────────────────────────
    local rowPanels={}

    local function RebuildRows()
        if not IsValid(canvas) then return end
        for _,rp in ipairs(rowPanels) do if IsValid(rp) then rp:Remove() end end
        rowPanels={}
        if IsValid(_G._F2WL_JobPicker) then _G._F2WL_JobPicker:Remove() end

        local filter=string.lower(IsValid(searchBg._entry) and searchBg._entry:GetValue() or "")

        -- Group by player
        local playerOrder={}; local playerData={}
        for _,row in ipairs(WLData) do
            local sid=row.steamid
            if not playerData[sid] then
                table.insert(playerOrder,sid)
                playerData[sid]={steamid=sid,nick=row.nick,online=row.online,activeSlot=row.activeSlot,slots={}}
            end
            if row.online then playerData[sid].online=true; playerData[sid].nick=row.nick; playerData[sid].activeSlot=row.activeSlot end
            playerData[sid].slots[row.slot_index]={slot_type=row.slot_type,saved_job=row.saved_job or "",granted_by=row.granted_by,granted_at=row.granted_at}
        end
        table.sort(playerOrder,function(a,b)
            local ao=playerData[a].online; local bo=playerData[b].online
            if ao~=bo then return ao end; return a<b
        end)

        local yOff,shown=0,0
        local altRow=0

        for _,sid in ipairs(playerOrder) do
            local pd=playerData[sid]
            if filter~="" then
                local mS=string.find(sid,filter,1,true)
                local mN=string.find(string.lower(pd.nick or ""),filter,1,true)
                local mJ=false
                for _,sd in pairs(pd.slots) do if string.find(string.lower(sd.saved_job or ""),filter,1,true) then mJ=true; break end end
                if not mS and not mN and not mJ then continue end
            end
            shown=shown+1; altRow=altRow+1

            local orderedSlots={}; for si in pairs(pd.slots) do table.insert(orderedSlots,si) end
            table.sort(orderedSlots)
            local viewSlot=orderedSlots[1] or 1

            local rp=vgui.Create("DPanel",canvas)
            rp:SetSize(canvasW,ROW_H-2); rp:SetPos(0,yOff)
            table.insert(rowPanels,rp)

            -- Column pixel widths
            local cws={}; for _,col in ipairs(COLS) do table.insert(cws,math.floor(canvasW*col.frac)) end

            rp.Paint=function(self,w,h)
                local vsd=pd.slots[viewSlot] or {}
                local tc=TC(vsd.slot_type or "generic")
                local isAct=pd.online and pd.activeSlot==viewSlot
                -- Row bg — alternating subtle tint
                Rect(0,0,w,h,FA(T.Card,altRow%2==1 and 200 or 160))
                if isAct then Rect(0,0,w,h,FA(tc,14)) end
                -- Left accent stripe matching slot type
                surface.SetDrawColor(FA(tc,isAct and 220 or 70)); surface.DrawRect(0,0,3,h)
                -- Bottom divider
                surface.SetDrawColor(FA(T.Border,60)); surface.DrawRect(0,h-1,w,1)

                -- PLAYER column
                local px=8
                if pd.online then
                    surface.SetDrawColor(T.Success); surface.DrawRect(px,h/2-5,3,10)
                    Txt(pd.nick or "","WL_Small",px+8,h/2-9,T.Text)
                    Txt(sid,"WL_Mono",px+8,h/2+3,FA(T.Dim,150))
                else
                    surface.SetDrawColor(FA(T.Faint,100)); surface.DrawRect(px,h/2-5,3,10)
                    Txt(sid,"WL_Mono",px+8,h/2,FA(T.Dim,180),0,1)
                end

                -- SAVED JOB column
                local jx=8+cws[1]+cws[2]+cws[3]
                local vsd2=pd.slots[viewSlot] or {}
                local sj=vsd2.saved_job or ""
                Txt(sj~="" and sj or "(default)","WL_Mono",jx+4,h/2,sj~="" and T.Text or FA(T.Dim,130),0,1)

                -- GRANTED BY column
                local gx=jx+cws[4]
                Txt(vsd2.granted_by or "?","WL_Sub",gx+4,h/2,FA(T.Dim,150),0,1)
            end

            -- SLOT badge (cycles slots)
            local slotX=8+cws[1]
            local slotBadge=vgui.Create("DButton",rp)
            slotBadge:SetSize(cws[2]-6,ROW_H-14); slotBadge:SetPos(slotX,6); slotBadge:SetText("")
            local sH,sL=0,CurTime()
            slotBadge.Think=function(self) local dt=CurTime()-sL; sL=CurTime(); sH=math.Approach(sH,self:IsHovered() and 1 or 0,dt*14) end
            slotBadge.Paint=function(self,w,h)
                local vsd=pd.slots[viewSlot] or {}; local tc=TC(vsd.slot_type or "generic")
                RRct(4,0,0,w,h,FA(tc,math.Round(Lerp(sH,30,60))))
                Bord(0,0,w,h,FA(tc,math.Round(Lerp(sH,80,160))))
                Txt("S"..viewSlot,"WL_Badge",w/2,h/2-(#orderedSlots>1 and 3 or 0),tc,1,1)
                if #orderedSlots>1 then Txt("▼","WL_Sub",w/2,h-5,FA(T.Dim,180),1,1) end
            end
            slotBadge.DoClick=function()
                if #orderedSlots<=1 then return end
                for i,si in ipairs(orderedSlots) do if si==viewSlot then viewSlot=orderedSlots[(i%#orderedSlots)+1]; break end end
            end

            -- TYPE pill
            local typeX=slotX+cws[2]
            local typePill=vgui.Create("DPanel",rp)
            typePill:SetSize(cws[3]-6,ROW_H-14); typePill:SetPos(typeX,6)
            typePill.Paint=function(self,w,h)
                local vsd=pd.slots[viewSlot] or {}; local tc=TC(vsd.slot_type or "generic")
                RRct(4,0,0,w,h,FA(tc,22)); Bord(0,0,w,h,FA(tc,65))
                Txt(string.upper((vsd.slot_type or "?"):sub(1,3)),"WL_Badge",w/2,h/2,tc,1,1)
            end

            -- ACTIONS column: revoke buttons + job picker
            local actX=8; for k=1,5 do actX=actX+cws[k] end
            local actW=canvasW-actX-6

            -- Revoke buttons for slots > 1
            local nonBase={}; for _,si in ipairs(orderedSlots) do if si>1 then table.insert(nonBase,si) end end
            local RVK_W,RVK_H=math.min(40,actW),12
            for bi,sn in ipairs(nonBase) do
                local vsdR=pd.slots[sn] or {}; local tc2=TC(vsdR.slot_type or "generic")
                local bX=actX+(bi-1)*(RVK_W+3); local bY=3
                local rvk=vgui.Create("DButton",rp)
                rvk:SetSize(RVK_W,RVK_H); rvk:SetPos(bX,bY); rvk:SetText("")
                local rH2,rL2=0,CurTime()
                rvk.Think=function(self) local dt=CurTime()-rL2; rL2=CurTime(); rH2=math.Approach(rH2,self:IsHovered() and 1 or 0,dt*14) end
                rvk.Paint=function(self,w,h)
                    RRct(3,0,0,w,h,FA(T.DangerBg,math.Round(Lerp(rH2,150,220))))
                    Bord(0,0,w,h,FA(T.Danger,math.Round(Lerp(rH2,100,220))))
                    Txt("✕ S"..sn,"WL_Sub",w/2,h/2,FA(T.Text,math.Round(Lerp(rH2,190,255))),1,1)
                end
                rvk.DoClick=function()
                    Derma_Query("Revoke Slot "..sn.." from\n"..(pd.nick~="" and pd.nick or sid).."?","Confirm Revoke",
                        "Revoke",function() net.Start("F2WL_RevokeSlot"); net.WriteString(sid); net.WriteUInt(sn,4); net.SendToServer() end,
                        "Cancel",function() end)
                end
            end

            -- Job picker button
            local pickerBtn=vgui.Create("DButton",rp)
            pickerBtn:SetSize(actW,18); pickerBtn:SetPos(actX,ROW_H-22); pickerBtn:SetText("")
            local pH,pL=0,CurTime()
            pickerBtn.Think=function(self) local dt=CurTime()-pL; pL=CurTime(); pH=math.Approach(pH,self:IsHovered() and 1 or 0,dt*14) end
            pickerBtn.Paint=function(self,w,h)
                local vsd=pd.slots[viewSlot] or {}
                local lbl=(vsd.saved_job and vsd.saved_job~="") and vsd.saved_job or "Set job…"
                RRct(4,0,0,w,h,FA(T.Card,math.Round(Lerp(pH,180,220))))
                Bord(0,0,w,h,FA(Accent(),math.Round(Lerp(pH,50,160))))
                Txt(lbl,"WL_Sub",8,h/2,FA(T.Text,math.Round(Lerp(pH,185,255))),0,1)
                Txt("▾","WL_Sub",w-6,h/2,FA(Accent(),180),2,1)
            end
            pickerBtn.DoClick=function()
                local vsd=pd.slots[viewSlot] or {}
                OpenJobPicker(pickerBtn,function(jobCmd)
                    net.Start("F2WL_SetSlotJob"); net.WriteString(sid); net.WriteUInt(viewSlot,4); net.WriteString(jobCmd); net.SendToServer()
                    if pd.slots[viewSlot] then pd.slots[viewSlot].saved_job=jobCmd end
                end, TC(vsd.slot_type or "generic"))
            end

            yOff=yOff+ROW_H
        end

        if shown==0 then
            local ep=vgui.Create("DPanel",canvas); ep:SetSize(canvasW,60); ep:SetPos(0,0)
            ep.Paint=function(self,w,h)
                Txt(filter~="" and "No results for \""..filter.."\"" or "No whitelist entries.","WL_Small",w/2,h/2,FA(T.Dim,150),1,1)
            end
            table.insert(rowPanels,ep)
        end

        local totalH=math.max(yOff,LIST_H)
        canvas:SetTall(totalH)
        sbar:SetUp(LIST_H,totalH)
    end

    RebuildFn=RebuildRows
    searchBg.OnChange=function() RebuildRows() end
    RebuildRows()

    -- ── GRANT TAB ─────────────────────────────────────────────────────────────
    local grantPanel=vgui.Create("DPanel",leftPanel)
    grantPanel:SetPos(0,0); grantPanel:SetSize(LEFT_W,contentH)
    grantPanel:SetVisible(false)
    grantPanel.Paint=function(self,w,h) Rect(0,0,w,h,FA(T.Overlay,160)) end

    local GP=PAD*2

    -- Info banner
    local banner=vgui.Create("DPanel",grantPanel)
    banner:SetPos(GP,GP); banner:SetSize(LEFT_W-GP*2,52)
    banner.Paint=function(self,w,h)
        RRct(4,0,0,w,h,FA(T.Card,200))
        surface.SetDrawColor(Accent()); surface.DrawRect(0,0,3,h)
        Bord(0,0,w,h,FA(Accent(),50))
        Txt("Grant a player access to an extra character slot.","WL_Small",14,h/2-8,T.Text)
        Txt("The player will be notified and can switch via F2.","WL_Sub",14,h/2+8,FA(T.Dim,190))
    end

    local FY=GP+62; local FW2=math.floor((LEFT_W-GP*2-16)/2)

    local function SectLbl(text,x,y)
        local lp=vgui.Create("DPanel",grantPanel); lp:SetSize(220,14); lp:SetPos(x,y)
        lp.Paint=function(self,w,h) Txt(text,"WL_Badge",0,h,FA(Accent(),200),0,2) end
    end

    -- Online player picker
    SectLbl("SELECT ONLINE PLAYER",GP,FY)
    local selectedSID,selectedNick=nil,nil
    local ppBtn=vgui.Create("DButton",grantPanel)
    ppBtn:SetPos(GP,FY+16); ppBtn:SetSize(FW2,34); ppBtn:SetText(""); ppBtn:SetCursor("hand")
    local ppH,ppL=0,CurTime()
    ppBtn.Think=function(self) local dt=CurTime()-ppL; ppL=CurTime(); ppH=math.Approach(ppH,self:IsHovered() and 1 or 0,dt*14) end
    ppBtn.Paint=function(self,w,h)
        RRct(4,0,0,w,h,FA(T.Card,math.Round(Lerp(ppH,180,220))))
        Bord(0,0,w,h,FA(Accent(),math.Round(Lerp(ppH,60,160))))
        local lbl=selectedNick and (selectedNick.." · "..selectedSID) or "Choose online player…"
        Txt(lbl,"WL_Small",10,h/2,selectedSID and T.Text or FA(T.Dim,180),0,1)
        Txt("▾","WL_Small",w-10,h/2,FA(Accent(),200),2,1)
    end
    ppBtn.DoClick=function()
        local m=DermaMenu()
        for _,p in ipairs(player.GetAll()) do
            local ps,pn=p:SteamID(),p:Nick()
            m:AddOption(pn.." · "..ps,function() selectedSID=ps; selectedNick=pn end)
        end
        m:Open()
    end

    -- OR divider
    local orDiv=vgui.Create("DPanel",grantPanel); orDiv:SetPos(GP+FW2+2,FY+16); orDiv:SetSize(14,34)
    orDiv.Paint=function(self,w,h) Txt("or","WL_Sub",w/2,h/2,FA(T.Dim,180),1,1) end

    -- Manual SteamID entry
    SectLbl("MANUAL STEAMID (offline)",GP+FW2+18,FY)
    local sidEntry=MakeEntry(grantPanel,GP+FW2+18,FY+16,FW2-18,34,"STEAM_X:X:XXXXXXXX")

    -- Slot picker
    local SLY=FY+70
    SectLbl("SLOT",GP,SLY)
    local selectedSlot=2
    local spBtn=vgui.Create("DButton",grantPanel)
    spBtn:SetPos(GP,SLY+16); spBtn:SetSize(190,34); spBtn:SetText(""); spBtn:SetCursor("hand")
    local spH,spL=0,CurTime()
    spBtn.Think=function(self) local dt=CurTime()-spL; spL=CurTime(); spH=math.Approach(spH,self:IsHovered() and 1 or 0,dt*14) end
    spBtn.Paint=function(self,w,h)
        RRct(4,0,0,w,h,FA(T.Card,math.Round(Lerp(spH,180,220))))
        Bord(0,0,w,h,FA(Accent(),math.Round(Lerp(spH,60,150))))
        local sl=F2SlotConfig.Slots[selectedSlot]
        Txt(sl and ("Slot "..selectedSlot.." — "..sl.label) or "Select slot…","WL_Small",10,h/2,T.Text,0,1)
        Txt("▾","WL_Small",w-10,h/2,FA(Accent(),200),2,1)
    end
    spBtn.DoClick=function()
        local m=DermaMenu()
        for i=2,#F2SlotConfig.Slots do
            local sl=F2SlotConfig.Slots[i]; local idx=i
            m:AddOption("Slot "..idx.." — "..(sl.label or "?"),function() selectedSlot=idx end)
        end
        m:Open()
    end

    -- Type picker
    SectLbl("TYPE",GP+206,SLY)
    local TYPES={"regiment","jedi","event","clone","generic"}
    local selectedType="regiment"
    local tpBtn=vgui.Create("DButton",grantPanel)
    tpBtn:SetPos(GP+206,SLY+16); tpBtn:SetSize(150,34); tpBtn:SetText(""); tpBtn:SetCursor("hand")
    local tpH,tpL=0,CurTime()
    tpBtn.Think=function(self) local dt=CurTime()-tpL; tpL=CurTime(); tpH=math.Approach(tpH,self:IsHovered() and 1 or 0,dt*14) end
    tpBtn.Paint=function(self,w,h)
        local tc=TC(selectedType)
        RRct(4,0,0,w,h,FA(T.Card,math.Round(Lerp(tpH,180,220))))
        Bord(0,0,w,h,FA(tc,math.Round(Lerp(tpH,80,180))))
        surface.SetDrawColor(FA(tc,200)); surface.DrawRect(0,0,3,h)
        Txt(string.upper(selectedType),"WL_Small",12,h/2,tc,0,1)
        Txt("▾","WL_Small",w-10,h/2,FA(tc,200),2,1)
    end
    tpBtn.DoClick=function()
        local m=DermaMenu()
        for _,t in ipairs(TYPES) do
            local tv=t; m:AddOption(string.upper(tv),function() selectedType=tv end)
        end
        m:Open()
    end

    -- GRANT button
    local grantBtn=vgui.Create("DButton",grantPanel)
    grantBtn:SetPos(GP,SLY+70); grantBtn:SetSize(160,40); grantBtn:SetText(""); grantBtn:SetCursor("hand")
    local gbH,gbL=0,CurTime()
    grantBtn.Think=function(self) local dt=CurTime()-gbL; gbL=CurTime(); gbH=math.Approach(gbH,self:IsHovered() and 1 or 0,dt*14) end
    grantBtn.Paint=function(self,w,h)
        RRct(4,0,0,w,h,FA(T.Card,math.Round(Lerp(gbH,180,230))))
        surface.SetDrawColor(FA(T.Success,math.Round(Lerp(gbH,100,220)))); surface.DrawOutlinedRect(0,0,w,h,1)
        surface.SetDrawColor(FA(T.Success,math.Round(Lerp(gbH,150,255)))); surface.DrawRect(0,0,3,h)
        Txt("✔  Grant Slot","WL_Sect",w/2,h/2,FA(T.Success,math.Round(Lerp(gbH,200,255))),1,1)
    end
    grantBtn.DoClick=function()
        local sid2=(selectedSID and selectedSID~="") and selectedSID or string.Trim(sidEntry:GetValue())
        if not sid2 or sid2=="" then if _G.PushNotif then PushNotif("Select a player or enter a SteamID.","",2) end; return end
        if not selectedSlot or selectedSlot<2 then if _G.PushNotif then PushNotif("Select a slot.","",2) end; return end
        net.Start("F2WL_GrantSlot"); net.WriteString(sid2); net.WriteUInt(selectedSlot,4); net.WriteString(selectedType); net.SendToServer()
        sidEntry:SetValue(""); selectedSID=nil; selectedNick=nil
        if _G.PushNotif then PushNotif("Whitelist granted!","Slot "..selectedSlot.." → "..selectedType,1) end
    end

    -- ── Tab visibility toggle ─────────────────────────────────────────────────
    local lastTab=ActiveTab
    local function UpdateVis()
        local isList=(ActiveTab=="list")
        searchBg:SetVisible(isList); colHdr:SetVisible(isList); scrollOuter:SetVisible(isList)
        grantPanel:SetVisible(not isList)
    end
    UpdateVis()

    overlay.Think = function(self)
        self:SetAlpha(math.min(255,math.Round((CurTime()-fadeT)/0.15*255)))
        if ActiveTab~=lastTab then lastTab=ActiveTab; UpdateVis() end
    end

    end) -- end pcall

    if not ok then
        print("[F2 WL] Build error: "..tostring(err))
        local e=vgui.Create("DPanel",overlay); e:SetSize(600,80); e:SetPos((sw-600)/2,(sh-80)/2)
        e.Paint=function(self,w,h)
            RRct(4,0,0,w,h,FA(T.DangerBg,220)); Bord(0,0,w,h,FA(T.Danger,100))
            Txt("WHITELIST ERROR — check console","WL_Title",w/2,20,T.Text,1)
            Txt(tostring(err):sub(1,120),"WL_Sub",w/2,44,FA(T.Text,200),1)
            Txt("Press ESC to close","WL_Sub",w/2,62,FA(T.Dim,160),1)
        end
    end
end

-- ─── CHAT COMMANDS ────────────────────────────────────────────────────────────
hook.Add("OnPlayerChat","F2WL_ChatCmd",function(ply,text)
    if ply~=LocalPlayer() then return end
    local cmd=string.lower(text)
    if cmd=="!wlmanager" or cmd=="!wl" then
        timer.Simple(0,OpenWLManager); return true
    end
end)

print("[F2 WL] Whitelist client loaded.")