--[[
    H2O Clone Wars — Slot System Client
    ====================================
    File:   f2_slots_client.lua
    Place:  garrysmod/lua/autorun/client/  (or your gamemode's cl_ autorun)

    Press F2 or type !slots to open the slot/presets/settings UI.

    SOUNDS — files live at  garrysmod/sound/starwarsrp/
        buttonhover.mp3         ← hover sound
        buttonselect.mp3        ← click / deploy sound
        mainmenu.mp3            ← looping background music
    Edit the SFX table in Section 1 to swap files at any time.

    LOGO — loaded from:  materials/lego h2o/h2o_lego.png
    Make sure that file is packed into your FastDL / workshop content.
]]

if not F2SlotConfig then
    error("[F2 Slots] F2SlotConfig is nil — make sure f2_slots_shared.lua is loaded first.")
    return
end

-- ══════════════════════════════════════════════════════════════════════════════
--  SECTION 1 — SOUNDS  (edit paths here to swap audio files)
-- ══════════════════════════════════════════════════════════════════════════════

local SFX = {
    open     = "buttons/button15.wav",
    hover    = "vanilla/buttons/button19.wav",
    click    = "buttons/button17.wav",
    deploy   = "buttons/button14.wav",
    music    = "starwarsrp/mainmenu.mp3",
    musicVol = 0.35,
}

local _music = nil
local _musicStarting = false
local function StartMusic()
    if IsValid(_music) then return end
    if _musicStarting then return end
    _musicStarting = true
    sound.PlayFile("sound/" .. SFX.music, "noblock", function(ch, err)
        _musicStarting = false
        if not IsValid(ch) then
            print("[F2 Slots] Music failed to load:", err)
            return
        end
        -- Stop anything that snuck in while the async callback was pending
        if IsValid(_music) then _music:Stop() end
        _music = ch
        ch:SetVolume(SFX.musicVol)
        ch:EnableLooping(true)
        ch:Play()
    end)
end
local function StopMusic()
    _musicStarting = false
    if IsValid(_music) then _music:Stop() end
    _music = nil
end
local function PlaySFX(path)
    surface.PlaySound(path)
end
local PlayHoverSFX = PlaySFX

-- ══════════════════════════════════════════════════════════════════════════════
--  SECTION 2 — STATE & SETTINGS
-- ══════════════════════════════════════════════════════════════════════════════

local SlotAccess       = {}
local SavedJobs        = {}
local ActiveSlot       = 1
local SelectedSlot     = 1
local MenuOpen         = false
local SlotMenu         = nil
local ActiveTab        = "characters"
local SlotPresetModels = {}

local Settings = { accentH=210, accentS=0.75, accentV=0.90 }
local function LoadSettings()
    Settings.accentH = cookie.GetNumber("f2_accentH", Settings.accentH)
    Settings.accentS = cookie.GetNumber("f2_accentS", Settings.accentS)
    Settings.accentV = cookie.GetNumber("f2_accentV", Settings.accentV)
end
local function SaveSettings()
    cookie.Set("f2_accentH", tostring(Settings.accentH))
    cookie.Set("f2_accentS", tostring(Settings.accentS))
    cookie.Set("f2_accentV", tostring(Settings.accentV))
end
LoadSettings()

-- ══════════════════════════════════════════════════════════════════════════════
--  SECTION 3 — COLOUR HELPERS
-- ══════════════════════════════════════════════════════════════════════════════

local function HSVtoColor(h, s, v)
    h = h % 360
    local c = v * s
    local x = c * (1 - math.abs((h / 60) % 2 - 1))
    local m = v - c
    local r, g, b
    if     h <  60 then r,g,b = c,x,0
    elseif h < 120 then r,g,b = x,c,0
    elseif h < 180 then r,g,b = 0,c,x
    elseif h < 240 then r,g,b = 0,x,c
    elseif h < 300 then r,g,b = x,0,c
    else                r,g,b = c,0,x end
    return Color((r+m)*255, (g+m)*255, (b+m)*255)
end
local function AccentColor() return HSVtoColor(Settings.accentH, Settings.accentS,      Settings.accentV) end
local function AccentDim()   return HSVtoColor(Settings.accentH, Settings.accentS*0.55, Settings.accentV*0.55) end
_G.F2SlotAccentColor = AccentColor

local T = {
    Bg       = Color( 12,  14,  18, 255),
    Bar      = Color( 24,  27,  34, 242),
    BarSel   = Color( 34,  38,  50, 255),
    Card     = Color( 30,  34,  44, 215),
    CardHov  = Color( 42,  48,  62, 235),
    CardSel  = Color( 40,  48,  66, 250),
    Overlay  = Color(  5,   7,  11, 175),
    Border   = Color( 52,  60,  78, 125),
    Text     = Color(222, 226, 238),
    Dim      = Color(135, 144, 165),
    Faint    = Color( 70,  78,  98),
    Success  = Color( 45, 196, 135),
    Danger   = Color(215,  60,  60),
    Acc      = Color( 59, 130, 246),
    AccDim   = Color( 29,  78, 216),
    regiment = Color( 70, 130, 200),
    jedi     = Color(190, 160,  55),
    event    = Color(200,  80,  80),
    generic  = Color(110, 116, 135),
    clone    = Color( 70, 150, 210),
}
local function TC(t) return T[t] or T.generic end
local function FA(c, a) return ColorAlpha(c, math.Clamp(math.Round(a), 0, 255)) end
local function RefreshAccent() T.Acc = AccentColor(); T.AccDim = AccentDim() end
RefreshAccent()

-- ══════════════════════════════════════════════════════════════════════════════
--  SECTION 4 — FONTS
-- ══════════════════════════════════════════════════════════════════════════════

local function CreateFonts()
    surface.CreateFont("F2_TopTab",   {font="Roboto", size=13, weight=700, antialias=true})
    surface.CreateFont("F2_TopInfo",  {font="Roboto", size=11, weight=600, antialias=true})
    surface.CreateFont("F2_TopSub",   {font="Roboto", size=10, weight=400, antialias=true})
    surface.CreateFont("F2_CardJob",  {font="Roboto", size=14, weight=800, antialias=true})
    surface.CreateFont("F2_CardSub",  {font="Roboto", size=10, weight=600, antialias=true})
    surface.CreateFont("F2_CardLock", {font="Roboto", size=13, weight=600, antialias=true})
    surface.CreateFont("F2_Deploy",   {font="Roboto", size=13, weight=700, antialias=true})
    surface.CreateFont("F2_Small",    {font="Roboto", size=11, weight=400, antialias=true})
    surface.CreateFont("F2_SectLbl",  {font="Roboto", size=11, weight=700, antialias=true})
    surface.CreateFont("F2_Sub",      {font="Roboto", size=10, weight=400, antialias=true})
    surface.CreateFont("F2_SubBold",  {font="Roboto", size=10, weight=700, antialias=true})
    surface.CreateFont("F2_SettLbl",  {font="Roboto", size=12, weight=700, antialias=true})
    surface.CreateFont("F2_SettSub",  {font="Roboto", size=10, weight=400, antialias=true})
    surface.CreateFont("F2_CatLbl",   {font="Roboto", size=11, weight=700, antialias=true})
    surface.CreateFont("F2_CardLbl",  {font="Roboto", size=11, weight=600, antialias=true})
    surface.CreateFont("F2_Notif",    {font="Roboto", size=12, weight=600, antialias=true})
    surface.CreateFont("F2_NotifSm",  {font="Roboto", size=10, weight=400, antialias=true})
    surface.CreateFont("F2_PresetNm", {font="Roboto", size=13, weight=800, antialias=true})
end
CreateFonts()
hook.Add("Initialize",          "F2Slot_Fonts",  CreateFonts)
hook.Add("OnScreenSizeChanged", "F2Slot_Fonts2", CreateFonts)

-- ══════════════════════════════════════════════════════════════════════════════
--  SECTION 5 — DRAW HELPERS
-- ══════════════════════════════════════════════════════════════════════════════

local function Rect(x,y,w,h,c)      draw.RoundedBox(0,x,y,w,h,c) end
local function RRct(r,x,y,w,h,c)    draw.RoundedBox(r,x,y,w,h,c) end
local function Txt(t,f,x,y,c,ax,ay) draw.SimpleText(t,f,x,y,c, ax or 0, ay or 0) end

local blurMat = Material("pp/blurscreen")
local function DrawBlur(panel, amount, passes)
    local bx, by = panel:LocalToScreen(0, 0)
    surface.SetDrawColor(255,255,255,255)
    surface.SetMaterial(blurMat)
    for i = 1, passes do
        blurMat:SetFloat("$blur", (i/passes)*amount)
        blurMat:Recompute()
        render.UpdateScreenEffectTexture()
        surface.DrawTexturedRect(-bx,-by, ScrW(), ScrH())
    end
end

-- Vertical gradient (top colour → bottom colour, in N steps)
local function GradV(x,y,w,h, ct, cb, steps)
    steps = steps or 14
    for i = 0, steps-1 do
        local f  = i / (steps-1)
        local a1 = ct.a or 255; local a2 = cb.a or 255
        surface.SetDrawColor(
            math.Round(Lerp(f, ct.r, cb.r)),
            math.Round(Lerp(f, ct.g, cb.g)),
            math.Round(Lerp(f, ct.b, cb.b)),
            math.Round(Lerp(f, a1, a2)))
        local sy = y + math.Round(i/steps*h)
        surface.DrawRect(x, sy, w, math.Round((i+1)/steps*h) - math.Round(i/steps*h))
    end
end

-- Scanlines overlay
local function Scanlines(w, h, alpha, gap)
    gap = gap or 4
    surface.SetDrawColor(0,0,0, math.Round(alpha))
    for y2 = 0, h, gap do surface.DrawRect(0, y2, w, 1) end
end

-- Moving shimmer streak across a rect
local GT = 0
hook.Add("Think","H2O_GT",function() GT = GT + FrameTime() end)

local function Shimmer(x, y, w, h, al)
    local t  = (GT * 0.55) % 1.4 - 0.2
    local cx = x + t * (w + 80) - 40
    local hw = 45
    for px = math.max(x, math.Round(cx-hw)), math.min(x+w-1, math.Round(cx+hw)) do
        local frac = 1 - math.abs(px - cx) / hw
        surface.SetDrawColor(255,255,255, math.Round(frac^2 * al))
        surface.DrawRect(px, y, 1, h)
    end
end

-- Easing functions
local function EaseOut(t)   return 1-(1-t)^3 end
local function EaseInOut(t) return t<0.5 and 4*t*t*t or 1-(-2*t+2)^3/2 end
local function EaseBack(t)  local c1=1.70158; local c3=c1+1; return 1+c3*(t-1)^3+c1*(t-1)^2 end

-- ══════════════════════════════════════════════════════════════════════════════
--  SECTION 6 — HOVER STATE HELPER
-- ══════════════════════════════════════════════════════════════════════════════

-- NewHover() returns a table you call :Update(isHovered) on each Think.
-- Read .v for the 0→1 smoothed hover fraction.
local function NewHover(speed)
    speed = speed or 12
    local s = { v=0, _t=CurTime() }
    function s:Update(isHov)
        local now = CurTime(); local dt = math.min(now-self._t, 0.1); self._t = now
        self.v = math.Approach(self.v, isHov and 1 or 0, dt * speed)
    end
    return s
end

-- ══════════════════════════════════════════════════════════════════════════════
--  SECTION 7 — BACKGROUND PARTICLES
-- ══════════════════════════════════════════════════════════════════════════════

-- ══════════════════════════════════════════════════════════════════════════════
--  BUBBLE PARTICLES — rising water bubbles for the H2O theme
-- ══════════════════════════════════════════════════════════════════════════════

local BUBBLES = {}
local function InitParticles(sw, sh)
    BUBBLES = {}
    for i = 1, 55 do
        BUBBLES[i] = {
            x      = math.random(0, sw),
            y      = math.random(0, sh),
            spd    = math.random(18, 55) * 0.1,   -- upward speed
            sway   = math.random(5, 22) * 0.01,   -- horizontal sway amplitude (radians/s)
            swayT  = math.random(0, 628) * 0.01,  -- sway phase offset
            swayW  = math.random(8, 32) * 0.1,    -- sway width in px
            r      = math.random(2, 7),            -- bubble radius
            al     = math.random(18, 60),
            pulse  = math.random(0, 628) * 0.01,
        }
    end
end

-- Draw a hollow circle bubble using line segments
local function DrawBubble(cx, cy, r, col)
    local steps = math.max(8, math.floor(r * 3.5))
    local prev_x, prev_y
    surface.SetDrawColor(col)
    for s = 0, steps do
        local a = (s / steps) * math.pi * 2
        local nx = cx + math.cos(a) * r
        local ny = cy + math.sin(a) * r
        if prev_x then
            surface.DrawLine(math.Round(prev_x), math.Round(prev_y), math.Round(nx), math.Round(ny))
        end
        prev_x, prev_y = nx, ny
    end
    -- tiny specular highlight at top-left of bubble
    local hx = cx - r * 0.35; local hy = cy - r * 0.35
    surface.SetDrawColor(ColorAlpha(col, math.min(col.a, math.Round(col.a * 0.65))))
    surface.DrawRect(math.Round(hx), math.Round(hy), 1, 1)
end

local function DrawParticles(sw, sh, masterAlpha)
    local acc = AccentColor()
    local dt  = FrameTime()
    for _, b in ipairs(BUBBLES) do
        b.swayT = b.swayT + dt * b.sway
        b.pulse = b.pulse + dt * 0.9
        b.x     = b.x + math.sin(b.swayT) * b.swayW * dt
        b.y     = b.y - b.spd * dt
        if b.y < -b.r * 2 then
            b.y = sh + b.r
            b.x = math.random(0, sw)
        end
        local pulse = (math.sin(b.pulse) + 1) * 0.5
        local al    = math.Round(b.al * masterAlpha * (0.5 + 0.5 * pulse))
        DrawBubble(math.Round(b.x), math.Round(b.y), b.r,
            FA(Color(
                math.min(255, acc.r + 40),
                math.min(255, acc.g + 20),
                math.min(255, acc.b + 10)
            ), al))
    end
end

-- ══════════════════════════════════════════════════════════════════════════════
--  SECTION 8 — GAME DATA HELPERS
-- ══════════════════════════════════════════════════════════════════════════════

local function GetJobName()
    local ply = LocalPlayer(); if not IsValid(ply) then return "UNKNOWN" end
    if ply.getDarkRPVar then return string.upper(ply:getDarkRPVar("job") or "UNKNOWN") end
    return string.upper(team.GetName(ply:Team()) or "UNKNOWN")
end
local function GetLevel()
    local ply = LocalPlayer(); if not IsValid(ply) then return 0 end
    if ply.getDarkRPVar then return ply:getDarkRPVar("level") or ply:getDarkRPVar("xplevel") or 0 end
    return 0
end
local function GetMoney()
    local ply = LocalPlayer(); if not IsValid(ply) then return 0 end
    if ply.getDarkRPVar then return ply:getDarkRPVar("money") or 0 end
    return 0
end
local function FmtMoney(n)
    local s = tostring(math.abs(math.floor(n))); local out, len = "", #s
    for i = 1, len do
        if i > 1 and (len-i) % 3 == 2 then out = out .. "," end
        out = out .. s:sub(i,i)
    end
    return (n < 0 and "-" or "") .. out
end

local function GetSlotJobInfo(idx)
    if SlotPresetModels[idx] then
        local cmd = SavedJobs[idx]; local nm = ""
        if cmd and cmd ~= "" and RPExtraTeams then
            for _, j in ipairs(RPExtraTeams) do if j.command==cmd then nm=string.upper(j.name); break end end
        end
        if idx == ActiveSlot then return GetJobName(), SlotPresetModels[idx] end
        return nm, SlotPresetModels[idx]
    end
    local cmd = SavedJobs[idx]
    if cmd and cmd ~= "" and RPExtraTeams then
        for _, j in ipairs(RPExtraTeams) do
            if j.command == cmd then
                local m = j.model; if type(m)=="table" then m=m[1] end
                return idx==ActiveSlot and GetJobName() or string.upper(j.name), m
            end
        end
    end
    local dc = F2SlotConfig.Slots[idx] and F2SlotConfig.Slots[idx].default_job or ""
    if dc ~= "" and RPExtraTeams then
        for _, j in ipairs(RPExtraTeams) do
            if j.command == dc then
                local m = j.model; if type(m)=="table" then m=m[1] end
                return string.upper(j.name), m
            end
        end
    end
    return idx==ActiveSlot and GetJobName() or string.upper(dc), nil
end

-- ══════════════════════════════════════════════════════════════════════════════
--  SECTION 9 — NOTIFICATIONS
-- ══════════════════════════════════════════════════════════════════════════════

local _notifs = {}
local function PushNotif(msg, sub, ntype)
    if F2Notify then F2Notify.Push(msg, sub, ntype); return end
    ntype = ntype or 0; sub = sub or ""
    local cols = {
        [0]=AccentColor,
        [1]=function() return Color(45,196,135) end,
        [2]=function() return Color(200,160,30) end,
        [3]=function() return Color(215,60,60) end,
    }
    table.insert(_notifs, {msg=msg, sub=sub, born=CurTime(), col=cols[ntype] or cols[0]})
    while #_notifs > 6 do table.remove(_notifs, 1) end
    PlaySFX("buttons/button15.wav")
end

hook.Add("HUDPaint","F2Slot_Notifs",function()
    if F2Notify then _notifs={}; return end
    if #_notifs == 0 then return end
    local sw, sh, now = ScrW(), ScrH(), CurTime()
    local NW, NH, LIFE, FADE = 300, 54, 5.0, 0.5
    local curY = sh - 80
    for i = #_notifs, 1, -1 do
        local n = _notifs[i]; local age = now - n.born
        if age > LIFE+FADE then table.remove(_notifs,i); goto cont end
        local hasSub = n.sub ~= ""; local nh = hasSub and 68 or NH; curY = curY - nh
        local al = age > LIFE and math.Round(255*(1-(age-LIFE)/FADE)) or 255
        -- slide in from right
        local slideA = EaseBack(math.Clamp(age/0.28,0,1))
        local slideX = math.Round((1-slideA)*70)
        local x = sw - NW - 16 + slideX
        local ac = n.col()
        -- shadow
        RRct(6, x+2, curY+2, NW, nh, FA(Color(0,0,0), math.Round(al*0.35)))
        -- body
        RRct(6, x, curY, NW, nh, FA(T.Bar, math.Round(al*0.97)))
        -- accent stripe
        surface.SetDrawColor(FA(ac,al)); surface.DrawRect(x, curY, 3, nh)
        -- border
        surface.SetDrawColor(FA(T.Border, math.Round(al*0.45))); surface.DrawOutlinedRect(x, curY, NW, nh, 1)
        -- progress
        local frac = math.Clamp(1-(age/LIFE),0,1)
        surface.SetDrawColor(FA(T.Border, math.Round(al*0.22))); surface.DrawRect(x+3, curY+nh-2, NW-3, 2)
        surface.SetDrawColor(FA(ac, math.Round(al*0.8)));  surface.DrawRect(x+3, curY+nh-2, math.Round((NW-3)*frac), 2)
        -- text
        Txt(n.msg, "F2_Notif", x+14, hasSub and curY+14 or curY+nh/2, FA(T.Text,al), 0, 1)
        if hasSub then Txt(n.sub, "F2_NotifSm", x+14, curY+32, FA(T.Dim, math.Round(al*0.82)), 0, 1) end
        curY = curY - 6
        ::cont::
    end
end)

-- ══════════════════════════════════════════════════════════════════════════════
--  SECTION 10 — NETWORK RECEIVERS
-- ══════════════════════════════════════════════════════════════════════════════

net.Receive("F2Slot_SyncData", function()
    ActiveSlot = net.ReadUInt(4); local count = net.ReadUInt(4); local oldJobs = {}
    for k,v in pairs(SavedJobs) do oldJobs[k]=v end
    for i = 1, count do
        SlotAccess[i] = net.ReadBool(); SavedJobs[i] = net.ReadString()
        if SavedJobs[i] ~= oldJobs[i] then SlotPresetModels[i] = nil end
    end
    if IsValid(SlotMenu) then
        local wasOpen = MenuOpen; SlotMenu:Remove(); SlotMenu=nil; MenuOpen=false
        if wasOpen then OpenSlotMenu() end
    end
end)

net.Receive("F2Slot_OpenMenu", function() OpenSlotMenu() end)

net.Receive("F2Slot_Notification", function()
    local msg = net.ReadString(); local srvType = net.ReadUInt(4)
    local typeMap = {[0]=0,[1]=1,[2]=3}; local sub = ""
    local patterns = {
        {"Switching","Stand by..."},{"Updating","Stand by..."},{"Deploying","Stand by..."},
        {"Now playing","Character deployed."},{"reset","Contact an administrator."},
        {"Reset","Contact an administrator."},{"wait","Please wait before trying again."},
        {"cooldown","Please wait before trying again."},{"access","You don't have permission."},
        {"Invalid","You don't have permission."},{"Rank","You don't have permission."},
        {"updated","An admin made a change."},{"admin","An admin made a change."},
    }
    for _, p in ipairs(patterns) do if string.find(msg,p[1],1,true) then sub=p[2]; break end end
    PushNotif(msg, sub, typeMap[srvType] or 0)
end)

-- ══════════════════════════════════════════════════════════════════════════════
--  SECTION 11 — MAIN SLOT MENU
-- ══════════════════════════════════════════════════════════════════════════════

function OpenSlotMenu()
    if IsValid(SlotMenu) then SlotMenu:Remove(); SlotMenu=nil end
    if MenuOpen then MenuOpen=false; return end

    local NUM    = #F2SlotConfig.Slots
    local sw, sh = ScrW(), ScrH()
    SelectedSlot = ActiveSlot
    RefreshAccent()
    InitParticles(sw, sh)

    PlaySFX(SFX.open)
    StartMusic()

    local frame = vgui.Create("DFrame")
    frame:SetSize(sw,sh); frame:SetPos(0,0)
    frame:SetTitle(""); frame:SetDraggable(false); frame:ShowCloseButton(false)
    frame:MakePopup(); frame:SetAlpha(0)
    SlotMenu=frame; MenuOpen=true

    local openT      = CurTime()
    local partAlpha  = 0
    local escWasDown = false
    local lastTab    = ""

    -- ── FRAME BACKGROUND ──────────────────────────────────────────────────────
    frame.Paint = function(self, w, h)
        local age = CurTime() - openT
        -- Blurred world behind
        DrawBlur(self, 5, 3)
        -- Original dark gradient
        GradV(0,0,w,h, FA(T.Bg,218), FA(Color(6,8,13),240), 20)
        -- Subtle scanlines
        Scanlines(w, h, 9)
        -- Faint caustic shimmer band (water feel without changing colours)
        local acc = AccentColor()
        local causticY = h * 0.38 + math.sin(GT * 0.4) * 18
        GradV(0, math.Round(causticY-40), w, 80,
            FA(Color(acc.r,acc.g,acc.b), 0),
            FA(Color(acc.r,acc.g,acc.b), 5),
            6)
        GradV(0, math.Round(causticY+40), w, 80,
            FA(Color(acc.r,acc.g,acc.b), 5),
            FA(Color(acc.r,acc.g,acc.b), 0),
            6)
        -- Drifting bubble particles (fade in)
        partAlpha = math.min(partAlpha + FrameTime()*1.6, 0.7)
        if age > 0.08 then DrawParticles(w, h, partAlpha) end
        -- Topbar accent line (sweeps in)
        local lineP = EaseOut(math.Clamp((age-0.05)/0.45, 0, 1))
        local lw    = math.Round(lineP * w)
        if lw > 0 then
            surface.SetDrawColor(FA(AccentColor(), 40))
            surface.DrawRect(0, 60, lw, 1)
        end
    end

    frame.OnRemoved = function()
        SlotMenu=nil; MenuOpen=false
        StopMusic()
    end

    -- ── TOPBAR ────────────────────────────────────────────────────────────────
    local TOP_H  = 60   -- slightly taller to give the logo space to breathe
    local BOT_H  = 62
    local LOGO_W = 180  -- reserved width on the left for the logo image
    local TABS   = {{id="characters",label="Characters"},{id="presets",label="Presets"},{id="settings",label="Settings"}}
    local TAB_W  = 140

    local topbar = vgui.Create("DPanel", frame)
    topbar:SetSize(sw, TOP_H); topbar:SetPos(0,0)
    topbar.Paint = function(self, w, h)
        GradV(0,0,w,h, FA(T.Bar,255), FA(T.Bar,248), 6)
        -- bottom border — wavy using sine sampling
        local acc = AccentColor()
        local wavAmp = 3
        local wavFreq = 0.022
        for px = 0, w-1, 2 do
            local wy = h - 1 + math.Round(math.sin((px * wavFreq) + GT * 1.6) * wavAmp)
            surface.SetDrawColor(FA(acc, 70))
            surface.DrawRect(px, wy, 2, 1)
        end
        surface.SetDrawColor(FA(acc, 28)); surface.DrawRect(0, h-1, w, 1)
        -- shimmer
        Shimmer(LOGO_W, 0, w-LOGO_W, h, 16)

        -- ── LOGO ──────────────────────────────────────────────────────────────
        local logoMat = Material("h2o/h2o_lego.png", "noclamp smooth")
        local lbX, lbY, lbS = 40, -20, 100
        surface.SetMaterial(logoMat)
        surface.SetDrawColor(255, 255, 255, 220)
        surface.DrawTexturedRect(lbX, lbY, lbS, lbS)

        -- centre info
        Txt("Level: "..GetLevel(),             "F2_TopInfo", w/2, h/2-7, T.Text, 1, 1)
        Txt("Balance: "..FmtMoney(GetMoney()), "F2_TopSub",  w/2, h/2+7, T.Dim,  1, 1)
    end

    -- Tab buttons — offset to start after the logo zone
    for i, tab in ipairs(TABS) do
        local t    = tab
        local hov  = NewHover(14)
        local prevH = false
        local btn  = vgui.Create("DButton", topbar)
        btn:SetSize(TAB_W, TOP_H); btn:SetPos(LOGO_W+(i-1)*TAB_W, 0); btn:SetText("")
        btn.Think = function(self)
            local isH = self:IsHovered()
            hov:Update(isH)
            if isH and not prevH then PlayHoverSFX(SFX.hover) end
            prevH = isH
        end
        btn.Paint = function(self, w, h)
            local sel = (ActiveTab == t.id)
            local acc = AccentColor()
            if sel then
                GradV(0,0,w,h, FA(acc,28), FA(acc,8), 8)
                -- wave underline when selected
                for px = 0, w-1, 2 do
                    local wy = h-2 + math.Round(math.sin((px*0.06)+GT*2)*1.5)
                    surface.SetDrawColor(FA(acc,230)); surface.DrawRect(px, wy, 2, 2)
                end
                surface.SetDrawColor(FA(acc,38)); surface.DrawRect(0, 0, w, 1)
                Txt(t.label, "F2_TopTab", w/2, h/2, T.Text, 1, 1)
            else
                if hov.v > 0 then GradV(0,0,w,h, FA(T.CardHov,math.Round(hov.v*65)), FA(T.CardHov,0), 6) end
                local lw2 = math.Round(Lerp(EaseOut(hov.v), 0, w*0.45))
                if lw2 > 0 then
                    surface.SetDrawColor(FA(acc, math.Round(hov.v*110)))
                    surface.DrawRect(math.Round((w-lw2)/2), h-2, lw2, 2)
                end
                Txt(t.label, "F2_TopTab", w/2, h/2, FA(T.Dim, math.Round(Lerp(hov.v,168,242))), 1, 1)
            end
        end
        btn.DoClick = function() ActiveTab = t.id; PlaySFX(SFX.click) end
    end

    -- Right-side action buttons (Request Admin / Links)
    local ACTIONS = {
        {label="Request Admin", onClick=function()
            if _G.F2Ticket_OpenForm then _G.F2Ticket_OpenForm()
            else PushNotif("Ticket system not loaded.","",3) end
        end},
        {label="Links", onClick=function()
            if IsValid(_G._F2_LinksPopup) then _G._F2_LinksPopup:Remove(); _G._F2_LinksPopup=nil; return end
            local links = {
                {label="Server Content", url="https://steamcommunity.com/sharedfiles/filedetails/?id=REPLACE_ME"},
                {label="Map Content",    url="https://steamcommunity.com/sharedfiles/filedetails/?id=REPLACE_ME"},
                {label="Discord",        url="https://discord.gg/REPLACE_ME"},
                {label="Forums",         url="https://REPLACE_ME.com/forums"},
            }
            local LW,LH = 180,36; local PH2 = #links*LH+8
            local pop = vgui.Create("DPanel",frame); pop:SetSize(LW,PH2); pop:SetPos(sw-LW-4,TOP_H+2)
            _G._F2_LinksPopup = pop
            pop.Paint = function(s,w,h)
                RRct(4,0,0,w,h,T.Bar)
                surface.SetDrawColor(FA(T.Border,175)); surface.DrawOutlinedRect(0,0,w,h,1)
            end
            for _, lnk in ipairs(links) do
                local l    = lnk
                local lhov = NewHover(14)
                local b    = vgui.Create("DButton",pop); b:SetSize(LW,LH); b:SetPos(0,(_-1)*LH); b:SetText("")
                b.Think = function(self) lhov:Update(self:IsHovered()) end
                b.Paint = function(self,w,h)
                    if lhov.v>0 then Rect(0,0,w,h, FA(T.CardHov,math.Round(lhov.v*175))) end
                    Txt(l.label,"F2_TopTab",14,h/2, FA(T.Text,math.Round(Lerp(lhov.v,185,255))),0,1)
                end
                b.DoClick = function() gui.OpenURL(l.url); PlaySFX(SFX.click) end
            end
        end},
    }
    local ACT_W = 140
    for i, act in ipairs(ACTIONS) do
        local a    = act
        local ahov = NewHover(14)
        local prevAH = false
        local btn  = vgui.Create("DButton",topbar); btn:SetSize(ACT_W,TOP_H); btn:SetPos(sw-(#ACTIONS-i+1)*ACT_W,0); btn:SetText("")
        btn.Think = function(self)
            local isH = self:IsHovered()
            ahov:Update(isH)
            if isH and not prevAH then PlayHoverSFX(SFX.hover) end
            prevAH = isH
        end
        btn.Paint = function(self,w,h)
            if ahov.v>0 then Rect(0,0,w,h, FA(T.CardHov,math.Round(ahov.v*95))) end
            surface.SetDrawColor(FA(T.Border,95)); surface.DrawRect(0,8,1,h-16)
            Txt(a.label,"F2_TopTab",w/2,h/2, FA(T.Dim,math.Round(Lerp(ahov.v,188,255))),1,1)
        end
        btn.DoClick = function() a.onClick(); PlaySFX(SFX.click) end
    end

    -- ── BOTTOM BAR ────────────────────────────────────────────────────────────
    local deployBar = vgui.Create("DPanel",frame)
    deployBar:SetSize(sw,BOT_H); deployBar:SetPos(0,sh-BOT_H)
    deployBar.Paint = function(self,w,h)
        GradV(0,0,w,h, FA(T.Bar,245), FA(T.Bar,255), 6)
        -- wavy top border
        local acc = AccentColor()
        for px = 0, w-1, 2 do
            local wy = math.Round(math.sin((px * 0.025) + GT * 1.8) * 2)
            surface.SetDrawColor(FA(acc, 45))
            surface.DrawRect(px, wy, 2, 1)
        end
        surface.SetDrawColor(FA(T.Border,115)); surface.DrawRect(0,0,w,1)
    end

    -- Active slot info
    local actInfo = vgui.Create("DPanel",deployBar); actInfo:SetSize(280,BOT_H); actInfo:SetPos(20,0)
    actInfo.Paint = function(self,w,h)
        surface.SetDrawColor(FA(T.Success,200)); surface.DrawRect(0,(h-24)/2,2,24)
        Txt("Active Slot","F2_TopSub",12,h/2-7, FA(T.Dim,200),0,1)
        Txt(GetJobName(),"F2_TopInfo",12,h/2+7, T.Text,0,1)
    end

    -- Deploy button — animated pulse when active
    local DBW,DBH  = 160,40
    local dBtn     = vgui.Create("DButton",deployBar)
    dBtn:SetSize(DBW,DBH); dBtn:SetPos((sw-DBW)/2,(BOT_H-DBH)/2); dBtn:SetText("")
    local dHov     = NewHover(14)
    local dCan     = false
    local dPulse   = 0
    local prevDH   = false
    local dFlash   = 0

    dBtn.Think = function(self)
        dCan = (SelectedSlot~=ActiveSlot) and (SelectedSlot==1 or SlotAccess[SelectedSlot]==true)
        local isH = self:IsHovered() and dCan
        dHov:Update(isH)
        if isH and not prevDH then PlayHoverSFX(SFX.hover) end
        prevDH = isH
        if dCan then dPulse = dPulse + FrameTime()*2.2 end
        if dFlash > 0 then dFlash = math.max(0, dFlash - FrameTime()*5) end
        self:SetEnabled(dCan)
    end
    dBtn.Paint = function(self,w,h)
        local acc = AccentColor()
        if dCan then
            -- outer pulse glow
            local pg = (math.sin(dPulse)+1)*0.5
            if pg > 0.04 then RRct(8,-4,-4,w+8,h+8, FA(acc, math.Round(pg*18))) end
            -- body gradient
            GradV(0,0,w,h,
                FA(Color(math.min(255,acc.r+28),math.min(255,acc.g+28),math.min(255,acc.b+28)), math.Round(Lerp(dHov.v,205,248))),
                FA(acc, math.Round(Lerp(dHov.v,195,238))), 12)
            -- click flash
            if dFlash>0 then Rect(0,0,w,h, FA(Color(255,255,255), math.Round(dFlash*45))) end
            -- top highlight
            surface.SetDrawColor(FA(Color(255,255,255), math.Round(38+dHov.v*28))); surface.DrawRect(0,0,w,1)
            -- border
            surface.SetDrawColor(FA(acc,255)); surface.DrawOutlinedRect(0,0,w,h,1)
            Txt("▶  Deploy","F2_Deploy",w/2,h/2, Color(255,255,255),1,1)
        else
            RRct(6,0,0,w,h, FA(T.Card,155))
            surface.SetDrawColor(FA(T.Border,95)); surface.DrawOutlinedRect(0,0,w,h,1)
            Txt("▶  Deploy","F2_Deploy",w/2,h/2, FA(T.Faint,125),1,1)
        end
    end
    dBtn.DoClick = function()
        if not dCan then return end
        dFlash = 1
        PlaySFX(SFX.deploy)
        net.Start("F2Slot_RequestSwitch"); net.WriteUInt(SelectedSlot,4); net.SendToServer()
        frame:Remove(); MenuOpen=false
        PushNotif("Deploying — Slot "..SelectedSlot,"Stand by for respawn.",0)
    end

    -- ESC hint
    local escLbl = vgui.Create("DPanel",deployBar); escLbl:SetSize(80,BOT_H); escLbl:SetPos(sw-100,0)
    escLbl.Paint = function(self,w,h) Txt("ESC","F2_TopSub",w/2,h/2, FA(T.Faint,125),1,1) end

    -- ── CHARACTERS PANEL ──────────────────────────────────────────────────────
    local charsPanel = vgui.Create("DPanel",frame)
    charsPanel:SetSize(sw, sh-TOP_H-BOT_H); charsPanel:SetPos(0,TOP_H)
    charsPanel.Paint = function() end

    local GAP    = 3
    local cardW2 = math.floor((sw-GAP*(NUM-1))/NUM)
    local cardH2 = sh-TOP_H-BOT_H

    for i = 1, NUM do
        local isUnlocked  = (i==1) or (SlotAccess[i]==true)
        local slotCfg     = F2SlotConfig.Slots[i]
        local typeCol     = TC(slotCfg and slotCfg.type or "generic")
        local cx2         = (i-1)*(cardW2+GAP)
        local revealDelay = (i-1)*0.045

        local card     = vgui.Create("DPanel",charsPanel)
        card:SetSize(cardW2,cardH2); card:SetPos(cx2,0)
        card:SetCursor(isUnlocked and "hand" or "arrow")

        local hov      = NewHover(10)
        local prevCH   = false
        local cFlash   = 0

        card.Think = function(self)
            local isH = self:IsHovered() and isUnlocked
            hov:Update(isH)
            if isH and not prevCH then PlayHoverSFX(SFX.hover) end
            prevCH = isH
            if cFlash>0 then cFlash = math.max(0, cFlash-FrameTime()*7) end
        end

        card.Paint = function(self, w, h)
            local isSel  = (SelectedSlot==i)
            local fadeA  = EaseOut(math.Clamp((CurTime()-openT-revealDelay)/0.32, 0, 1))
            -- slide up on open
            self:SetPos(cx2, math.Round((1-fadeA)*28))
            if fadeA <= 0.02 then return end

            local acc = AccentColor()
            local bgC = isSel and T.CardSel or (hov.v>0 and FA(T.CardHov,math.Round(Lerp(hov.v,212,240))) or FA(T.Card,212))
            Rect(0,0,w,h, FA(bgC, math.Round((bgC.a or 215)*fadeA)))

            -- subtle depth gradient (neutral, matches original palette)
            GradV(0,0,w,h,
                FA(Color(12,14,18), math.Round(30*fadeA)),
                FA(Color(12,14,18), math.Round(10*fadeA)), 8)

            -- top accent bar
            local barC = isSel and acc or FA(typeCol, math.Round(Lerp(hov.v,125,215)))
            surface.SetDrawColor(FA(barC, math.Round(fadeA*255)))
            surface.DrawRect(0,0,w, isSel and 3 or 2)

            -- left selection stripe
            if isSel then
                GradV(0,0,3,h, FA(acc,210), FA(acc,0), 6)
            end

            -- click flash
            if cFlash>0 then Rect(0,0,w,h, FA(Color(255,255,255), math.Round(cFlash*38*fadeA))) end

            -- border — water blue tint when selected
            local borderC = isSel and acc or (hov.v>0 and Color(
                    math.Round(Lerp(hov.v, T.Border.r, acc.r*0.6)),
                    math.Round(Lerp(hov.v, T.Border.g, acc.g*0.6)),
                    math.Round(Lerp(hov.v, T.Border.b, acc.b*0.6))
                ) or T.Border)
            surface.SetDrawColor(FA(borderC, math.Round(fadeA*(isSel and 175 or 85))))
            surface.DrawOutlinedRect(0,0,w,h,1)

            -- ripple wave at bottom of card when selected / hovered
            if isSel or hov.v > 0.1 then
                local wAl = math.Round(fadeA * (isSel and 55 or math.Round(hov.v*30)))
                if wAl > 2 then
                    local wAmp = 3
                    for px = 0, w-1, 2 do
                        local wy = h - 6 + math.Round(math.sin((px * 0.04) + GT * 2.2) * wAmp)
                        surface.SetDrawColor(FA(acc, wAl))
                        surface.DrawRect(px, wy, 2, 1)
                    end
                end
            end

            -- locked overlay
            if not isUnlocked then
                Rect(0,0,w,h, FA(Color(4,5,8), math.Round(155*fadeA)))
                local lx, ly = w/2, h/2
                surface.SetDrawColor(FA(T.Faint, math.Round(115*fadeA)))
                surface.DrawRect(lx-10,ly,20,17)
                surface.DrawRect(lx-7,ly-11,14,3)
                surface.DrawRect(lx-7,ly-11,3,13)
                surface.DrawRect(lx+4,ly-11,3,13)
                Txt("LOCKED","F2_CardLock",lx,ly+28, FA(T.Dim,math.Round(155*fadeA)),1,0)
            end
        end

        if isUnlocked then
            -- 3D model preview
            local mdlPanel = vgui.Create("DModelPanel",card)
            mdlPanel:SetSize(cardW2,cardH2); mdlPanel:SetPos(0,0)
            local function RefreshModel()
                local _, mdl = GetSlotJobInfo(i); mdl = mdl or "models/player/soldier_stripped.mdl"
                mdlPanel:SetModel(mdl)
                local mn, mx = mdlPanel.Entity:GetRenderBounds()
                local c = (mn+mx)*0.5; local sz = mx.z-mn.z; local lz = mn.z+sz*0.55
                mdlPanel:SetCamPos(Vector(c.x+sz*1.5,c.y,lz)); mdlPanel:SetLookAt(Vector(c.x,c.y,lz))
                mdlPanel:SetFOV(22)
                mdlPanel:SetAmbientLight(Color(44,47,58))
                mdlPanel:SetDirectionalLight(BOX_FRONT, Color(172,178,204))
                mdlPanel:SetDirectionalLight(BOX_TOP,   Color(142,148,172))
            end
            RefreshModel()
            -- Subtle idle sway on hover
            function mdlPanel:LayoutEntity(ent)
                local sway = hov.v>0.1 and math.sin(GT*0.65)*7*hov.v or 0
                ent:SetAngles(Angle(0, sway, 0))
            end
            mdlPanel.OnMousePressed = function(self,mc)
                if mc==MOUSE_LEFT then SelectedSlot=i; cFlash=1; PlaySFX(SFX.click) end
            end

            -- Info strip (gradient at top of card)
            local INFO_H = 58
            local strip  = vgui.Create("DPanel",card)
            strip:SetSize(cardW2,INFO_H); strip:SetPos(0,0); strip:SetZPos(10)
            strip.Paint = function(self,w,h)
                GradV(0,0,w,h, FA(T.Bar,215), FA(T.Bar,0), 12)
                local jn = GetSlotJobInfo(i)
                local sl = slotCfg and string.upper(slotCfg.label) or ("SLOT "..i)
                Txt(jn,"F2_CardJob",14,16, T.Text,0,1)
                Txt(sl,"F2_CardSub",14,32, FA(typeCol,218),0,1)
                if i==ActiveSlot then
                    surface.SetDrawColor(FA(T.Success,195)); surface.DrawRect(w-8,8,3,22)
                end
            end
            strip.OnMousePressed = function(self,mc) if mc==MOUSE_LEFT then SelectedSlot=i; cFlash=1; PlaySFX(SFX.click) end end
            card.OnMousePressed  = function(self,mc) if mc==MOUSE_LEFT then SelectedSlot=i; cFlash=1; PlaySFX(SFX.click) end end
        else
            card.OnMousePressed = function() end
        end
    end

    -- ── PRESETS PANEL ─────────────────────────────────────────────────────────
    --
    --  NEW LAYOUT  (three-column design, nothing overlaps)
    --  ┌─────────────────────────────────────────────────────────────────────┐
    --  │  [CAT_W=180]  │  [GRID area — fills middle]  │  [DET_W=260 right]  │
    --  │               │                               │                     │
    --  │  CATEGORIES   │  scrollable preset grid       │  Model preview      │
    --  │  header       │                               │  (tall, centred)    │
    --  │  ──────────── │                               │  ──────────────     │
    --  │  All Presets  │                               │  Name / desc        │
    --  │  Regiment     │                               │  Weapons list       │
    --  │  Jedi         │                               │  ──────────────     │
    --  │  …            │                               │  ◀ Variant ▶        │
    --  │               │                               │  [Apply Preset]     │
    --  │  ──────────── │                               │                     │
    --  │  🔍 Search    │                               │  (empty state msg)  │
    --  └───────────────┴───────────────────────────────┴─────────────────────┘
    --
    local presetsPanel = vgui.Create("DPanel",frame)
    presetsPanel:SetSize(sw,sh-TOP_H-BOT_H); presetsPanel:SetPos(0,TOP_H)
    presetsPanel.Paint = function(self,w,h) Rect(0,0,w,h, FA(T.Overlay,175)) end

    do
        local PW,PH   = sw, sh-TOP_H-BOT_H
        local CAT_W   = 180   -- left category sidebar
        local DET_W   = 260   -- right detail panel
        local GRID_W  = PW - CAT_W - DET_W
        local P_PAD   = 10
        -- Grid cards: fit 3 columns comfortably, or 2 on very small screens
        local PGRID_GAP = 10
        local PGRID_W   = math.max(120, math.floor((GRID_W - P_PAD*2 - PGRID_GAP*2) / 3))
        local PGRID_H   = math.floor(PGRID_W * 1.35)

        local pCat     = "__all__"
        local pIdx     = nil
        local pMdlVar  = 1
        local pQuery   = ""
        local pCats    = {}
        local pByCat   = {}
        local RebuildGrid, ShowDetail, HideDetail

        -- ── LEFT: CATEGORY SIDEBAR ────────────────────────────────────────────
        local catPnl = vgui.Create("DPanel",presetsPanel)
        catPnl:SetSize(CAT_W,PH); catPnl:SetPos(0,0)
        catPnl.Paint = function(self,w,h)
            Rect(0,0,w,h, FA(T.Bar,252))
            -- right separator
            surface.SetDrawColor(FA(T.Border,105)); surface.DrawRect(w-1,0,1,h)
        end

        -- Category sidebar header
        local catHdr = vgui.Create("DPanel",catPnl); catHdr:SetPos(0,0); catHdr:SetSize(CAT_W,46)
        catHdr.Paint = function(self,w,h)
            local acc = AccentColor()
            Rect(0,0,w,h, FA(T.BarSel,245))
            surface.SetDrawColor(FA(acc,200)); surface.DrawRect(0,h-2,w,2)
            surface.SetDrawColor(FA(T.Border,85)); surface.DrawRect(0,h-1,w,1)
            Txt("CATEGORIES","F2_SectLbl",w/2,h/2, FA(T.Dim,210),1,1)
        end

        -- Scrollable category list
        local catScr = vgui.Create("DScrollPanel",catPnl)
        catScr:SetPos(0,46); catScr:SetSize(CAT_W, PH-46-52)
        local csb = catScr:GetVBar(); csb:SetWide(3)
        csb.Paint=function(s,w,h) RRct(2,0,0,w,h,FA(T.Border,65)) end
        csb.btnUp.Paint=function()end; csb.btnDown.Paint=function()end
        csb.btnGrip.Paint=function(s,w,h) RRct(2,0,0,w,h,FA(T.Acc,135)) end
        local catCanvas = vgui.Create("DPanel",catScr); catCanvas:SetSize(CAT_W,0); catCanvas.Paint=function()end

        -- Search box pinned to bottom of sidebar
        local srchPnl = vgui.Create("DPanel",catPnl)
        srchPnl:SetSize(CAT_W,52); srchPnl:SetPos(0,PH-52)
        srchPnl.Paint = function(self,w,h)
            Rect(0,0,w,h,FA(T.Bar,252))
            surface.SetDrawColor(FA(T.Border,105)); surface.DrawRect(0,0,w,1)
            surface.SetDrawColor(FA(T.Border,105)); surface.DrawRect(w-1,0,1,h)
        end
        local srch = vgui.Create("DTextEntry",srchPnl)
        srch:SetSize(CAT_W-20,26); srch:SetPos(10,13); srch:SetText(""); srch:SetFont("F2_Small")
        srch.Paint = function(self,w,h)
            RRct(4,0,0,w,h,FA(T.Card,215))
            local acc = AccentColor()
            surface.SetDrawColor(self:IsEditing() and FA(acc,175) or FA(T.Border,135))
            surface.DrawOutlinedRect(0,0,w,h,1)
            Txt("🔍  ","F2_Small",8,h/2,FA(T.Faint,140),0,1)
            if self:GetText()=="" then Txt("Search presets…","F2_Small",26,h/2,FA(T.Faint,145),0,1) end
            self:DrawTextEntryText(T.Text,FA(acc,200),T.Text)
        end
        srch.OnChange = function(self) pQuery=string.lower(self:GetText()) end

        -- ── MIDDLE: GRID AREA ─────────────────────────────────────────────────
        local midPnl = vgui.Create("DPanel",presetsPanel)
        midPnl:SetSize(GRID_W,PH); midPnl:SetPos(CAT_W,0); midPnl.Paint=function()end

        local gridScr = vgui.Create("DScrollPanel",midPnl)
        gridScr:SetPos(0,0); gridScr:SetSize(GRID_W,PH)
        local gsb = gridScr:GetVBar(); gsb:SetWide(4)
        gsb.Paint=function(s,w,h) RRct(2,0,0,w,h,FA(T.Border,65)) end
        gsb.btnUp.Paint=function()end; gsb.btnDown.Paint=function()end
        gsb.btnGrip.Paint=function(s,w,h) RRct(2,0,0,w,h,FA(T.Acc,135)) end
        local gridCanvas = vgui.Create("DPanel",gridScr); gridCanvas:SetSize(GRID_W,0); gridCanvas.Paint=function()end

        -- ── RIGHT: DETAIL PANEL ───────────────────────────────────────────────
        local detPnl = vgui.Create("DPanel",presetsPanel)
        detPnl:SetSize(DET_W,PH); detPnl:SetPos(CAT_W+GRID_W,0)
        detPnl.Paint = function(self,w,h)
            Rect(0,0,w,h, FA(T.Bar,245))
            surface.SetDrawColor(FA(T.Border,110)); surface.DrawRect(0,0,1,h)
        end

        -- Model viewer — top portion of detail panel
        local MDL_H = math.min(280, math.floor(PH*0.52))
        local detMdl = vgui.Create("DModelPanel",detPnl)
        detMdl:SetPos(8,8); detMdl:SetSize(DET_W-16, MDL_H)
        detMdl:SetAmbientLight(Color(40,42,52))
        detMdl:SetDirectionalLight(BOX_FRONT,Color(165,170,195))
        detMdl:SetDirectionalLight(BOX_TOP,Color(125,130,155))
        detMdl.LayoutEntity=function(self,ent) ent:SetAngles(Angle(0,0,0)) end
        detMdl.Paint=function(self,w,h)
            RRct(6,0,0,w,h,FA(T.Card,235))
            surface.SetDrawColor(FA(T.Border,95)); surface.DrawOutlinedRect(0,0,w,h,1)
            -- inner vignette gradient (bottom fade)
            GradV(0,h-36,w,36, FA(Color(20,22,28),0), FA(Color(20,22,28),145), 8)
        end

        -- Info area — below model
        local INFO_Y = 8+MDL_H+10
        local INFO_H = PH - INFO_Y - 8

        local detInf = vgui.Create("DPanel",detPnl)
        detInf:SetPos(8,INFO_Y); detInf:SetSize(DET_W-16, INFO_H)
        detInf.Paint = function(self,w,h)
            RRct(6,0,0,w,h,FA(T.Card,210))
            surface.SetDrawColor(FA(T.Border,90)); surface.DrawOutlinedRect(0,0,w,h,1)
        end

        -- Preset name label inside detInf
        local detName = vgui.Create("DPanel",detInf); detName:SetPos(10,10); detName:SetSize(DET_W-36, 22)
        detName.Paint=function(self,w,h)end  -- drawn dynamically in ShowDetail

        -- Weapons scroll area
        local WPN_TOP = 40
        local WPN_H   = INFO_H - WPN_TOP - 100  -- space below for variant + apply
        local wpnScr  = vgui.Create("DScrollPanel",detInf)
        wpnScr:SetPos(10,WPN_TOP); wpnScr:SetSize(DET_W-36, WPN_H)
        local wsb=wpnScr:GetVBar(); wsb:SetWide(3)
        wsb.Paint=function(s,w,h) RRct(2,0,0,w,h,FA(T.Border,55)) end
        wsb.btnUp.Paint=function()end; wsb.btnDown.Paint=function()end
        wsb.btnGrip.Paint=function(s,w,h) RRct(2,0,0,w,h,FA(T.Acc,120)) end
        local wpnCanvas=vgui.Create("DPanel",wpnScr); wpnCanvas:SetSize(DET_W-36,0); wpnCanvas.Paint=function()end

        -- Variant nav row
        local VAR_Y = INFO_H - 88
        local VBW   = 30
        local dVP   = vgui.Create("DButton",detInf); dVP:SetPos(10,VAR_Y); dVP:SetSize(VBW,28); dVP:SetText("")
        local dVN   = vgui.Create("DButton",detInf); dVN:SetPos(DET_W-36-VBW,VAR_Y); dVN:SetSize(VBW,28); dVN:SetText("")
        local varLbl= vgui.Create("DPanel",detInf); varLbl:SetPos(10+VBW+4,VAR_Y); varLbl:SetSize(DET_W-36-VBW*2-8,28)

        local vpHov=NewHover(14); local vnHov=NewHover(14); local vpPr=false; local vnPr=false
        dVP.Think=function(self) local isH=self:IsHovered(); vpHov:Update(isH); if isH and not vpPr then PlayHoverSFX(SFX.hover) end; vpPr=isH end
        dVN.Think=function(self) local isH=self:IsHovered(); vnHov:Update(isH); if isH and not vnPr then PlayHoverSFX(SFX.hover) end; vnPr=isH end
        dVP.Paint=function(self,w,h) local acc=AccentColor(); RRct(4,0,0,w,h,FA(T.Card,math.Round(Lerp(vpHov.v,185,235)))); surface.SetDrawColor(FA(T.Border,95)); surface.DrawOutlinedRect(0,0,w,h,1); Txt("◀","F2_SectLbl",w/2,h/2,FA(T.Text,math.Round(Lerp(vpHov.v,168,242))),1,1) end
        dVN.Paint=function(self,w,h) local acc=AccentColor(); RRct(4,0,0,w,h,FA(T.Card,math.Round(Lerp(vnHov.v,185,235)))); surface.SetDrawColor(FA(T.Border,95)); surface.DrawOutlinedRect(0,0,w,h,1); Txt("▶","F2_SectLbl",w/2,h/2,FA(T.Text,math.Round(Lerp(vnHov.v,168,242))),1,1) end
        varLbl.Paint=function(self,w,h)
            local presets=SWRP_PRESETS and SWRP_PRESETS.GetPresetsForPlayer(LocalPlayer())
            local preset=presets and pIdx and pIdx>0 and presets[pIdx]
            if preset and type(preset.model)=="table" then
                Txt("Variant "..pMdlVar.." / "..#preset.model,"F2_Sub",w/2,h/2,FA(T.Dim,195),1,1)
            end
        end

        -- Apply button
        local APPLY_Y = INFO_H - 52
        local dApply  = vgui.Create("DButton",detInf)
        dApply:SetPos(10,APPLY_Y); dApply:SetSize(DET_W-36,38); dApply:SetText(""); dApply:SetEnabled(false)
        local daHov   = NewHover(14); local daPr=false
        dApply.Think = function(self) local isH=self:IsHovered() and self:IsEnabled(); daHov:Update(isH); if isH and not daPr then PlayHoverSFX(SFX.hover) end; daPr=isH end
        dApply.Paint = function(self,w,h)
            local en=self:IsEnabled(); local acc=AccentColor()
            if en then
                RRct(5,0,0,w,h,FA(T.Card,math.Round(Lerp(daHov.v,188,215))))
                GradV(0,0,w,h,
                    FA(Color(math.min(255,acc.r+22),math.min(255,acc.g+22),math.min(255,acc.b+22)),math.Round(Lerp(daHov.v,185,215))),
                    FA(acc,math.Round(Lerp(daHov.v,178,205))), 10)
                surface.SetDrawColor(FA(acc,math.Round(Lerp(daHov.v,175,238)))); surface.DrawOutlinedRect(0,0,w,h,1)
                surface.SetDrawColor(FA(Color(255,255,255),math.Round(Lerp(daHov.v,22,40)))); surface.DrawRect(0,0,w,1)
                -- shimmer on hover
                if daHov.v>0.05 then Shimmer(0,0,w,h,math.Round(daHov.v*28)) end
            else
                RRct(5,0,0,w,h,FA(T.Card,145))
                surface.SetDrawColor(FA(T.Border,65)); surface.DrawOutlinedRect(0,0,w,h,1)
            end
            Txt("✓  Apply Preset","F2_SectLbl",w/2,h/2, en and Color(255,255,255) or FA(T.Faint,120),1,1)
        end

        -- Empty/select state label
        local detEmpty = vgui.Create("DPanel",detPnl)
        detEmpty:SetPos(0,0); detEmpty:SetSize(DET_W,PH); detEmpty.Paint=function(self,w,h)
            Txt("Select a preset","F2_SectLbl",w/2,PH*0.42, FA(T.Dim,145),1,1)
            Txt("to preview it here","F2_Sub",w/2,PH*0.42+20, FA(T.Faint,110),1,1)
        end

        -- ── HELPERS ───────────────────────────────────────────────────────────
        local function ResolveMdl(p,v)
            if not p then return nil end
            if type(p.model)=="table" then return p.model[v] or p.model[1] end
            return p.model
        end
        local function CanUse(p)
            if not p or not p.requiredGroup then return true end
            local ply=LocalPlayer(); if not IsValid(ply) then return false end
            local pg=ply:GetUserGroup() or "user"; if p.requiredGroup==pg then return true end
            if ULib and ULib.ucl and ULib.ucl.groups then
                local g=ULib.ucl.groups[pg]; while g do if g.inherit_from==p.requiredGroup then return true end; g=ULib.ucl.groups[g.inherit_from] end
            end
            return false
        end

        -- ── ShowDetail / HideDetail ───────────────────────────────────────────
        ShowDetail = function()
            local presets=SWRP_PRESETS and SWRP_PRESETS.GetPresetsForPlayer(LocalPlayer())
            local isDef   = (pIdx==0)
            local preset  = presets and pIdx and pIdx>0 and presets[pIdx]

            detEmpty:SetVisible(false)
            detMdl:SetVisible(true)
            detInf:SetVisible(true)

            -- update model
            local mdl = isDef and (select(2,GetSlotJobInfo(ActiveSlot)) or "models/player/soldier_stripped.mdl") or ResolveMdl(preset,pMdlVar)
            if mdl then
                detMdl:SetModel(mdl)
                local mn,mx = detMdl.Entity:GetRenderBounds()
                local c2=(mn+mx)*0.5; local sz2=mx.z-mn.z; local lz2=mn.z+sz2*0.55
                detMdl:SetCamPos(Vector(c2.x+sz2*2.4,c2.y,lz2))
                detMdl:SetLookAt(Vector(c2.x,c2.y,lz2))
                detMdl:SetFOV(22)
            end

            -- update preset name + description in the info panel
            local nm = isDef and "Default Loadout" or (preset and preset.name or "?")
            local desc = (not isDef and preset and preset.description and preset.description~="") and preset.description or ""
            -- Repaint name label dynamically
            detName.Paint=function(self,w,h)
                local acc=AccentColor()
                Txt(nm,"F2_PresetNm",0,h/2-2,FA(T.Text,242),0,1)
            end

            -- rebuild weapons list
            wpnCanvas:Clear(); wpnCanvas:SetTall(0)
            if preset and preset.weapons and #preset.weapons>0 then
                local iw=DET_W-36; local WW=math.floor((iw-6)/2)-2; local WH=22; local WG=4
                local col2,row2=0,0
                for _,wc in ipairs(preset.weapons) do
                    local wp=vgui.Create("DPanel",wpnCanvas); wp:SetPos(col2*(WW+WG+2),row2*(WH+WG)); wp:SetSize(WW,WH)
                    wp.Paint=function(s,w2,h2)
                        RRct(3,0,0,w2,h2,FA(T.BarSel,215))
                        local acc=AccentColor(); surface.SetDrawColor(FA(acc,120)); surface.DrawRect(0,0,2,h2)
                        surface.SetDrawColor(FA(T.Border,75)); surface.DrawOutlinedRect(0,0,w2,h2,1)
                        Txt(wc,"F2_Sub",8,h2/2,FA(T.Dim,208),0,1)
                    end
                    col2=col2+1; if col2>=2 then col2=0; row2=row2+1 end
                end
                local totalH=(row2+(col2>0 and 1 or 0))*(WH+WG)+4
                wpnCanvas:SetTall(totalH)
            elseif isDef then
                wpnCanvas:SetTall(22)
                local ep=vgui.Create("DPanel",wpnCanvas); ep:SetPos(0,0); ep:SetSize(DET_W-36,22)
                ep.Paint=function(self,w,h) Txt("Current job loadout","F2_Sub",0,h/2,FA(T.Faint,135),0,1) end
            else
                wpnCanvas:SetTall(22)
                local ep=vgui.Create("DPanel",wpnCanvas); ep:SetPos(0,0); ep:SetSize(DET_W-36,22)
                ep.Paint=function(self,w,h) Txt("No weapons listed","F2_Sub",0,h/2,FA(T.Faint,135),0,1) end
            end

            -- weapons section header in detInf
            detInf.Paint=function(self,w,h)
                RRct(6,0,0,w,h,FA(T.Card,210))
                surface.SetDrawColor(FA(T.Border,90)); surface.DrawOutlinedRect(0,0,w,h,1)
                -- Name underline
                surface.SetDrawColor(FA(T.Border,75)); surface.DrawRect(10,32,w-20,1)
                -- Weapons label
                Txt("WEAPONS","F2_Sub",10,WPN_TOP-10,FA(T.Dim,165),0,1)
                -- Variant label
                Txt("VARIANT","F2_Sub",10,VAR_Y-12,FA(T.Dim,165),0,1)
                surface.SetDrawColor(FA(T.Border,60)); surface.DrawRect(10,VAR_Y-18,w-20,1)
            end

            -- show/hide variant nav
            local hasVariants = not isDef and preset and type(preset.model)=="table" and #preset.model>1
            dVP:SetVisible(hasVariants)
            dVN:SetVisible(hasVariants)
            varLbl:SetVisible(hasVariants)

            dApply:SetEnabled(not(not isDef and preset and not CanUse(preset)))
        end

        HideDetail = function()
            detMdl:SetVisible(false)
            detInf:SetVisible(false)
            detEmpty:SetVisible(true)
        end

        dVP.DoClick=function()
            local p=SWRP_PRESETS and SWRP_PRESETS.GetPresetsForPlayer(LocalPlayer()) and pIdx and SWRP_PRESETS.GetPresetsForPlayer(LocalPlayer())[pIdx]
            if not p or type(p.model)~="table" then return end
            pMdlVar=((pMdlVar-2)%#p.model)+1; ShowDetail(); PlaySFX(SFX.click)
        end
        dVN.DoClick=function()
            local p=SWRP_PRESETS and SWRP_PRESETS.GetPresetsForPlayer(LocalPlayer()) and pIdx and SWRP_PRESETS.GetPresetsForPlayer(LocalPlayer())[pIdx]
            if not p or type(p.model)~="table" then return end
            pMdlVar=(pMdlVar%#p.model)+1; ShowDetail(); PlaySFX(SFX.click)
        end
        dApply.DoClick=function()
            if not pIdx then return end
            if pIdx==0 then
                net.Start("swrp_presets_reset"); net.SendToServer(); SlotPresetModels[ActiveSlot]=nil
            else
                local presets=SWRP_PRESETS and SWRP_PRESETS.GetPresetsForPlayer(LocalPlayer())
                local p=presets and presets[pIdx]
                net.Start("swrp_presets_apply"); net.WriteUInt(pIdx,8); net.WriteUInt(pMdlVar,8); net.SendToServer()
                if p then SlotPresetModels[ActiveSlot]=ResolveMdl(p,pMdlVar) end
            end
            PlaySFX(SFX.deploy); PushNotif("Preset applied!","",1)
        end

        -- ── BuildCats ─────────────────────────────────────────────────────────
        local function BuildCats()
            catCanvas:Clear(); local y=6
            local all={"__all__"}; for _,c in ipairs(pCats) do table.insert(all,c) end
            for _,cat in ipairs(all) do
                local c=cat; local lbl=(cat=="__all__") and "All Presets" or cat
                local bH=NewHover(14); local prevBH=false
                local btn=vgui.Create("DButton",catCanvas)
                btn:SetPos(8,y); btn:SetSize(CAT_W-16,30); btn:SetText(""); y=y+34
                btn.Think=function(self) local isH=self:IsHovered(); bH:Update(isH); if isH and not prevBH then PlayHoverSFX(SFX.hover) end; prevBH=isH end
                btn.Paint=function(self,w,h)
                    local sel=(pCat==c); local acc=AccentColor()
                    if sel then
                        RRct(5,0,0,w,h,FA(acc,22))
                        surface.SetDrawColor(FA(acc,195)); surface.DrawRect(0,0,3,h)
                        surface.SetDrawColor(FA(acc,75)); surface.DrawOutlinedRect(0,0,w,h,1)
                        Txt(lbl,"F2_CatLbl",16,h/2, acc,0,1)
                    else
                        if bH.v>0 then RRct(5,0,0,w,h,FA(T.CardHov,math.Round(bH.v*135))) end
                        Txt(lbl,"F2_CatLbl",12,h/2, FA(T.Text,math.Round(Lerp(bH.v,145,230))),0,1)
                    end
                    local cnt=(c=="__all__") and (1+(SWRP_PRESETS and #(SWRP_PRESETS.GetPresetsForPlayer(LocalPlayer()) or {}) or 0)) or (pByCat[c] and #pByCat[c] or 0)
                    -- count badge
                    local badge=tostring(cnt); local bw=select(1,surface.GetTextSize(badge))+10
                    RRct(3,w-bw-4,(h-16)/2,bw,16,FA(T.Faint,sel and 95 or 65))
                    Txt(badge,"F2_Sub",w-bw/2-4,h/2,FA(T.Dim,sel and 210 or 145),1,1)
                end
                btn.DoClick=function() pCat=c; PlaySFX(SFX.click); if RebuildGrid then RebuildGrid() end end
            end
            catCanvas:SetTall(y+4)
        end

        -- ── RebuildGrid ───────────────────────────────────────────────────────
        RebuildGrid=function()
            gridCanvas:Clear(); local gw=gridCanvas:GetWide()
            local presets=SWRP_PRESETS and SWRP_PRESETS.GetPresetsForPlayer(LocalPlayer()) or {}
            pCats={}; pByCat={}; local seen={}
            for i2,p2 in ipairs(presets) do
                local cat=(p2.category and p2.category~="") and p2.category or "General"
                if not seen[cat] then seen[cat]=true; table.insert(pCats,cat); pByCat[cat]={} end
                table.insert(pByCat[cat],{idx=i2,preset=p2})
            end
            BuildCats()

            local items={{kind="default",idx=0}}
            if pCat==nil or pCat=="__all__" then
                for i2,p2 in ipairs(presets) do
                    local nm=string.lower(p2.name or ""); local desc2=string.lower(p2.description or "")
                    if pQuery=="" or string.find(nm,pQuery,1,true) or string.find(desc2,pQuery,1,true) then
                        table.insert(items,{kind="preset",idx=i2,preset=p2})
                    end
                end
            else
                for _,ci in ipairs(pByCat[pCat] or {}) do
                    local nm=string.lower(ci.preset.name or ""); local desc2=string.lower(ci.preset.description or "")
                    if pQuery=="" or string.find(nm,pQuery,1,true) or string.find(desc2,pQuery,1,true) then
                        table.insert(items,{kind="preset",idx=ci.idx,preset=ci.preset})
                    end
                end
            end

            if #items==0 then
                local el=vgui.Create("DLabel",gridCanvas)
                el:SetPos(P_PAD,P_PAD); el:SetSize(gw-P_PAD*2,32)
                el:SetFont("F2_Small"); el:SetTextColor(FA(T.Dim,140)); el:SetText("No presets found.")
                gridCanvas:SetTall(60); return
            end

            -- Recalculate columns based on actual grid width
            local CPR=math.max(1,math.floor((gw+PGRID_GAP)/(PGRID_W+PGRID_GAP)))
            local col=0; local curY=P_PAD

            for itemIdx,item in ipairs(items) do
                local isDef=(item.kind=="default"); local preset=item.preset; local idx=item.idx
                local mdl3=isDef and (select(2,GetSlotJobInfo(ActiveSlot)) or "models/player/soldier_stripped.mdl") or ResolveMdl(preset,1)
                local locked=not isDef and preset and not CanUse(preset)
                local ac3=isDef and T.Success or (preset and preset.accentColor and Color(preset.accentColor.r,preset.accentColor.g,preset.accentColor.b) or T.Acc)
                local cx3=P_PAD+col*(PGRID_W+PGRID_GAP); local baseY=curY
                local cDelay=itemIdx*0.020

                local c3=vgui.Create("DPanel",gridCanvas)
                c3:SetPos(cx3,curY); c3:SetSize(PGRID_W,PGRID_H); c3:SetCursor("hand")
                local cHov=NewHover(12); local prevCGH=false

                c3.Think=function(self) local isH=self:IsHovered(); cHov:Update(isH); if isH and not prevCGH then PlayHoverSFX(SFX.hover) end; prevCGH=isH end
                c3.Paint=function(self,w3,h3)
                    local isSel=(pIdx==idx)
                    local fadeA=EaseOut(math.Clamp((CurTime()-openT-cDelay)/0.28,0,1))
                    if fadeA<=0.02 then return end
                    self:SetPos(cx3, baseY+math.Round((1-fadeA)*18))

                    -- card background
                    RRct(6,0,0,w3,h3,FA(T.Card,math.Round(Lerp(cHov.v,200,225)*fadeA)))
                    if isSel then
                        RRct(6,0,0,w3,h3,FA(ac3,20))
                    end

                    -- top accent bar
                    draw.RoundedBoxEx(6,0,0,w3,3,FA(ac3,isSel and 255 or math.Round(Lerp(cHov.v,85,185)*fadeA)),true,true,false,false)

                    -- selection stripe (left edge)
                    if isSel then
                        surface.SetDrawColor(FA(ac3,210)); surface.DrawRect(0,3,2,h3-3)
                    end

                    -- name gradient backdrop at bottom
                    GradV(0,h3-44,w3,44, FA(T.Bar,0), FA(Color(10,12,16),210), 10)

                    -- card name
                    Txt(isDef and "Default" or (preset and preset.name or "?"),"F2_CardLbl",w3/2,h3-14,
                        FA(T.Text,math.Round((isSel and 255 or Lerp(cHov.v,185,240))*fadeA)),1,1)

                    -- locked badge
                    if locked then
                        RRct(4,w3-38,6,32,18,FA(T.Danger,175))
                        Txt("RANK","F2_Sub",w3-22,15,Color(255,255,255),1,1)
                    end

                    -- border
                    if isSel then
                        surface.SetDrawColor(FA(ac3,math.Round(175*fadeA))); surface.DrawOutlinedRect(0,0,w3,h3,1)
                    else
                        surface.SetDrawColor(FA(T.Border,math.Round(Lerp(cHov.v,70,140)*fadeA))); surface.DrawOutlinedRect(0,0,w3,h3,1)
                    end

                    -- ripple on selected/hovered
                    if (isSel or cHov.v>0.1) then
                        local wAl=math.Round(fadeA*(isSel and 48 or math.Round(cHov.v*22)))
                        if wAl>1 then
                            for px=0,w3-1,2 do
                                local wy=h3-8+math.Round(math.sin((px*0.05)+GT*2.4)*2.5)
                                surface.SetDrawColor(FA(ac3,wAl)); surface.DrawRect(px,wy,2,1)
                            end
                        end
                    end
                end

                -- Model panel inside card
                local mp=vgui.Create("DModelPanel",c3)
                mp:SetPos(0,2); mp:SetSize(PGRID_W,PGRID_H-44)
                mp:SetModel(mdl3); mp:SetFOV(22)
                mp:SetAmbientLight(Color(40,42,52))
                mp:SetDirectionalLight(BOX_FRONT,Color(165,170,195))
                mp:SetDirectionalLight(BOX_TOP,Color(125,130,155))
                mp:RunAnimation()
                local mn3,mx3b=mp.Entity:GetRenderBounds()
                local c3b=(mn3+mx3b)*0.5; local sz3b=mx3b.z-mn3.z; local lz3=mn3.z+sz3b*0.55
                mp:SetCamPos(Vector(c3b.x+sz3b*2.4,c3b.y,lz3)); mp:SetLookAt(Vector(c3b.x,c3b.y,lz3))
                mp.LayoutEntity=function(self,ent) ent:SetAngles(Angle(0,0,0)) end

                local function doSel() pIdx=idx; pMdlVar=1; ShowDetail(); PlaySFX(SFX.click) end
                mp.OnMousePressed=function(self,mc) if mc==MOUSE_LEFT then doSel() end end
                c3.OnMousePressed=function(self,mc) if mc==MOUSE_LEFT then doSel() end end

                col=col+1
                if col>=CPR then col=0; curY=curY+PGRID_H+PGRID_GAP end
            end
            if col>0 then curY=curY+PGRID_H+PGRID_GAP end
            gridCanvas:SetTall(math.max(curY+P_PAD, gridScr:GetTall()))
        end

        RebuildGrid(); HideDetail()
        local lastQ=""
        presetsPanel.Think=function(self) if pQuery~=lastQ then lastQ=pQuery; RebuildGrid() end end
    end

    -- ── SETTINGS PANEL ────────────────────────────────────────────────────────
    local settPanel = vgui.Create("DPanel",frame)
    settPanel:SetSize(sw,sh-TOP_H-BOT_H); settPanel:SetPos(0,TOP_H)
    settPanel.Paint = function(self,w,h) Rect(0,0,w,h,FA(T.Overlay,200)) end

    local settScr = vgui.Create("DScrollPanel",settPanel); settScr:SetPos(0,0); settScr:SetSize(sw,sh-TOP_H-BOT_H)
    local ssb=settScr:GetVBar(); ssb:SetWide(4)
    ssb.Paint=function(s,w,h) RRct(2,0,0,w,h,FA(T.Border,78)) end
    ssb.btnUp.Paint=function()end; ssb.btnDown.Paint=function()end
    ssb.btnGrip.Paint=function(s,w,h) RRct(2,0,0,w,h,FA(T.Acc,148)) end

    local settCanvas=vgui.Create("DPanel",settScr); settCanvas:SetSize(sw,0); settCanvas.Paint=function()end
    local SPAD=36; local BW=sw-SPAD*2; local cY=SPAD

    local function MakeBlock(label,height)
        local blk=vgui.Create("DPanel",settCanvas); blk:SetPos(SPAD,cY); blk:SetSize(BW,height)
        blk.Paint=function(self,w,h)
            RRct(6,0,0,w,h,FA(T.Bar,232))
            surface.SetDrawColor(FA(T.Border,95)); surface.DrawOutlinedRect(0,0,w,h,1)
            local acc=AccentColor(); surface.SetFont("F2_Sub")
            local lw2=select(1,surface.GetTextSize(label))+16
            RRct(3,0,0,lw2,18,FA(acc,215)); Txt(label,"F2_Sub",8,9,Color(255,255,255),0,1)
        end
        cY=cY+height+16; return blk
    end
    local function RowLbl(parent,label,sub,y,h)
        local lp=vgui.Create("DPanel",parent); lp:SetPos(16,y); lp:SetSize(200,h)
        lp.Paint=function(self,w,ph) Txt(label,"F2_SettLbl",0,sub~="" and ph/2-5 or ph/2,T.Text,0,1); if sub~="" then Txt(sub,"F2_SettSub",0,ph/2+7,FA(T.Dim,172),0,1) end end
    end

    -- Accent colour
    local acBlk=MakeBlock("ACCENT COLOUR",138)
    RowLbl(acBlk,"Hue","Drag to change colour",12,28)
    local HW=BW-220
    local hueS=vgui.Create("DPanel",acBlk); hueS:SetPos(220,12); hueS:SetSize(HW,24); hueS:SetCursor("hand")
    hueS.Paint=function(self,w,h) for px=0,w-1,2 do surface.SetDrawColor(HSVtoColor((px/w)*360,1,1)); surface.DrawRect(px,0,2,h) end; local cx2=math.Round((Settings.accentH/360)*w); surface.SetDrawColor(255,255,255,200); surface.DrawRect(cx2-1,0,2,h); surface.SetDrawColor(0,0,0,100); surface.DrawOutlinedRect(cx2-2,0,4,h,1); surface.SetDrawColor(FA(T.Border,148)); surface.DrawOutlinedRect(0,0,w,h,1) end
    hueS.OnMousePressed=function(self,mc) if mc==MOUSE_LEFT then local mx=self:ScreenToLocal(gui.MouseX(),gui.MouseY()); Settings.accentH=math.Clamp((mx/HW)*360,0,360); RefreshAccent(); SaveSettings() end end
    hueS.OnCursorMoved=function(self,lx) if input.IsMouseDown(MOUSE_LEFT) then Settings.accentH=math.Clamp((lx/HW)*360,0,360); RefreshAccent(); SaveSettings() end end

    RowLbl(acBlk,"Saturation / Brightness","",44,28)
    local SVW=math.floor((HW-8)/2)
    local satS=vgui.Create("DPanel",acBlk); satS:SetPos(220,44); satS:SetSize(SVW,24); satS:SetCursor("hand")
    satS.Paint=function(self,w,h) for px=0,w-1,2 do surface.SetDrawColor(HSVtoColor(Settings.accentH,px/w,Settings.accentV)); surface.DrawRect(px,0,2,h) end; local cx2=math.Round(Settings.accentS*w); surface.SetDrawColor(255,255,255,200); surface.DrawRect(cx2-1,0,2,h); surface.SetDrawColor(0,0,0,100); surface.DrawOutlinedRect(cx2-2,0,4,h,1); Txt("SAT","F2_Sub",3,h/2,FA(Color(0,0,0),118),0,1) end
    satS.OnMousePressed=function(self,mc) if mc==MOUSE_LEFT then local mx=self:ScreenToLocal(gui.MouseX(),gui.MouseY()); Settings.accentS=math.Clamp(mx/SVW,0,1); RefreshAccent(); SaveSettings() end end
    satS.OnCursorMoved=function(self,lx) if input.IsMouseDown(MOUSE_LEFT) then Settings.accentS=math.Clamp(lx/SVW,0,1); RefreshAccent(); SaveSettings() end end

    local valS=vgui.Create("DPanel",acBlk); valS:SetPos(220+SVW+8,44); valS:SetSize(SVW,24); valS:SetCursor("hand")
    valS.Paint=function(self,w,h) for px=0,w-1,2 do surface.SetDrawColor(HSVtoColor(Settings.accentH,Settings.accentS,px/w)); surface.DrawRect(px,0,2,h) end; local cx2=math.Round(Settings.accentV*w); surface.SetDrawColor(255,255,255,200); surface.DrawRect(cx2-1,0,2,h); surface.SetDrawColor(0,0,0,100); surface.DrawOutlinedRect(cx2-2,0,4,h,1); Txt("BRI","F2_Sub",3,h/2,FA(Color(0,0,0),118),0,1) end
    valS.OnMousePressed=function(self,mc) if mc==MOUSE_LEFT then local mx=self:ScreenToLocal(gui.MouseX(),gui.MouseY()); Settings.accentV=math.Clamp(mx/SVW,0.2,1); RefreshAccent(); SaveSettings() end end
    valS.OnCursorMoved=function(self,lx) if input.IsMouseDown(MOUSE_LEFT) then Settings.accentV=math.Clamp(lx/SVW,0.2,1); RefreshAccent(); SaveSettings() end end

    local sw2=vgui.Create("DPanel",acBlk); sw2:SetPos(220,76); sw2:SetSize(38,22)
    sw2.Paint=function(self,w,h) RRct(4,0,0,w,h,AccentColor()); surface.SetDrawColor(FA(T.Border,178)); surface.DrawOutlinedRect(0,0,w,h,1) end

    local rcHov=NewHover(14)
    local rcBPrev=false
    local rcB=vgui.Create("DButton",acBlk); rcB:SetPos(266,76); rcB:SetSize(88,22); rcB:SetText("")
    rcB.Think=function(self) local isH=self:IsHovered(); rcHov:Update(isH); if isH and not rcBPrev then PlayHoverSFX(SFX.hover) end; rcBPrev=isH end
    rcB.Paint=function(self,w,h) local lw2=math.Round(Lerp(rcHov.v,14,w-10)); surface.SetDrawColor(FA(T.Acc,math.Round(Lerp(rcHov.v,48,188)))); surface.DrawRect(math.floor((w-lw2)*0.5),h-2,lw2,2); Txt("Reset","F2_Sub",w/2,h/2-1,FA(T.Text,math.Round(Lerp(rcHov.v,158,255))),1,1) end
    rcB.DoClick=function() Settings.accentH=210; Settings.accentS=0.75; Settings.accentV=0.90; RefreshAccent(); SaveSettings(); PlaySFX(SFX.click); PushNotif("Colour reset to blue.","",0) end

    RowLbl(acBlk,"Quick presets","",104,22)
    local presets2={{label="BLUE",h=210,s=0.75,v=0.90},{label="CYAN",h=190,s=0.80,v=0.90},{label="PURPLE",h=265,s=0.70,v=0.88},{label="GREEN",h=145,s=0.72,v=0.82},{label="GOLD",h=40,s=0.82,v=0.88},{label="RED",h=0,s=0.82,v=0.90},{label="WHITE",h=0,s=0.00,v=0.95}}
    local pbW2=math.floor(HW/#presets2)-4
    for idx,pc in ipairs(presets2) do
        local p=pc; local pbHov=NewHover(14); local pbPrev=false
        local pb=vgui.Create("DButton",acBlk); pb:SetSize(pbW2,20); pb:SetPos(220+(idx-1)*(pbW2+4),108); pb:SetText("")
        pb.Think=function(self) local isH=self:IsHovered(); pbHov:Update(isH); if isH and not pbPrev then PlayHoverSFX(SFX.hover) end; pbPrev=isH end
        pb.Paint=function(self,w,h) local c=HSVtoColor(p.h,p.s,p.v); RRct(4,0,0,w,h,FA(c,math.Round(Lerp(pbHov.v,128,218)))); surface.SetDrawColor(FA(c,math.Round(Lerp(pbHov.v,148,255)))); surface.DrawOutlinedRect(0,0,w,h,1); Txt(p.label,"F2_Sub",w/2,h/2,FA(T.Text,math.Round(Lerp(pbHov.v,198,255))),1,1) end
        pb.DoClick=function() Settings.accentH=p.h; Settings.accentS=p.s; Settings.accentV=p.v; RefreshAccent(); SaveSettings(); PlaySFX(SFX.click) end
    end

    -- Music volume block
    local musBlk=MakeBlock("MENU MUSIC",72)
    RowLbl(musBlk,"Volume","Drag to adjust music volume",12,28)
    local musW=BW-220
    local musBar=vgui.Create("DPanel",musBlk); musBar:SetPos(220,12); musBar:SetSize(musW,24); musBar:SetCursor("hand")
    musBar.Paint=function(self,w,h)
        RRct(3,0,0,w,h,FA(T.Card,200)); local acc=AccentColor()
        local filled=math.Round(SFX.musicVol*w); if filled>0 then RRct(3,0,0,filled,h,FA(acc,175)) end
        surface.SetDrawColor(FA(T.Border,142)); surface.DrawOutlinedRect(0,0,w,h,1)
        Txt(math.Round(SFX.musicVol*100).."%","F2_Sub",w/2,h/2,FA(T.Text,198),1,1)
    end
    musBar.OnMousePressed=function(self,mc) if mc==MOUSE_LEFT then local mx=self:ScreenToLocal(gui.MouseX(),gui.MouseY()); SFX.musicVol=math.Clamp(mx/musW,0,1); if IsValid(_music) then _music:SetVolume(SFX.musicVol) end end end
    musBar.OnCursorMoved=function(self,lx) if input.IsMouseDown(MOUSE_LEFT) then SFX.musicVol=math.Clamp(lx/musW,0,1); if IsValid(_music) then _music:SetVolume(SFX.musicVol) end end end

    local muted=false
    local mmHov=NewHover(14)
    local mmPrev=false
    local musMute=vgui.Create("DButton",musBlk); musMute:SetPos(220,44); musMute:SetSize(80,22); musMute:SetText("")
    musMute.Think=function(self) local isH=self:IsHovered(); mmHov:Update(isH); if isH and not mmPrev then PlayHoverSFX(SFX.hover) end; mmPrev=isH end
    musMute.Paint=function(self,w,h) RRct(4,0,0,w,h,FA(muted and T.Danger or T.Card,math.Round(Lerp(mmHov.v,148,215)))); surface.SetDrawColor(FA(T.Border,95)); surface.DrawOutlinedRect(0,0,w,h,1); Txt(muted and "Unmute" or "Mute","F2_Sub",w/2,h/2,FA(T.Text,math.Round(Lerp(mmHov.v,198,255))),1,1) end
    musMute.DoClick=function() muted=not muted; if IsValid(_music) then _music:SetVolume(muted and 0 or SFX.musicVol) end; PlaySFX(SFX.click) end

    -- Owner tools
    local OWNER="STEAM_1:1:743498109"
    if IsValid(LocalPlayer()) and LocalPlayer():SteamID()==OWNER then
        local owBlk=MakeBlock("OWNER TOOLS",60)
        local lp2=vgui.Create("DPanel",owBlk); lp2:SetPos(16,16); lp2:SetSize(200,28)
        lp2.Paint=function(self,w,ph) Txt("Reset all data","F2_SettLbl",0,ph/2-5,T.Text,0,1); Txt("Wipes f2_slot_data + whitelists","F2_SettSub",0,ph/2+7,FA(T.Dim,172),0,1) end
        local armed,armT=false,0
        local owHov=NewHover(10)
        local owPrev=false
        local owR=vgui.Create("DButton",owBlk); owR:SetPos(220,12); owR:SetSize(200,34); owR:SetText("")
        owR.Think=function(self) local isH=self:IsHovered(); owHov:Update(isH); if isH and not owPrev then PlayHoverSFX(SFX.hover) end; owPrev=isH; if armed and (CurTime()-armT)>4 then armed=false end end
        owR.Paint=function(self,w,h) local col=armed and Color(220,60,40) or T.Acc; RRct(4,0,0,w,h,FA(col,math.Round(Lerp(owHov.v,24,58)))); surface.SetDrawColor(FA(col,math.Round(Lerp(owHov.v,118,238)))); surface.DrawOutlinedRect(0,0,w,h,1); surface.SetDrawColor(FA(col,math.Round(Lerp(owHov.v,138,252)))); surface.DrawRect(0,0,3,h); Txt(armed and "⚠  CONFIRM?" or "⚠  RESET ALL DATA","F2_SectLbl",w/2,h/2,FA(T.Text,math.Round(Lerp(owHov.v,208,255))),1,1) end
        owR.DoClick=function() PlaySFX(SFX.click); if not armed then armed=true; armT=CurTime() else armed=false; net.Start("F2Slot_OwnerReset"); net.SendToServer(); PushNotif("RESET SENT","All data wiped.",2) end end
    end
    settCanvas:SetTall(cY+SPAD)

    -- ── TAB VISIBILITY + ESC ──────────────────────────────────────────────────
    frame.Think = function(self)
        self:SetAlpha(math.Round(EaseOut(math.Clamp((CurTime()-openT)/0.18,0,1))*255))
        local esc=input.IsKeyDown(KEY_ESCAPE)
        if esc and not escWasDown then StopMusic(); self:Remove(); MenuOpen=false end
        escWasDown=esc
        if ActiveTab~=lastTab then
            lastTab=ActiveTab
            charsPanel:SetVisible(ActiveTab=="characters")
            presetsPanel:SetVisible(ActiveTab=="presets")
            settPanel:SetVisible(ActiveTab=="settings")
        end
    end
    charsPanel:SetVisible(ActiveTab=="characters")
    presetsPanel:SetVisible(ActiveTab=="presets")
    settPanel:SetVisible(ActiveTab=="settings")
end

-- ══════════════════════════════════════════════════════════════════════════════
--  SECTION 12 — ENTRY POINTS & KEYBINDS
-- ══════════════════════════════════════════════════════════════════════════════

local _kd = false
hook.Add("Think","F2Slot_Key",function()
    local d = input.IsKeyDown(KEY_F2)
    if d and not _kd then
        if IsValid(SlotMenu) then StopMusic(); SlotMenu:Remove(); SlotMenu=nil; MenuOpen=false
        else OpenSlotMenu() end
    end
    _kd = d
end)

hook.Add("OnPlayerChat","F2Slot_Chat",function(ply,text)
    if ply==LocalPlayer() and string.lower(text)=="!slots" then
        timer.Simple(0, OpenSlotMenu); return true
    end
end)

print("[H2O] Slot system loaded.")