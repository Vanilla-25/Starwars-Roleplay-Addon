--[[
    F2 Slot System - Whitelist Server (rewrite)
]]

if not F2SlotConfig then
    error("[F2 WL] F2SlotConfig is nil — load f2_slots_shared.lua first."); return
end

util.AddNetworkString("F2WL_OpenManager")
util.AddNetworkString("F2WL_RequestList")
util.AddNetworkString("F2WL_SendList")
util.AddNetworkString("F2WL_GrantSlot")
util.AddNetworkString("F2WL_RevokeSlot")
util.AddNetworkString("F2WL_SetSlotJob")
util.AddNetworkString("F2WL_SetMyJob")
util.AddNetworkString("F2WL_SwapSlots")
util.AddNetworkString("F2WL_Result")

local WL_TABLE = "f2_whitelists"

sql.Query([[
    CREATE TABLE IF NOT EXISTS ]] .. WL_TABLE .. [[ (
        steamid     TEXT    NOT NULL,
        slot_index  INTEGER NOT NULL,
        granted_by  TEXT    DEFAULT 'SYSTEM',
        granted_at  INTEGER DEFAULT 0,
        slot_type   TEXT    DEFAULT 'generic',
        PRIMARY KEY (steamid, slot_index)
    )
]])
print("[F2 WL] Whitelist table ready.")

function F2WL_HasAccess(steamid, slotIndex)
    local row = sql.QueryRow(string.format(
        "SELECT 1 FROM %s WHERE steamid = %s AND slot_index = %d",
        WL_TABLE, sql.SQLStr(steamid), slotIndex))
    return row ~= nil
end

local function WL_Grant(steamid, slotIndex, grantedBy, slotType)
    if F2WL_HasAccess(steamid, slotIndex) then return false, "already_granted" end
    local slotCfg = F2SlotConfig.Slots[slotIndex]
    slotType = slotType or (slotCfg and slotCfg.type or "generic")
    sql.Query(string.format(
        "INSERT INTO %s (steamid, slot_index, granted_by, granted_at, slot_type) VALUES (%s, %d, %s, %d, %s)",
        WL_TABLE,
        sql.SQLStr(steamid), slotIndex,
        sql.SQLStr(tostring(grantedBy or "SYSTEM")),
        os.time(),
        sql.SQLStr(slotType)
    ))
    return true
end

local function WL_Revoke(steamid, slotIndex)
    if not F2WL_HasAccess(steamid, slotIndex) then return false, "not_granted" end
    sql.Query(string.format(
        "DELETE FROM %s WHERE steamid = %s AND slot_index = %d",
        WL_TABLE, sql.SQLStr(steamid), slotIndex))
    return true
end

local function WL_GetAll()
    return sql.Query("SELECT * FROM " .. WL_TABLE .. " ORDER BY steamid ASC, slot_index ASC") or {}
end

local function WL_Notify(ply, ok, msg)
    if not IsValid(ply) then return end
    net.Start("F2WL_Result")
        net.WriteBool(ok)
        net.WriteString(msg or "")
    net.Send(ply)
end

local function SendWLList(ply)
    if not IsValid(ply) then return end

    -- Build online player lookup
    local online = {}
    for _, p in ipairs(player.GetAll()) do
        online[p:SteamID()] = {
            nick       = p:Nick(),
            activeSlot = (ActiveSlot and ActiveSlot[p:SteamID()]) or 1,
        }
    end

    -- Collect all rows: slot 1 for every online player + all whitelist DB entries
    local rows = {}
    local seen = {}  -- key: steamid.."|"..slot_index

    -- Slot 1 for every currently online player (slot 1 is always unlocked, never in DB)
    for sid, info in pairs(online) do
        local key = sid .. "|1"
        seen[key] = true
        table.insert(rows, {
            steamid    = sid,
            slot_index = "1",
            granted_by = "SYSTEM",
            granted_at = "0",
            slot_type  = "generic",
        })
    end

    -- All whitelist DB entries (slots 2+, and any offline player rows)
    for _, row in ipairs(WL_GetAll()) do
        local key = row.steamid .. "|" .. tostring(row.slot_index)
        if not seen[key] then
            seen[key] = true
            table.insert(rows, row)
        end
    end

    -- Sort: online first, then by steamid + slot
    table.sort(rows, function(a, b)
        local aOnline = online[a.steamid] ~= nil
        local bOnline = online[b.steamid] ~= nil
        if aOnline ~= bOnline then return aOnline end
        if a.steamid ~= b.steamid then return a.steamid < b.steamid end
        return (tonumber(a.slot_index) or 0) < (tonumber(b.slot_index) or 0)
    end)

    net.Start("F2WL_SendList")
        net.WriteUInt(#rows, 16)
        for _, row in ipairs(rows) do
            local sid  = row.steamid
            local sIdx = tonumber(row.slot_index) or 0
            net.WriteString(sid)
            net.WriteUInt(sIdx, 4)
            net.WriteString(row.granted_by or "SYSTEM")
            net.WriteUInt(tonumber(row.granted_at) or 0, 32)
            net.WriteString(row.slot_type or "generic")
            local saved = (DB_GetSavedJob and DB_GetSavedJob(sid, sIdx)) or ""
            net.WriteString(saved)
            local info = online[sid]
            net.WriteBool(info ~= nil)
            net.WriteString(info and info.nick or "")
            net.WriteUInt(info and info.activeSlot or 0, 4)
        end
    net.Send(ply)
end

-- ── Net receivers ──────────────────────────────────────────────────────────────

net.Receive("F2WL_RequestList", function(len, ply)
    if not IsValid(ply) or not ply:IsAdmin() then return end
    SendWLList(ply)
end)

net.Receive("F2WL_GrantSlot", function(len, ply)
    if not IsValid(ply) or not ply:IsAdmin() then
        WL_Notify(ply, false, "Permission denied."); return
    end
    local targetSID = net.ReadString()
    local slotIndex = net.ReadUInt(4)
    local slotType  = net.ReadString()

    if not F2SlotConfig.Slots[slotIndex] then
        WL_Notify(ply, false, "Invalid slot index."); return
    end
    local ok, err = WL_Grant(targetSID, slotIndex, ply:SteamID64(), slotType)
    if not ok then
        WL_Notify(ply, false, "Already granted slot " .. slotIndex .. " to " .. targetSID); return
    end
    WL_Notify(ply, true, "Granted Slot " .. slotIndex .. " to " .. targetSID)
    print(string.format("[F2 WL] %s granted slot %d to %s (%s)", ply:Nick(), slotIndex, targetSID, slotType))
    for _, p in ipairs(player.GetAll()) do
        if p:SteamID() == targetSID then
            -- Sync UI so the new slot shows as unlocked — do NOT auto-switch or kill them
            if SyncPlayerData then pcall(SyncPlayerData, p) end
            if F2Slot_Notify then
                F2Slot_Notify(p, "You've been granted Slot " .. slotIndex .. "! Open F2 to switch.", 1)
            end
        end
    end
    SendWLList(ply)
end)

net.Receive("F2WL_RevokeSlot", function(len, ply)
    if not IsValid(ply) or not ply:IsAdmin() then
        WL_Notify(ply, false, "Permission denied."); return
    end
    local targetSID = net.ReadString()
    local slotIndex = net.ReadUInt(4)

    local ok = WL_Revoke(targetSID, slotIndex)
    if not ok then
        WL_Notify(ply, false, "Slot " .. slotIndex .. " was not granted to " .. targetSID); return
    end
    WL_Notify(ply, true, "Revoked Slot " .. slotIndex .. " from " .. targetSID)
    print(string.format("[F2 WL] %s revoked slot %d from %s", ply:Nick(), slotIndex, targetSID))

    for _, p in ipairs(player.GetAll()) do
        if p:SteamID() == targetSID then
            local activeSl = (ActiveSlot and ActiveSlot[targetSID]) or 1
            if activeSl == slotIndex then
                if ActiveSlot then ActiveSlot[targetSID] = 1 end
                if F2Slot_Notify then F2Slot_Notify(p, "Your Slot " .. slotIndex .. " access was revoked.", 2) end
                timer.Simple(0.5, function()
                    if IsValid(p) then
                        local s1 = F2SlotConfig.Slots[1]
                        if s1 and RPExtraTeams then
                            for _, job in ipairs(RPExtraTeams) do
                                if job.command == s1.default_job or job.name == s1.default_job then
                                    p.F2PendingSlotJob   = job
                                    p.F2PendingSlotIndex = 1
                                    if p:Alive() then p:Kill() end
                                    break
                                end
                            end
                        end
                    end
                end)
            else
                if SyncPlayerData then pcall(SyncPlayerData, p) end
                if F2Slot_Notify then F2Slot_Notify(p, "Your Slot " .. slotIndex .. " access has been revoked.", 2) end
            end
        end
    end
    SendWLList(ply)
end)

-- Admin sets saved job for any player
net.Receive("F2WL_SetSlotJob", function(len, ply)
    if not IsValid(ply) or not ply:IsAdmin() then
        WL_Notify(ply, false, "Permission denied."); return
    end
    local targetSID = net.ReadString()
    local slotIndex = net.ReadUInt(4)
    local jobCmd    = net.ReadString()
    if DB_SetSavedJob then DB_SetSavedJob(targetSID, slotIndex, jobCmd) end
    WL_Notify(ply, true, "Set Slot " .. slotIndex .. " job for " .. targetSID .. " → " .. jobCmd)
    for _, p in ipairs(player.GetAll()) do
        if p:SteamID() == targetSID then
            if SyncPlayerData then pcall(SyncPlayerData, p) end
            local activeSl = (ActiveSlot and ActiveSlot[targetSID]) or 1
            if activeSl == slotIndex then
                -- Admin set the job on the player's CURRENT slot → respawn them into it now
                if F2Slot_Notify then F2Slot_Notify(p, "An admin set your job to: " .. jobCmd .. ". Respawning...", 1) end
                timer.Simple(0.3, function()
                    if IsValid(p) and F2Slot_RespawnIntoSlot then
                        F2Slot_RespawnIntoSlot(p, slotIndex)
                    end
                end)
            else
                -- Different slot — just save quietly so they get it next time they switch
                if F2Slot_Notify then F2Slot_Notify(p, "An admin set your Slot " .. slotIndex .. " job to: " .. jobCmd .. ".", 0) end
            end
        end
    end
    SendWLList(ply)
end)

-- Player sets their OWN saved job for a slot they own
net.Receive("F2WL_SetMyJob", function(len, ply)
    if not IsValid(ply) then return end
    local slotIndex = net.ReadUInt(4)
    local jobCmd    = net.ReadString()
    local sid       = ply:SteamID()

    local canUse = (slotIndex == 1) or F2WL_HasAccess(sid, slotIndex)
    if not canUse then WL_Notify(ply, false, "You don't have access to that slot."); return end

    local jobExists = false
    if RPExtraTeams then
        for _, job in ipairs(RPExtraTeams) do
            if job.command == jobCmd then jobExists = true; break end
        end
    end
    if not jobExists then WL_Notify(ply, false, "Unknown job: " .. tostring(jobCmd)); return end

    if DB_SetSavedJob then DB_SetSavedJob(sid, slotIndex, jobCmd) end

    local activeSl = (ActiveSlot and ActiveSlot[sid]) or 1
    if activeSl == slotIndex then
        -- Changing job on their current active slot → respawn them into it now
        WL_Notify(ply, true, "Switching to " .. jobCmd .. " on Slot " .. slotIndex .. "...")
        timer.Simple(0.1, function()
            if IsValid(ply) and F2Slot_RespawnIntoSlot then
                F2Slot_RespawnIntoSlot(ply, slotIndex)
            end
        end)
    else
        -- Different slot — save for when they next switch to it
        WL_Notify(ply, true, "Saved " .. jobCmd .. " for Slot " .. slotIndex .. ".")
    end
end)

net.Receive("F2WL_SwapSlots", function(len, ply)
    if not IsValid(ply) then return end
    local slotA = net.ReadUInt(4)
    local slotB = net.ReadUInt(4)
    local sid   = ply:SteamID()

    if not F2SlotConfig.Slots[slotA] or not F2SlotConfig.Slots[slotB] then
        WL_Notify(ply, false, "Invalid slot index."); return
    end
    if not ((slotA == 1) or F2WL_HasAccess(sid, slotA)) or
       not ((slotB == 1) or F2WL_HasAccess(sid, slotB)) then
        WL_Notify(ply, false, "You don't have access to one of those slots."); return
    end

    local jobA = (DB_GetSavedJob and DB_GetSavedJob(sid, slotA)) or ""
    local jobB = (DB_GetSavedJob and DB_GetSavedJob(sid, slotB)) or ""
    if DB_SetSavedJob then
        DB_SetSavedJob(sid, slotA, jobB)
        DB_SetSavedJob(sid, slotB, jobA)
    end

    local rowA = sql.QueryRow(string.format("SELECT slot_type FROM %s WHERE steamid = %s AND slot_index = %d", WL_TABLE, sql.SQLStr(sid), slotA))
    local rowB = sql.QueryRow(string.format("SELECT slot_type FROM %s WHERE steamid = %s AND slot_index = %d", WL_TABLE, sql.SQLStr(sid), slotB))
    if rowA and rowB then
        sql.Query(string.format("UPDATE %s SET slot_type = %s WHERE steamid = %s AND slot_index = %d", WL_TABLE, sql.SQLStr(rowB.slot_type), sql.SQLStr(sid), slotA))
        sql.Query(string.format("UPDATE %s SET slot_type = %s WHERE steamid = %s AND slot_index = %d", WL_TABLE, sql.SQLStr(rowA.slot_type), sql.SQLStr(sid), slotB))
    end

    local cur = (ActiveSlot and ActiveSlot[sid]) or 1
    if cur == slotA then
        if ActiveSlot then ActiveSlot[sid] = slotB end
    elseif cur == slotB then
        if ActiveSlot then ActiveSlot[sid] = slotA end
    end

    if SyncPlayerData then pcall(SyncPlayerData, ply) end
    WL_Notify(ply, true, string.format("Swapped Slot %d and Slot %d", slotA, slotB))
end)

-- ── Console commands ───────────────────────────────────────────────────────────

concommand.Add("f2wl_grant", function(ply, cmd, args)
    if IsValid(ply) and not ply:IsAdmin() then print("[F2 WL] Permission denied."); return end
    local sid = args[1]; local slotIdx = tonumber(args[2]); local sType = args[3] or "generic"
    if not sid or not slotIdx then print("[F2 WL] Usage: f2wl_grant <STEAMID> <slot> [type]"); return end
    local ok = WL_Grant(sid, slotIdx, IsValid(ply) and ply:SteamID64() or "CONSOLE", sType)
    if ok then
        print(string.format("[F2 WL] Granted slot %d (%s) to %s", slotIdx, sType, sid))
        for _, p in ipairs(player.GetAll()) do
            if p:SteamID() == sid then
                if SyncPlayerData then pcall(SyncPlayerData, p) end
                if F2Slot_Notify then F2Slot_Notify(p, "You've been granted Slot " .. slotIdx .. "!", 1) end
            end
        end
    else
        print("[F2 WL] Already granted.")
    end
end)

concommand.Add("f2wl_revoke", function(ply, cmd, args)
    if IsValid(ply) and not ply:IsAdmin() then print("[F2 WL] Permission denied."); return end
    local sid = args[1]; local slotIdx = tonumber(args[2])
    if not sid or not slotIdx then print("[F2 WL] Usage: f2wl_revoke <STEAMID> <slot>"); return end
    local ok = WL_Revoke(sid, slotIdx)
    if ok then
        print(string.format("[F2 WL] Revoked slot %d from %s", slotIdx, sid))
    else
        print("[F2 WL] Not granted.")
    end
end)

concommand.Add("f2wl_list", function(ply, cmd, args)
    if IsValid(ply) and not ply:IsAdmin() then return end
    local rows = WL_GetAll()
    print(string.format("[F2 WL] Whitelist (%d entries):", #rows))
    for _, row in ipairs(rows) do
        local saved = (DB_GetSavedJob and DB_GetSavedJob(row.steamid, tonumber(row.slot_index))) or "(none)"
        print(string.format("  %s  slot=%s  type=%-10s  job=%-25s  by=%s",
            row.steamid, row.slot_index, row.slot_type or "?", saved, row.granted_by or "?"))
    end
end)

concommand.Add("f2wl_open", function(ply, cmd, args)
    if not IsValid(ply) then print("[F2 WL] Must run from in-game."); return end
    if not ply:IsAdmin() then ply:ChatPrint("[F2 WL] Admins only."); return end
    net.Start("F2WL_OpenManager"); net.Send(ply)
end)

print("[F2 WL] Whitelist server loaded.")