--[[
    F2 Slot System - Server Backend
    =================================
    Handles:
        • Slot data persistence (SQLite via DarkRP's sql lib)
        • ULX group whitelist validation
        • Job switching logic (kill → respawn → setjob)
        • Net message receivers from client
        • Console commands for admins
]]

-- Config is loaded by lua/autorun/f2_slots_shared.lua which runs before this file.
if not F2SlotConfig then
    error("[F2 Slots] F2SlotConfig is nil — make sure f2_slots_shared.lua is present in lua/autorun/")
    -- FIX 6: removed dead `return` — error() throws immediately, return never ran
end

-- ─────────────────────────────────────────────────────────────────────────────
-- NET STRINGS
-- ─────────────────────────────────────────────────────────────────────────────
util.AddNetworkString("F2Slot_OpenMenu")
util.AddNetworkString("F2Slot_RequestSwitch")
util.AddNetworkString("F2Slot_SyncData")
util.AddNetworkString("F2Slot_Notification")
util.AddNetworkString("F2Slot_OwnerReset")   -- owner-only full wipe, triggered from F2 settings

-- ─────────────────────────────────────────────────────────────────────────────
-- DATABASE SETUP
-- ─────────────────────────────────────────────────────────────────────────────

local TABLE_NAME = "f2_slot_data"

local function DB_Init()
    sql.Query([[
        CREATE TABLE IF NOT EXISTS ]] .. TABLE_NAME .. [[ (
            steamid     TEXT NOT NULL,
            slot_index  INTEGER NOT NULL,
            saved_job   TEXT DEFAULT '',
            PRIMARY KEY (steamid, slot_index)
        )
    ]])
    print("[F2 Slots] Database initialized.")
end

DB_Init()

-- Returns saved job string for a player's slot, or nil if none
function DB_GetSavedJob(steamid, slotIndex)  -- global: shared with f2_whitelist_server.lua
    local result = sql.QueryRow(string.format(
        "SELECT saved_job FROM %s WHERE steamid = %s AND slot_index = %d",
        TABLE_NAME,
        sql.SQLStr(steamid),
        slotIndex
    ))
    if result then return result.saved_job end
    return nil
end

-- Saves / updates which job a player is using in a given slot.
-- Uses INSERT OR REPLACE (SQLite UPSERT) — one round-trip instead of two.
function DB_SetSavedJob(steamid, slotIndex, jobName)  -- global: shared with f2_whitelist_server.lua
    sql.Query(string.format(
        "INSERT OR REPLACE INTO %s (steamid, slot_index, saved_job) VALUES (%s, %d, %s)",
        TABLE_NAME,
        sql.SQLStr(steamid),
        slotIndex,
        sql.SQLStr(jobName)
    ))
end

-- ─────────────────────────────────────────────────────────────────────────────
-- INTERNAL HELPERS
-- ─────────────────────────────────────────────────────────────────────────────

-- Build a command-lookup cache from RPExtraTeams on first use (lazy).
-- Key = job.name (string), value = job.command (string).
-- Invalidated automatically when RPExtraTeams changes length (which only
-- happens on map load), so this is safe for the server lifetime.
local _jobCmdCache     = nil
local _jobCmdCacheSize = 0

local function GetJobCmdCache()
    if not RPExtraTeams then return {} end
    if _jobCmdCacheSize ~= #RPExtraTeams then
        _jobCmdCache     = {}
        _jobCmdCacheSize = #RPExtraTeams
        for _, job in ipairs(RPExtraTeams) do
            _jobCmdCache[job.name] = job.command
        end
    end
    return _jobCmdCache
end

-- Resolves the saved job COMMAND string for the current job a player is in.
-- Tries RPExtraTeams name→command first, then falls back to RegimentJobMap.
local function CurrentJobCommand(ply)
    local ok, jobName = pcall(function() return ply:getDarkRPVar("job") or "" end)
    if not ok or jobName == "" then return nil end
    local cache = GetJobCmdCache()
    if cache[jobName] then return cache[jobName] end
    return F2SlotConfig.RegimentJobMap and F2SlotConfig.RegimentJobMap[jobName] or nil
end

-- Finds a DarkRP job object by command string.
local function FindJobByCommand(cmd)
    if not RPExtraTeams or not cmd then return nil end
    for _, job in ipairs(RPExtraTeams) do
        if job.command == cmd then return job end
    end
    return nil
end

-- Active slot tracking: steamid → current slot index (1/2/3)
ActiveSlot = {}  -- global: shared with f2_whitelist_server.lua

-- Returns the current active slot index for a player (defaults to 1)
local function GetActiveSlot(ply)
    return ActiveSlot[ply:SteamID()] or 1
end

-- Returns true if the player has access to a given slot.
-- Slot 1 is always open. Slots 2+ require a whitelist entry in f2_whitelists.
-- Superadmins always have access to everything for testing purposes.
local function PlayerCanUseSlot(ply, slotIndex)
    local slot = F2SlotConfig.Slots[slotIndex]
    if not slot then return false end

    -- Slot 1 (Clone Trooper) is always available to everyone
    if slotIndex == 1 then return true end

    -- Superadmin bypass for testing (only in singleplayer/dev)
    if game.SinglePlayer() and ply:IsSuperAdmin() then return true end

    local sid = ply:SteamID()

    -- Use the global helper from f2_whitelist_server if loaded,
    -- otherwise fall back to direct SQL (same table, same result)
    local hasAccess
    if F2WL_HasAccess then
        hasAccess = F2WL_HasAccess(sid, slotIndex)
    else
        local row = sql.QueryRow(string.format(
            "SELECT 1 FROM f2_whitelists WHERE steamid = %s AND slot_index = %d",
            sql.SQLStr(sid), slotIndex))
        hasAccess = row ~= nil
    end

    return hasAccess
end

-- Resolves which DarkRP job to spawn a player as for a given slot.
local function ResolveJobForSlot(ply, slotIndex)
    local slot = F2SlotConfig.Slots[slotIndex]
    if not slot then return nil end

    local sid   = ply:SteamID()
    local saved = DB_GetSavedJob(sid, slotIndex)

    -- Always use the DB row if it exists — never override it with a live lookup.
    if saved and saved ~= "" then return saved end

    -- No DB entry yet. For slot 1, try to map from their current regiment job.
    -- Only write to the DB if we get a real match (not a fallback default),
    -- so we don't clobber a future save with a stale "just joined" job name.
    if slotIndex == 1 then
        local ok, currentJobName = pcall(function() return ply:getDarkRPVar("job") or "" end)
        if ok and currentJobName ~= "" then
            local mapped = F2SlotConfig.RegimentJobMap and F2SlotConfig.RegimentJobMap[currentJobName]
            if mapped then
                -- Real regiment job found — persist it now
                DB_SetSavedJob(sid, slotIndex, mapped)
                return mapped
            end
        end
    end

    -- Fall back to the slot default. Do NOT write this to the DB — the player
    -- hasn't meaningfully chosen a job yet, and writing it would overwrite a
    -- valid saved job if DarkRP hadn't finished initialising when we ran.
    return slot.default_job
end

-- Sends full slot state to a player's client (global: used by f2_whitelist_server.lua)
function SyncPlayerData(ply)
    if not IsValid(ply) then return end
    if not ply:IsPlayer() then return end

    local sid       = ply:SteamID()
    local numSlots  = #F2SlotConfig.Slots

    net.Start("F2Slot_SyncData")
        net.WriteUInt(GetActiveSlot(ply), 4)
        net.WriteUInt(numSlots, 4)
        for i = 1, numSlots do
            net.WriteBool(PlayerCanUseSlot(ply, i))
            net.WriteString(DB_GetSavedJob(sid, i) or "")
        end
    net.Send(ply)
end

-- Sends a notification to a player's screen
function F2Slot_Notify(ply, msg, notifType)  -- global for whitelist server
    net.Start("F2Slot_Notification")
        net.WriteString(msg)
        net.WriteUInt(notifType or 0, 4) -- 0=info, 1=success, 2=error
    net.Send(ply)
end

-- Respawns a player into a specific slot immediately.
-- Called by f2_whitelist_server when:
--   • Admin grants a slot (player respawns into that slot's job)
--   • Player sets their saved job via F2WL_SetMyJob (respawns into new job on current slot)
-- slotIndex = which slot to switch to (nil = keep current active slot, just re-resolve job)
function F2Slot_RespawnIntoSlot(ply, slotIndex)
    if not IsValid(ply) then return end
    slotIndex = slotIndex or (ActiveSlot[ply:SteamID()] or 1)

    -- If the player is ALREADY on this slot we can't use DoSlotSwitch (it bails early).
    -- Instead, resolve the saved job and kill/respawn directly — same as DoSlotSwitch
    -- does internally, but without the "already on this slot" guard.
    if GetActiveSlot(ply) == slotIndex then
        timer.Simple(0.05, function()
            if not IsValid(ply) then return end
            local sid    = ply:SteamID()
            local newJob = ResolveJobForSlot(ply, slotIndex)
            local jobObj = FindJobByCommand(newJob)
            if not jobObj then
                F2Slot_Notify(ply, "Could not find job: " .. tostring(newJob) .. ". Contact an admin.", 2)
                return
            end
            ply.F2PendingSlotJob   = jobObj
            ply.F2PendingSlotIndex = slotIndex
            F2Slot_Notify(ply, "Updating job...", 0)
            if ply:Alive() then ply:Kill() else ply:Spawn() end
        end)
        return
    end

    -- Different slot — use normal DoSlotSwitch path
    timer.Simple(0.05, function()
        if IsValid(ply) then DoSlotSwitch(ply, slotIndex) end
    end)
end

-- ─────────────────────────────────────────────────────────────────────────────
-- CORE: SLOT SWITCHING LOGIC
-- ─────────────────────────────────────────────────────────────────────────────

-- Players currently mid-switch (to prevent double-switching)
SwitchingPlayers = {}  -- global: also used by f2_whitelist_server.lua

function DoSlotSwitch(ply, targetSlot)
    -- IsValid MUST come first — ply:SteamID() will error on an invalid entity
    if not IsValid(ply) then return end

    local sid = ply:SteamID()

    if SwitchingPlayers[sid] then
        F2Slot_Notify(ply, "Please wait before switching again.", 2)
        return
    end

    -- Validate slot exists
    local slotConfig = F2SlotConfig.Slots[targetSlot]
    if not slotConfig then
        F2Slot_Notify(ply, "Invalid slot.", 2)
        return
    end

    -- Check access
    if not PlayerCanUseSlot(ply, targetSlot) then
        F2Slot_Notify(ply, "You don't have access to that slot.", 2)
        return
    end

    -- Already on this slot?
    if GetActiveSlot(ply) == targetSlot then
        F2Slot_Notify(ply, "You're already on that slot.", 0)
        return
    end

    -- Save current job COMMAND to current slot before switching.
    local currentSlot    = GetActiveSlot(ply)
    local savedCmd       = CurrentJobCommand(ply)
    if savedCmd then
        DB_SetSavedJob(sid, currentSlot, savedCmd)
    end

    -- Lock switching during transition
    SwitchingPlayers[sid] = true

    -- FIX 7: Safety timer registered HERE at lock time, not inside PlayerSpawn.
    -- Previously the 8s timer was only registered if PlayerSpawn fired — meaning
    -- if the player died but PlayerSpawn never triggered (e.g. spectator states,
    -- non-standard DarkRP builds), the lock would be permanent.
    timer.Simple(12, function()
        if SwitchingPlayers[sid] then
            SwitchingPlayers[sid] = nil
            print("[F2 Slots] Safety: released stale switch lock for " .. sid)
        end
    end)

    -- Resolve new job
    local newJob = ResolveJobForSlot(ply, targetSlot)

    -- Find the DarkRP job object
    local jobObj = FindJobByCommand(newJob)

    if not jobObj then
        SwitchingPlayers[sid] = nil
        F2Slot_Notify(ply, "Could not find job: " .. tostring(newJob) .. ". Contact an admin.", 2)
        return
    end

    -- Update active slot
    ActiveSlot[sid] = targetSlot

    -- Kill → wait for respawn hook to assign job
    -- We store the pending job so the SpawnHook can apply it
    ply.F2PendingSlotJob = jobObj
    ply.F2PendingSlotIndex = targetSlot

    F2Slot_Notify(ply, "Switching to " .. slotConfig.label .. "...", 0)

    -- Kill the player - SpawnHook below handles the rest
    if ply:Alive() then
        ply:Kill()
    else
        -- Already dead, just force respawn
        timer.Simple(0.2, function()
            if IsValid(ply) then
                ply:Spawn()
            end
        end)
    end
end

-- ─────────────────────────────────────────────────────────────────────────────
-- PLAYER SPAWN HOOK — applies the pending job after death
-- ─────────────────────────────────────────────────────────────────────────────

hook.Add("PlayerSpawn", "F2Slot_ApplyJobOnSpawn", function(ply)
    if not IsValid(ply) then return end
    if not ply:IsPlayer() then return end

    local sid        = ply:SteamID()
    local jobObj     = ply.F2PendingSlotJob
    local targetSlot = ply.F2PendingSlotIndex

    -- No pending F2 switch — do NOT touch SwitchingPlayers here.
    -- The lock is only ever owned by DoSlotSwitch and released by ApplyJob.
    -- Clearing it on a normal spawn would race with an in-progress switch.
    if not jobObj then return end

    -- Snapshot and clear pending markers immediately so a second spawn
    -- (e.g. player dies during the apply window) doesn't re-trigger.
    ply.F2PendingSlotJob   = nil
    ply.F2PendingSlotIndex = nil

    -- We use DarkRP's own changeTeam() which handles model, weapons, salary,
    -- and all NW vars in one call — no need to fight DarkRP's own spawn hooks.
    -- We fire it at 0.3s so DarkRP's PlayerSpawn hooks have finished resetting
    -- the player to their old job first, then we cleanly override.
    -- A second call at 1.0s catches any gamemode-specific late overrides.

    local function ApplyJob(isFinal)
        if not IsValid(ply) then
            SwitchingPlayers[sid] = nil
            return
        end

        -- Safety: if ActiveSlot changed since we queued (player switched again),
        -- abort this apply — the newer switch owns the player now.
        if ActiveSlot[sid] ~= targetSlot then
            if isFinal then SwitchingPlayers[sid] = nil end
            return
        end

        local ok, err = pcall(function()
            -- changeTeam is DarkRP's canonical job-switch function.
            -- Args: team, giveloadout, resetHunger
            -- It sets model, weapons, salary, DarkRP NW vars, and calls
            -- the job's PlayerSpawn callback automatically on the final pass.
            if ply.changeTeam then
                ply:changeTeam(jobObj.team, true, false)
            else
                -- Fallback for non-standard DarkRP builds
                ply:updateJob(jobObj.name)
                ply:setDarkRPVar("job", jobObj.name)
                ply:SetTeam(jobObj.team)
                if jobObj.salary then ply:setSalary(jobObj.salary) end
                if jobObj.model then
                    local mdl = jobObj.model
                    if type(mdl) == "table" then mdl = mdl[math.random(#mdl)] end
                    ply:SetModel(mdl)
                end
                ply:StripWeapons()
                if jobObj.weapons then
                    for _, wep in ipairs(jobObj.weapons) do ply:Give(wep) end
                end
            end
        end)

        if not ok then
            print("[F2 Slots] ApplyJob error: " .. tostring(err))
        end

        if isFinal then
            -- Run custom spawn callback once everything is settled,
            -- but only if changeTeam didn't already call it.
            if not ply.changeTeam and jobObj.PlayerSpawn then
                pcall(jobObj.PlayerSpawn, ply)
            end

            -- Always persist the confirmed applied job — most reliable save point.
            DB_SetSavedJob(sid, targetSlot, jobObj.command)

            SyncPlayerData(ply)

            local slotConfig = F2SlotConfig.Slots[targetSlot]
            F2Slot_Notify(ply, "Now playing as " .. jobObj.name ..
                " (" .. (slotConfig and slotConfig.label or "Slot " .. targetSlot) .. ")", 1)

            -- Release switch lock
            SwitchingPlayers[sid]  = nil
            PlayerInitialised[sid] = true  -- now in their correct F2 job
        end
    end

    -- 0.3s: DarkRP's own PlayerSpawn hooks have finished by now
    -- 1.0s: final confirmation pass, releases lock
    timer.Simple(0.3, function() ApplyJob(false) end)
    timer.Simple(1.0, function() ApplyJob(true)  end)
    -- Note: the 12s hard safety valve is registered in DoSlotSwitch at lock time.
end)

-- ─────────────────────────────────────────────────────────────────────────────
-- NET: CLIENT REQUESTS SLOT SWITCH
-- ─────────────────────────────────────────────────────────────────────────────

net.Receive("F2Slot_RequestSwitch", function(len, ply)
    local targetSlot = net.ReadUInt(4)
    DoSlotSwitch(ply, targetSlot)
end)

-- ─────────────────────────────────────────────────────────────────────────────
-- PLAYER CONNECT / DISCONNECT HOOKS
-- ─────────────────────────────────────────────────────────────────────────────

-- Tracks whether a player has been F2-respawned into their saved job this
-- session. Until this is true the periodic save must NOT write back, because
-- the player's current DarkRP job is still the gamemode default — not their
-- real saved regiment.
local PlayerInitialised = {}

hook.Add("PlayerInitialSpawn", "F2Slot_InitPlayer", function(ply)
    if not IsValid(ply) then return end
    if not ply:IsPlayer() then return end

    local sid = ply:SteamID()
    ActiveSlot[sid]        = 1
    PlayerInitialised[sid] = false

    timer.Simple(5, function()
        if not IsValid(ply) then return end
        if not ply:IsPlayer() then return end

        local ok, err = pcall(SyncPlayerData, ply)
        if not ok then
            print("[F2 Slots] SyncPlayerData error for " .. tostring(ply:Nick()) .. ": " .. tostring(err))
        end

        -- Respawn the player into their saved Slot 1 job.
        -- Previously this step was missing: SyncPlayerData told the *client*
        -- what the saved job was, but the server never put the player in that
        -- team. DarkRP kept them on its default job, and the periodic save then
        -- wrote that default back over the real saved value.
        local saved = DB_GetSavedJob(sid, 1)
        if saved and saved ~= "" then
            local jobObj = FindJobByCommand(saved)
            if jobObj then
                -- Apply the saved job directly via changeTeam rather than
                -- kill→spawn. This avoids the permanent-death issue caused by
                -- killing a player who may not be fully spawned yet, and avoids
                -- racing with DarkRP's own first-spawn hooks.
                -- We wait an extra 0.5s after sync (5.5s total) to be sure
                -- DarkRP has finished its own initialisation pass.
                timer.Simple(0.5, function()
                    if not IsValid(ply) then PlayerInitialised[sid] = true; return end
                    local ok, err = pcall(function()
                        if ply.changeTeam then
                            ply:changeTeam(jobObj.team, true, false)
                        else
                            ply:updateJob(jobObj.name)
                            ply:setDarkRPVar("job", jobObj.name)
                            ply:SetTeam(jobObj.team)
                            if jobObj.salary then ply:setSalary(jobObj.salary) end
                            if jobObj.model then
                                local mdl = jobObj.model
                                if type(mdl) == "table" then mdl = mdl[math.random(#mdl)] end
                                ply:SetModel(mdl)
                            end
                        end
                        DB_SetSavedJob(sid, 1, jobObj.command)
                    end)
                    if not ok then
                        print("[F2 Slots] InitialSpawn changeTeam error for " .. sid .. ": " .. tostring(err))
                    end
                    SyncPlayerData(ply)
                    PlayerInitialised[sid] = true
                end)
            else
                -- Job in DB but not in RPExtraTeams (job removed/renamed).
                PlayerInitialised[sid] = true
            end
        else
            -- No saved job — brand new player, DarkRP default is correct.
            PlayerInitialised[sid] = true
        end
    end)

    if F2SlotConfig.OpenOnFirstJoin then
        timer.Simple(6, function()
            if not IsValid(ply) then return end
            net.Start("F2Slot_OpenMenu")
            net.Send(ply)
        end)
    end
end)

-- ─────────────────────────────────────────────────────────────────────────────
-- PERIODIC SLOT-1 SAVE
-- ─────────────────────────────────────────────────────────────────────────────
-- PlayerDisconnected fires too late during map changes — DarkRP has already
-- torn down the player entity by then, so getDarkRPVar returns nil and the
-- Slot 1 job is never written to the DB.  We solve this by flushing the
-- current job to the DB on a regular heartbeat while the player is alive,
-- so the DB row is always current regardless of how the session ends.
timer.Create("F2Slot_PeriodicSave", 60, 0, function()
    for _, ply in ipairs(player.GetAll()) do
        if IsValid(ply) and ply:IsPlayer() and ply:Alive() then
            local sid = ply:SteamID()
            -- Don't save until the player has been put in their correct F2 job.
            -- Before that point their DarkRP job is the gamemode default, and
            -- writing it would clobber the real saved regiment.
            if not PlayerInitialised[sid] then continue end
            if SwitchingPlayers[sid] then continue end
            local cmd = CurrentJobCommand(ply)
            if cmd then
                DB_SetSavedJob(sid, ActiveSlot[sid] or 1, cmd)
            end
        end
    end
end)

hook.Add("PlayerDeath", "F2Slot_SaveOnDeath", function(ply)
    if not IsValid(ply) then return end
    local sid = ply:SteamID()
    if not PlayerInitialised[sid] then return end  -- not yet in their real job
    if SwitchingPlayers[sid] then return end
    local cmd = CurrentJobCommand(ply)
    if cmd then DB_SetSavedJob(sid, ActiveSlot[sid] or 1, cmd) end
end)

hook.Add("PlayerDisconnected", "F2Slot_CleanupPlayer", function(ply)
    -- Save current job COMMAND to current slot on disconnect.
    -- Note: getDarkRPVar may return nil here during map changes (DarkRP tears
    -- down the entity before this hook fires).  The periodic save timer and
    -- PlayerDeath hook above are the primary save points for Slot 1;
    -- this is just a last-chance attempt.
    local sid         = ply:SteamID()
    local currentSlot = ActiveSlot[sid] or 1
    local savedCmd    = CurrentJobCommand(ply)
    if savedCmd then
        DB_SetSavedJob(sid, currentSlot, savedCmd)
    end

    -- Clean up memory
    ActiveSlot[sid]        = nil
    SwitchingPlayers[sid]  = nil
    PlayerInitialised[sid] = nil
end)

-- ─────────────────────────────────────────────────────────────────────────────
-- ADMIN CONSOLE COMMANDS
-- ─────────────────────────────────────────────────────────────────────────────

-- Usage: rcon f2slot_setjob <steamid> <slot> <jobcommand>
concommand.Add("f2slot_setjob", function(ply, cmd, args)
    if IsValid(ply) and not ply:IsSuperAdmin() then
        ply:ChatPrint("[F2 Slots] You must be superadmin to use this command.")
        return
    end

    local steamid  = args[1]
    local slotIdx  = tonumber(args[2])
    local jobCmd   = args[3]

    if not steamid or not slotIdx or not jobCmd then
        print("[F2 Slots] Usage: f2slot_setjob <steamid> <slot 1-4> <job_command>")
        return
    end

    DB_SetSavedJob(steamid, slotIdx, jobCmd)
    print(string.format("[F2 Slots] Set slot %d for %s to job '%s'", slotIdx, steamid, jobCmd))

    -- Sync to player if online
    for _, p in ipairs(player.GetAll()) do
        if p:SteamID() == steamid then
            SyncPlayerData(p)
            F2Slot_Notify(p, "An admin updated your Slot " .. slotIdx .. " job.", 1)
        end
    end
end)

-- Usage: f2slot_info <player name>
concommand.Add("f2slot_info", function(ply, cmd, args)
    if IsValid(ply) and not ply:IsAdmin() then return end

    local targetName = table.concat(args, " ")
    local target     = player.GetByName(targetName)
    if not IsValid(target) then
        -- Partial match fallback
        local lower = string.lower(targetName)
        for _, p in ipairs(player.GetAll()) do
            if string.find(string.lower(p:Nick()), lower, 1, true) then
                target = p; break
            end
        end
    end

    if not IsValid(target) then
        print("[F2 Slots] Player not found: " .. targetName)
        return
    end

    local sid = target:SteamID()
    print(string.format("[F2 Slots] Info for %s (%s):", target:Nick(), sid))
    print(string.format("  Active Slot: %d", ActiveSlot[sid] or 1))
    for i = 1, #F2SlotConfig.Slots do
        local saved = DB_GetSavedJob(sid, i) or "(none)"
        local access = PlayerCanUseSlot(target, i) and "UNLOCKED" or "LOCKED"
        print(string.format("  Slot %d [%s]: saved job = %s", i, access, saved))
    end
end)

print("[F2 Slot System] Server backend loaded.")

-- ─────────────────────────────────────────────────────────────────────────────
-- RESET COMMANDS  (superadmin / server console only)
-- ─────────────────────────────────────────────────────────────────────────────

-- f2_reset_player <steamid or name>
-- Wipes ALL F2 slot data and whitelist entries for one player.
-- They will be treated exactly like a new joining player.
concommand.Add("f2_reset_player", function(ply, cmd, args)
    if IsValid(ply) and not ply:IsSuperAdmin() then
        print("[F2 Reset] Permission denied."); return
    end

    local query = table.concat(args, " ")
    if query == "" then
        print("[F2 Reset] Usage: f2_reset_player <steamid or partial name>"); return
    end

    -- Accept a raw SteamID or a partial name of an online player
    local steamid = nil
    if string.sub(query, 1, 6) == "STEAM_" or string.sub(query, 1, 3) == "[U:" then
        steamid = query
    else
        for _, p in ipairs(player.GetAll()) do
            if string.find(string.lower(p:Nick()), string.lower(query), 1, true) then
                steamid = p:SteamID(); break
            end
        end
    end

    if not steamid then
        print("[F2 Reset] Could not find player: " .. query); return
    end

    -- Wipe slot data
    sql.Query("DELETE FROM f2_slot_data WHERE steamid = " .. sql.SQLStr(steamid))
    -- Wipe whitelists
    sql.Query("DELETE FROM f2_whitelists WHERE steamid = " .. sql.SQLStr(steamid))

    -- Reset in-memory active slot
    if ActiveSlot then ActiveSlot[steamid] = 1 end
    if SwitchingPlayers then SwitchingPlayers[steamid] = nil end

    -- If the player is online, resync them and kill back to slot 1
    for _, p in ipairs(player.GetAll()) do
        if p:SteamID() == steamid then
            local slot1Cmd = F2SlotConfig.Slots[1] and F2SlotConfig.Slots[1].default_job or ""
            p.F2PendingSlotJob   = FindJobByCommand(slot1Cmd)
            p.F2PendingSlotIndex = 1
            SyncPlayerData(p)
            if p:Alive() then p:Kill() end
            F2Slot_Notify(p, "Your character data has been reset by an admin.", 2)
            break
        end
    end

    print(string.format("[F2 Reset] Wiped all data for %s", steamid))
end)

-- f2_reset_all
-- Wipes ALL data for ALL players — both tables fully cleared.
-- Resets every online player back to slot 1 default.
concommand.Add("f2_reset_all", function(ply, cmd, args)
    if IsValid(ply) and not ply:IsSuperAdmin() then
        print("[F2 Reset] Permission denied."); return
    end

    -- Safety confirmation argument required so it can't be run by accident
    if args[1] ~= "CONFIRM" then
        print("[F2 Reset] WARNING: This wipes ALL slot and whitelist data for every player.")
        print("[F2 Reset] Run:  f2_reset_all CONFIRM  to proceed.")
        return
    end

    sql.Query("DELETE FROM f2_slot_data")
    sql.Query("DELETE FROM f2_whitelists")

    -- Reset in-memory tables
    ActiveSlot       = {}
    SwitchingPlayers = {}

    -- Kick all online players back to slot 1
    local slot1Cmd = F2SlotConfig.Slots[1] and F2SlotConfig.Slots[1].default_job or ""
    local slot1Job = FindJobByCommand(slot1Cmd)
    for _, p in ipairs(player.GetAll()) do
        p.F2PendingSlotJob   = slot1Job
        p.F2PendingSlotIndex = 1
        SyncPlayerData(p)
        if p:Alive() then p:Kill() end
        F2Slot_Notify(p, "All character data has been reset by an admin.", 2)
    end

    print("[F2 Reset] All F2 slot and whitelist data wiped for all players.")
end)

-- ─── OWNER RESET (net-triggered from F2 settings button) ─────────────────────
-- Only executes if the requesting player's SteamID exactly matches the owner SteamID.
-- No other player — including superadmins — can trigger this path.
local OWNER_STEAMID = "STEAM_1:1:743498109"

net.Receive("F2Slot_OwnerReset", function(len, ply)
    if not IsValid(ply) then return end
    if ply:SteamID() ~= OWNER_STEAMID then
        -- Silently ignore — don't even log, so no one knows this receiver exists
        return
    end

    sql.Query("DELETE FROM f2_slot_data")
    sql.Query("DELETE FROM f2_whitelists")
    ActiveSlot       = {}
    SwitchingPlayers = {}

    local slot1Cmd = F2SlotConfig.Slots[1] and F2SlotConfig.Slots[1].default_job or ""
    local slot1Job = FindJobByCommand(slot1Cmd)
    for _, p in ipairs(player.GetAll()) do
        p.F2PendingSlotJob   = slot1Job
        p.F2PendingSlotIndex = 1
        SyncPlayerData(p)
        if p:Alive() then p:Kill() end
        F2Slot_Notify(p, "Server character data has been reset.", 2)
    end

    print(string.format("[F2] Owner reset performed by %s (%s)", ply:Nick(), ply:SteamID()))
end)