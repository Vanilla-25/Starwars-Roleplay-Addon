COMBO.id = "formvb" -- internal ID, lower case only
COMBO.PrintName = "Vibroblade" -- what should be displayed in your hud
COMBO.Author = "Truce"
COMBO.Description = "" -- write an essay explaining what makes your saber style the best
COMBO.Icon = "kybercore/form_vb.png" -- icon to be displayed in the hud

COMBO.DeflectBullets = false -- false, because this style can not deflect bullets. Set to true to enable
COMBO.AutoBlock = true -- false, because this style can only block when a perfect block is performed. Doesn't use stamina system. For any style that should not suck set to true

COMBO.LeftSaberActive = false -- if this combo is selected, left saber is deactivated
COMBO.Spawnable = false 
COMBO.MaxBlockPoints = 50 -- use this to make op boss saber stances. Avoid using this. Only uncomment if you really need it.
--COMBO.BPDrainPerHit = 25 -- how much bp damage this saber stance should be doing. Avoid using this. Only uncomment if you really need it.

--COMBO.BlockDistanceNormal = 60 -- distance of crosshair to block pos until  a normal block is detected with this stance. Avoid using this. Only uncomment if you really need it.
--COMBO.BlockDistancePerfect = 20 -- distance of crosshair to block pos until  a perfect block is detected with this stance. Avoid using this. Only uncomment if you really need it.

COMBO.HoldType = "knife"  -- just like any other weapon. If you have wos installed you can just use their holdtype editor to add custom holdtypes.

COMBO.Attacks = {}
COMBO.Attacks = {
    ["____"] = {
		AttackAnim = "phalanx_b_s3_t2",
        AttackAnimStart = 0, -- start from this cycle
		BeginAttack = function( weapon, ply ) 
			weapon:DoAttackSound()
			
		end,
		FinishAttack = function( weapon, ply ) end,
		Delay = 0,
		Duration = 0.2,
		Rate = 1.3,
	},
    ["W___"] = {
		AttackAnim = "vanguard_b_s4_t1",
        AttackAnimStart = 0, -- start from this cycle
		BeginAttack = function( weapon, ply )  
			weapon:DoAttackSound()
			if ply:OnGround() then
				ply:SetVelocity( Angle(0,ply:EyeAngles().y,0):Forward() * 1000 )
			end
			ply:lscsSetTimedMove( 1, CurTime(), 1, Vector(0,0,0) )
		end,
		FinishAttack = function( weapon, ply ) end,
		Delay = 0.1,
		Duration = 0.4,
		Rate = 1.7,
	},
    ["_A__"] = {
		AttackAnim = "judge_r_s3_t2",
		AttackAnimStart = 0.1, -- start from this cycle
		AttackAnimMenu = "judge_b_left_t1",
		BeginAttack = function( weapon, ply ) 
			weapon:DoAttackSound()
			ply:lscsSetTimedMove( 1, CurTime(), 0.1, Vector(0,-100,0) )
			ply:lscsSetTimedMove( 2, CurTime() + 0.2, 0.1, Vector(0,0,0) )
		end,
		FinishAttack = function( weapon, ply ) end,
		Delay = 0.1,
		Duration = 0.7,
		Rate = 1.2,
	},
    ["___D"] = {
		AttackAnim = "pure_r_right_t3",
        AttackAnimStart = 0.25, -- start from this cycle
		BeginAttack = function( weapon, ply )  
			weapon:DoAttackSound()
			ply:lscsSetTimedMove( 1, CurTime(), 0, Vector(0,100,0) )
			ply:lscsSetTimedMove( 2, CurTime() + 0.2, 0.1, Vector(0,0,0) )
		end,
		FinishAttack = function( weapon, ply ) end,
		Delay = 0.1,
		Duration = 0.4,
		Rate = 0.8,
	},
	["W_S_"] = {
		AttackAnim = "phalanx_b_s2_t1",
        AttackAnimStart = 0, -- start from this cycle
		BeginAttack = function( weapon, ply )  
			weapon:DoAttackSound()
			ply:lscsSetTimedMove( 1, CurTime(), 1, Vector(250,0,0) )
			ply:lscsSetTimedMove( 2, CurTime() + 0.7, 0.2, Vector(250,0,0) )
			ply:lscsSetTimedMove( 3, CurTime() + 0.9, 0.7, Vector(250,0,0) )

			timer.Simple(0.2, function()
				if not IsValid( weapon ) then return end
				weapon:DoAttackSound()
			end)
			timer.Simple(0.8, function()
				if not IsValid( weapon ) then return end
				weapon:DoAttackSound()
			end)
		end,
		FinishAttack = function( weapon, ply ) end,
		Delay = 0.1,
		Duration = 1,
	},
    ["W__D"] = {
		AttackAnim = "pure_b_left_t3",
        AttackAnimStart = 0, -- start from this cycle
		BeginAttack = function( weapon, ply )  
			weapon:DoAttackSound()
			ply:lscsSetTimedMove( 1, CurTime(), 0, Vector(0,0,0) )
			ply:lscsSetTimedMove( 2, CurTime() + 0, 0, Vector(0,0,0) )
		end,
		FinishAttack = function( weapon, ply ) end,
		Delay = 0.0,
		Duration = 0.35,
	},
    ["WA__"] = {
		AttackAnim = "wos_phalanx_b_left_t3",
		AttackAnimStart = 0.1,
		BeginAttack = function( weapon, ply )  
			weapon:DoAttackSound()
			ply:lscsSetTimedMove( 1, CurTime(), 0.2, Vector(0,-100,0) )
			ply:lscsSetTimedMove( 2, CurTime() + 0.2, 0.1, Vector(0,0,0) )
		end,
		FinishAttack = function( weapon, ply ) end,
		Delay = 0.1,
		Duration = 0.25,
		Rate = 1.1
	},
    ["-45-"] = {
		AttackAnim = "phalanx_b_s3_t2",
        AttackAnimStart = 0, -- start from this cycle
		BeginAttack = function( weapon, ply ) 
			weapon:DoAttackSound()
			ply:lscsSetTimedMove( 1, CurTime(), 0.3, Vector(10,0,0) )
		end,
		FinishAttack = function( weapon, ply ) end,
		Delay = 0,
		Duration = 0.2,
		Rate = 1.3,
	},
	["+45+"] = {
		AttackAnim = "vanguard_r_s1_t2",
		AttackAnimStart = 0, -- start from this cycle
		BeginAttack = function( weapon, ply ) 
			weapon:DoAttackSound()
			ply:lscsSetTimedMove( 1, CurTime(), 0.3, Vector(10,0,0) )
		end,
		FinishAttack = function( weapon, ply ) end,
		Delay = 0.1,
		Duration = 0.2,
		Rate = 1.3,
    },
    ["FRONT_DASH"] = {
        AttackAnim = "phalanx_a_s1_t1",
        AttackAnimStart = 0, -- start from this cycle
        BeginAttack = function( weapon, ply )  
            weapon:DoAttackSound()
    
            timer.Simple(0.2, function()
                if not IsValid( weapon ) then return end
                weapon:DoAttackSound()
            end)
            timer.Simple(0.6, function()
                if not IsValid( weapon ) then return end
                weapon:DoAttackSound()
            end)
    
            if ply:OnGround() then
                ply:SetVelocity( Angle(0,ply:EyeAngles().y,0):Forward() * 350 )
            else
                ply:SetVelocity( Angle(0,ply:EyeAngles().y,0):Forward() * 200 + Vector(0,0,40) )
            end
        end,
        FinishAttack = function( weapon, ply ) end,
        Delay = 0.1,
        Duration = 0.4,
		Rate = 0.8,
    },
    ["BACKFLIP"] = {
		AttackAnim = "rollback",
        AttackAnimStart = 0, -- start from this cycle
		BeginAttack = function( weapon, ply )  
			weapon:SetDMGActive( false )

			ply:SetVelocity( Vector(0,0,3) - Angle(0,ply:EyeAngles().y,0):Forward() * 250 )

		end,
		FinishAttack = function( weapon, ply ) end,
		Delay = 0,
		Duration = 0.2,
	},
	["ROLL_RIGHT"] = {
		AttackAnim = "wos_bs_shared_roll_right",
        AttackAnimStart = 0, -- start from this cycle
		BeginAttack = function( weapon, ply )  
			weapon:DoAttackSound()

			ply:SetVelocity( Vector(0,0,3) + Angle(0,ply:EyeAngles().y,0):Right() * 150 )

		end,
		FinishAttack = function( weapon, ply ) end,
		Delay = 0,
		Duration = 0.2,
	},
	["ROLL_LEFT"] = {
		AttackAnim = "wos_bs_shared_roll_left",
		BeginAttack = function( weapon, ply )  
			weapon:DoAttackSound()

			ply:SetVelocity( Vector(0,0,3) - Angle(0,ply:EyeAngles().y,0):Right() * 150 )

		end,
		FinishAttack = function( weapon, ply ) end,
		Delay = 0,
		Duration = 0.2,
    },
}


--[[ -- list of valid COMBO.Attacks

	"____"			// standing still or fallback. Every saber style MUST HAVE THIS or the combo file will error.
	"SLAM"			// pressing attack after doing BACKFLIP
	"FRONT_DASH"		// when holding w + jump while in air and then pressing mouse1 (while still holding w + jump)
	"BACKFLIP"		// when holding s + jump while in air and then pressing mouse1 (while still holding s + jump)
	"ROLL_RIGHT"		// when holding d + jump while in air and then pressing mouse1 (while still holding d + jump)
	"ROLL_LEFT"		// when holding a + jump while in air and then pressing mouse1 (while still holding a + jump)
	"-45-"			// standing, looking up
	"+45+"			// standing, looking down
	"W_S_"			// while holding W + S
	"__S_"			// ect ect
	"_A__"			// ok ?
	"___D"
	"W__D"
	"WA__"
	"__SD"
	"_AS_"
	"W___"			// order always has to be W A S D

]]--

-- LSCS:Reload() -- calling LSCS:Reload() is actually not needed but it helps alot while working on a combo file. 
-- Its so you dont have to reload the map all the time. Once you are finished you should comment it out to avoid hundreds of files spamming refresh on the basescript. If this function is called twice or on gamestartup the basescript will actually refuse to reload. So PLEASE remove it when you release your stuff.