COMBO.id = "form5" -- internal ID, lower case only
COMBO.PrintName = "Form 5: Shien" -- what should be displayed in your hud
COMBO.Author = "Truce"
COMBO.Description = "The most physically demanding form. Form 5 uses strength to overpower their opponents and use their opponents attacks against them." -- write an essay explaining what makes your saber style the best
COMBO.Icon = "kybercore/form5.png" -- icon to be displayed in the hud

COMBO.DeflectBullets = true -- false, because this style can not deflect bullets. Set to true to enable
COMBO.AutoBlock = true -- false, because this style can only block when a perfect block is performed. Doesn't use stamina system. For any style that should not suck set to true

COMBO.LeftSaberActive = false -- if this combo is selected, left saber is deactivated, left saber is deactivated by default, so set to true to activate it
COMBO.SaberStaffActive = true -- if this combo is selected, saber staff's second blade is deactivated, second blade is activated by default, so set to false to deactivate it

--COMBO.MaxBlockPoints = 500 -- use this to make op boss saber stances. Avoid using this. Only uncomment if you really need it.
--COMBO.BPDrainPerHit = 40 -- how much bp damage this saber stance should be doing. Avoid using this. Only uncomment if you really need it.
COMBO.DamageMultiplier = 1.25 -- multiplies global server damage setting for this stance. Avoid using this. Only uncomment if you really need it.
--COMBO.BlockDistanceNormal = 60 -- distance of crosshair to block pos until  a normal block is detected with this stance. Avoid using this. Only uncomment if you really need it.
--COMBO.BlockDistancePerfect = 20 -- distance of crosshair to block pos until  a perfect block is detected with this stance. Avoid using this. Only uncomment if you really need it.

COMBO.HoldType = "wos-truce-form5"  -- just like any other weapon. If you have wos installed you can just use their holdtype editor to add custom holdtypes.

// Special will run a function everytime the form is selected!
COMBO.Special = function( ply, wep )
end

COMBO.Attacks = {}
COMBO.Attacks = {
    ["____"] = {
		AttackAnim = "combo32",
        AttackAnimStart = 0.1, -- start from this cycle
		BeginAttack = function( weapon, ply )  
			weapon:DoAttackSound()
		end,
		FinishAttack = function( weapon, ply ) end,
		Delay = 0,
		Duration = 0.3,
		Rate = 1.1,
	},
    ["W___"] = {
		AttackAnim = "wos_judge_a_s1_t3",
        AttackAnimStart = 0, -- start from this cycle
		BeginAttack = function( weapon, ply )  
			weapon:DoAttackSound()
			if ply:OnGround() then
				ply:SetVelocity( Angle(0,ply:EyeAngles().y,0):Forward() * 1000 )
			end
			ply:lscsSetTimedMove( 1, CurTime(), 0.9, Vector(0,0,0) )
		end,
		FinishAttack = function( weapon, ply ) end,
		Delay = 0,
		Duration = 0.55,
		Rate = 1.3,
	},
    ["_A__"] = {
		AttackAnim = "wos_judge_h_left_t2",
		AttackAnimStart = 0.05, -- start from this cycle
		AttackAnimMenu = "judge_b_left_t1",
		BeginAttack = function( weapon, ply ) 
			weapon:DoAttackSound()
			ply:lscsSetTimedMove( 1, CurTime(), 0.1, Vector(0,-100,0) )
			ply:lscsSetTimedMove( 2, CurTime() + 0.2, 0.1, Vector(0,0,0) )
		end,
		FinishAttack = function( weapon, ply ) end,
		Delay = 0,
		Duration = 0.55,
		Rate = 1.1,
	},
    ["___D"] = {
		AttackAnim = "judge_h_right_t2",
        AttackAnimStart = 0.09, -- start from this cycle
		BeginAttack = function( weapon, ply )  
			weapon:DoAttackSound()
			ply:lscsSetTimedMove( 1, CurTime(), 0.2, Vector(0,100,0) )
			ply:lscsSetTimedMove( 2, CurTime() + 0.2, 0.1, Vector(0,0,0) )
		end,
		FinishAttack = function( weapon, ply ) end,
		Delay = 0.1,
		Duration = 1,
	},
	["W_S_"] = {
		AttackAnim = "b_c4_t2",
        AttackAnimStart = 0, -- start from this cycle
		BeginAttack = function( weapon, ply )  
			weapon:DoAttackSound()
			ply:lscsSetTimedMove( 1, CurTime(), 1, Vector(250,0,0) )
			ply:lscsSetTimedMove( 2, CurTime() + 0.7, 0.2, Vector(250,0,0) )
			ply:lscsSetTimedMove( 3, CurTime() + 0.9, 0.7, Vector(250,0,0) )

			timer.Simple(0.2, function()
				if not IsValid( weapon ) then return end
				weapon:DoAttackSound()
			end)
			timer.Simple(0.8, function()
				if not IsValid( weapon ) then return end
				weapon:DoAttackSound()
			end)
		end,
		FinishAttack = function( weapon, ply ) end,
		Delay = 0,
		Duration = 1,
	},
    ["W__D"] = {
		AttackAnim = "judge_h_s1_t2",
        AttackAnimStart = 0, -- start from this cycle
		BeginAttack = function( weapon, ply )  
			weapon:DoAttackSound()
			ply:lscsSetTimedMove( 1, CurTime(), 0.2, Vector(0,100,0) )
			ply:lscsSetTimedMove( 2, CurTime() + 0.2, 0.1, Vector(0,0,0) )
		end,
		FinishAttack = function( weapon, ply ) end,
		Delay = 0,
		Duration = 0.5,
		Rate = 1.6,
	},
    ["WA__"] = {
		AttackAnim = "wos_judge_h_s2_t1",
		AttackAnimStart = 0.2,
		BeginAttack = function( weapon, ply )  
			weapon:DoAttackSound()
			ply:lscsSetTimedMove( 1, CurTime(), 0.2, Vector(0,-100,0) )
			ply:lscsSetTimedMove( 2, CurTime() + 0.2, 0.1, Vector(0,0,0) )
		end,
		FinishAttack = function( weapon, ply ) end,
		Delay = 0,
		Duration = 0.5,
		Rate = 1.2,
	},
    ["-45-"] = {
		AttackAnim = "combo32",
        AttackAnimStart = 0.1, -- start from this cycle
		BeginAttack = function( weapon, ply )  
			weapon:DoAttackSound()
		end,
		FinishAttack = function( weapon, ply ) end,
		Delay = 0,
		Duration = 0.3,
		Rate = 1.1,
	},
	["+45+"] = {
		AttackAnim = "wos_judge_h_s3_t2",
		AttackAnimStart = 0.1, -- start from this cycle
		BeginAttack = function( weapon, ply ) 
			weapon:DoAttackSound()
			ply:lscsSetTimedMove( 1, CurTime(), 0.3, Vector(10,0,0) )
		end,
		FinishAttack = function( weapon, ply ) end,
		Delay = 0,
		Duration = 0.6,
		Rate = 1,
    },
    ["FRONT_DASH"] = {
        AttackAnim = "wos_judge_a_s1_t2",
        AttackAnimStart = 0, -- start from this cycle
        BeginAttack = function( weapon, ply )  
            weapon:DoAttackSound()
    
            timer.Simple(0.2, function()
                if not IsValid( weapon ) then return end
                weapon:DoAttackSound()
            end)
            timer.Simple(0.6, function()
                if not IsValid( weapon ) then return end
                weapon:DoAttackSound()
            end)
    
            if ply:OnGround() then
                ply:SetVelocity( Angle(0,ply:EyeAngles().y,0):Forward() * 1600 )
            else
                ply:SetVelocity( Angle(0,ply:EyeAngles().y,0):Forward() * 600 + Vector(0,0,40) )
            end
        end,
        FinishAttack = function( weapon, ply ) end,
        Delay = 0.1,
        Duration = 0.65,
		Rate = 1.1,
    },
    ["BACKFLIP"] = {
		AttackAnim = "rollback",
        AttackAnimStart = 0, -- start from this cycle
		BeginAttack = function( weapon, ply )  
			weapon:SetDMGActive( false )

			ply:SetVelocity( Vector(0,0,250) - Angle(0,ply:EyeAngles().y,0):Forward() * 100 )
			ply:lscsSuppressFalldamage( CurTime() + 5 )
		end,
		FinishAttack = function( weapon, ply ) end,
		Delay = 0,
		Duration = 0.5,
	},
    ["SLAM"] = {
		AttackAnim = "slashdown",
        AttackAnimStart = 0, -- start from this cycle
		BeginAttack = function( weapon, ply ) 
			weapon:DoAttackSound()
			ply:Freeze( true )
			ply:SetVelocity( Vector(0,0,200) )
			ply:lscsSuppressFalldamage( CurTime() + 5 )

			timer.Simple( 0.5, function()
				if IsValid( weapon ) and IsValid( ply ) then
					ply:SetVelocity( Vector(0,0,-1500) )
				end
			end)
		end,
		FinishAttack = function( weapon, ply )
			ply:Freeze( false )
		end,
		Delay = 0,
		Duration = 1.5,
	},
	["ROLL_RIGHT"] = {
		AttackAnim = "roll_right",
        AttackAnimStart = 0, -- start from this cycle
		BeginAttack = function( weapon, ply )  
			weapon:DoAttackSound()

			ply:SetVelocity( Vector(0,0,50) + Angle(0,ply:EyeAngles().y,0):Right() * 400 )
			ply:lscsSuppressFalldamage( CurTime() + 5 )
		end,
		FinishAttack = function( weapon, ply ) end,
		Delay = 0,
		Duration = 1,
	},
	["ROLL_LEFT"] = {
		AttackAnim = "roll_left",
		BeginAttack = function( weapon, ply )  
			weapon:DoAttackSound()

			ply:SetVelocity( Vector(0,0,50) - Angle(0,ply:EyeAngles().y,0):Right() * 400 )
			ply:lscsSuppressFalldamage( CurTime() + 5 )
		end,
		FinishAttack = function( weapon, ply ) end,
		Delay = 0,
		Duration = 1,
    },
}


--[[ -- list of valid COMBO.Attacks

	"____"			// standing still or fallback. Every saber style MUST HAVE THIS or the combo file will error.
	"SLAM"			// pressing attack after doing BACKFLIP
	"FRONT_DASH"		// when holding w + jump while in air and then pressing mouse1 (while still holding w + jump)
	"BACKFLIP"		// when holding s + jump while in air and then pressing mouse1 (while still holding s + jump)
	"ROLL_RIGHT"		// when holding d + jump while in air and then pressing mouse1 (while still holding d + jump)
	"ROLL_LEFT"		// when holding a + jump while in air and then pressing mouse1 (while still holding a + jump)
	"-45-"			// standing, looking up
	"+45+"			// standing, looking down
	"W_S_"			// while holding W + S
	"__S_"			// ect ect
	"_A__"			// ok ?
	"___D"
	"W__D"
	"WA__"
	"__SD"
	"_AS_"
	"W___"			// order always has to be W A S D

]]--

-- LSCS:Reload() -- calling LSCS:Reload() is actually not needed but it helps alot while working on a combo file. 
-- Its so you dont have to reload the map all the time. Once you are finished you should comment it out to avoid hundreds of files spamming refresh on the basescript. If this function is called twice or on gamestartup the basescript will actually refuse to reload. So PLEASE remove it when you release your stuff.