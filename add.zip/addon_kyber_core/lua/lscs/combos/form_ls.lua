COMBO.id = "formls" -- internal ID, lower case only
COMBO.PrintName = "Lightsaber Shield" -- what should be displayed in your hud
COMBO.Author = "Truce"
COMBO.Description = "Teaches to block." -- write an essay explaining what makes your saber style the best
COMBO.Icon = "" -- icon to be displayed in the hud

COMBO.DeflectBullets = false -- false, because this style can not deflect bullets. Set to true to enable
COMBO.AutoBlock = true -- false, because this style can only block when a perfect block is performed. Doesn't use stamina system. For any style that should not suck set to true
COMBO.BlockGun = true

COMBO.LeftSaberActive = true -- if this combo is selected, left saber is deactivated
COMBO.SaberStaffActive = false -- if this combo is selected, saber staff's second blade is deactivated, second blade is activated by default, so set to false to deactivate it

COMBO.Spawnable = false
COMBO.FormBlockPoints = 500 -- How much bonus or penalty blockpoints this saber stance should have. 20 is +20, -20 is -20.
-- COMBO.MaxBlockPoints = 500 -- use this to make op boss saber stances. Avoid using this. Only uncomment if you really need it.
--COMBO.BPDrainPerHit = 25 -- how much bp damage this saber stance should be doing. Avoid using this. Only uncomment if you really need it.

COMBO.BlockDistanceNormal = 70 -- distance of crosshair to block pos until a normal block is detected with this stance. Avoid using this. Only uncomment if you really need it.
COMBO.BlockDistancePerfect = 30 -- distance of crosshair to block pos until a perfect block is detected with this stance. Avoid using this. Only uncomment if you really need it.

COMBO.HoldType = "melee2"  -- just like any other weapon. If you have wos installed you can just use their holdtype editor to add custom holdtypes.

COMBO.Attacks = {}
COMBO.Attacks = {
    ["____"] = {
		AttackAnim = "range_melee2_b",
		BeginAttack = function( weapon, ply )  
			weapon:DoAttackSound()
		end,
		FinishAttack = function( weapon, ply ) end,
		Delay = 0.2,
		Duration = 0.3,
	},
}


--[[ -- list of valid COMBO.Attacks

	"____"			// standing still or fallback. Every saber style MUST HAVE THIS or the combo file will error.
	"SLAM"			// pressing attack after doing BACKFLIP
	"FRONT_DASH"		// when holding w + jump while in air and then pressing mouse1 (while still holding w + jump)
	"BACKFLIP"		// when holding s + jump while in air and then pressing mouse1 (while still holding s + jump)
	"ROLL_RIGHT"		// when holding d + jump while in air and then pressing mouse1 (while still holding d + jump)
	"ROLL_LEFT"		// when holding a + jump while in air and then pressing mouse1 (while still holding a + jump)
	"-45-"			// standing, looking up
	"+45+"			// standing, looking down
	"W_S_"			// while holding W + S
	"__S_"			// ect ect
	"_A__"			// ok ?
	"___D"
	"W__D"
	"WA__"
	"__SD"
	"_AS_"
	"W___"			// order always has to be W A S D

]]--

-- LSCS:Reload() -- calling LSCS:Reload() is actually not needed but it helps alot while working on a combo file. 
-- Its so you dont have to reload the map all the time. Once you are finished you should comment it out to avoid hundreds of files spamming refresh on the basescript. If this function is called twice or on gamestartup the basescript will actually refuse to reload. So PLEASE remove it when you release your stuff.