COMBO.id = "formjk" -- internal ID, lower case only
COMBO.PrintName = "Form: Jar'Kai" -- what should be displayed in your hud
COMBO.Author = "Truce"
COMBO.Description = "Jar'kai was the method of using 2 lightsaber during combat with the most common tactics to be heavily on the offensive.  MaxBlockPoints 70" -- write an essay explaining what makes your saber style the best
COMBO.Icon = "kybercore/jarkai.png" -- icon to be displayed in the hud

COMBO.DeflectBullets = true -- false, because this style can not deflect bullets. Set to true to enable
COMBO.AutoBlock = true -- false, because this style can only block when a perfect block is performed. Doesn't use stamina system. For any style that should not suck set to true

COMBO.LeftSaberActive = true -- if this combo is selected, left saber is deactivated
COMBO.SaberStaffActive = false


COMBO.MaxBlockPoints = 70 -- use this to make op boss saber stances. Avoid using this. Only uncomment if you really need it.
--COMBO.BPDrainPerHit = 30 -- how much bp damage this saber stance should be doing. Avoid using this. Only uncomment if you really need it.

--COMBO.BlockDistanceNormal = 60 -- distance of crosshair to block pos until  a normal block is detected with this stance. Avoid using this. Only uncomment if you really need it.
--COMBO.BlockDistancePerfect = 20 -- distance of crosshair to block pos until  a perfect block is detected with this stance. Avoid using this. Only uncomment if you really need it.

COMBO.HoldType = "wos-truce-formjk"  -- just like any other weapon. If you have wos installed you can just use their holdtype editor to add custom holdtypes.


COMBO.Attacks = {}
COMBO.Attacks = {
    ["____"] = {
		AttackAnim = "vanguard_r_s1_t2",
        AttackAnimStart = 0.1, 
		BeginAttack = function( weapon, ply )  
			weapon:DoAttackSound()
		end,
		FinishAttack = function( weapon, ply ) end,
		Delay = 0,
		Duration = 0.4,
		Rate = 1.5,
	},
	["W___"] = {
		AttackAnim = "wos_judge_r_s3_t2",
		AttackAnimStart = 0.1, -- start from this cycle
		BeginAttack = function( weapon, ply )  
			weapon:DoAttackSound()
			if ply:OnGround() then
				ply:SetVelocity( Angle(0,ply:EyeAngles().y,0):Forward() * 1000 )
			end
			ply:lscsSetTimedMove( 1, CurTime(), 0, Vector(0,0,0) )
		end,
		FinishAttack = function( weapon, ply ) end,
		Delay = 0,
		Duration = 0.8,
		Rate = 1,
	},
    ["_A__"] = {
		AttackAnim = "pure_h_left_t3",
		AttackAnimStart = 0.1, -- start from this cycle
		BeginAttack = function( weapon, ply )  
			ply:lscsSetTimedMove( 1, CurTime(), 0.7, Vector(0,-150,0) )
			ply:lscsSetTimedMove( 2, CurTime() + 0.7, 0.3, Vector(0,0,0) )
			ply:lscsSetTimedMove( 3, CurTime() + 1, 0.4, Vector(0,0,0) )

			timer.Simple(0.2, function()
				if not IsValid( weapon ) then return end
				weapon:DoAttackSound()
			end)
			timer.Simple(0.5, function()
				if not IsValid( weapon ) then return end
				weapon:DoAttackSound()
			end)
		end,
		FinishAttack = function( weapon, ply ) end,
		Delay = 0,
		Duration = 1.2,
		Rate = 1.3,
	},
    ["___D"] = {
		AttackAnim = "h_left_t3",
        AttackAnimStart = 0.3, -- start from this cycle
		BeginAttack = function( weapon, ply )  
			weapon:DoAttackSound()
			ply:lscsSetTimedMove( 1, CurTime(), 0.2, Vector(0,100,0) )
			ply:lscsSetTimedMove( 2, CurTime() + 0.2, 0.1, Vector(0,0,0) )
		end,
		FinishAttack = function( weapon, ply ) end,
		Delay = 0,
		Duration = 1,
		Rate = 1,
	},
	["W_S_"] = {
		AttackAnim = "flourish_bow_basic",
        AttackAnimStart = 0, -- start from this cycle
		BeginAttack = function( weapon, ply )  
			weapon:DoAttackSound()
			ply:lscsSetTimedMove( 1, CurTime(), 1, Vector(75,0,0) )
			ply:lscsSetTimedMove( 2, CurTime() + 0.7, 0.2, Vector(50,0,0) )
			ply:lscsSetTimedMove( 3, CurTime() + 0.9, 0.7, Vector(0,0,0) )

			timer.Simple(0.2, function()
				if not IsValid( weapon ) then return end
				weapon:DoAttackSound()
			end)
			timer.Simple(0.8, function()
				if not IsValid( weapon ) then return end
				weapon:DoAttackSound()
			end)
		end,
		FinishAttack = function( weapon, ply ) end,
		Delay = 0,
		Duration = 2,
	},
	["W__D"] = {
		AttackAnim = "pure_b_s2_t3",
		BeginAttack = function( weapon, ply )  
			ply:lscsSetTimedMove( 1, CurTime(), 0.7, Vector(150,150,0) )
			ply:lscsSetTimedMove( 2, CurTime() + 0.7, 0.3, Vector(80,80,0) )
			ply:lscsSetTimedMove( 3, CurTime() + 1, 0.4, Vector(0,0,0) )

			timer.Simple(0.2, function()
				if not IsValid( weapon ) then return end
				weapon:DoAttackSound()
			end)
			timer.Simple(0.9, function()
				if not IsValid( weapon ) then return end
				weapon:DoAttackSound()
			end)
		end,
		FinishAttack = function( weapon, ply ) end,
		Delay = 0,
		Duration = 1.25,
	},
    ["WA__"] = {
		AttackAnim = "vanguard_h_right_t3",
		BeginAttack = function( weapon, ply )  
			ply:lscsSetTimedMove( 1, CurTime(), 0.7, Vector(150,-150,0) )
			ply:lscsSetTimedMove( 2, CurTime() + 0.7, 0.3, Vector(80,-80,0) )
			ply:lscsSetTimedMove( 3, CurTime() + 1, 0.4, Vector(0,0,0) )

			timer.Simple(0.2, function()
				if not IsValid( weapon ) then return end
				weapon:DoAttackSound()
			end)
			timer.Simple(0.9, function()
				if not IsValid( weapon ) then return end
				weapon:DoAttackSound()
			end)
		end,
		FinishAttack = function( weapon, ply ) end,
		Delay = 0,
		Duration = 0.9,
	},
	["_AS_"] = {
		AttackAnim = "ryoku_a_left_t1",
        AttackAnimStart = 0, -- start from this cycle
		BeginAttack = function( weapon, ply )  
			weapon:DoAttackSound()

			ply:SetVelocity( Vector(0,0,50) + Angle(0,ply:EyeAngles().y,0):Right() * 150 )
			
		end,
		FinishAttack = function( weapon, ply ) end,
		Delay = 0,
		Duration = 1,
	},
	["__SD"] = {
	AttackAnim = "h_left_t3",
	AttackAnimStart = 0.3, -- start from this cycle
	BeginAttack = function( weapon, ply )  
		weapon:DoAttackSound()
		ply:lscsSetTimedMove( 1, CurTime(), 0.2, Vector(0,100,0) )
		ply:lscsSetTimedMove( 2, CurTime() + 0.2, 0.1, Vector(0,0,0) )
	end,
	FinishAttack = function( weapon, ply ) end,
	Delay = 0,
	Duration = 1,
	Rate = 1,
	},
    ["-45-"] = {
		AttackAnim = "vanguard_r_s1_t2",
        AttackAnimStart = 0.1, 
		BeginAttack = function( weapon, ply )  
			weapon:DoAttackSound()
		end,
		FinishAttack = function( weapon, ply ) end,
		Delay = 0,
		Duration = 0.5,
		Rate = 1.5,
	},
	["+45+"] = {
		AttackAnim = "ryoku_a_left_t1",
		AttackAnimStart = 0, -- start from this cycle
		BeginAttack = function( weapon, ply ) 
			weapon:DoAttackSound()
			ply:lscsSetTimedMove( 1, CurTime(), 0.3, Vector(10,0,0) )
		end,
		FinishAttack = function( weapon, ply ) end,
		Delay = 0,
		Duration = 0.6,
		Rate = 0.9,
    },
    ["FRONT_DASH"] = {
        AttackAnim = "ryoku_a_left_t1",
        AttackAnimStart = 0, -- start from this cycle
        BeginAttack = function( weapon, ply )  
            weapon:DoAttackSound()
    
            timer.Simple(0.2, function()
                if not IsValid( weapon ) then return end
                weapon:DoAttackSound()
            end)
            timer.Simple(0.6, function()
                if not IsValid( weapon ) then return end
                weapon:DoAttackSound()
            end)
    
            if ply:OnGround() then
                ply:SetVelocity( Angle(0,ply:EyeAngles().y,0):Forward() * 1600 )
            else
                ply:SetVelocity( Angle(0,ply:EyeAngles().y,0):Forward() * 600 + Vector(0,0,40) )
            end
        end,
        FinishAttack = function( weapon, ply ) end,
        Delay = 0,
        Duration = 0.7,
		Rate = 0.9,
    },
    ["BACKFLIP"] = {
		AttackAnim = "rollback",
        AttackAnimStart = 0, -- start from this cycle
		BeginAttack = function( weapon, ply )  
			weapon:SetDMGActive( false )

			ply:SetVelocity( Vector(0,0,250) - Angle(0,ply:EyeAngles().y,0):Forward() * 100 )
			ply:lscsSuppressFalldamage( CurTime() + 5 )
		end,
		FinishAttack = function( weapon, ply ) end,
		Delay = 0,
		Duration = 0.5,
	},
    ["SLAM"] = {
		AttackAnim = "slashdown",
        AttackAnimStart = 0, -- start from this cycle
		BeginAttack = function( weapon, ply ) 
			weapon:DoAttackSound()
			ply:Freeze( true )
			ply:SetVelocity( Vector(0,0,200) )
			ply:lscsSuppressFalldamage( CurTime() + 5 )

			timer.Simple( 0.5, function()
				if IsValid( weapon ) and IsValid( ply ) then
					ply:SetVelocity( Vector(0,0,-1500) )
				end
			end)
		end,
		FinishAttack = function( weapon, ply )
			ply:Freeze( false )
		end,
		Delay = 0,
		Duration = 1.5,
	},
	["ROLL_RIGHT"] = {
		AttackAnim = "ryoku_a_right_t1",
        AttackAnimStart = 0, -- start from this cycle
		BeginAttack = function( weapon, ply )  
			weapon:DoAttackSound()

			ply:SetVelocity( Vector(0,0,50) + Angle(0,ply:EyeAngles().y,0):Right() * 150 )
			ply:lscsSuppressFalldamage( CurTime() + 5 )
		end,
		FinishAttack = function( weapon, ply ) end,
		Delay = 0,
		Duration = 1,
	},
	["ROLL_LEFT"] = {
		AttackAnim = "ryoku_a_left_t1",
		BeginAttack = function( weapon, ply )  
			weapon:DoAttackSound()

			ply:SetVelocity( Vector(0,0,50) - Angle(0,ply:EyeAngles().y,0):Right() * 150 )
			ply:lscsSuppressFalldamage( CurTime() + 5 )
		end,
		FinishAttack = function( weapon, ply ) end,
		Delay = 0,
		Duration = 1,
    },
}


--[[ -- list of valid COMBO.Attacks

	"____"			// standing still or fallback. Every saber style MUST HAVE THIS or the combo file will error.
	"SLAM"			// pressing attack after doing BACKFLIP
	"FRONT_DASH"		// when holding w + jump while in air and then pressing mouse1 (while still holding w + jump)
	"BACKFLIP"		// when holding s + jump while in air and then pressing mouse1 (while still holding s + jump)
	"ROLL_RIGHT"		// when holding d + jump while in air and then pressing mouse1 (while still holding d + jump)
	"ROLL_LEFT"		// when holding a + jump while in air and then pressing mouse1 (while still holding a + jump)
	"-45-"			// standing, looking up
	"+45+"			// standing, looking down
	"W_S_"			// while holding W + S
	"__S_"			// ect ect
	"_A__"			// ok ?
	"___D"
	"W__D"
	"WA__"
	"__SD"
	"_AS_"
	"W___"			// order always has to be W A S D

]]--

-- LSCS:Reload() -- calling LSCS:Reload() is actually not needed but it helps alot while working on a combo file. 
-- Its so you dont have to reload the map all the time. Once you are finished you should comment it out to avoid hundreds of files spamming refresh on the basescript. If this function is called twice or on gamestartup the basescript will actually refuse to reload. So PLEASE remove it when you release your stuff.