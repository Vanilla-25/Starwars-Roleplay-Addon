
// ============================================================================== //
//                                                                                //
//                          		Force Telekenesis		               		  //
//                                                                                //
// ============================================================================== //

local possiblesounds = {
	"npc/combine_soldier/vo/engaging.wav",
	"npc/combine_soldier/vo/executingfullresponse.wav",
	"npc/combine_soldier/vo/fixsightlinesmovein.wav",
	"npc/combine_soldier/vo/onedutyvacated.wav",
	"npc/combine_soldier/vo/overwatchrequestreinforcement.wav",
	"npc/combine_soldier/vo/ovewatchorders3ccstimboost.wav",
	"npc/combine_soldier/vo/priority1objective.wav",
	"npc/combine_soldier/vo/prioritytwoescapee.wav",
	"npc/combine_soldier/vo/requestmedical.wav",
	"npc/combine_soldier/vo/requeststimdose.wav",
}
local function PhysCallback( ent, data )
	// find entities in a 10 unit radius
	local entities = ents.FindInSphere( ent:GetPos(), 17 )
	for k, v in pairs( entities ) do
		if v == ent then continue end
		if v.IsStonemanDroids then
			if v:Health() < 0 then continue end
			// Do damage equal to 100% of the player's health
			local d = DamageInfo()
			d:SetDamage( 75 )
			d:SetAttacker( ent )
			d:SetDamageType( DMG_DISSOLVE )
			v:TakeDamageInfo( d )
		end
	end

	if data.HitEntity:IsWorld() then
		// Can only scream once every 1 second
		if ent.StoneOSPower_Telekenesis_LastScream and ent.StoneOSPower_Telekenesis_LastScream > CurTime() then return end
		// Play sound
		local randomsound = possiblesounds[ math.random( 1, #possiblesounds ) ]
		ent:EmitSound( randomsound )
		// Set last scream time
		ent.StoneOSPower_Telekenesis_LastScream = CurTime() + 1

		if ent.WasStonemanDroid2 then
			if ent.ShouldExplodeImmediately then
				// Explode
				local effectdata = EffectData()
				effectdata:SetOrigin( ent:GetPos() )
				util.Effect( "Explosion", effectdata )
				ent:Remove()
			end
		end
	end
end

local force = {}
force.PrintName = "Force Telekenesis"
force.Author = "Stoneman"
force.Description = "Allows you to gain full control of a target and be able to manipulate the target in certain ways e.g. pick them up and throw them."
force.id = "telekenesis"
force.Icon = "kybercore/telekenesis.png"
force.OnClk = function( ply, TIME )
	if not ply.StoneOSPower_Telekenesis then return end
	if not ply:Alive() then return end
	if IsValid( ply.WindTarget ) then
		// Use 0.5 force per second
		ply:lscsTakeForce( 0.5 )
		// Make them fly up!
		local vec = ( ( ply:EyePos() + ply:GetAimVector()*ply.WindDistance  ) - ply.WindTarget:GetPos() )
		local vec2 = ( ( ply:EyePos() + ply:GetAimVector()*2*ply.WindDistance  ) - ply.WindTarget:GetPos() )

		if ply.WindTarget:IsPlayer() or ply.WindTarget:IsNPC() then
			ply.WindTarget:SetLocalVelocity( vec*10 )
		elseif ply.WindTarget.IsStonemanDroids then
			// Don't do anything if the droid has more than 500 health
			if ply.WindTarget:GetMaxHealth() > 500 then return end
			// Remove the nextbot, but put the ragdoll in its place
			local rag = ents.Create( "prop_ragdoll" )
			rag:SetModel( ply.WindTarget:GetModel() )
			rag:SetPos( ply.WindTarget:GetPos() )
			rag:SetAngles( ply.WindTarget:GetAngles() )
			rag:Spawn()
			rag.WasStonemanDroid = true
			ply.WindTarget:Remove()

			rag:AddCallback( "PhysicsCollide", PhysCallback )

			ply.WindTarget = rag
			ply.WindTarget:SetCollisionGroup( COLLISION_GROUP_WORLD )
			ply.WindTarget:SetMoveType( MOVETYPE_NONE )
		elseif ply.WindTarget:IsRagdoll() then
			local phys = ply.WindTarget:GetPhysicsObject()
			if not phys then return end
			phys:SetVelocity( vec*100 )
		else
			local phys = ply.WindTarget:GetPhysicsObject()
			if not phys then return end
			phys:SetVelocity( vec*10 )
		end
		return
	end

	local tr = util.TraceLine( util.GetPlayerTrace( ply ) )
	local dist = tr.HitPos:Distance( ply:GetPos() )
	if not tr.Entity then return end
	if dist >= 400 then return end
	ply.WindTarget = tr.Entity
	ply.WindDistance = dist

	// Make them fly up!
	local vec = ( ( ply:EyePos() + ply:GetAimVector()*ply.WindDistance  ) - ply.WindTarget:GetPos() )
	local vec2 = ( ( ply:EyePos() + ply:GetAimVector()*2*ply.WindDistance  ) - ply.WindTarget:GetPos() )

	if ply.WindTarget:IsPlayer() or ply.WindTarget:IsNPC() then
		ply.WindTarget:SetLocalVelocity( vec*10 )
	else
		local phys = ply.WindTarget:GetPhysicsObject()
		if phys:IsValid() then
			phys:SetVelocity( vec*10 )
		end
	end
end
force.StartUse = function( ply )
	// 1 second cooldown
	if ply.StoneOSPower_Telekenesis_LastUse and ply.StoneOSPower_Telekenesis_LastUse > CurTime() then return end
	ply.StoneOSPower_Telekenesis = true
end
force.StopUse = function ( ply )
	ply.StoneOSPower_Telekenesis = nil
	if not IsValid( ply.WindTarget ) then return end
	local vec2 = ( ( ply:EyePos() + ply:GetAimVector()*2*ply.WindDistance  ) - ply.WindTarget:GetPos() )

	
	ply.WindTarget:SetLocalVelocity( vec2*3 )

	if ply.WindTarget.WasStonemanDroid then
		local ragdoll = ply.WindTarget
		timer.Simple( 10, function()
			if IsValid( ragdoll ) then
				ragdoll:Remove()
			end
		end)
	end

	ply.StoneOSPower_Telekenesis_LastUse = CurTime() + 1
	
	local ed = EffectData()
	ed:SetOrigin( ply.WindTarget:GetPos() + Vector( 0, 0, 36 ) )
	ed:SetRadius( 128 )
	util.Effect( "rb655_force_repulse_out", ed, true, true )
	ply.WindTarget = nil
end
LSCS:RegisterForce( force )

// ============================================================================== //
//                                                                                //
//                          		Force Leap  			               		  //
//                                                                                //
// ============================================================================== //
local force = {}
force.PrintName = "Force Leap"
force.Author = "Truce and Stoneman"
force.Description = "Use the force to Leap up to areas which are out of range even those who are jumping."
force.id = "jump_3"
force.Icon = "entities/item_force_leap.png"
force.StartUse = function( ply )
	if ply:lscsGetForce() < 50 then return end -- do we have enough force points ?

	// 5 second cooldown
	local Time = CurTime()
	local CanDo = (ply.StoneOS_ForceJump_cooldown or 0) < Time
	if not CanDo then return end

	ply.StoneOS_ForceJump_cooldown = Time + 5

	if ply:IsOnGround() == true then
		ply:SetVelocity( ply:GetAimVector() * 1024 + Vector( 0, 0, 1024 ) )
		ply:EmitSound("npc/combine_gunship/ping_search.wav")
		ply:lscsTakeForce( 50 ) -- take amount of force we need
		ply.StoneOS_ForceJump_FallDMG = true
	end
end
LSCS:RegisterForce( force )

hook.Add("OnPlayerHitGround", "StoneOS_ForceJump_Falldamage", function( ply, inWater, onFloater, speed )
	if not ply.StoneOS_ForceJump_FallDMG then
		ply.StoneOS_ForceJump_FallDMG = false
	else
		ply.StoneOS_ForceJump_FallDMG = false
		return true
	end
end)


// ============================================================================== //
//                                                                                //
//                          		Force Speed 			               		  //
//                                                                                //
// ============================================================================== //
local force = {}
force.PrintName = "Force Speed"
force.Author = "Truce and Stoneman"
force.Description = "Use the force to enhance yourself to sprint at a faster rate than your peers for a short period of time. (+250 Speed)"
force.id = "speed"
force.Icon = "entities/item_force_speed.png"
force.StartUse = function( ply )
	
	if ply:lscsGetForce() < 5 then return end
	local Time = CurTime()

	local CanDo = (ply.KyberCorePower_Speed_Timer or 0) < Time

	if not CanDo then return end
	ply:lscsTakeForce( 50 ) -- take amount of force we need
	ply.KyberCorePower_Speed_Timer = Time + 10
	local available = ply:lscsGetForce()
	ply:EmitSound("npc/combine_gunship/ping_search.wav")

	local speed = ply:GetRunSpeed()
	ply:SetRunSpeed( speed + 250 )
	timer.Simple(5, function()
		ply:SetRunSpeed( speed )
	end)
end
LSCS:RegisterForce( force )

// ============================================================================== //
//                                                                                //
//                          		Diamond Storm			               		  //
//                                                                                //
// ============================================================================== //
local force = {}
force.PrintName = "Diamond Storm"
force.Author = "Stoneman"
force.Description = "It's just a force shotgun"
force.id = "diamondstorm"
force.Icon = "entities/item_force_diamondstorm.png"
force.StartUse = function( ply )
	local Time = CurTime()
	local CanDo = (ply.StoneOSPower_Diamonds_Storm_Timer or 0) < Time
	if not CanDo then return end
	ply.StoneOSPower_Diamonds_Storm_Timer = Time + 10
	ply:lscsTakeForce( 60 ) -- take amount of force we need

	local tr = util.TraceLine( util.GetPlayerTrace( ply ) )
	local pos = tr.HitPos
	local pi = math.pi
	local bullet = {}
	bullet.Num 		= 40
	bullet.Spread 	= Vector( 0.3, 0.3, 0 )
	bullet.Tracer	= 1
	bullet.Force	= 100						
	bullet.Damage	= 400
	bullet.AmmoType = "AR2"
	bullet.Entity = ply
	bullet.IgnoreEntity = ply
	bullet.TracerName = "wos_alcs_diamondbullet"
	bullet.Callback = function( attacker, tr, dmginfo )
		if tr.Hit then
			if tr.Entity:IsPlayer() or tr.Entity:IsNPC() or tr.Entity:IsNextBot() then
				dmginfo:SetDamageType( DMG_BLAST )
			end
		end
	end
	ply:EmitSound( "physics/glass/glass_sheet_break3.wav" )
	LSCS:PlayVCDSequence( ply, "pure_taunt_balanced", 0 )
	local time = 0.6
	local ed = EffectData()
	ed:SetEntity( ply )
	ed:SetScale( time )

	util.Effect( "wos_alcs_diamondstorm", ed, true, true )

	timer.Simple( 1, function()
		if not IsValid( ply ) then return end
		bullet.Src 		= ply:GetShootPos()
		bullet.Dir 		= ply:GetAimVector()
		ply:FireBullets( bullet )
		ply:EmitSound( "npc/manhack/mh_blade_snick1.wav" )
		for i=1, 6 do
			timer.Simple( 0.03*i, function()
				if not IsValid( ply ) then return end
				if not ply:Alive() then return end
				ply:EmitSound( "npc/manhack/mh_blade_snick1.wav" )
			end )
		end
	end )
end
LSCS:RegisterForce( force )

// ============================================================================== //
//                                                                                //
//                          		Force Stasis			               		  //
//                                                                                //
// ============================================================================== //
local force = {}
force.PrintName = "Force Stasis"
force.Author = "Stoneman"
force.Description = "Use the force to freeze your enemies in their track and immobilise them for a few seconds."
force.id = "stasis"
force.Icon = "kybercore/stasis.png"
force.OnClk = function( ply )
	if not ply.StoneOSPower_Stasis then return end
	local tr = util.TraceLine( util.GetPlayerTrace( ply ) )
	
	if tr.Hit then
		// If it's a player and is alive, make them not able to move.
		if tr.Entity:IsPlayer() and tr.Entity:Alive() or tr.Entity:IsNextBot() then
			if ply:lscsGetForce() < 1 then return end
			local edc = EffectData()
			edc:SetOrigin( tr.Entity:GetShootPos() )
			edc:SetEntity( ply )
			edc:SetStart( ply:GetShootPos() )
			util.Effect( "thor_thunder", edc, true, true )
			tr.Entity:Freeze(true)
			timer.Create( "Freeze Timer" .. tr.Entity:EntIndex(), 5, 1, function() 	 tr.Entity:Freeze(false) end )
			LSCS:PlayVCDSequence(ply, "wos_jedi_forceblast", 0.8)

			// Use 5 force!
			ply:lscsTakeForce( 50 )
		end
	end
end
force.StartUse = function( ply )
	ply.StoneOSPower_Stasis = true 
end
force.StopUse = function( ply )
	ply.StoneOSPower_Stasis = false
end
LSCS:RegisterForce( force )

// ============================================================================== //
//                                                                                //
//                          		Force Choke  			               		  //
//                                                                                //
// ============================================================================== //
local softChoke = {}
softChoke.PrintName = "Choke"
softChoke.Author = "Stoneman"
softChoke.Description = "An ability used to choke a target. While not as potent as Expert Choke, it can still be used for intimidation and immobilizing a target."
softChoke.id = "softchoke"
softChoke.Icon = "kybercore/soft_cho.png"

local possiblesounds = {
	"npc/combine_soldier/vo/engaging.wav",
	"npc/combine_soldier/vo/executingfullresponse.wav",
	"npc/combine_soldier/vo/fixsightlinesmovein.wav",
	"npc/combine_soldier/vo/onedutyvacated.wav",
	"npc/combine_soldier/vo/overwatchrequestreinforcement.wav",
	"npc/combine_soldier/vo/ovewatchorders3ccstimboost.wav",
	"npc/combine_soldier/vo/priority1objective.wav",
	"npc/combine_soldier/vo/prioritytwoescapee.wav",
	"npc/combine_soldier/vo/requestmedical.wav",
	"npc/combine_soldier/vo/requeststimdose.wav",
}

local function PhysCallback(ent, data)
	local entities = ents.FindInSphere(ent:GetPos(), 17)
	for k, v in pairs(entities) do
		if v == ent then continue end
		if v.IsStonemanDroids then
			if v:Health() < 0 then continue end
			local d = DamageInfo()
			d:SetDamage(75)
			d:SetAttacker(ent)
			d:SetDamageType(DMG_DISSOLVE)
			v:TakeDamageInfo(d)
		end
	end

	if data.HitEntity:IsWorld() then
		if ent.StoneOSPower_Telekenesis_LastScream and ent.StoneOSPower_Telekenesis_LastScream > CurTime() then return end
		local randomsound = possiblesounds[math.random(1, #possiblesounds)]
		ent:EmitSound(randomsound)
		ent.StoneOSPower_Telekenesis_LastScream = CurTime() + 1

		if ent.WasStonemanDroid2 then
			if ent.ShouldExplodeImmediately then
				local effectdata = EffectData()
				effectdata:SetOrigin(ent:GetPos())
				util.Effect("Explosion", effectdata)
				ent:Remove()
			end
		end
	end
end

local force = {}
force.PrintName = "Force Telekenesis"
force.Author = "Stoneman"
force.Description = "Allows you to gain full control of a target and be able to manipulate the target in certain ways e.g. pick them up and throw them."
force.id = "telekenesis"
force.Icon = "kybercore/telekenesis.png"

force.OnClk = function(ply, TIME)
	if not ply.StoneOSPower_Telekenesis then return end
	if not ply:Alive() then return end

	if IsValid(ply.WindTarget) then
		ply:lscsTakeForce(0.5)

		local vec = ((ply:EyePos() + ply:GetAimVector() * ply.WindDistance) - ply.WindTarget:GetPos())
		local vec2 = ((ply:EyePos() + ply:GetAimVector() * 2 * ply.WindDistance) - ply.WindTarget:GetPos())

		if ply.WindTarget:IsPlayer() or ply.WindTarget:IsNPC() then
			ply.WindTarget:SetLocalVelocity(vec * 10)
		elseif ply.WindTarget.IsStonemanDroids then
			if ply.WindTarget:GetMaxHealth() > 500 then return end

			local rag = ents.Create("prop_ragdoll")
			rag:SetModel(ply.WindTarget:GetModel())
			rag:SetPos(ply.WindTarget:GetPos())
			rag:SetAngles(ply.WindTarget:GetAngles())
			rag:Spawn()
			rag.WasStonemanDroid = true
			ply.WindTarget:Remove()

			rag:AddCallback("PhysicsCollide", PhysCallback)

			ply.WindTarget = rag
			ply.WindTarget:SetCollisionGroup(COLLISION_GROUP_WORLD)
			ply.WindTarget:SetMoveType(MOVETYPE_NONE)
		elseif ply.WindTarget:IsRagdoll() then
			local phys = ply.WindTarget:GetPhysicsObject()
			if not phys then return end
			phys:SetVelocity(vec * 100)
		else
			local phys = ply.WindTarget:GetPhysicsObject()
			if not phys then return end
			phys:SetVelocity(vec * 10)
		end
		return
	end

	local tr = util.TraceLine(util.GetPlayerTrace(ply))
	local dist = tr.HitPos:Distance(ply:GetPos())
	if not tr.Entity then return end
	if dist >= 1000 then return end
	ply.WindTarget = tr.Entity
	ply.WindDistance = dist

	local vec = ((ply:EyePos() + ply:GetAimVector() * ply.WindDistance) - ply.WindTarget:GetPos())
	local vec2 = ((ply:EyePos() + ply:GetAimVector() * 2 * ply.WindDistance) - ply.WindTarget:GetPos())

	if ply.WindTarget:IsPlayer() or ply.WindTarget:IsNPC() then
		ply.WindTarget:SetLocalVelocity(vec * 10)
	else
		local phys = ply.WindTarget:GetPhysicsObject()
		if phys:IsValid() then
			phys:SetVelocity(vec * 10)
		end
	end

	-- Play casting animation when grabbing begins
	if SERVER then
		ply:lscsSetGesture(ACT_IDLE_MAGIC)
	end
end

force.StartUse = function(ply)
	if ply.StoneOSPower_Telekenesis_LastUse and ply.StoneOSPower_Telekenesis_LastUse > CurTime() then return end
	ply.StoneOSPower_Telekenesis = true
end

force.StopUse = function(ply)
	ply.StoneOSPower_Telekenesis = nil

	-- Stop animation when releasing
	if SERVER then
		ply:lscsSetGesture(ACT_RESET)
	end

	if not IsValid(ply.WindTarget) then return end
	local vec2 = ((ply:EyePos() + ply:GetAimVector() * 2 * ply.WindDistance) - ply.WindTarget:GetPos())

	ply.WindTarget:SetLocalVelocity(vec2 * 3)

	if ply.WindTarget.WasStonemanDroid then
		local ragdoll = ply.WindTarget
		timer.Simple(10, function()
			if IsValid(ragdoll) then
				ragdoll:Remove()
			end
		end)
	end

	ply.StoneOSPower_Telekenesis_LastUse = CurTime() + 1

	local ed = EffectData()
	ed:SetOrigin(ply.WindTarget:GetPos() + Vector(0, 0, 36))
	ed:SetRadius(128)
	util.Effect("rb655_force_repulse_out", ed, true, true)

	ply.WindTarget = nil
end

LSCS:RegisterForce(force)

// ============================================================================== //
//                                                                                //
//                          		Expert Choke  			               		  //
//                                                                                //
// ============================================================================== //
local forceChoke = {}
forceChoke.PrintName = "Expert Choke"
forceChoke.Author = "Stoneman"
forceChoke.Description = "An ability used to choke a target. Causes a large amount of damage over a short period of time."
forceChoke.id = "choke"
forceChoke.Icon = "kybercore/choke.png"

forceChoke.StartUse = function(ply)
    ply.StoneOSPower_ForceChoke = true

    if IsValid(ply.StoneOSForce_ChokeTarget) then return end

    local tr = util.TraceLine(util.GetPlayerTrace(ply))
    if not IsValid(tr.Entity) then return end
    if not tr.Entity:IsPlayer() and not tr.Entity:IsNPC() then return end
    if ply:GetPos():Distance(tr.Entity:GetPos()) >= 400 then return end
    if tr.Entity.IsStonemanDroids then return end

    ply.StoneOSForce_ChokeTarget = tr.Entity
    ply.StoneOSForce_ChokeTarget:EmitSound("kybercore/jinx.wav")
    ply.StoneOSForce_ChokePos = tr.Entity:GetPos()

    LSCS:PlayVCDSequence(ply.StoneOSForce_ChokeTarget, "wos_force_choke", 0)
    timer.Create("ForceChokeTimers" .. ply.StoneOSForce_ChokeTarget:EntIndex(), 1.6, 0, function()
        if IsValid(ply.StoneOSForce_ChokeTarget) then
            LSCS:PlayVCDSequence(ply.StoneOSForce_ChokeTarget, "wos_force_choke", 0)
        end
    end)
end

forceChoke.StopUse = function(ply)
    if IsValid(ply.StoneOSForce_ChokeTarget) then
        timer.Remove("ForceChokeTimers" .. ply.StoneOSForce_ChokeTarget:EntIndex())
        LSCS:PlayVCDSequence(ply.StoneOSForce_ChokeTarget, "wos_force_choke", 1.6)
    end
    ply.StoneOSForce_ChokeTarget = nil
    ply.StoneOSForce_ChokePos = nil
    ply.StoneOSPower_ForceChoke = false
end

forceChoke.OnClk = function(ply)
    if not IsValid(ply.StoneOSForce_ChokeTarget) then return end
    if ply:lscsGetForce() < 1 then return end
    if not ply.StoneOSForce_ChokeTarget:Alive() then
        ply.StoneOSForce_ChokeTarget = nil
        ply.StoneOSForce_ChokePos = nil
        ply.StoneOSPower_ForceChoke = false
        return
    end

    local dmg = DamageInfo()
    dmg:SetDamage(10) -- Set higher damage for Force Choke
    dmg:SetDamageType(DMG_CRUSH)
    dmg:SetAttacker(ply)
    dmg:SetInflictor(ply)
    ply.StoneOSForce_ChokeTarget:TakeDamageInfo(dmg)
    ply.StoneOSForce_ChokeTarget:SetLocalVelocity((ply.StoneOSForce_ChokePos - ply.StoneOSForce_ChokeTarget:GetPos() + Vector(0, 0, 55)) * 5)

    ply.StoneOSForce_ChokeTarget:SetNW2Float("wOS.ChokeTime", CurTime() + 0.5)
    ply.StoneOSForce_ChokeTarget:SetNW2Float("wOS.SaberAttackDelay", CurTime() + 0.5)

    LSCS:PlayVCDSequence(ply, "wos_cast_choke", 0)
    ply:SetNW2Float("wOS.ForceAnim", CurTime() + 0.1)
    ply:lscsTakeForce(0.75)

    if not ply.StoneOSForce_SoundChoking then
        ply.StoneOSForce_SoundChoking = CreateSound(ply, "kybercore/jinx.wav")
        ply.StoneOSForce_SoundChoking:PlayEx(0.25, 100)
    else
        ply.StoneOSForce_SoundChoking:PlayEx(0.25, 100)
    end

    timer.Create("ForceChokeSound" .. ply:SteamID64(), 0.2, 1, function()
        if ply.StoneOSForce_SoundChoking then
            ply.StoneOSForce_SoundChoking:Stop()
            ply.StoneOSForce_SoundChoking = nil
        end
    end)

    if not ply.StoneOSForce_SoundGagging then
        if IsValid(ply.StoneOSForce_ChokeTarget) then
            ply.StoneOSForce_SoundGagging = CreateSound(ply.StoneOSForce_ChokeTarget, "kybercore/jinx.wav")
            ply.StoneOSForce_SoundGagging:Play()
        end
    else
        if IsValid(ply.StoneOSForce_ChokeTarget) then
            ply.StoneOSForce_SoundGagging:Play()
        end
    end

    timer.Create("ForceChokeGagging" .. ply:SteamID64(), 0.2, 1, function()
        if ply.StoneOSForce_SoundGagging then
            ply.StoneOSForce_SoundGagging:Stop()
            ply.StoneOSForce_SoundGagging = nil
        end
    end)

    if ply:lscsGetForce() < 1 then
        ply.StoneOSForce_ChokeTarget = nil
    end
end

LSCS:RegisterForce(forceChoke)

// ============================================================================== //
//                                                                                //
//                          		Force Slow  			               		  //
//                                                                                //
// ============================================================================== //
local force = {}
force.PrintName = "Force Slow"
force.Author = "Stoneman"
force.Description = "Using the force cloud some of the target's senses and slow them down making them easier to hit."
force.id = "slow"
force.Icon = "kybercore/slow.png"
force.StartUse = function( ply )
	local Time = CurTime()

	local CanDo = (ply._lscsNextForce or 0) < Time

	if not CanDo then return end

	ply._lscsNextForce = Time + 3

	
	local tr = util.TraceHull({
		start = ply:GetShootPos(),
		endpos = ply:GetShootPos() + ply:GetAimVector() * 10000,
		mins = Vector(-10, -10, -10),
		maxs = Vector(10, 10, 10),
		filter = ply
	})
	local ent = tr.Entity
	--local dmg = DamageInfo()
	
	if !IsValid( ent ) then return end
	if ply:lscsGetForce() < 10 then return end
	ply:lscsTakeForce( 10 )
	
	local ed = EffectData()
	ed:SetOrigin( ply:GetShootPos() )
	ed:SetEntity( ent )
	util.Effect( "wos_emerald_lightning", ed, true, true )

	// Slow them down to a crawl.
	// Get their current speeds.
	local walkSpeed = ent:GetWalkSpeed()
	local runSpeed = ent:GetRunSpeed()
	local crouchSpeed = ent:GetCrouchedWalkSpeed()

	if ent.StoneOSForce_GotSlowed then return end

	// Slow them to like 10.
	ent:SetWalkSpeed( 60 )
	ent:SetRunSpeed( 60 )
	ent:SetCrouchedWalkSpeed( 60 )

	ent.StoneOSForce_GotSlowed = true

	// After 5 seconds, reset their speeds.
	timer.Simple( 5, function()
		if !IsValid( ent ) then return end
		ent:SetWalkSpeed( walkSpeed )
		ent:SetRunSpeed( runSpeed )
		ent:SetCrouchedWalkSpeed( crouchSpeed )
		ent.StoneOSForce_GotSlowed = false
	end )
	
	ply:EmitSound( Sound( "npc/strider/fire.wav" ) )
	if ( !ply.SoundLightning ) then
		ply.SoundLightning = CreateSound( ply, "lightsaber/force_lightning" .. math.random( 1, 2 ) .. ".wav" )
		ply.SoundLightning:Play()
	else
		ply.SoundLightning:Play()
	end

	timer.Create( "test" .. ply:EntIndex(), 0.2, 1, function() if ( ply.SoundLightning ) then ply.SoundLightning:Stop() ply.SoundLightning = nil end end )
	LSCS:PlayVCDSequence( ply, "wos_cast_lightning_armed", 0 )
end
LSCS:RegisterForce( force )


// ============================================================================== //
//                                                                                //
//                          		Burn Out    			               		  //
//                                                                                //
// ============================================================================== //
local force = {}
force.PrintName = "Burn Out"
force.Author = "Stoneman"
force.Description = "Use the force to exert a small torrent of flames from your palm burning those that come into touch."
force.id = "burnout"
force.Icon = "kybercore/burnout.png"
force.OnClk = function( ply )
	if not ply.StoneOSForce_BurnOut then return end
	if ply:lscsGetForce() < 1 then return end
	if not ply:OnGround() then return end
	if not ply:Alive() then ply.StoneOSForce_BurnOut = false return end

	local tr = util.TraceLine( util.GetPlayerTrace( ply ) )
	if tr.Entity then
		if tr.Entity:IsPlayer() or tr.Entity:IsNPC() or tr.Entity.IsStonemanDroids then
			if ply:GetPos():DistToSqr( tr.Entity:GetPos() ) < 75000 then 
				local dmg = DamageInfo()
				dmg:SetAttacker( ply )
				dmg:SetInflictor( ply )
				dmg:SetDamage( 10 )
				dmg:SetDamageType( DMG_BURN )
				tr.Entity:TakeDamageInfo( dmg )
				tr.Entity:Ignite( 8 )
			end
		end
	end
	local ed = EffectData()
	ed:SetEntity( ply )
	ed:SetAngles( ply:GetAimVector():Angle() )
	ed:SetMagnitude( 3 )
	util.Effect( "wos_alcs_fireflood", ed, true, true )
	LSCS:PlayVCDSequence( ply, "wos_cast_lightning_armed", 0 )
	ply:lscsTakeForce( 3 )
	if ( !ply.SoundLightning ) then
		ply.SoundLightning = CreateSound( ply, "ambient/fire/fire_med_loop1.wav" )
		ply.SoundLightning:Play()
	else
		ply.SoundLightning:Play()
	end
	timer.Create( "test" .. ply:EntIndex(), 0.2, 1, function() if ( ply.SoundLightning ) then ply.SoundLightning:Stop() ply.SoundLightning = nil end end )
end
force.StartUse = function( ply )
	ply.StoneOSForce_BurnOut = true
end
force.StopUse = function( ply )
	ply.StoneOSForce_BurnOut = false
end
LSCS:RegisterForce( force )


// ============================================================================== //
//                                                                                //
//                          		Force Pulse 			               		  //
//                                                                                //
// ============================================================================== //
local force = {}
force.PrintName = "Force Pulse"
force.Author = "Stoneman"
force.Description = "Unleash a destructive stream of force energy across the ground harming those that come into contact with it."
force.id = "pulse"
force.Icon = "kybercore/pulse.png"
force.StartUse = function( ply )
	local Time = CurTime()

	local CanDo = (ply.StoneOSPower_PulseCooldown or 0) < Time
	
	if not CanDo then return end
	ply.StoneOSPower_PulseCooldown = Time + 15

	if ply:lscsGetForce() < 100 then return end
	ply:lscsTakeForce( 100 )

	local maxdist = 254 * 4

	local ed = EffectData()
	ed:SetOrigin( ply:GetPos() + Vector( 0, 0, 36 ) )
	ed:SetRadius( maxdist )
	util.Effect( "rb655_force_repulse_out", ed, true, true )
	for i, e in pairs( ents.FindInSphere( ply:GetPos(), maxdist ) ) do
		if e:IsNPC() or e:IsNextBot() then

			local dist = ply:GetPos():Distance( e:GetPos() )
			local mul = ( maxdist - dist ) / 206

			local v = ( ply:GetPos() - e:GetPos() ):GetNormalized()
			v.z = 0

			local dmg = DamageInfo()
			dmg:SetDamagePosition( e:GetPos() + e:OBBCenter() )
			dmg:SetDamage( 100 * mul )
			dmg:SetDamageType( DMG_DISSOLVE )
			dmg:SetDamageForce( -v * math.min( mul * 40000, 80000 ) )
			dmg:SetInflictor( ply )
			dmg:SetAttacker( ply )
			e:TakeDamageInfo( dmg )

			if ( e:IsOnGround() ) then
				e:SetVelocity( v * mul * -1024 + Vector( 0, 0, 64 ) )
			elseif ( !e:IsOnGround() ) then
				e:SetVelocity( v * mul * -512 + Vector( 0, 0, 64 ) )
			end
		end
	end

	if ( !ply.SoundLightning ) then
		ply.SoundLightning = CreateSound( ply, "lightsaber/force_lightning" .. math.random( 1, 2 ) .. ".wav" )
		ply.SoundLightning:Play()
		ply.SoundLightning:ChangeVolume(0,0.3)
	else
		ply.SoundLightning:Play()
	end
	timer.Create( "test", 0.6, 1, function() if ( ply.SoundLightning ) then ply.SoundLightning:Stop() ply.SoundLightning = nil end end )

	ply:EmitSound( "lightsaber/force_repulse.wav" )
	
end
LSCS:RegisterForce( force )


// ============================================================================== //
//                                                                                //
//                          		Force Repair			               		  //
//                                                                                //
// ============================================================================== //
local force = {}
force.PrintName = "Force Repair"
force.Author = "Stoneman/Truce"
force.Description = "Use the force to mend and repair your vehicle."
force.id = "repair"
force.Icon = "kybercore/repair.png"
force.OnClk = function(ply)
	local Time = CurTime()

	local CanDo = (ply.StoneOSPower_ForceFreezeCooldown or 0) < Time

	if not CanDo then return end

	if not ply.StoneOSPower_Repair then return end
	// Finds an lfs vehicle infront of you!
	local tr = util.TraceLine( {
		start = ply:GetShootPos(),
		endpos = ply:GetShootPos() + ply:GetAimVector() * 250,
		filter = ply
	} )

	
	if not tr.Entity:IsValid() then return end
	if not tr.Entity.LVS then return end

    if tr.Entity:GetHP() >= tr.Entity:GetMaxHP() then
        -- The vehicle is already at maximum HP, no need to repair further
        return
    end

	// Take 5 force
	if ply:lscsGetForce() < 25 then return end
	ply:lscsTakeForce( 25 )
	
	// Heal the vehicle
	tr.Entity:SetHP( tr.Entity:GetHP() + 300 )

	// If the HP goes over the max, set it to the max
	if tr.Entity:GetHP() > tr.Entity:GetMaxHP() then
		tr.Entity:SetHP( tr.Entity:GetMaxHP() )
	end
	local effectData = EffectData()
    effectData:SetOrigin(tr.Entity:GetPos())  -- Position of the repaired vehicle
    effectData:SetEntity(tr.Entity)  -- The repaired vehicle entity
    util.Effect("repair", effectData, true, true)
	LSCS:PlayVCDSequence( ply, "range_slam", 0 )
	ply.StoneOSPower_ForceFreezeCooldown = Time + 1

	// Play repair sound
	tr.Entity:EmitSound( "weapons/crowbar/crowbar_impact2.wav", 55,100,1 )
end
force.StartUse = function( ply )
	ply.StoneOSPower_Repair = true
end
force.StopUse = function( ply )
	ply.StoneOSPower_Repair = false
end
LSCS:RegisterForce( force )


// ============================================================================== //
//                                                                                //
//                          		Force Vault 			               		  //
//                                                                                //
// ============================================================================== //
local force = {}
force.PrintName = "Force Vault"
force.Author = "Truce and Stoneman"
force.Description = "OLD FORCE JUMP PORT"
force.id = "jump_1"
force.Icon = "entities/item_force_jump.png"
force.StartUse = function( ply )
	if ply:lscsGetForce() < 10 then return end -- do we have enough force points ?

	// 5 second cooldown
	local Time = CurTime()
	local CanDo = (ply.StoneOS_ForceJump_cooldown or 0) < Time
	if not CanDo then return end

	ply.StoneOS_ForceJump_cooldown = Time + 2

	if ply:IsOnGround() == true then
		ply:SetVelocity( ply:GetAimVector() * 206 + Vector( 0, 0, 206 ) )

		ply:lscsTakeForce( 10 ) -- take amount of force we need
		LSCS:PlayVCDSequence( ply, "balanced_jump", 0 ) -- play animation
		// No fall damage!
		ply.StoneOS_ForceJump_FallDMG = true
	end
end
LSCS:RegisterForce( force )


// ============================================================================== //
//                                                                                //
//                          		Force Jump  			               		  //
//                                                                                //
// ============================================================================== //
local force = {}
force.PrintName = "Force Jump"
force.Author = "Truce and Stoneman"
force.Description = "Use the force to Jump up to areas which are normally out of range."
force.id = "jump_2"
force.Icon = "entities/item_force_jump.png"
force.StartUse = function( ply )
	if ply:lscsGetForce() < 10 then return end -- do we have enough force points ?
	
	// 5 second cooldown
	local Time = CurTime()
	local CanDo = (ply.StoneOS_ForceJump_cooldown or 0) < Time
	if not CanDo then return end
	
	ply.StoneOS_ForceJump_cooldown = Time + 1

	if ply:IsOnGround() == true then
		ply:SetVelocity( ply:GetAimVector() * 512 + Vector( 0, 0, 512 ) )
		ply:EmitSound("npc/combine_gunship/ping_search.wav")
		ply:lscsTakeForce( 10 ) -- take amount of force we need
		// No fall damage!
		ply.StoneOS_ForceJump_FallDMG = true
	end
end
LSCS:RegisterForce( force )


// ============================================================================== //
//                                                                                //
//                          		Force Repulse			               		  //
//                                                                                //
// ============================================================================== //
local function StopRepulse(ply)
	if not ply.StoneOSPower_Repulse then return end
	local ed = EffectData()
	ed:SetOrigin(ply:GetPos() + Vector(0, 0, 36))
	ed:SetRadius(200 * ply.StoneOSPower_RepulseTime)
	util.Effect("rb655_force_repulse_in", ed, true, true)

	ply:EmitSound("lightsaber/force_repulse.wav")

	local maxdist = 200 * ply.StoneOSPower_RepulseTime

	for k, v in pairs(ents.FindInSphere(ply:GetPos(), maxdist)) do
		if v == ply then continue end
		if v:IsPlayer() and v:Alive() or v:IsNPC() or v:IsNextBot() then
			local dist = v:GetPos():Distance(ply:GetPos())
			local mul = (maxdist - dist) / 206
			local vel = (ply:GetPos() - v:GetPos()):GetNormalized()

			local dmg = DamageInfo()
			dmg:SetDamagePosition(v:GetPos() + v:OBBCenter())
			dmg:SetDamage(10 * mul)
			dmg:SetDamageType(DMG_GENERIC)
			dmg:SetDamageForce(-vel * math.min(mul * 40000, 80000))
			dmg:SetInflictor(ply)
			dmg:SetAttacker(ply)
			v:TakeDamageInfo(dmg)

			vel.z = 0
			v:SetVelocity(vel * mul * -2048 + Vector(0, 0, 64))
		end
	end

	ply.StoneOSPower_NextRepulse = CurTime() + 2
end

local force = {}
force.PrintName = "Force Repulse"
force.Author = "Stoneman"
force.Description = "Draw upon the surrounding force to send out a concussive force blast from the user. The longer you hold the charge the more damage it can do."
force.id = "repulse"
force.Icon = "kybercore/repulse.png"

force.OnClk = function(ply)
	if not ply.StoneOSPower_Repulse then return end
	ply.StoneOSPower_RepulseTime = ply.StoneOSPower_RepulseTime + 0.150
	if ply:lscsGetForce() < 5 then
		StopRepulse(ply)
		ply.StoneOSPower_Repulse = false
		return
	end
	ply:lscsTakeForce(5)
end

force.StartUse = function(ply)
	if ply:lscsGetForce() < 5 then return end
	if ply.StoneOSPower_RepulseCooldown and ply.StoneOSPower_RepulseCooldown > CurTime() then return end

	ply.StoneOSPower_Repulse = true
	ply.StoneOSPower_RepulseTime = 1
end

force.StopUse = function(ply)
	if ply.StoneOSPower_Repulse then
		StopRepulse(ply)
		ply.StoneOSPower_Repulse = false
		ply.StoneOSPower_RepulseCooldown = CurTime() + 10 -- 10s cooldown
	end
end

LSCS:RegisterForce(force)


// ============================================================================== //
//                                                                                //
//                          		Self Heal   			               		  //
//                                                                                //
// ============================================================================== //
local force = {}
force.PrintName = "Self Heal"
force.Author = "Stoneman"
force.Description = "Using the force to slowly heal oneself. While not as fast as Force Heal can be useful in a pinch."
force.id = "selfheal"
force.Icon = "kybercore/self_heal.png"
force.StartUse = function( ply )
	if ply:lscsGetForce() < 5 then return end
	ply.StoneOSPower_SelfHeal = true
end
force.OnClk = function( ply )
	if not ply.StoneOSPower_SelfHeal then return end
	if ply:lscsGetForce() < 5 then ply.StoneOSPower_SelfHeal = false return end -- do we have enough force points ?
	if ply:Health() >= ply:GetMaxHealth() then ply.StoneOSPower_SelfHeal = false return end
	if not ply:Alive() then ply.StoneOSPower_SelfHeal = false return end
	local effectdata = EffectData()
	effectdata:SetOrigin( ply:GetPos() )
	effectdata:SetEntity( ply )
	util.Effect( "force_heal", effectdata, true, true )
	ply:SetHealth(math.Clamp( ply:Health() + 10, 0, ply:GetMaxHealth()))

	ply:lscsTakeForce( 5 ) -- take amount of force we need
end
force.StopUse = function( ply )
	ply.StoneOSPower_SelfHeal = false
end
LSCS:RegisterForce( force )


// ============================================================================== //
//                                                                                //
//                          		Force Blink			              	 		  //
//                                                                                //
// ============================================================================== //
local force = {}
force.PrintName = "Force Blink"
force.Author = "Stoneman and Truce"
force.Description = "Use the force to teleport yourself to different locations of the users choice."
force.id = "blink"
force.Icon = "kybercore/teleport.png"
force.OnClk = function( ply )
	if ply:lscsGetForce() < 100 then return end
	
	if not ply.KyberCorePower_Blink then return end
	local Time = CurTime()
    local CanDo = (ply.KyberCorePower_BlinkCooldown or 0) < Time
	if not CanDo then return end

	ply.KyberCorePower_BlinkCooldown = Time + 10

	if ply:lscsGetForce() < 100 then return end
	if not ply.KyberCorePower_Blink then return end
	local bFoundEdge = false
	ply:SetNW2Float( "wOS.ShowBlink", CurTime() + 1 )
	local hullTrace = util.TraceHull({
		start = ply:EyePos(),
		endpos = ply:EyePos() + ply:EyeAngles():Forward() * 2400,
		filter = ply,
		mins = Vector(-16, -16, 0),
		maxs = Vector(16, 16, 9)
	})

	local groundTrace = util.TraceHull({
		start = hullTrace.HitPos + Vector(0, 0, 1),
		endpos = hullTrace.HitPos - Vector(0, 0, 1000),
		filter = ply,
		mins = Vector(-16, -16, 0),
		maxs = Vector(16, 16, 1)
	})

	local edgeTrace

	if (hullTrace.Hit and hullTrace.HitNormal.z <= 0) then
		local ledgeForward = Angle(0, hullTrace.HitNormal:Angle().y, 0):Forward();
		edgeTrace = util.TraceEntity({
			start = hullTrace.HitPos - ledgeForward * 33 + Vector(0, 0, 40),
			endpos = hullTrace.HitPos - ledgeForward * 33,
			filter = ply
		}, ply)

		if (edgeTrace.Hit and !edgeTrace.AllSolid) then
			local clearTrace = util.TraceHull({
				start = hullTrace.HitPos,
				endpos = hullTrace.HitPos + Vector(0, 0, 35),
				mins = Vector(-16, -16, 0),
				maxs = Vector(16, 16, 1),
				filter = ply
			})

			bFoundEdge = !clearTrace.Hit
		end
	end

	ply.KyberCorePower_BlinkReady = true
end
force.StartUse = function( ply )
	ply.KyberCorePower_Blink = true 
end
force.StopUse = function( ply )
	ply.KyberCorePower_Blink = false
	local speed = 4000
	local bFoundEdge = false

	ply:SetNW2Float("wOS.ShowBlink", 0 )

	local hullTrace = util.TraceHull({
		start = ply:EyePos(),
		endpos = ply:EyePos() + ply:EyeAngles():Forward() * 2400,
		filter = ply,
		mins = Vector(-16, -16, 0),
		maxs = Vector(16, 16, 9)
	})

	local groundTrace = util.TraceEntity({
		start = hullTrace.HitPos + Vector(0, 0, 1),
		endpos = hullTrace.HitPos - (ply:EyePos() - ply:GetPos()),
		filter = ply
	}, ply)

	local edgeTrace

	if (hullTrace.Hit and hullTrace.HitNormal.z <= 0) then
		local ledgeForward = Angle(0, hullTrace.HitNormal:Angle().y, 0):Forward()
		edgeTrace = util.TraceEntity({
			start = hullTrace.HitPos - ledgeForward * 33 + Vector(0, 0, 40),
			endpos = hullTrace.HitPos - ledgeForward * 33,
			filter = ply
		}, ply)

		if (edgeTrace.Hit and !edgeTrace.AllSolid) then
			local clearTrace = util.TraceHull({
				start = hullTrace.HitPos,
				endpos = hullTrace.HitPos + Vector(0, 0, 35),
				mins = Vector(-16, -16, 0),
				maxs = Vector(16, 16, 1),
				filter = ply
			})

			bFoundEdge = !clearTrace.Hit
		end
	end

	if (!bFoundEdge and groundTrace.AllSolid) then
		ply.groundTrace = nil		
		return
	end

	local endPos = ( bFoundEdge and edgeTrace.HitPos ) or groundTrace.HitPos

	if ply.KyberCorePower_BlinkReady then
		ply:SetPos( endPos )
		ply.KyberCorePower_BlinkReady = false
		ply:EmitSound("blink/exit" .. math.random(1, 2) .. ".wav")
		ply:lscsTakeForce( 100 )
	end

	timer.Simple(0.05, function()
		if !ply:IsOnGround() then
			ply.KyberCore_ForceJump_FallDMG = true
		end
	end)

	ply.groundTrace = nil
end
LSCS:RegisterForce( force )