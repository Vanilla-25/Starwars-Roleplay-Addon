// ============================================================================== //
//                                                                                //
//                          		Force Die               				      //
//                                                                                //
// ============================================================================== //

local force = {}
force.PrintName = "Force Die"
force.Author = "Truce and Stoneman"
force.Description = "Literally die"
force.id = "die"
force.Icon = "icon16/heart_delete.png"
force.StartUse = function( ply )
	LSCS:PlayVCDSequence( ply, "wos_force_crush", 0 )

	timer.Simple( 2.75, function()
		ply:EmitSound( "wos/reverb_fart.wav" )
	end)
	
	timer.Simple( 3, function()
        local effectData = EffectData()
        effectData:SetOrigin(ply:GetPos())
        util.Effect("BloodImpact", effectData)

		local numProps = 20
		local spawnRadius = 150
	
		for i = 1, numProps do
			// Random position, in all directions, x y z.
			local gibPos = ply:GetPos() + Vector(0, 0, 50)
			local randAng = Angle(math.random(-180, 180), math.random(-180, 180), 0)
	
			local props = ents.Create("prop_physics")
			if IsValid(props) then
				props:SetModel("models/gibs/antlion_gib_small_2.mdl")
				props:SetPos(gibPos)
				props:SetAngles(randAng)
				// Sets no collision with the player at all.
				props:SetCollisionGroup(COLLISION_GROUP_DEBRIS)
				props:SetColor(Color(255, 0, 0))
				props:Spawn()
				local phys = props:GetPhysicsObject()
				if IsValid(phys) then
					phys:EnableMotion(true)
					phys:SetMass(1)
				end
			
				// Go in random directions everywhere!
				phys:ApplyForceCenter(VectorRand() * 500)

				// Apply red blood trails to the gibs.
				local trail = util.SpriteTrail(props, 0, Color(255, 0, 0, 100), true, 10, 1, 4, 1/(15+1)*0.5, "effects/beam001_white.vmt")
				
				// Make a particle
				local effectData = EffectData()
				effectData:SetOrigin(gibPos)
				effectData:SetRadius(1)
				util.Effect( "wos_alcs_bloodtouch" , effectData )
				timer.Simple(5, function()
					if IsValid(props) then
						props:Remove()
					end
				end)
			end
		end

		// Do a force repulse effect on the player.
		local ed = EffectData()
		ed:SetOrigin( ply:GetPos() + Vector( 0, 0, 36 ) )
		ed:SetRadius( 128 )
		util.Effect( "rb655_force_repulse_out", ed, true, true )

		// Do damage equal to 100% of the player's health
		local d = DamageInfo()
		d:SetDamage( ply:Health() )
		d:SetAttacker( ply )
		d:SetDamageType( DMG_REMOVENORAGDOLL )
		ply:TakeDamageInfo( d )
		
		// Just kill
		ply:Kill()
		-- // Get player ragdoll
		-- if ply.deathragdoll then
		-- 	ply.deathragdoll:SetNoDraw( true )
		-- end
	end)
end
LSCS:RegisterForce( force )

// ============================================================================== //
//                                                                                //
//                          		Force Super Jump              				  //
//                                                                                //
// ============================================================================== //

local force = {}
force.PrintName = "Force Super Jump"
force.Author = "Stoneman"
force.Description = "HOOWEE"
force.id = "superman"
force.Icon = "icon16/arrow_up.png"
force.OnClk = function( ply )
	if not ply.KyberCorePower_SuperJump then return end
	local look
	// Check if we're looking up
	if ply:EyeAngles().p < -10 then
		look = "up"
	elseif ply:EyeAngles().p > 10 then
		look = "down"
	else
		look = "front"
	end

	if look == "up" then
		ply:SetVelocity( ply:GetAimVector() * 512 + Vector( 0, 0, 512 ) )
	elseif look == "down" then
		ply:SetVelocity( ply:GetAimVector() * 512 + Vector( 0, 0, -512 ) )
	else
		ply:SetVelocity( ply:GetAimVector() * 512 )
	end

	ply:lscsTakeForce( 0 ) -- take amount of force we need
end
force.StartUse = function(ply)
	ply.KyberCorePower_SuperJump = true
end
force.StopUse = function(ply)
	ply.KyberCorePower_SuperJump = nil
end
LSCS:RegisterForce( force )

// ============================================================================== //
//                                                                                //
//                          		Fuck		               				      //
//                                                                                //
// ============================================================================== //

local force = {}
force.PrintName = "fuck"
force.Author = "Stoneman"
force.Description = "fuck"
force.id = "fuck"
force.Icon = "entities/item_force_fuck.png"
force.OnClk = function( ply )
	if not ply.KyberCorePower_Fuck then return end
	ply:EmitSound("kybercore/metal_pipe.mp3", 100,100,1 )
end
force.StartUse = function( ply )
	ply.KyberCorePower_Fuck = true
end
force.StopUse = function( ply )
	ply.KyberCorePower_Fuck = nil
end
LSCS:RegisterForce( force )

// ============================================================================== //
//                                                                                //
//                          		Divine Sorcery		                 		  //
//                                                                                //
// ============================================================================== //

local possiblesounds = {
	"npc/combine_soldier/vo/engaging.wav",
	"npc/combine_soldier/vo/executingfullresponse.wav",
	"npc/combine_soldier/vo/fixsightlinesmovein.wav",
	"npc/combine_soldier/vo/onedutyvacated.wav",
	"npc/combine_soldier/vo/overwatchrequestreinforcement.wav",
	"npc/combine_soldier/vo/ovewatchorders3ccstimboost.wav",
	"npc/combine_soldier/vo/priority1objective.wav",
	"npc/combine_soldier/vo/prioritytwoescapee.wav",
	"npc/combine_soldier/vo/requestmedical.wav",
	"npc/combine_soldier/vo/requeststimdose.wav",
}
local function PhysCallback( ent, data )
	// find entities in a 10 unit radius
	local entities = ents.FindInSphere( ent:GetPos(), 17 )
	for k, v in pairs( entities ) do
		if v == ent then continue end
		if v.IsStonemanDroids then
			if v:Health() < 0 then continue end
			// Do damage equal to 100% of the player's health
			local d = DamageInfo()
			d:SetDamage( 75 )
			d:SetAttacker( ent )
			d:SetDamageType( DMG_DISSOLVE )
			v:TakeDamageInfo( d )
		end
	end

	if data.HitEntity:IsWorld() then
		// Can only scream once every 1 second
		if ent.KyberCorePower_Telekenesis_LastScream and ent.KyberCorePower_Telekenesis_LastScream > CurTime() then return end
		// Play sound
		local randomsound = possiblesounds[ math.random( 1, #possiblesounds ) ]
		ent:EmitSound( randomsound )
		// Set last scream time
		ent.KyberCorePower_Telekenesis_LastScream = CurTime() + 1

		if ent.WasStonemanDroid2 then
			if ent.ShouldExplodeImmediately then
				// Explode
				local effectdata = EffectData()
				effectdata:SetOrigin( ent:GetPos() )
				util.Effect( "Explosion", effectdata )
				ent:Remove()
			end
		end
	end
end

local force = {}
force.PrintName = "Divine Sorcery"
force.Author = "Stoneman"
force.Description = "No, I'm not a wizard."
force.id = "divine_sorcery"
force.Icon = "kybercore/jerry.png"
force.OnClk = function( ply )
	if not ply.KyberCorePower_DivineSorcery then return end
	if IsValid( ply.WindTarget ) then
		// Make them fly up!
		local vec = ( ( ply:EyePos() + ply:GetAimVector()*ply.WindDistance  ) - ply.WindTarget:GetPos() )
		local vec2 = ( ( ply:EyePos() + ply:GetAimVector()*2*ply.WindDistance  ) - ply.WindTarget:GetPos() )

		if ply.WindTarget:IsPlayer() or ply.WindTarget:IsNPC() then
			ply.WindTarget:SetLocalVelocity( vec*10 )
		elseif ply.WindTarget.IsStonemanDroids then
			// Don't do anything if the droid has more than 500 health
			if ply.WindTarget:GetMaxHealth() > 500 then return end
			// Remove the nextbot, but put the ragdoll in its place
			local rag = ents.Create( "prop_ragdoll" )
			rag:SetModel( ply.WindTarget:GetModel() )
			rag:SetPos( ply.WindTarget:GetPos() )
			rag:SetAngles( ply.WindTarget:GetAngles() )
			rag:Spawn()
			rag.WasStonemanDroid2 = true
			rag.ShouldExplodeImmediately = false
			ply.WindTarget:Remove()

			if not rag then return end
			rag:AddCallback( "PhysicsCollide", PhysCallback )

			ply.WindTarget = rag
			ply.WindTarget:SetCollisionGroup( COLLISION_GROUP_WORLD )
			ply.WindTarget:SetMoveType( MOVETYPE_NONE )
		elseif ply.WindTarget:IsRagdoll() then
			local phys = ply.WindTarget:GetPhysicsObject()
			phys:SetVelocity( vec*50 )
		else
			local phys = ply.WindTarget:GetPhysicsObject()
			phys:SetVelocity( vec*10 )
		end

		if ply:KeyDown( IN_USE ) then
			if ply.WindTarget:IsPlayer() or ply.WindTarget:IsNPC() then
				ply.WindTarget:EmitSound( "wos/reverb_fart.wav" )
				local d = DamageInfo()
				d:SetDamage( ply.WindTarget:Health() )
				d:SetAttacker( ply )
				d:SetDamageType( DMG_DISSOLVE )
				ply.WindTarget:TakeDamageInfo( d )
			elseif ply.WindTarget:IsRagdoll() then
				ply.WindTarget:EmitSound( "wos/reverb_fart.wav" )
				// Dissolve the ragdoll
				local d = DamageInfo()
				d:SetDamage( 1000 )
				d:SetAttacker( ply )
				d:SetDamageType( DMG_DISSOLVE )
				ply.WindTarget:TakeDamageInfo( d )
			end
		end
		return
	end
	local tr = util.TraceLine( util.GetPlayerTrace( ply ) )
	local dist = tr.HitPos:Distance( ply:GetPos() )
	if not tr.Entity then return end
	if dist >= 9999 then return end
	ply.WindTarget = tr.Entity
	ply.WindDistance = dist

	// Make them fly up!
	local vec = ( ( ply:EyePos() + ply:GetAimVector()*ply.WindDistance  ) - ply.WindTarget:GetPos() )
	local vec2 = ( ( ply:EyePos() + ply:GetAimVector()*2*ply.WindDistance  ) - ply.WindTarget:GetPos() )

	if ply.WindTarget:IsPlayer() or ply.WindTarget:IsNPC() or ply.WindTarget:IsNextBot() then
		ply.WindTarget:SetLocalVelocity( vec*10 )
	else
		local phys = ply.WindTarget:GetPhysicsObject()
		if phys:IsValid() then
			phys:SetVelocity( vec*10 )
		end
	end
end
force.StartUse = function( ply )
	ply.KyberCorePower_DivineSorcery = true
end
force.StopUse = function ( ply )
	ply.KyberCorePower_DivineSorcery = nil
	if not IsValid( ply.WindTarget ) then return end
	// Get the direction of the player's aim
	local vec = (ply:GetAimVector())
	// Throw the object in that direction
	if ply.WindTarget:IsPlayer() or ply.WindTarget:IsNPC() then
		ply.WindTarget:SetLocalVelocity( vec*9999 )
	else
		local phys = ply.WindTarget:GetPhysicsObject()
		phys:SetVelocity( vec*9999 )
	end

	if ply.WindTarget.WasStonemanDroid2 then
		local phys = ply.WindTarget:GetPhysicsObject()
		phys:SetVelocity( vec*9999 )
		ply.WindTarget.ShouldExplodeImmediately = true
		local ragdoll = ply.WindTarget
		timer.Simple( 10, function()
			if IsValid( ragdoll ) then
				ragdoll:Remove()
			end
		end)
	end

	local ed = EffectData()
	ed:SetOrigin( ply.WindTarget:GetPos() + Vector( 0, 0, 36 ) )
	ed:SetRadius( 128 )
	util.Effect( "rb655_force_repulse_out", ed, true, true )
	ply.WindTarget = nil
end
LSCS:RegisterForce( force )

local function detachAreaPortals(door)
	door.KyberCore_detachedAreaPortals = {}

	local doorName = door:GetName()
	if doorName == "" then return end

	for id, portal in pairs(ents.FindByClass("func_areaportal")) do
		local portalTarget = portal:GetInternalVariable("m_target")
		if portalTarget ~= doorName then continue end

		portal:Input("Open", self, door)

		-- Disconnect the areaportal so any entities playing with the door don't
		-- trigger it to close. We'll link it again when we put the door back.
		door.KyberCore_detachedAreaPortals[id] = portal
		portal:SetSaveValue("m_target", "")
	end
end

-- From Source SDK 2013, BasePropDoor.h
-- Door is fully closed.
local DOOR_STATE_CLOSED = 0

-- Reconnect a door's areaportals and update their state.
local function reattachAreaPortals(door)
	local doorName = door:GetName()
	local doorClosed = (door:GetInternalVariable("m_eDoorState")
		== DOOR_STATE_CLOSED)
	for _, portal in pairs(door.KyberCore_detachedAreaPortals) do
		portal:SetSaveValue("m_target", doorName)
		portal:Input(doorClosed and "Close" or "Open", door, door)
	end
	door.KyberCore_detachedAreaPortals = nil
end

// ============================================================================== //
//                                                                                //
//                          		Super Kick				               		  //
//                                                                                //
// ============================================================================== //

local force = {}
force.PrintName = "Super-kick"
force.Author = "Stoneman"
force.Description = "I hate you all"
force.id = "superkick"
force.Icon = "entities/item_force_breach.png"
force.OnClk = function( ply )
	if not ply.KyberCorePower_Superkick then return end
	local Time = CurTime()

	local CanDo = (ply._lscsNextForce or 0) < Time
	
	if not CanDo then return end
	ply._lscsNextForce = Time + 0.5

	local tr = util.TraceLine( {
		start = ply:GetShootPos(),
		endpos = ply:GetShootPos() + ply:GetAimVector() * 200,
		filter = ply,
		mask = MASK_SHOT_HULL
	} )
	local ent = tr.Entity
	if !IsValid( ent ) then return end
	if ent:GetClass()=="func_door" or ent:GetClass()=="prop_door_rotating" or ent:GetClass()=="func_door_rotating" then

		// Make the door entity.
		local door = ents.Create( "prop_physics" )
		door:SetModel( ent:GetModel() )
		door:SetPos( ent:GetPos() )
		door:SetAngles( ent:GetAngles() )
		door:Spawn()
		door:SetCollisionGroup( COLLISION_GROUP_WEAPON )
		door:SetMoveType( MOVETYPE_VPHYSICS )
		door:SetSolid( SOLID_VPHYSICS )

		// Make the door entity fly away.
		local phys = door:GetPhysicsObject()
		phys:EnableGravity( false )
		phys:ApplyForceOffset( ply:GetAimVector()*99999, tr.HitPos )

		// Make the original door invisible and uncollidable for 10 seconds.
		local solid = ent:GetSolid()
		local col = ent:GetCollisionGroup()
		ent:SetNoDraw( true )
		ent:SetCollisionGroup( COLLISION_GROUP_WORLD )
		ent:SetSolid( SOLID_NONE )

		detachAreaPortals(ent)

		timer.Simple( 10, function()
			if IsValid( ent ) then
				ent:SetNoDraw( false )
				ent:SetCollisionGroup( col )
				ent:SetSolid( solid )
				reattachAreaPortals(ent)

				// Remove the door entity.
				if IsValid( door ) then
					door:Remove()
				end
			end
		end )
	elseif ent:GetClass()=="prop_physics" then
		// Make the door entity fly away.
		local phys = ent:GetPhysicsObject()
		phys:ApplyForceCenter( ply:GetAimVector()*100000)
	elseif ent:GetClass()=="player" then
		// Make the player fly away.
		GMSNX:AddStatus(ent, ply, "heavystun", 2, 1, false)

		timer.Simple( 0.1, function()
			// Throw the player's ragdoll away.
			if IsValid( ent.tw_Ragdoll ) then
				local phys = ent.tw_Ragdoll:GetPhysicsObject()
				// Make the ragdoll fly away, low gravity.
				phys:EnableGravity( false )
				phys:EnableDrag( false )
				phys:ApplyForceOffset( ply:GetAimVector()*100000, tr.HitPos )
			end
		end)
	elseif ent:GetClass()=="prop_ragdoll" then
		// Make the ragdoll fly away.
		local phys = ent:GetPhysicsObject()
		phys:EnableGravity( false )
		phys:EnableDrag( false )
		phys:ApplyForceOffset( ply:GetAimVector()*100000, tr.HitPos )
	elseif ent:IsNPC() or ent:IsNextBot() then
		// Kill NPC, and make it's ragdoll fly away.
		local dmginfo = DamageInfo()
		dmginfo:SetDamage( 99999 )
		dmginfo:SetAttacker( ply )
		dmginfo:SetInflictor( ply )
		dmginfo:SetDamageType( DMG_BLAST )
		ent:TakeDamageInfo( dmginfo )
	end

	LSCS:PlayVCDSequence(ply, "wos_bs_shared_kick", 0.5)
	ply:EmitSound( "physics/metal/metal_box_break1.wav" )
end
force.StartUse = function( ply )
	ply.KyberCorePower_Superkick = true
end
force.StopUse = function( ply )
	ply.KyberCorePower_Superkick = nil
end
LSCS:RegisterForce( force )

// ============================================================================== //
//                                                                                //
//                          		HEY CATCH!!! 			               		  //
//                                                                                //
// ============================================================================== //

local force = {}
force.PrintName = "HEY CATCH!!!"
force.Author = "Stoneman"
force.Description = "Throw your Lightsaber"
force.id = "heycatch"
force.Icon = "entities/item_force_heycatch.png"
force.OnClk = function( ply )
	if not ply.KyberCorePower_HEYCATCH then return end
	local CurSWEP = ply:GetActiveWeapon()
	local SWEP = ply:GetWeapon( "weapon_lscs" )

	if IsValid( CurSWEP ) then
		if CurSWEP.LSCS then
			SWEP = CurSWEP
		end
	end

	if not IsValid( SWEP ) then return end
	
	LSCS:PlayVCDSequence( ply, "zombie_attack_02", 0.3 )

	local proj = ents.Create("lscs_projectile")
	proj:SetPos( ply:GetShootPos() - Vector(0,0,20) )
	proj:SetSWEP( SWEP, true )
	proj:Spawn()
	proj:Activate()

	ply:lscsTakeForce(-100)

	ply:EmitSound("npc/zombie/claw_miss1.wav")

	SWEP:SetHoldType( "magic" )

	ply._lscsThrownSaber = proj
end
force.StartUse = function( ply )
	ply.KyberCorePower_HEYCATCH = true 
end
force.StopUse = function( ply )
	ply.KyberCorePower_HEYCATCH = false
	if IsValid( ply._lscsThrownSaber ) then
		ply._lscsThrownSaber:ResetProgress()
		ply._lscsThrownSaber.Returning = true
	end
end

LSCS:RegisterForce( force )

// ============================================================================== //
//                                                                                //
//                          		KAMEHAMEHA  			               		  //
//                                                                                //
// ============================================================================== //
local force = {}
force.PrintName = "KAMEHAMEHA"
force.Author = "Stoneman"
force.Description = "DIE"
force.id = "kamehameha"
force.Icon = "kybercore/bad_batch_nose_art.png"
force.OnClk = function( ply )
	if not ply.KyberCorePower_KAMEHAMEHA then return end
	// Shoots tracers!
	local Time = CurTime()
	// Shoots conc_tracer
	local bullet = {}
	bullet.Num 		= 1
	bullet.Spread 	= Vector( 0, 0, 0 )
	bullet.Tracer	= 1
	bullet.Force	= 5
	bullet.Damage	= 100
	bullet.AmmoType = "Pistol"
	bullet.Entity = ply
	bullet.IgnoreEntity = ply
	bullet.TracerName = "conc_tracer"
	bullet.Src 		= ply:GetEyeTrace().StartPos
	bullet.Dir 		= ply:GetAimVector()
	ply:FireBullets( bullet )

	LSCS:PlayVCDSequence(ply, "wos_jedi_forceblast", 0.8)

	local tr = util.TraceLine( util.GetPlayerTrace( ply ) )
	if tr.Hit then
		// If it's a player and is alive, disintegrate!
		if tr.Entity:IsPlayer() and tr.Entity:Alive() or tr.Entity:IsNextBot() then
			local d = DamageInfo()
			d:SetDamage( tr.Entity:Health() )
			d:SetAttacker( ply )
			d:SetDamageType( DMG_DISSOLVE )
			tr.Entity:TakeDamageInfo( d )
		end
	end
end
force.StartUse = function( ply )
	ply.KyberCorePower_KAMEHAMEHA = true 
end
force.StopUse = function( ply )
	ply.KyberCorePower_KAMEHAMEHA = false
end
LSCS:RegisterForce( force )

// ============================================================================== //
//                                                                                //
//                          		Tears of Denial			               		  //
//                                                                                //
// ============================================================================== //
local function TearsOfDenial(ply)
	local deathpos = ply:GetPos()
	local deathangles = ply:GetAngles()
	ply:Spawn()
	ply:SetModel(ply.DefibModels)
	ply:StripWeapons()
	ply:SetPos(deathpos)
	ply:SetAngles(deathangles)

	// Turn on god mode for 3 seconds.
	ply:GodEnable()

	ply._KyberCorePower_Tears_Reviving = false

	timer.Simple( 3, function() ply:GodDisable() end )
	for k,v in pairs(ply.DefibWeps) do ply:Give(v) end
end

local force = {}
force.PrintName = "Tears of Denial"
force.Author = "Stoneman"
force.Description = "Resist death."
force.id = "tears"
force.Icon = "kybercore/tears_of_denial.png"
force.OnClk = function(ply, TIME)
	if not ply._KyberCorePower_Tears then return end
	if ply:Health() <= 0 or not ply:Alive() then
		if ply._KyberCorePower_Tears_Reviving then return end
		ply._KyberCorePower_Tears_Reviving = true
		local ed = EffectData()
		ed:SetEntity( ply )
		ed:SetRadius( 5 )

		// Use wos_alcs_acidpool
		util.Effect( "wos_alcs_bloodtouch", ed, true, true )

		// After 3 seconds, you will come back to life.
		timer.Simple( 3, function()
			TearsOfDenial(ply)
		end )
	end
end
force.StartUse = function( ply )
	// Once you activate this, you will come back to life after death.
	if ply._KyberCorePower_Tears then
		ply:ChatPrint("You accept death.")
		ply._KyberCorePower_Tears = false
		return
	else
		ply:ChatPrint("You will come back to life after death.")
		ply._KyberCorePower_Tears = true
	end

	// Make a sound
	ply:EmitSound( "kybercore/tears.wav" )
end
LSCS:RegisterForce( force )

// ============================================================================== //
//                                                                                //
//                          		Force Flash 			               		  //
//                                                                                //
// ============================================================================== //
local force = {}
force.PrintName = "Force Flash"
force.Author = "Truce and Stoneman"
force.Description = "Use the force to enhance yourself to go further and faster than others. (+1000 Speed)"
force.id = "flash"
force.Icon = "kybercore/flash.png"
force.StartUse = function( ply )
	if ply:lscsGetForce() < 5 then return end
	local Time = CurTime()

	local CanDo = (ply._lscsNextForce or 0) < Time

	
	if not CanDo then return end
	ply:lscsTakeForce( 30 ) -- take amount of force we need
	ply._lscsNextForce = Time + 10
	
	local available = ply:lscsGetForce()
	ply:EmitSound("npc/combine_gunship/ping_search.wav")

	local speed = ply:GetRunSpeed()
	ply:SetRunSpeed( speed + 1000 )
	timer.Simple(5, function()
		ply:SetRunSpeed( ply.df_runspeed )
	end)
end
LSCS:RegisterForce( force )

// ============================================================================== //
//                                                                                //
//                          		Diamond Hurricane			               	  //
//                                                                                //
// ============================================================================== //
local force = {}
force.PrintName = "Diamond Hurricane"
force.Author = "Stoneman"
force.Description = "Go all out, destroy them all!"
force.id = "diamondhurricane"
force.Icon = "kybercore/diam.png"
force.OnClk = function( ply )
	if not ply.KyberCorePower_diamondhurricane then return end
	local Time = CurTime()
	
	local tr = util.TraceLine( util.GetPlayerTrace( ply ) )
	local pos = tr.HitPos
	local pi = math.pi
	local bullet = {}
	bullet.Num 		= 40
	bullet.Spread 	= Vector( 0.3, 0.3, 0 )
	bullet.Tracer	= 1
	bullet.Force	= 100						
	bullet.Damage	= 400
	bullet.AmmoType = "AR2"
	bullet.Entity = ply
	bullet.IgnoreEntity = ply
	bullet.TracerName = "wos_alcs_diamondbullet"
	ply:EmitSound( "physics/glass/glass_sheet_break3.wav" )
	LSCS:PlayVCDSequence( ply, "pure_taunt_balanced", 0 )
	local time = 0.6
	local ed = EffectData()
	ed:SetEntity( ply )
	ed:SetScale( time )

	util.Effect( "wos_alcs_diamondstorm", ed, true, true )

	if not IsValid( ply ) then return end
	bullet.Src 		= ply:GetShootPos()
	bullet.Dir 		= ply:GetAimVector()
	ply:FireBullets( bullet )
	ply:EmitSound( "npc/manhack/mh_blade_snick1.wav" )
end
force.StartUse = function(ply)
	ply.KyberCorePower_diamondhurricane = true
end
force.StopUse = function(ply)
	ply.KyberCorePower_diamondhurricane = nil
end
LSCS:RegisterForce( force )

// ============================================================================== //
//                                                                                //
//                          		Glock 19			               			  //
//                                                                                //
// ============================================================================== //
local force = {}
force.PrintName = "Glock 19"
force.Author = "Stoneman"
force.Description = "A glock 19, a pistol that can be used to shoot people."
force.id = "glock19"
force.Icon = "kybercore/glock19.png"
force.StartUse = function( ply )
	// Does nothing else but play a sound and do massive damage.
	ply:EmitSound( "kybercore/gunshot.mp3" )

	// Play animation
	LSCS:PlayVCDSequence( ply, "run_pistol", 0.2 )

	// Shoots bullet
	local bullet = {}
	bullet.Num 		= 1
	bullet.Spread 	= Vector( 0, 0, 0 )
	bullet.Tracer	= 1
	bullet.Force	= 100
	bullet.Damage	= 999999
	bullet.AmmoType = "Pistol"
	bullet.Entity = ply
	bullet.IgnoreEntity = ply
	bullet.TracerName = "rw_sw_laser_red"
	bullet.Src 		= ply:GetShootPos()
	bullet.Dir 		= ply:GetAimVector()
	ply:FireBullets( bullet )

end
LSCS:RegisterForce( force )

// ============================================================================== //
//                                                                                //
//                          		Force Freeze			               		  //
//                                                                                //
// ============================================================================== //
local force = {}
force.PrintName = "Force Freeze"
force.Author = "Stoneman"
force.Description = "Using the force creates a link to all targets that shoot at the user. Transferring any damage the user receives back to the target."
force.id = "freeze"
force.Icon = "kybercore/slow.png"
force.StartUse = function( ply )
	local Time = CurTime()

	local CanDo = (ply.KyberCorePower_ForceFreezeCooldown or 0) < Time

	if not CanDo then return end

	ply.KyberCorePower_ForceFreezeCooldown = Time + 5

	if ply:lscsGetForce() < 3 then return end
	ply:lscsTakeForce( 25 )
	
	local tr = util.TraceLine( {
		start = ply:GetShootPos(),
		endpos = ply:GetShootPos() + ply:GetAimVector() * 10000,
		filter = ply,
		mask = MASK_SHOT_HULL
	} )
	
	local ent = tr.Entity
	
	if !IsValid( ent ) then return end

	if not ent:IsPlayer() then return end
	
	local edc = EffectData()
	edc:SetOrigin( ent:GetPos() )
	edc:SetEntity( ent )
	util.Effect( "wos_emerald_lightning", edc, true, true )
	
	ent:Freeze(true)
	timer.Create( "Freeze Timer" .. ent:EntIndex(), 10, 1, function() 	 ent:Freeze(false) end )
	LSCS:PlayVCDSequence( ply, "wos_cast_freeze", 0 )
end
LSCS:RegisterForce( force )

local force = {}
force.PrintName = "Mind Trick"
force.Author = "Stoneman"
force.Description = "Confuse your enemy."
force.id = "mindtrick"
force.Icon = "kybercore/mindtrick.jpg"
force.StartUse = function( ply )
	if not ply:IsOnGround() then return end
	local Time = CurTime()

	// Get the npc's in front of the player
	// Get hull for entities in front of player
	local tr = util.TraceHull( {
		start = ply:GetShootPos(),
		endpos = ply:GetShootPos() + ply:GetAimVector() * 75000,
		filter = ply,
		mins = Vector( -50, -50, -50 ),
		maxs = Vector( 50, 50, 50 ),
		mask = MASK_SHOT_HULL
	} )

	if not IsValid( tr.Entity ) then return end
	ply:ChatPrint( "Mind tricked " .. tr.Entity:Nick() )
	tr.Entity:SetNWBool( "StonemanMindTricked", true )
	
	timer.Simple( 10, function()
		if not IsValid( tr.Entity ) then return end
		tr.Entity:SetNWBool( "StonemanMindTricked", false )
	end )
end
LSCS:RegisterForce( force )

// Reverses player's controls
hook.Add( "SetupMove", "StonemanMindTrick", function( ply, mv, cmd )
	if ply:GetNWBool( "StonemanMindTricked" ) then
		local forward = mv:GetForwardSpeed()
		local right = mv:GetSideSpeed()
		local up = mv:GetUpSpeed()

		mv:SetForwardSpeed( -forward )
		mv:SetSideSpeed( -right )
		mv:SetUpSpeed( -up )
	end
end )

local force = {}
force.PrintName = "Rewind"
force.Author = "Stoneman"
force.Description = "Cheers love, the cavalry's here!"
force.id = "rewind"
force.StartUse = function( ply )
	ply.KyberCorePowers_Rewind = !ply.KyberCorePowers_Rewind
	ply:ChatPrint("REWIND MODE: " .. tostring( ply.KyberCorePowers_Rewind ) )
	ply.KyberCorePowers_Rewind_Table = {}
end
force.OnClk = function( ply )
	if not ply.KyberCorePowers_Rewind then return end
	local function SaveEntry()
		ply.KyberCorePowers_Rewind_Table[ #ply.KyberCorePowers_Rewind_Table + 1 ] = {
			pos = ply:GetPos(),
			ang = ply:GetAngles(),
			health = ply:Health(),
			weapon = ply:GetActiveWeapon():GetClass(),
			time = CurTime()
		}

		if #ply.KyberCorePowers_Rewind_Table > 100 then
			table.remove( ply.KyberCorePowers_Rewind_Table, 1 )
		end
	end

	local function ApplyEntry( entry )
		if not entry then return end
		ply:SetPos( entry.pos )
		ply:SetEyeAngles( entry.ang )
		// Reset velocity
		ply:SetVelocity( Vector(0,0,0) )
		ply:SetLocalVelocity( Vector(0,0,0) )
		ply:SetHealth( entry.health )
		ply:SelectWeapon( entry.weapon )
	end

	timer.Create( "StonemanRewind"..ply:EntIndex(), 0.01, 0, function()
		if not IsValid( ply ) then timer.Remove( "StonemanRewind"..ply:EntIndex()) return end
		if not ply:Alive() then timer.Remove( "StonemanRewind"..ply:EntIndex()) return end
		if not ply.KyberCorePowers_Rewind then timer.Remove( "StonemanRewind"..ply:EntIndex()) return end
		if ply.KyberCorePowers_Rewinding then timer.Remove( "StonemanRewind"..ply:EntIndex()) return end
		SaveEntry()
	end )

	if ply:KeyDown( IN_RELOAD ) then
		ply.KyberCorePowers_Rewinding = true

		timer.Create("StonemanRewind2"..ply:EntIndex(), 0.01, 0, function()
			// Apply the last entry
			ApplyEntry( ply.KyberCorePowers_Rewind_Table[ #ply.KyberCorePowers_Rewind_Table ] )

			// Remove the last entry
			table.remove( ply.KyberCorePowers_Rewind_Table, #ply.KyberCorePowers_Rewind_Table )

			if !ply:IsOnGround() then
				ply.KyberCore_ForceJump_FallDMG = true
			end

			// Once the table is empty, stop rewinding
			if #ply.KyberCorePowers_Rewind_Table == 0 then
				ply.KyberCorePowers_Rewinding = false
				timer.Remove("StonemanRewind2"..ply:EntIndex())
			end
		end)
	else
		if ply.KyberCorePowers_Rewinding then
			ply.KyberCorePowers_Rewinding = false
			timer.Remove("StonemanRewind2"..ply:EntIndex())
		end
	end
end
LSCS:RegisterForce( force )

local force = {}
force.PrintName = "Rocket"
force.Author = "Stoneman"
force.Description = "Fly, rocketman."
force.id = "rocket"
force.StartUse = function( ply )
	if not ply:IsOnGround() then return end
	local Time = CurTime()

	local CanDo = (ply.KyberCorePowers_Rocket_Time or 0) < Time
	
	-- if not CanDo then return end

	// Find person in front of player
	local tr = util.TraceLine( {
		start = ply:EyePos(),
		endpos = ply:EyePos() + ply:GetAimVector()*600,
		filter = ply
	} )

	if not IsValid( tr.Entity ) then return end

	if tr.Entity:IsPlayer() then
		// Make the player go straight up
		tr.Entity:SetVelocity( Vector( 0, 0, 2500 ) )
		// Explode player after 5 seconds
		timer.Simple( 2, function()
			if not IsValid( tr.Entity ) then return end
			tr.Entity:TakeDamage( tr.Entity:Health(), ply, ply)
			// Explosion effect
			local effectdata = EffectData()
			effectdata:SetOrigin( tr.Entity:GetPos() )
			effectdata:SetMagnitude( 3 )
			util.Effect( "Explosion", effectdata )
		end )
	end
end
LSCS:RegisterForce( force )

local force = {}
force.PrintName = "Sus"
force.Author = "Stoneman"
force.Description = "The sus among us imposter"
force.id = "sus"
force.Icon = "kybercore/amongus.png"
force.StartUse = function( ply )
	// Find person in front of player
	local tr = util.TraceLine( {
		start = ply:EyePos(),
		endpos = ply:EyePos() + ply:GetAimVector()*600,
		filter = ply
	} )

	if not IsValid( tr.Entity ) then return end
	// Play sound
	ply:EmitSound( "kybercore/amongus.mp3" )
	
	// Kill player with no ragdoll
	if tr.Entity:IsPlayer() then
		// Make player invisible
		tr.Entity:SetMaterial("models/effects/vol_light001")
		tr.Entity:TakeDamage( tr.Entity:Health(), ply, ply )
	elseif tr.Entity:IsNPC() or tr.Entity.IsStonemanDroids then
		// Make player invisible
		tr.Entity:SetMaterial("models/effects/vol_light001")
		tr.Entity:TakeDamage( tr.Entity:Health(), ply, ply )

		// Shadows off
		tr.Entity:DrawShadow( false )
	end

	// Then make them visible again once they're dead
	timer.Simple( 0.1, function()
		if not IsValid( tr.Entity ) then return end
		tr.Entity:SetMaterial("")
	end )

	local sus = ents.Create( "prop_physics" )
	sus:SetModel( "models/amongus/player/corpse.mdl" )
	sus:SetPos( tr.Entity:GetPos() )
	sus:Spawn()
	sus:SetCollisionGroup( COLLISION_GROUP_WEAPON )

	// Don't move at all
	sus:SetMoveType( MOVETYPE_NONE )

	// 90 degree rotation
	sus:SetAngles( Angle( 90, 0, 0 ) )

	// Pull it up a bit
	sus:SetPos( sus:GetPos() + Vector( 0, 0, 10 ) )

	timer.Simple( 10, function()
		if not IsValid( sus ) then return end
		sus:Remove()
	end )
end
LSCS:RegisterForce( force )

local force = {}
force.PrintName = "Displacement"
force.Author = "Stoneman"
force.Description = "Displace yourself, returning later."
force.id = "displacement"
force.StartUse = function( ply )
	if not ply:Alive() then return end

	if not ply.KyberCorePowers_Displacement then
		ply.KyberCorePowers_Displacement = ply:GetPos()
		ply.KyberCorePowers_Displacement_Angles = ply:GetAngles()

		ply:lscsTakeForce( 25 )
	else
		// Teleport to saved position
		ply:SetPos( ply.KyberCorePowers_Displacement )
		ply:SetAngles( ply.KyberCorePowers_Displacement_Angles )
		ply.KyberCorePowers_Displacement = nil
		ply.KyberCorePowers_Displacement_Angles = nil
	end

	// Play sound from hl2
	ply:EmitSound( "npc/combine_soldier/gear5.wav" )
end
LSCS:RegisterForce( force )

--local force = {}
--force.PrintName = "Force Familiar"
--force.Author = "Stoneman"
--force.Description = "Summon a familiar to fight for you."
--force.id = "familiar1"
--force.StartUse = function( ply )
	// Spawns a headcrab infront of you
	--local tr = util.TraceLine( {
		--start = ply:EyePos(),
		--endpos = ply:EyePos() + ply:GetAimVector()*600,
		--filter = ply
	--} )

	--if not IsValid( tr.Entity ) then return end

	--// Play sound from hl2
	--ply:EmitSound( "npc/combine_soldier/gear5.wav" )

	--// Spawn headcrab
	--local headcrab = ents.Create( "npc_coruscant_police_h" )
	--headcrab:SetPos( tr.HitPos )
	--headcrab:Spawn()

	--// It attacks everyone except the player
	--headcrab:AddEntityRelationship( ply, D_HT, 99 )
	--:AddEntityRelationship( ply, D_LI, 99 )
--end
--LSCS:RegisterForce( force )

local force = {}
force.PrintName = "Blind"
force.Author = "Foxi / Main author, Kayer / editor, Charon / support"
force.Description = "Make your enemies blind"
force.id = "blind"

local function darkenScreen(ply)

	  for _, player in pairs(player.GetAll()) do 
		if player ~= ply and player:GetPos():Distance(ply:GetPos()) <= 200 then 
			
		    player:ScreenFade(SCREENFADE.OUT, Color(0, 0, 0), 1, 2) 
        timer.Simple(2, function() 
          player:ScreenFade(SCREENFADE.IN, Color(0, 0, 0), 1, 2) 
		
		end)
	  end
	end
end

force.OnClk = function (ply, TIME)
	if not ply:GetNWBool( "_lscsForceBlind", false ) then return end
    darkenScreen(ply)
	if (ply._lscsBlindTime or 0) < TIME then
		ply:SetNWBool( "_lscsForceBlind", false )
	end
end

force.UnEquip = function( ply ) 
	ply:SetNWBool( "_lscsForceBlind", false ) 
end

force.Equip = function (ply)
	ply:SetNWBool( "_lscsForceBlind", false) 
end

force.StartUse = function (ply, TIME)
	local Time = CurTime()
	local CanDo = (ply._lscsNextForce or 0) < Time
	if not CanDo then return end
	ply._lscsNextForce = Time + 10
	if ply:GetNWBool( "_lscsForceBlind", true ) then
		ply:SetNWBool( "_lscsForceBlind", false )
	else
		if ply:lscsGetForce() >= 30 then
			ply:SetNWBool( "_lscsForceBlind", true )
			ply:lscsTakeForce( 30 )
			ply:EmitSound("lscs/force/sense.mp3")
		end
	end
end
	
force.StopUse = function (ply)
	
end
LSCS:RegisterForce(force)

local force = {}
force.PrintName = "Force Wave"
force.Author = "Apollo"
force.Description = "Create a ripple in the force to repel and damage your opponents"
force.id = "forcewave"
force.Cooldown = 5
force.StartUse = function( ply )
    local forceuse = 40
    local CanDo = ply:lscsGetForce() >= forceuse
    if not CanDo then return end

    for k,v in ipairs(ents.FindInCone(ply:GetPos(), ply:GetAimVector(), 250, 0.5)) do
        if not IsValid(v) then continue end
        v:TakeDamage(75, ply, ply)
        local plypos = ply:GetPos()
        local vpos = v:GetPos()
        local dir = (vpos - plypos)
        local dist = dir:LengthSqr()
        dir:Normalize()
        local maxforce = 300
        local pushforce = math.max(maxforce / dist, 1)
        v:SetVelocity((dir + Vector(0,0,0.4)) * pushforce)
    end

    ply:lscsTakeForce( forceuse )

    return true
end
LSCS:RegisterForce( force )


// ============================================================================== //
//                                                                                //
//                          		Force Radiance				               	  //
//                                                                                //
// ============================================================================== //
local force = {}
force.PrintName = "Force Radiance"
force.Author = "Truce"
force.Description = "Flood your body with radiant energy, greatly enhancing your speed and force control for a short time."
force.id = "rad"
force.Icon = "kybercore/radiance.png"
force.StartUse = function( ply )

	if ply:lscsGetForce() < 30 then return end
	local Time = CurTime()

	local CanDo = (ply.KyberCorePower_radiance_Timer or 0) < Time

	if not CanDo then return end
	ply:lscsTakeForce( 30 ) -- take amount of force we need
	ply.KyberCorePower_radiance_Timer = Time + 30
	local available = ply:lscsGetForce()
	ply:EmitSound("npc/combine_gunship/ping_search.wav")
	LSCS:PlayVCDSequence( ply, "gesture_signal_halt", 0 )
	ply:SetNWBool( "KyberCorePower_Radiance", true )

    ply.originalMaxForce = ply:lscsGetMaxForce()
    ply:lscsSetForce( 1000 )
    ply:lscsSetMaxForce( 1000 )

    timer.Simple(10, function()
        if IsValid(ply) then 
            ply:lscsSetMaxForce(ply.originalMaxForce or ply:lscsGetMaxForce()) 
			ply:SetNWBool("KyberCorePower_Radiance", false) 
        end
    end)
	
	force.StopUse = function( ply )
		ply.KyberCorePower_Radiance = false
	end

end
LSCS:RegisterForce( force )


// ============================================================================== //
//                                                                                //
//                          		Boulder Throw					              //
//                                                                                //
// ============================================================================== //

local force = {}
force.PrintName = "Boulder Throw"
force.Author = "Truce"
force.Description = "Call upon raw telekinetic might to summon and hurl a massive boulder at your enemies."
force.id = "boulderthrow"
force.Icon = "kybercore/boulder.png"
force.StartUse = function( ply )
    if ply:lscsGetForce() < 200 then return end -- do we have enough force points ?
	ply:lscsTakeForce( 200 ) -- take amount of force we need
	LSCS:PlayVCDSequence( ply, "zombie_attack_02", 0.5) -- play animation
    local ent = ents.Create( "boulder" )
    ent:SetPos( ply:EyePos() + (ply:GetAimVector() * 60) )
    ent:SetAngles( ply:EyeAngles() )
    ent:Spawn()
    ent:SetOwner( ply )
    local phys = ent:GetPhysicsObject()
    if (phys:IsValid()) then
        phys:SetVelocity( ply:GetAimVector() * 2000 )
    end

    return true
end
LSCS:RegisterForce( force )


// ============================================================================== //
//                                                                                //
//                          		Force Barrier					              //
//                                                                                //
// ============================================================================== //

local force = {}
force.PrintName = "Force Barrier"
force.Author = "Truce"
force.Description = "Create a protective barrier using the Force."
force.id = "bar"
force.Icon = "kybercore/barrier.png"

force.StartUse = function(ply)
    if ply:InVehicle() then return end
    if ply:lscsGetForce() < 50 then return end
    if (ply.KyberCorePower_Barrier or 0) > CurTime() then return end

    ply.KyberCorePower_Barrier = CurTime() + 1
    ply:lscsTakeForce(50)

    local proj = ents.Create("barrier")
    LSCS:PlayVCDSequence(ply, "gesture_item_throw", 0.5)
    if not IsValid(proj) then return end
    ply._KyberCore_barrier = proj

    proj:SetPos(ply:GetShootPos())
    proj:SetAngles(Angle(ply:EyeAngles().x - 90, ply:EyeAngles().y, 0))
    proj:SetOwner(ply)
    proj:Spawn()
    proj:Activate()

    -- Begin force drain + barrier check loop
    timer.Create("KyberCore_BarrierDrain_" .. ply:SteamID64(), 1, 0, function()
        if not IsValid(ply) or not IsValid(ply._KyberCore_barrier) then
            timer.Remove("KyberCore_BarrierDrain_" .. ply:SteamID64())
            return
        end

        local currentForce = ply:lscsGetForce()
        if currentForce <= 0 then
            force.StopUse(ply)
            timer.Remove("KyberCore_BarrierDrain_" .. ply:SteamID64())
            return
        end

        ply:lscsTakeForce(5)
    end)
end

force.StopUse = function(ply)
    if IsValid(ply._KyberCore_barrier) then
        ply._KyberCore_barrier:Remove()
        ply._KyberCore_barrier = nil
    end

    timer.Remove("KyberCore_BarrierDrain_" .. ply:SteamID64())
end

LSCS:RegisterForce(force)

hook.Add("PlayerDeath", "RemoveBarrierOnDeath", function(ply)
    if IsValid(ply._KyberCore_barrier) then
        ply._KyberCore_barrier:Remove()
        ply._KyberCore_barrier = nil
    end

    timer.Remove("KyberCore_BarrierDrain_" .. ply:SteamID64())
end)

hook.Add("PlayerDisconnected", "RemoveBarrierOnDisconnect", function(ply)
    if IsValid(ply._KyberCore_barrier) then
        ply._KyberCore_barrier:Remove()
        ply._KyberCore_barrier = nil
    end

    timer.Remove("KyberCore_BarrierDrain_" .. ply:SteamID64())
end)

// ============================================================================== //
//                                                                                //
//                          		Rock Throw					          		  //
//                                                                                //
// ============================================================================== //

local force = {}
force.PrintName = "Rock Throw"
force.Author = "Truce"
force.Description = "Lob a boulder at your foe"
force.id = "rock"
force.Icon = "kybercore/gwobus.png"
force.StartUse = function( ply )
    if ply:lscsGetForce() < 1 then return end -- do we have enough force points ?
	ply:lscsTakeForce( 1 ) -- take amount of force we need
	LSCS:PlayVCDSequence( ply, "zombie_attack_02", 0.3 )
    local ent = ents.Create( "rock" )
    ent:SetPos( ply:EyePos() + (ply:GetAimVector() * 60) )
    ent:SetAngles( ply:EyeAngles() )
    ent:Spawn()
    ent:SetOwner( ply )

    local phys = ent:GetPhysicsObject()
    if (phys:IsValid()) then
        phys:SetVelocity( ply:GetAimVector() * 1500 )
    end

    return true
end
LSCS:RegisterForce( force )

// ============================================================================== //
//                                                                                //
//                          		Melon Throw					          		  //
//                                                                                //
// ============================================================================== //

local force = {}
force.PrintName = "Melon Throw"
force.Author = "Truce"
force.Description = "Lob a boulder at your foe"
force.id = "melon"
force.Icon = "kybercore/melon.png"
force.StartUse = function( ply )
    if ply:lscsGetForce() < 1 then return end -- do we have enough force points ?
	ply:lscsTakeForce( 1 ) -- take amount of force we need
	LSCS:PlayVCDSequence( ply, "zombie_attack_02", 0.3 )
    local ent = ents.Create( "melon" )
    ent:SetPos( ply:EyePos() + (ply:GetAimVector() * 60) )
    ent:SetAngles( ply:EyeAngles() )
    ent:Spawn()
    ent:SetOwner( ply )

	ent.Target = nil

    local phys = ent:GetPhysicsObject()
    if (phys:IsValid()) then
        phys:SetVelocity( ply:GetAimVector() * 500 )
    end

	// Home in towards the nearest player
	local target = nil
	local dist = 5000
	for k,v in pairs(player.GetAll()) do
		if v == ply then continue end
		if v:GetPos():Distance( ply:GetPos() ) < dist then
			target = v
			dist = v:GetPos():Distance( ply:GetPos() )
		end
	end

	if IsValid( target ) then
		ent.Target = target
	end

	// Got target, let's add think function and apply velocity towards target
	ent.Think = function( self )
		if not IsValid( self.Target ) then return end
		local dir = (self.Target:GetPos() - self:GetPos()):GetNormalized()
		self:GetPhysicsObject():SetVelocity( dir * 2500 )
	end

    return true
end
LSCS:RegisterForce( force )


// ============================================================================== //
//                                                                                //
//                          		Force Snap 					                  //
//                                                                                //
// ============================================================================== //

local force = {}
force.PrintName = "Force Snap"
force.Author = "Truce"
force.Description = "Snap"
force.id = "snap"
force.Icon = "kybercore/snap.png"
force.StartUse = function( ply )
	local Time = CurTime()
	local CanDo = (ply.KyberCorePower_Force_Propulsion_Timer or 0) < Time
	if not CanDo then return end
	ply.KyberCorePower_Force_Propulsion_Timer = Time + 0.1
	ply:lscsTakeForce( 1 ) -- take amount of force we need

	
	local tr = util.TraceLine( util.GetPlayerTrace( ply ) )
	local pos = tr.HitPos
	local pi = math.pi
	local bullet = {}
	bullet.Num 		= 1
	bullet.Spread 	= Vector( 0, 0, 0 )
	bullet.Tracer	= 1
	bullet.Force	= 0						
	bullet.Damage	= 10000
	bullet.AmmoType = "Pistol"
	bullet.Entity = ply
	bullet.IgnoreEntity = ply

	ply:EmitSound( "wos/force_snap.wav" )
	LSCS:PlayVCDSequence(ply, "wos_cast_choke", 0.6)
	local ed = EffectData()
	ed:SetEntity( ply )
	ed:SetScale( 0.4 )

	timer.Simple( 0.2*0.2, function()
		if not IsValid( ply ) then return end
		bullet.Src 		= ply:GetShootPos()
		bullet.Dir 		= ply:GetAimVector()
		ply:FireBullets( bullet )

		for i=1, 6 do
			timer.Simple( 0.003*i, function()
				if not IsValid( ply ) then return end
				if not ply:Alive() then return end
				ply:EmitSound( "" )
			end )
		end
	end )
	return true
end
LSCS:RegisterForce( force )

// ============================================================================== //
//                                                                                //
//                          		Telekinetic Assault					      	//
//                                                                                //
// ============================================================================== //


local force = {}
force.PrintName = "Telekinetic Assault"
force.Author = "Solace"
force.Description = "Throw a chunk of earth"
force.id = "sfrockthrow"
force.Icon = "entities/item_force_boulderthrow.png"
force.OnClk =  function( ply, TIME )
	if ply.HoldingRock then
		ply:lscsTakeForce()
	end
end
force.StartUse = function( ply )
	local Time = CurTime()
	
	ply._rock = nil
	ply._rockphys = nil
	ply.HoldingRock = false
	
	local CanThrow = (ply._lscsNextForce or 0) < Time
	if not CanThrow then return end
	
	if ply:lscsGetForce() < 40 then return end
	
	ply._lscsNextForce = Time + 3
	ply.HoldingRock = true

	ply:lscsTakeForce( 40 )
	ply:EmitSound("physics/concrete/boulder_impact_hard4.wav")
	LSCS:PlayVCDSequence( ply, "gesture_becon", 0.8 )
	
	ply._rock = ents.Create ("sf_rock")
	
	local v = ply:GetPos()
	v = v + ply:GetForward() * 50
	v = v + ply:GetRight() * 50
	v = v + ply:GetUp() * 20
	ply._rock:SetPos( v )
	
	ply._rock:SetAngles(Angle(math.Rand(0,180), math.Rand(0,180), math.Rand(0,180)))
	ply._rock:SetOwner(ply)
	ply._rock:Spawn()
	
	ply._rockphys = ply._rock:GetPhysicsObject()
	ply._rockphys:SetVelocity(Vector(0,0,500))
	
	timer.Simple(0.1, function() ply._rock:SetPos( v + Vector(0,0,60) ) end)
	
end
force.StopUse = function( ply )
	if ply._rock then
		ply:EmitSound("lscs/force/push.mp3")
		LSCS:PlayVCDSequence( ply, "gesture_item_throw", 0.5 )
		ply.HoldingRock = false
		ply._rock.DieTime = CurTime() + 5
		ply._rock.IsThrown = true
		local TargetPos = ply:GetEyeTrace().HitPos
		local Sub = (TargetPos-ply._rock:GetPos()):GetNormalized()
		ply._rockphys:SetVelocity((Sub * 3000) + Vector(0,0,200))
		ply._rockphys:EnableGravity( true )
		ply._rockphys:EnableDrag( true )
	end
end
LSCS:RegisterForce( force )


// ============================================================================== //
//                                                                                //
//                          		Auto Parry					          		  //
//                                                                                //
// ============================================================================== //

local force = {}
force.PrintName = "Auto Parry"
force.Author = "Stoneman"
force.Description = "Fine. I'll parry this."
force.id = "autoparry"
force.Icon = "entities/item_force_boulderthrow.png"
force.StartUse =  function( ply, TIME )
	ply.KyberCorePower_AutoParry = !ply.KyberCorePower_AutoParry
	if ply.KyberCorePower_AutoParry then
		ply:ChatPrint( "You are temporarily a parry god." )
	else
		ply:ChatPrint( "You are no longer a parry god." )
	end
end
LSCS:RegisterForce( force )




// ============================================================================== //
//                                                                                //
//                          		Genji						          		  //
//                                                                                //
// ============================================================================== //

local force = {}
force.PrintName = "Genji"
force.Author = "Truce"
force.Description = "Lob a boulder at your foe"
force.id = "genji"
force.Icon = "kybercore/gwobus.png"
force.StartUse = function( ply )

	LSCS:PlayVCDSequence( ply, "wos_genji_dance", 0.001 )

end
LSCS:RegisterForce( force )

// ============================================================================== //
//                                                                                //
//                          		GunSaber			               			  //
//                                                                                //
// ============================================================================== //
local force = {}
force.PrintName = "GunSaber"
force.Author = "Truce"
force.Description = "GunSaber"
force.id = "gunsaber"
force.Icon = "entities/item_saberhilt_gunh.png"
force.StartUse = function( ply )
	if ply:lscsGetForce() < 5 then return end
	local Time = CurTime()

	local CanDo = (ply.KyberCorePower_gunsaber or 0) < Time

	if not CanDo then return end
	ply:lscsTakeForce( 5 ) -- take amount of force we need
	ply.KyberCorePower_gunsaber = Time + 0.1
	// Does nothing else but play a sound and do massive damage.
	

	// Play animation
	LSCS:PlayVCDSequence( ply, "run_revolver", 0.01 )
	ply:EmitSound( "w/westar35.wav" )
	// Shoots bullet
	local bullet = {}
	bullet.Num 		= 1
	bullet.Spread 	= Vector( 0, 0, 0 )
	bullet.Tracer	= 1
	bullet.Force	= 100
	bullet.Damage	= 25
	bullet.AmmoType = "Pistol"
	bullet.Entity = ply
	bullet.IgnoreEntity = ply
	bullet.TracerName = "rw_sw_laser_red"
	bullet.Src 		= ply:GetShootPos()
	bullet.Dir 		= ply:GetAimVector()
	ply:FireBullets( bullet )

end
LSCS:RegisterForce( force )

// ============================================================================== //
//                                                                                //
//                          		Give Cancer 		          		  		  //
//                                                                                //
// ============================================================================== //
local force = {}
force.PrintName = "Give Cancer"
force.Author = "Stoneman"
force.Description = "i cast cancer"
force.id = "cancer"
force.Icon = "entities/item_saberhilt_gunh.png"
force.StartUse = function( ply )
	local tr = util.TraceHull( {
		start = ply:EyePos(),
		endpos = ply:EyePos() + ply:GetAimVector()*600,
		maxs = Vector( 16, 16, 16 ),
		mins = Vector( -16, -16, -16 ),
		filter = ply
	} )

	if not IsValid( tr.Entity ) then return end
	local target = tr.Entity

	local organs = {
		"Lung",
		"Breast",
		"Prostate",
		"Colon",
		"Pancreas",
		"Liver",
		"Kidney",
		"Stomach",
		"Intestine",
		"Heart",
		"Bladder",
		"Esophagus",
		"Thyroid",
		"Skin",
		"Bone",
		"Brain",
		"Blood",
		"Lymph Node",
		"Gallbladder",
		"Adrenal Gland",
		"Appendix",
		"Spleen",
	}


	local randomorgan = organs[ math.random( 1, #organs ) ]

	target:ChatPrint("You now have ".. randomorgan .. " cancer")
	ply:ChatPrint("You have given ".. target:GetName() .. " " .. randomorgan .. " cancer")
	target:ChatPrint("It's starting to hurt to move....")

	local cancerTimer = "KyberCoreCancer_" .. target:EntIndex()
	timer.Create( cancerTimer, 3, 30, function()
		if not IsValid( target ) then timer.Remove( cancerTimer ) return end
		if not target:Alive() then timer.Remove( cancerTimer ) return end
		local random = math.random( 1, 100 )
		target:EmitSound("ambient/voices/cough"..math.random(1,4)..".wav", 75, 100)

		if random > 40 and random < 60 then
			target:EmitSound("npc/zombie/zombie_pain"..math.random(1,6)..".wav", 90, 80)
		end

		if random > 60 and random < 80 then
			target:SetNWBool("StonemanMindTricked", true)
			timer.Simple( 3, function()
				if not IsValid( target ) then return end
				target:SetNWBool("StonemanMindTricked", false)
			end )
		end

		// Force them to crouch, from chronic back pain
		if random > 80 and random < 100 then
			target:AddFlags( FL_DUCKING )

			timer.Simple( 3, function()
				if not IsValid( target ) then return end
				target:RemoveFlags( FL_DUCKING )
			end )
		end

		util.ScreenShake(target:GetPos(), 10, 5, 0.3, 128, true, target)

		target:TakeDamage( 20 )
	end )
end
LSCS:RegisterForce( force )