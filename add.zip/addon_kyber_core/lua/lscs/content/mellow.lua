local ENTITY = FindMetaTable('Entity')
function ENTITY:RemoveAura()
    self:StopParticles()
end

/*
    Args:
        1 - Name - string - The name of the particle effect to attach.
        2 - Time - number - The time in seconds to remove the particle effect.
    Example:
        ply:CreateAura('[1]_Particle_Name', time)
*/
function ENTITY:CreateAura(name, time)
    self:RemoveAura()
    ParticleEffectAttach(name, PATTACH_POINT_FOLLOW, self, 0)
    if time then
        timer.Simple(time, function()
            if IsValid(self) then
                self:RemoveAura()
            end
        end)
    end
end
hook.Add("PlayerSay", "createAura", function(ply, text) // remove if dont need
    local cmd = string.Explode(" ", text)
    if cmd[1] == "/aura" then
        local who = cmd[2]
        if who == "^" then
            who = ply
        elseif who == "@" then
            who = ply:GetEyeTrace().Entity
        else
            who = player.GetBySteamID(who)
        end
        local name = cmd[3]
        local time = tonumber(cmd[4])
        local e = scripted_ents.Get(name) and scripted_ents.Get(name).pfxname or name
        if who and time and isnumber(time) and time > 0 then
            who:CreateAura(e, time)
        elseif name then
            who:CreateAura(e)
        end
    end
    if cmd[1] == "/removeaura" then
        local who = cmd[2]
        if who == "^" then
            who = ply
        elseif who == "@" then
            who = ply:GetEyeTrace().Entity
        else
            who = player.GetBySteamID(who)
        end
        who:RemoveAura()
    end
end)
  
// ============================================================================== //
//                                                                                //
//                          		Force Shockwave  		               		  //
//                                                                                //
// ============================================================================== //


local force = {}
force.PrintName = "Force Shockwave"
force.Author = "Mellow"
force.Description = "Unleashes a lightning burst, striking nearby enemies with arcs of blue lightning."
force.id = "forceshockwave"
force.Icon = "entities/item_force_fuck.png"

force.StartUse = function(ply)
    if ply.NextShockwave and ply.NextShockwave > CurTime() then return end

    -- Run chat command for the lightning ring aura
    ply:ConCommand("say /aura ^ electro_ring")

    local radius = 300
    local damageAmount = 800
    local origin = ply:GetPos() + Vector(0, 0, 36)

    -- Central burst visual effect
    local ed = EffectData()
    ed:SetOrigin(origin)
    ed:SetRadius(radius)
    util.Effect("cball_explode", ed, true, true)
    util.ScreenShake(origin, 5, 5, 0.5, radius)

    for _, ent in pairs(ents.FindInSphere(origin, radius)) do
        if ent == ply then continue end
        if not (ent:IsPlayer() or ent:IsNPC()) then continue end
        if not ent:Alive() then continue end

        -- Deal shock damage
        local dmg = DamageInfo()
        dmg:SetDamage(damageAmount)
        dmg:SetDamageType(DMG_SHOCK)
        dmg:SetAttacker(ply)
        dmg:SetInflictor(ply)
        ent:TakeDamageInfo(dmg)

        -- Spark effect on hit target
        local spark = EffectData()
        spark:SetOrigin(ent:GetPos() + Vector(0, 0, 40))
        util.Effect("ElectricSpark", spark, true, true)

      
    end

    ply.NextShockwave = CurTime() + 5
end

force.OnClk = function(ply, TIME) end
force.StopUse = function(ply) end

LSCS:RegisterForce(force)

// ============================================================================== //
//                                                                                //
//                          		Force Crush      		               		  //
//                                                                                //
// ============================================================================== //

local force = {}
force.PrintName = "Force Crush"
force.Author = "Mellow"
force.Description = "Lifts and crushes a single enemy using the Force."
force.id = "forcecrush"
force.Icon = "kybercore/diam.png"

local CRUSH_DURATION = 6 -- seconds
local DAMAGE_PER_TICK = 17.5
local TICK_RATE = 0.5

force.StartUse = function(ply)
    if ply.NextCrush and ply.NextCrush > CurTime() then return end

    local tr = util.TraceLine(util.GetPlayerTrace(ply))
    local target = tr.Entity

    if not IsValid(target) then return end
    if not (target:IsNPC() or target:IsPlayer()) then return end
    if target == ply then return end
    if target:GetPos():Distance(ply:GetPos()) > 500 then return end

    ply.NextCrush = CurTime() + 3

    -- Lift the target
    local liftPos = target:GetPos() + Vector(0, 0, 20)
    target:SetMoveType(MOVETYPE_NONE)
    target:SetPos(liftPos)

    -- VJ-compatible flinch trigger
    local flinchDmg = DamageInfo()
    flinchDmg:SetDamage(1)
    flinchDmg:SetDamageType(DMG_GENERIC)
    flinchDmg:SetAttacker(ply)
    target:TakeDamageInfo(flinchDmg)

    local elapsed = 0
    local crushSound = "physics/body/body_medium_break2.wav"
    local id = "ForceCrush_" .. target:EntIndex()

    timer.Create(id, TICK_RATE, CRUSH_DURATION / TICK_RATE, function()
        if not IsValid(target) then timer.Remove(id) return end
        if not target:Alive() then timer.Remove(id) return end

        target:EmitSound(crushSound, 75, 100)

        local eff = EffectData()
        eff:SetOrigin(target:GetPos() + Vector(0, 0, 40))
        util.Effect("dismemberment", eff, true, true)

        local dmg = DamageInfo()
        dmg:SetAttacker(ply)
        dmg:SetDamageType(DMG_CRUSH)
        dmg:SetInflictor(ply)
        dmg:SetDamage(DAMAGE_PER_TICK)
        target:TakeDamageInfo(dmg)

        elapsed = elapsed + TICK_RATE

        if elapsed >= CRUSH_DURATION then
            target:SetMoveType(MOVETYPE_STEP)

            if not target:Alive() then
                local burstPos = target:GetPos() + Vector(0, 0, 40)

                -- Final blood burst
                for i = 1, 6 do
                    local eff = EffectData()
                    eff:SetOrigin(burstPos + VectorRand() * 10)
                    util.Effect("BloodImpact", eff, true, true)
                end

                util.ScreenShake(burstPos, 25, 150, 0.75, 300)

                if not target:IsPlayer() then
                    local rag = ents.Create("prop_ragdoll")
                    rag:SetModel(target:GetModel())
                    rag:SetPos(target:GetPos())
                    rag:SetAngles(target:GetAngles())
                    rag:Spawn()

                    -- Pose the ragdoll by manipulating bone angles
                    for i = 0, rag:GetBoneCount() - 1 do
                        rag:ManipulateBoneAngles(i, AngleRand(-90, 90))
                    end

                    -- Apply random force to make it flop dramatically
                    timer.Simple(0.1, function()
                        if IsValid(rag) then
                            for i = 0, rag:GetPhysicsObjectCount() - 1 do
                                local bone = rag:GetPhysicsObjectNum(i)
                                if IsValid(bone) then
                                    bone:ApplyForceCenter(VectorRand() * 200 + Vector(0, 0, -400))
                                end
                            end
                        end
                    end)

                    target:Remove()
                end
            end
        end
    end)
end

force.OnClk = function(ply, TIME)
    -- No hold behavior
end

force.StopUse = function(ply)
    -- No cleanup needed
end

LSCS:RegisterForce(force)

// ============================================================================== //
//                                                                                //
//                          		Chain Lightning (DNT)               		  //
//                                                                                //
// ============================================================================== //

local force = {}
force.PrintName = "Chain Lightning"
force.Author = "Mellow"
force.Description = "Launches a burst of purple lightning that chains between multiple enemies."
force.id = "chainlightning"
force.Icon = "kybercore/lightning.png"

-- CONFIGURABLE SETTINGS
local MAX_TARGETS = 5
local CHAIN_RADIUS = 250
local BASE_DAMAGE = 200
local DAMAGE_DECAY = 0.75
local LIGHTNING_EFFECT = "wos_emerald_lightning"
local ZAP_SOUND = "ambient/energy/zap9.wav"

-- Find next enemy to chain to
local function FindNextChainTarget(fromPos, excluded, ply)
    local nearby = ents.FindInSphere(fromPos, CHAIN_RADIUS)
    local closest, closestDist
    for _, ent in ipairs(nearby) do
        if not IsValid(ent) or not (ent:IsNPC() or ent:IsPlayer()) then continue end
        if table.HasValue(excluded, ent) then continue end
        if ent == ply then continue end
        if ent:Health() <= 0 then continue end

        local dist = fromPos:DistToSqr(ent:GetPos())
        if not closestDist or dist < closestDist then
            closest = ent
            closestDist = dist
        end
    end
    return closest
end

force.StartUse = function(ply)
    if ply.NextChainLightning and ply.NextChainLightning > CurTime() then return end

    local tr = util.TraceLine(util.GetPlayerTrace(ply))
    local firstTarget = tr.Entity
    if not IsValid(firstTarget) or not (firstTarget:IsNPC() or firstTarget:IsPlayer()) then return end
    if firstTarget == ply then return end
    if ply:GetPos():Distance(firstTarget:GetPos()) > 500 then return end

    ply.NextChainLightning = CurTime() + 3

    local targets = { firstTarget }
    local currentPos = firstTarget:GetPos()
    local currentDmg = BASE_DAMAGE

    while #targets < MAX_TARGETS do
        local nextTarget = FindNextChainTarget(currentPos, targets, ply)
        if not nextTarget then break end
        table.insert(targets, nextTarget)
        currentPos = nextTarget:GetPos()
    end

    for i, target in ipairs(targets) do
        timer.Simple(0.05 * (i - 1), function()
            if not IsValid(target) then return end

            local damage = BASE_DAMAGE * (DAMAGE_DECAY ^ (i - 1))
            local dmg = DamageInfo()
            dmg:SetAttacker(IsValid(ply) and ply or game.GetWorld())
            dmg:SetInflictor(IsValid(ply) and ply or game.GetWorld())
            dmg:SetDamageType(DMG_SHOCK)
            dmg:SetDamage(damage)
            target:TakeDamageInfo(dmg)

            local fromEnt = (i == 1 and ply or targets[i - 1])
            local fromPos
            if fromEnt == ply then
                fromPos = ply:EyePos()
            else
                fromPos = fromEnt:WorldSpaceCenter()
            end
            local toPos = target:WorldSpaceCenter()

            -- Effect and tracer
            local eff = EffectData()
            eff:SetStart(fromPos)
            eff:SetOrigin(toPos)
            eff:SetEntity(target)
            eff:SetMagnitude(1)
            eff:SetScale(1)
            eff:SetRadius(1)
            util.Effect(LIGHTNING_EFFECT, eff, true, true)

            -- Dynamic light
            local dlight = DynamicLight(target:EntIndex())
            if dlight then
                dlight.pos = toPos
                dlight.r = 150
                dlight.g = 0
                dlight.b = 255
                dlight.brightness = 4
                dlight.Decay = 512
                dlight.Size = 256
                dlight.DieTime = CurTime() + 0.3
            end

            -- Sound and shake
            sound.Play(ZAP_SOUND, toPos, 90, 110, 1)
            util.ScreenShake(toPos, 3, 5, 0.25, 150)
        end)
    end
end

force.OnClk = function(ply, TIME) end
force.StopUse = function(ply) end

LSCS:RegisterForce(force)

// ============================================================================== //
//                                                                                //
//                          		Lightning Aura  		               		  //
//                                                                                //
// ============================================================================== //
hook.Add("PlayerSay", "HideAuraCommands", function(ply, text)
    if string.StartWith(string.lower(text), "/aura") then return "" end
end)


local force = {}
force.PrintName = "Lightning Aura"
force.Author = "Mellow"
force.Description = "Empowers you with crackling electricity, boosting speed and health."
force.id = "lightningaura"
force.Icon = "kybercore/lightning.png"

local AURA_DURATION = 20
local SPEED_BOOST = 350
local HEALTH_BOOST = 100
local CHAT_COMMAND = "say /aura ^ electro_aura 20"

force.StartUse = function(ply)
    if not IsValid(ply) then return end
    if ply.NextAura and ply.NextAura > CurTime() then return end

    ply.NextAura = CurTime() + AURA_DURATION + 5

    -- Run hidden chat command
    ply:ConCommand(CHAT_COMMAND)

    -- Buffs
    local originalHealth = ply:Health()
    local maxHealth = ply:GetMaxHealth()
    ply:SetHealth(math.min(originalHealth + HEALTH_BOOST, maxHealth + HEALTH_BOOST))
    ply:SetWalkSpeed(ply:GetWalkSpeed() + SPEED_BOOST)
    ply:SetRunSpeed(ply:GetRunSpeed() + SPEED_BOOST)

    -- Revert buffs after duration
    timer.Simple(AURA_DURATION, function()
        if not IsValid(ply) then return end
        ply:SetWalkSpeed(ply:GetWalkSpeed() - SPEED_BOOST)
        ply:SetRunSpeed(ply:GetRunSpeed() - SPEED_BOOST)
        ply:SetHealth(math.min(ply:Health(), maxHealth))
    end)
end

force.OnClk = function(ply, TIME) end
force.StopUse = function(ply) end

LSCS:RegisterForce(force)

// ============================================================================== //
//                                                                                //
//                          		Flaming Aura    		               		  //
//                                                                                //
// ============================================================================== //


local force = {}
force.PrintName = "Flaming Aura"
force.Author  = "Mellow"
force.Description = "Engulfs you in flames, boosting health but slowing movement."
force.id   = "flamingaura"
force.Icon = "kybercore/flame.png"

local AURA_DURATION = 10
local SPEED_PENALTY = 50   -- how much to slow the player (positive number)
local HEALTH_BOOST  = 200
local CHAT_COMMAND  = "say /aura ^ fire_aura_3 10"

force.StartUse = function(ply)
    if not IsValid(ply) then return end
    if ply.NextAura and ply.NextAura > CurTime() then return end

    ply.NextAura = CurTime() + AURA_DURATION + 5

    -- trigger the aura particle via chat command
    ply:ConCommand(CHAT_COMMAND)

    -- record original speeds
    local originalWalk = ply:GetWalkSpeed()
    local originalRun  = ply:GetRunSpeed()

    -- apply buffs / debuffs
    ply:SetHealth(math.min(ply:Health() + HEALTH_BOOST,
                           ply:GetMaxHealth() + HEALTH_BOOST))

    ply:SetWalkSpeed(originalWalk - SPEED_PENALTY)
    ply:SetRunSpeed(originalRun  - SPEED_PENALTY)

    -- revert everything after the duration
    timer.Simple(AURA_DURATION, function()
        if not IsValid(ply) then return end
        ply:SetWalkSpeed(originalWalk)
        ply:SetRunSpeed(originalRun)
        ply:SetHealth(math.min(ply:Health(), ply:GetMaxHealth()))
    end)
end

force.OnClk  = function(ply, TIME) end
force.StopUse = function(ply) end

LSCS:RegisterForce(force)

// ============================================================================== //
//                                                                                //
//                          		Vladvari Aura		 	              		  //
//                                                                                //
// ============================================================================== //


local force = {}
force.PrintName = "Vlad'vari Aura"
force.Author = "Mellow"
force.Description = "Engulfs you in the aura of an ancient one, making you an impenetrable fortress."
force.id = "cursed_aura"
force.Icon = "kybercore/flame.png"

local AURA_DURATION = 10
local SPEED_PENALTY = -75 -- Negative to reduce speed
local HEALTH_BOOST = 560
local CHAT_COMMAND = "say /aura ^ cursed_aura 10"

force.StartUse = function(ply)
    if not IsValid(ply) then return end
    if ply.NextAura and ply.NextAura > CurTime() then return end

    ply.NextAura = CurTime() + AURA_DURATION + 5

    -- Run hidden chat command
    ply:ConCommand(CHAT_COMMAND)

    -- Buffs
    local originalHealth = ply:Health()
    local maxHealth = ply:GetMaxHealth()
    ply:SetHealth(math.min(originalHealth + HEALTH_BOOST, maxHealth + HEALTH_BOOST))
    ply:SetWalkSpeed(ply:GetWalkSpeed() + SPEED_PENALTY)
    ply:SetRunSpeed(ply:GetRunSpeed() + SPEED_PENALTY)

    -- Revert buffs after duration
    timer.Simple(AURA_DURATION, function()
        if not IsValid(ply) then return end
        ply:SetWalkSpeed(ply:GetWalkSpeed() - SPEED_PENALTY)
        ply:SetRunSpeed(ply:GetRunSpeed() - SPEED_PENALTY)
        ply:SetHealth(math.min(ply:Health(), maxHealth))
    end)
end

force.OnClk = function(ply, TIME) end
force.StopUse = function(ply) end

LSCS:RegisterForce(force)

// ============================================================================== //
//                                                                                //
//                          		Group Choke     		               		  //
//                                                                                //
// ============================================================================== //

local groupChoke = {}
groupChoke.PrintName = "Group Choke"
groupChoke.Author = "Mellow"
groupChoke.Description = "Chokes multiple enemies around you, immobilizing and lightly damaging them."
groupChoke.id = "groupchoke"
groupChoke.Icon = "kybercore/soft_cho.png"

local CHOKE_RADIUS = 400
local MAX_TARGETS = 5

groupChoke.StartUse = function(ply)
    if not IsValid(ply) then return end
    ply.StoneOSPower_GroupChoke = true
    ply.StoneOSGroupChokeTargets = {}

    local found = 0
    for _, ent in ipairs(ents.FindInSphere(ply:GetPos(), CHOKE_RADIUS)) do
        if found >= MAX_TARGETS then break end
        if ent == ply then continue end
        if not IsValid(ent) then continue end
        if not ent:IsPlayer() and not ent:IsNPC() then continue end
        if not ent:Alive() then continue end
        if ent.IsStonemanDroids then continue end

        table.insert(ply.StoneOSGroupChokeTargets, ent)
        found = found + 1

        ent:EmitSound("kybercore/jinx.wav")

        ent.StoneOS_ChokeOrigin = ent:GetPos()
        ent.StoneOS_ChokeSound = CreateSound(ent, "kybercore/jinx.wav")
        if ent.StoneOS_ChokeSound then ent.StoneOS_ChokeSound:Play() end

        if ent:IsPlayer() then
            LSCS:PlayVCDSequence(ent, "wos_force_choke", 0)
        else
            -- NPC animation override fallback (not all NPCs have VCDs)
            ent:SetSchedule(SCHED_BIG_FLINCH)
        end

        timer.Create("GroupChokeTimers_" .. ent:EntIndex(), 1.6, 0, function()
            if IsValid(ent) then
                if ent:IsPlayer() then
                    LSCS:PlayVCDSequence(ent, "wos_force_choke", 0)
                else
                    ent:SetSchedule(SCHED_BIG_FLINCH)
                end
            end
        end)
    end
end

groupChoke.StopUse = function(ply)
    if not ply.StoneOSGroupChokeTargets then return end

    for _, ent in ipairs(ply.StoneOSGroupChokeTargets) do
        if IsValid(ent) then
            timer.Remove("GroupChokeTimers_" .. ent:EntIndex())
            if ent:IsPlayer() then
                LSCS:PlayVCDSequence(ent, "wos_force_choke", 1.6)
            end
            if ent.StoneOS_ChokeSound then
                ent.StoneOS_ChokeSound:Stop()
                ent.StoneOS_ChokeSound = nil
            end
        end
    end

    ply.StoneOSGroupChokeTargets = nil
    ply.StoneOSPower_GroupChoke = false
end

groupChoke.OnClk = function(ply)
    if not ply.StoneOSGroupChokeTargets or #ply.StoneOSGroupChokeTargets == 0 then return end
    if ply:lscsGetForce() < 1 then return end

    for _, ent in ipairs(ply.StoneOSGroupChokeTargets) do
        if not IsValid(ent) or not ent:Alive() then continue end

        local dmg = DamageInfo()
        dmg:SetDamage(1)
        dmg:SetDamageType(DMG_CRUSH)
        dmg:SetAttacker(ply)
        dmg:SetInflictor(ply)
        ent:TakeDamageInfo(dmg)

        local pos = ent.StoneOS_ChokeOrigin or ent:GetPos()
        ent:SetLocalVelocity((pos - ent:GetPos() + Vector(0, 0, 55)) * 5)

        ent:SetNW2Float("wOS.ChokeTime", CurTime() + 0.5)
        ent:SetNW2Float("wOS.SaberAttackDelay", CurTime() + 0.5)
    end

    LSCS:PlayVCDSequence(ply, "wos_cast_choke", 0)
    ply:SetNW2Float("wOS.ForceAnim", CurTime() + 0.1)
    ply:lscsTakeForce(0.75)
end

LSCS:RegisterForce(groupChoke)

// ============================================================================== //
//                                                                                //
//                          		Group Lightning   		               		  //
//                                                                                //
// ============================================================================== //

local MAX_TARGETS = 4
local CONE_ANGLE = 60
local LIGHTNING_RANGE = 1000

local function ForceFry(ply, TIME)
    local MyPos = ply:GetShootPos()
    local AimVector = ply:GetAimVector()
    local Force = AimVector * 100
    local targets = {}

    for _, ent in ipairs(ents.FindInSphere(MyPos, LIGHTNING_RANGE)) do
        if #targets >= MAX_TARGETS then break end
        if ent == ply then continue end
       if not IsValid(ent) or not (ent:IsPlayer() or ent:IsNPC() or ent:IsNextBot()) or (ent.Alive and not ent:Alive()) then continue end


        local ToTarget = (ent:WorldSpaceCenter() - MyPos):GetNormalized()
        local angle = math.deg(math.acos(math.Clamp(AimVector:Dot(ToTarget), -1, 1)))
        if angle <= CONE_ANGLE then
            local trace = util.TraceLine({
                start = MyPos,
                endpos = ent:WorldSpaceCenter(),
                mask = MASK_SHOT,
                filter = ply
            })
            if trace.Entity == ent then
                table.insert(targets, ent)
            end
        end
    end

    for _, target in ipairs(targets) do
        local startPos = ply:GetAttachment(ply:LookupAttachment("anim_attachment_RH"))
        startPos = startPos and startPos.Pos or ply:GetShootPos()

        local endPos = target:WorldSpaceCenter()

        -- Emerald Lightning visual
        local effect = EffectData()
        effect:SetStart(startPos)
        effect:SetOrigin(endPos)
        effect:SetEntity(ply)
        util.Effect("wos_group_lightning", effect, true, true)

        -- Damage application
        local dmginfo = DamageInfo()
        dmginfo:SetDamage(5)
        dmginfo:SetAttacker(ply)
        dmginfo:SetInflictor(ply)
        dmginfo:SetDamageType(bit.bor(DMG_SHOCK, DMG_BULLET))
        dmginfo:SetDamagePosition(endPos)
        dmginfo:SetDamageForce(Force)
        target:TakeDamageInfo(dmginfo)

        target:EmitSound("Weapon_StunStick.Activate")

        -- Delay check for ragdoll zap
        timer.Simple(0.1, function()
            if not IsValid(target) then return end

            -- Try to find the ragdoll created if they died
            for _, ent in ipairs(ents.FindInSphere(target:GetPos(), 64)) do
                if ent:GetClass() == "prop_ragdoll" and not ent._lscsBoogieTime then
                    ent:Fire("StartRagdollBoogie")

                    ent._lscsBoogieTime = TIME + 6

                    for i = 1, 70 do
                        if math.random(1, 5) == 1 then continue end

                        timer.Simple(i * 0.1, function()
                            if not IsValid(ent) then return end

                            local zap = EffectData()
                            zap:SetEntity(ent)
                            zap:SetMagnitude(30)
                            zap:SetScale(30)
                            zap:SetRadius(30)
                            util.Effect("TeslaHitBoxes", zap)
                            ent:EmitSound("Weapon_StunStick.Activate")
                        end)
                    end
                end
            end
        end)
    end
end

local force = {}
force.PrintName = "Group Lightning"
force.Author = "Mellow"
force.Description = "A Dark Side ability that fires Lightning Bolts out of your Hand"
force.id = "grouplightning"
force.Icon = "entities/item_force_lightning.png"
force.OnClk =  function( ply, TIME )
	if not ply._lscsgroupLightningTime then return end

	ply:lscsTakeForce( 2 )

	ForceFry( ply, TIME )

	if ply._lscsgroupLightningStartTime < TIME then
		LSCS:PlayVCDSequence( ply, "gesture_item_give", 0.7 )
	end

	if ply._lscsgroupLightningTime < TIME or ply:lscsGetForce() <= 0 or not ply:Alive() or ply:GetObserverMode() ~= OBS_MODE_NONE then
		ply._lscsgroupLightningTime = nil
		ply._lscsgroupLightningStartTime = nil
	end
end
force.Equip = function( ply ) end
force.UnEquip = function( ply ) end
force.StartUse = function( ply )
	local Time = CurTime()

	if (ply._lscsgroupLightningTime or 0) > Time then
		ply._lscsgroupLightningTime = nil
		ply._lscsgroupLightningStartTime = nil

		return
	end

	if ply:lscsGetForce() < 10 then return end

	local CanDo = (ply._lscsNextForce or 0) < Time and (ply._lscsgroupLightningTime or 0) < Time

	if not CanDo then return end

	ply._lscsNextForce = Time + 2

	ply:EmitSound("lscs/force/lightning.mp3")

	ply:lscsTakeForce( 5 )

	ForceFry( ply, Time )

	if not ply._lscsgroupLightningTime then
		ply._lscsgroupLightningTime = CurTime() + 5
		ply._lscsgroupLightningStartTime = CurTime() + 0.15

		LSCS:PlayVCDSequence( ply, "gesture_signal_forward", 0.1 )
	end
end
force.StopUse = function( ply )
	ply._lscsgroupLightningTime = nil
end
LSCS:RegisterForce( force )

if SERVER then
	hook.Add( "LSCS:PlayerCanManipulate", "!!!lscs_forceblocking", function( ply, target_ent, ignore_passive )
		if not target_ent.IsPlayer or not target_ent:IsPlayer() then return end

		if target_ent:GetNWBool( "_lscsForceProtect", false ) then
			target_ent:lscsSetForce( math.min(target_ent:lscsGetForce() + 15, target_ent:lscsGetMaxForce()) )

			local effectdata = EffectData()
				effectdata:SetOrigin( target_ent:GetPos() )
				effectdata:SetEntity( target_ent )
			util.Effect( "force_block", effectdata, true, true )

			target_ent:EmitSound("lscs/force/block.mp3")
			LSCS:PlayVCDSequence( target_ent, "walk_magic" )

			return true
		end

		if ignore_passive then return end

		if target_ent._lscsForceResistant and target_ent:lscsGetForce() > 50 then
			LSCS:PlayVCDSequence( target_ent, "walk_magic" )

			return true
		end
	end )
else
	local zoom_mat = Material( "vgui/zoom" )
	local warp = Material("effects/tp_eyefx/tpeye3")

	hook.Add( "HUDPaint", "!lscs_senseoverlay", function()
		local ply = LocalPlayer()

		if not ply:GetNWBool( "_lscsForceSense", false ) then return end

		local X = ScrW()
		local Y = ScrH()

		surface.SetDrawColor( Color(255,255,255,255) )
		surface.SetMaterial( zoom_mat ) 
		surface.DrawTexturedRectRotated( X + X * 0.5, Y * 0.5, X, Y, 0 )
		surface.DrawTexturedRectRotated( X + X * 0.5, Y + Y * 0.5, Y, X, 270 )
		surface.DrawTexturedRectRotated( X * 0.5, Y * 0.5, Y, X, 90 )
		surface.DrawTexturedRectRotated( X * 0.5, Y + Y * 0.5, X, Y, 180 )
	
		surface.SetMaterial( warp ) 
		surface.DrawTexturedRect( 0, 0, X, Y )
	end )

	hook.Add( "HUDPaint", "!lscs_protectoverlay", function()
		local ply = LocalPlayer()

		if not ply:GetNWBool( "_lscsForceProtect", false ) then return end

		local X = ScrW()
		local Y = ScrH()
	
		surface.SetDrawColor(0, 127, 255, 25)
		surface.DrawRect( 0, 0, X, Y )
	end )

	
	local function StencilMagic( renderfunction, Col )
		render.SetStencilWriteMask( 0xFF )
		render.SetStencilTestMask( 0xFF )
		render.ClearStencil()

		render.SetStencilEnable( true )
		render.SetStencilReferenceValue( 1 )
		render.SetStencilCompareFunction( STENCIL_ALWAYS )
		render.SetStencilPassOperation( STENCILOPERATION_REPLACE )
		render.SetStencilZFailOperation( STENCILOPERATION_REPLACE )

		renderfunction()

		render.SetStencilCompareFunction( STENCIL_EQUAL )
		render.ClearBuffersObeyStencil(Col.r, Col.g, Col.b, Col.a , false)

		render.SetStencilEnable( false )
	end

	hook.Add("PostDrawOpaqueRenderables", "!!!!lscs_playertrackerwallhack", function( bDrawingDepth, bDrawingSkybox, isDraw3DSkybox )
		if isDraw3DSkybox then return end

		local ply = LocalPlayer()

		if not ply:GetNWBool( "_lscsForceSense", false ) then return end

		StencilMagic( 
			function()
				for _, ent in pairs( ents.GetAll() ) do
					if ent == ply then continue end

					if not ent.IsNPC or not ent.IsNextBot or not ent.IsPlayer then continue end

					if not ent:IsNPC() and not ent:IsNextBot() and not ent:IsPlayer() then continue end

					if ent.Alive and not ent:Alive() then continue end -- doesnt do shit on npc's ...
					if ent.Health and ent:Health() <= 0 then continue end -- doesnt do shit on npc's ...
					if ent.GetMoveType and ent:GetMoveType() == MOVETYPE_NONE then continue end -- this works for npc's
					if ent:GetNWBool( "Administrated", false ) then
						if ent:GetNWBool("KyberCorePowers_Cloak") then
							ent:DrawModel()
							continue
						else
							continue
						end
					end
					ent:DrawModel()
				end
			end,
			Color(255,200,0,255)
		)
	end)
end
  
  
// ============================================================================== //
//                                                                                //
//                          		Lightning Overclock		               		  //
//                                                                                //
// ============================================================================== //

local force = {}
force.PrintName = "Lightning Overclock"
force.Author = "Mellow"
force.Description = "Surges your body with unstable lightning, greatly enhancing your abilities at a cost."
force.id = "lightningoverclock"
force.Icon = "kybercore/lightning.png"

-- Configurable values
local AURA_DURATION = 20
local SPEED_BOOST = 500
local HEALTH_BOOST = 100
local FORCE_OVERCHARGE = 1000
local BLOCK_BOOST = 250
local DOT_INTERVAL = 2
local DOT_DAMAGE = 5
local CHAT_COMMAND = "say /aura ^ electro_aura_r 20"

force.StartUse = function(ply)
    if not IsValid(ply) then return end
    if ply.NextAura and ply.NextAura > CurTime() then return end

    ply.NextAura = CurTime() + AURA_DURATION + 5

    -- Run hidden chat command to show aura
    ply:ConCommand(CHAT_COMMAND)

    -- Buffs: Health, Speed, Force pool
    local originalHealth = ply:Health()
    local maxHealth = ply:GetMaxHealth()
    ply:SetHealth(math.min(originalHealth + HEALTH_BOOST, maxHealth + HEALTH_BOOST))
    ply:SetWalkSpeed(ply:GetWalkSpeed() + SPEED_BOOST)
    ply:SetRunSpeed(ply:GetRunSpeed() + SPEED_BOOST)

    -- Force pool overclock
    ply.originalMaxForce = ply:lscsGetMaxForce()
    ply.originalForce = ply:lscsGetForce()
    ply:lscsSetMaxForce(FORCE_OVERCHARGE)
    ply:lscsSetForce(FORCE_OVERCHARGE)

    -- Saber block boost
    if ply.lscsGetMaxBlock and ply.lscsSetMaxBlock and ply.lscsSetBlock then
        ply.originalMaxBlock = ply:lscsGetMaxBlock()
        ply.originalBlock = ply:lscsGetBlock()
        ply:lscsSetMaxBlock(ply.originalMaxBlock + BLOCK_BOOST)
        ply:lscsSetBlock(ply.originalBlock + BLOCK_BOOST)
    end

    -- Track active status
    ply._OverclockAuraActive = true

    -- Damage over time
    for i = 1, math.floor(AURA_DURATION / DOT_INTERVAL) do
        timer.Simple(i * DOT_INTERVAL, function()
            if not IsValid(ply) or not ply._OverclockAuraActive then return end
            local dmg = DamageInfo()
            dmg:SetDamage(DOT_DAMAGE)
            dmg:SetAttacker(ply)
            dmg:SetDamageType(DMG_SHOCK)
            ply:TakeDamageInfo(dmg)
        end)
    end

    -- Revert after duration
    timer.Simple(AURA_DURATION, function()
        if not IsValid(ply) then return end
        ply._OverclockAuraActive = false

        -- Revert buffs
        ply:SetWalkSpeed(ply:GetWalkSpeed() - SPEED_BOOST)
        ply:SetRunSpeed(ply:GetRunSpeed() - SPEED_BOOST)
        ply:SetHealth(math.min(ply:Health(), maxHealth))

        -- Restore force pool
        if ply.originalMaxForce then
            ply:lscsSetMaxForce(ply.originalMaxForce)
        end
        if ply.originalForce then
            ply:lscsSetForce(math.min(ply.originalForce, ply.originalMaxForce))
        end

        -- Restore saber block
        if ply.originalMaxBlock and ply.originalBlock and ply.lscsSetMaxBlock and ply.lscsSetBlock then
            ply:lscsSetMaxBlock(ply.originalMaxBlock)
            ply:lscsSetBlock(math.min(ply.originalBlock, ply.originalMaxBlock))
        end
    end)
end

force.OnClk = function(ply, TIME) end
force.StopUse = function(ply) end

LSCS:RegisterForce(force)


  
  
// ============================================================================== //
//                                                                                //
//                          		Judgement Cut   		               		  //
//                                                                                //
// ============================================================================== //
  local force = {}
force.PrintName = "Judgement Cut"
force.Author = "Mellow"
force.Description = "Unleash a burst of slashing energy around you, tearing through enemies over time."
force.id = "judgement_cut"
force.Icon = "kybercore/judgementcut.png"
  
-- Configurable values
local DURATION = 3 -- Duration of the effect in seconds
local TICK_INTERVAL = 0.25
local DAMAGE_PER_TICK = 25
local AOE_RADIUS = 300
local SOUND_HIT = "weapons/knife/knife_hit"..math.random(1, 4)..".wav"

force.StartUse = function(ply)
    if not IsValid(ply) then return end
    if ply.NextSlashStorm and ply.NextSlashStorm > CurTime() then return end

    ply.NextSlashStorm = CurTime() + DURATION + 2

    -- Cloak player (ULX)
    ply:ConCommand("ulx cloak ^")

    -- Play aura effect using hidden chat command
    timer.Simple(0, function()
        if IsValid(ply) then
            ply:ConCommand("say /aura ^ judgment_cut 3")
        end
    end)

    local origin = ply:GetPos()

    for i = 0, DURATION / TICK_INTERVAL - 1 do
        timer.Simple(i * TICK_INTERVAL, function()
            if not IsValid(ply) then return end

            local center = ply:GetPos() + Vector(0, 0, 36)

            for _, ent in pairs(ents.FindInSphere(center, AOE_RADIUS)) do
                if ent == ply then continue end
                if not ent:IsPlayer() and not ent:IsNPC() and not ent:IsNextBot() then continue end
                if not ent:Alive() then continue end

                local dmg = DamageInfo()
                dmg:SetDamage(DAMAGE_PER_TICK)
                dmg:SetAttacker(ply)
                dmg:SetInflictor(ply)
                dmg:SetDamageType(DMG_SLASH)
                dmg:SetDamagePosition(ent:GetPos() + ent:OBBCenter())
                ent:TakeDamageInfo(dmg)

                ent:EmitSound(SOUND_HIT, 75, 100, 1, CHAN_BODY)
            end
        end)
    end

    -- Uncloak player after effect ends
    timer.Simple(DURATION, function()
        if IsValid(ply) then
            ply:ConCommand("ulx uncloak ^")
        end
    end)
end

force.OnClk = function(ply, TIME) end
force.StopUse = function(ply) end

LSCS:RegisterForce(force)
  
// ============================================================================== //
//                                                                                //
//                          		Funny           		               		  //
//                                                                                //
// ============================================================================== //
 
  
