
----------------------------Lore HILTS----------------------------------------

local hilt = {}
hilt.PrintName = "Aayla Secura's Hilt"
hilt.Author = "Truce"
hilt.id = "ash"
hilt.mdl = "models/starwars/cwa/lightsabers/aaylasecura.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent, SWEP, ply )
		if not ent.BladeID1 then
			ent.BladeID1 = ent:LookupAttachment( "blade1" )
		end

        local att1 = ent:GetAttachment( ent.BladeID1 )

		if att1 then
			local blades = {
				[1] = {
					pos = att1.Pos,
					dir = att1.Ang:Forward(),
				},
			}
			return blades
		end
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Ahsoka Tano's Hilt"
hilt.Author = "Truce"
hilt.id = "ash3"
hilt.mdl = "models/starwars/cwa/lightsabers/ahsoka.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = {
                pos = ent:LocalToWorld( Vector(2,-0.6,-0.1) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Ahsoka Tano's Reversed Hilt"
hilt.Author = "Truce"
hilt.id = "ash3r"
hilt.mdl = "models/starwars/cwa/lightsabers/reverseahsoka.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, 4),
            ang = Angle(90, 90, 90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, -6),
            ang = Angle(-90, -90, -90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = {
                pos = ent:LocalToWorld( Vector(2,-0.6,-0.1) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Anakin Skywalker Hilt"
hilt.Author = "Truce"
hilt.id = "ash4"
hilt.mdl = "models/sgg/starwars/weapons/w_anakin_ep3_saber_hilt.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = {
                pos = ent:LocalToWorld( Vector(2,-0.6,-0.1) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Asajj Ventress' Hilt"
hilt.Author = "Truce"
hilt.id = "ash5"
hilt.mdl = "models/starwars/cwa/lightsabers/ventress.mdl"
hilt.Spawnable = false
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
                pos = ent:LocalToWorld( Vector(0.5,-0.9,-0.3) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Byph Hilt"
hilt.Author = "Truce"
hilt.id = "bsh"
hilt.mdl = "models/starwars/cwa/lightsabers/byph.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = {
                pos = ent:LocalToWorld( Vector(2,-0.6,-0.1) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Vader Hilt"
hilt.Author = "Rubat"
hilt.id = "vah"
hilt.mdl = "models/sgg/starwars/weapons/w_vader_saber_hilt.mdl"
hilt.Spawnable = true
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = {
                pos = ent:LocalToWorld( Vector(2,-0.6,-0.1) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(), length_multiplier = 1.2222
            },
        }

        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Mace Windu Hilt"
hilt.Author = "Rubat"
hilt.id = "mah"
hilt.mdl = "models/sgg/starwars/weapons/w_mace_windu_saber_hilt.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = {
                pos = ent:LocalToWorld( Vector(2,-0.6,-0.1) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }

        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Obi Wan Hilt"
hilt.Author = "Rubat"
hilt.id = "obh"
hilt.mdl = "models/sgg/starwars/weapons/w_obiwan_ep3_saber_hilt.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = {
                pos = ent:LocalToWorld( Vector(2,-0.6,-0.1) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }

        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Darth Sidious's Hilt"
hilt.Author = "Rubat"
hilt.id = "sidh"
hilt.mdl = "models/sgg/starwars/weapons/w_sidious_saber_hilt.mdl"
hilt.Spawnable = false
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = {
                pos = ent:LocalToWorld( Vector(2,-0.6,-0.1) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }

        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Yoda's Hilt"
hilt.Author = "Rubat"
hilt.id = "yh"
hilt.mdl = "models/sgg/starwars/weapons/w_yoda_saber_hilt.mdl"
hilt.Spawnable = true
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = {
                pos = ent:LocalToWorld( Vector(2,-0.6,-0.1) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }

        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Dooku Hilt"
hilt.Author = "Rubat"
hilt.id = "dh"
hilt.mdl = "models/weapons/starwars/w_dooku_saber_hilt.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
                pos = ent:LocalToWorld( Vector(2,-0.55,0.45) ),
                dir = ent:LocalToWorldAngles( Angle(55,180,0) ):Up(),
            },
        }

        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Maul Staff Hilt"
hilt.Author = "Rubat"
hilt.id = "maul"
hilt.mdl = "models/weapons/starwars/w_maul_saber_staff_hilt.mdl"
hilt.functiontype = "staff"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, 0),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 0),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = {
                pos = ent:LocalToWorld( Vector(-12.5,-0.05,0) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
	   [2] = {
                pos = ent:LocalToWorld( Vector(12.5,-0.05,0) ),
                dir = ent:LocalToWorldAngles( Angle(-90,-180,0) ):Up(),
            },
        }

        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Luminara's and Plo's Hilt"
hilt.Author = "Rubat"
hilt.id = "lph"
hilt.mdl = "models/starwars/cwa/lightsabers/luminara.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = {
                pos = ent:LocalToWorld( Vector(2,-0.6,-0.1) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }

        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Kit Fisto's Hilt"
hilt.Author = "Rubat"
hilt.id = "kfh"
hilt.mdl = "models/starwars/cwa/lightsabers/kitfisto.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = {
                pos = ent:LocalToWorld( Vector(2,-0.6,-0.1) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }

        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Shaak Ti's Hilt"
hilt.Author = "Rubat"
hilt.id = "sth"
hilt.mdl = "models/starwars/cwa/lightsabers/shaakti.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = {
                pos = ent:LocalToWorld( Vector(2,-0.6,-0.1) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }

        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Jocasta's Hilt"
hilt.Author = "Rubat"
hilt.id = "jh"
hilt.mdl = "models/starwars/cwa/lightsabers/jocastanu.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = {
                pos = ent:LocalToWorld( Vector(2,-0.6,-0.1) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }

        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Saesee Tiin's Hilt"
hilt.Author = "Rubat"
hilt.id = "stih"
hilt.mdl = "models/starwars/cwa/lightsabers/saeseetiin.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = {
                pos = ent:LocalToWorld( Vector(2,-0.6,-0.1) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }

        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Hett Hilt 1"
hilt.Author = "Rubat"
hilt.id = "hh1"
hilt.mdl = "models/plo/cwa/sabers/hett_saber_1.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
                pos = ent:LocalToWorld( Vector(2,-0.6,-0.2) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Hett Hilt 2"
hilt.Author = "Rubat"
hilt.id = "hh2"
hilt.mdl = "models/plo/cwa/sabers/hett_saber_2.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
                pos = ent:LocalToWorld( Vector(2,-0.6,-0.2) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Darksaber Hilt"
hilt.Author = "Truce"
hilt.id = "dsh"
hilt.mdl = "models/starwars/cwa/lightsabers/darksaber.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = {
                pos = ent:LocalToWorld( Vector(2,-0.6,-0.1) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }

        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Knott"
hilt.Author = "Truce"
hilt.id = "knot"
hilt.mdl = "models/plo/lightsaber/knottlightsaber.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------  y   x   z
                pos = ent:LocalToWorld( Vector(-0,-0.4,-0.1) ),
                dir = ent:LocalToWorldAngles( Angle(90,179,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "7th Sister SaberStaff hilt"
hilt.Author = "Luna"
hilt.id = "inqss7"
hilt.mdl = "models/twcustom/jedi_lightsabers/simon_cc/inquisitor_saber.mdl"
hilt.info = {
	ParentData = {
		["RH"] = {
			bone = "ValveBiped.Bip01_R_Hand",
			pos = Vector(3,-1.5,0),
			ang = Angle(-90,0,0),
		},
		["LH"] = {
			bone = "ValveBiped.Bip01_L_Hand",
			pos = Vector(3,-1.5,0),
			ang = Angle(90,0,0),
		},
	},
	GetBladePos = function( ent, SWEP, ply )
		local Rate = CurTime() * 4

		if SWEP:IsThrown() then
			if ent:GetSequence() == 0 then
				ent:SetSequence( ent:LookupSequence( "spin" ) )
			end

			ent:SetCycle( Rate )
		else
			if ent:GetCycle() ~= 0 then
				ent:SetCycle( Rate )

				if ent:GetCycle() >= 1 then
					ent:SetCycle( 0 )
				end
			end
		end

		if not ent.BladeID1 then
			ent.BladeID1 = ent:LookupAttachment( "blade1" )
		end

		if not ent.BladeID2 then
			ent.BladeID2 = ent:LookupAttachment( "blade2" )
		end

		local att1 = ent:GetAttachment( ent.BladeID1 )
		local att2 = ent:GetAttachment( ent.BladeID2 )

		if att1 and att2 then
			local blades = {
				[1] = {
					pos = att1.Pos,
					dir = att1.Ang:Forward(),
				},
				[2] = {
					pos = att2.Pos,
					dir = att2.Ang:Forward(),
				},
			}
			return blades
		end
	end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Inquisitor Single Hilt"
hilt.Author = "Miller"
hilt.id = "inqs"
hilt.mdl = "models/budds/sabers/inqusitor_saber_single.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, 0),
            ang = Angle(-90, -0, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 0),
            ang = Angle(90, 0, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = {
                pos = ent:LocalToWorld( Vector(-5,0,0) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }

        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Inquisitor Hilt 2"
hilt.Author = "Miller"
hilt.id = "inqss2"
hilt.functiontype = "staff"
hilt.mdl = "models/rising/inqusitor_saber.mdl"
hilt.info = {
	ParentData = {
		["RH"] = {
			bone = "ValveBiped.Bip01_R_Hand",
			pos = Vector(3,-1.5,0),
			ang = Angle(90,0,0),
		},
		["LH"] = {
			bone = "ValveBiped.Bip01_L_Hand",
			pos = Vector(3,-1.5,0),
			ang = Angle(90,0,0),
		},
	},
	GetBladePos = function( ent, SWEP, ply )
		local Rate = CurTime() * 4

		if SWEP:IsThrown() then
			if ent:GetSequence() == 0 then
				ent:SetSequence( ent:LookupSequence( "spin" ) )
			end

			ent:SetCycle( Rate )
		else
			if ent:GetCycle() ~= 0 then
				ent:SetCycle( Rate )

				if ent:GetCycle() >= 1 then
					ent:SetCycle( 0 )
				end
			end
		end

		if not ent.BladeID1 then
			ent.BladeID1 = ent:LookupAttachment( "blade1" )
		end

		if not ent.BladeID2 then
			ent.BladeID2 = ent:LookupAttachment( "blade2" )
		end

		local att1 = ent:GetAttachment( ent.BladeID1 )
		local att2 = ent:GetAttachment( ent.BladeID2 )

		if att1 and att2 then
			local blades = {
				[1] = {
					pos = att1.Pos,
					dir = att1.Ang:Forward(),
				},
				[2] = {
					pos = att2.Pos,
					dir = att2.Ang:Forward(),
				},
			}
			return blades
		end
	end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Inquisitor Single Hilt 2"
hilt.Author = "Miller"
hilt.id = "inqs2"
hilt.mdl = "models/rising/inqusitor_saber2.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, 0),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 0),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = {
                pos = ent:LocalToWorld( Vector(-5,0,0) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }

        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Inquisitor Single Hilt (R)"
hilt.Author = "Miller"
hilt.id = "inqsr"
hilt.mdl = "models/budds/sabers/inqusitor_saber_single.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, 0),
            ang = Angle(90,0,90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 0),
            ang = Angle(-90, 0, -90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = {
                pos = ent:LocalToWorld( Vector(-5,0,0) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }

        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Inquisitor Single Hilt 2 (R)"
hilt.Author = "Miller"
hilt.id = "inqsr2"
hilt.mdl = "models/rising/inqusitor_saber2.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, 0),
            ang = Angle(90, 90, 90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 0),
            ang = Angle(-90, -90, -90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
                pos = ent:LocalToWorld( Vector(-5,0,0) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }

        return blades
    end,
}
LSCS:RegisterHilt( hilt )
------------------------------- Novice -----------------------------------------------


local hilt = {}
hilt.PrintName = "Single Hilt 01"
hilt.Author = "Truce"
hilt.id = "sh1"
hilt.mdl = "models/sgg/starwars/weapons/w_saber_1_hilt.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
                pos = ent:LocalToWorld( Vector(2,-0.6,-0.1) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Single Hilt 02"
hilt.Author = "Truce"
hilt.id = "sh2"
hilt.mdl = "models/sgg/starwars/weapons/w_saber_2_hilt.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
                pos = ent:LocalToWorld( Vector(2,-0.6,-0.1) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Single Hilt 03"
hilt.Author = "Truce"
hilt.id = "sh3"
hilt.mdl = "models/sgg/starwars/weapons/w_saber_3_hilt.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
                pos = ent:LocalToWorld( Vector(2,-0.6,-0.1) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Single Hilt 04"
hilt.Author = "Truce"
hilt.id = "sh4"
hilt.mdl = "models/sgg/starwars/weapons/w_saber_4_hilt.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
                pos = ent:LocalToWorld( Vector(2,-0.6,-0.1) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Single Hilt 05"
hilt.Author = "Truce"
hilt.id = "sh5"
hilt.mdl = "models/sgg/starwars/weapons/w_saber_5_hilt.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
                pos = ent:LocalToWorld( Vector(2,-0.6,-0.1) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Single Hilt 06"
hilt.Author = "Truce"
hilt.id = "sh6"
hilt.mdl = "models/sgg/starwars/weapons/w_saber_6_hilt.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
                pos = ent:LocalToWorld( Vector(2,-0.6,-0.1) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Single Hilt 07"
hilt.Author = "Truce"
hilt.id = "sh7"
hilt.mdl = "models/sgg/starwars/weapons/w_saber_7_hilt.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
                pos = ent:LocalToWorld( Vector(2,-0.6,-0.15) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Single Hilt 08"
hilt.Author = "Truce"
hilt.id = "sh8"
hilt.mdl = "models/sgg/starwars/weapons/w_saber_8_hilt.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
                pos = ent:LocalToWorld( Vector(2,-0.5,-0.15) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Single Hilt 09"
hilt.Author = "Truce"
hilt.id = "sh9"
hilt.mdl = "models/sgg/starwars/weapons/w_saber_9_hilt.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
                pos = ent:LocalToWorld( Vector(2,-0.5,-0.18) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Single Hilt 10"
hilt.Author = "Truce"
hilt.id = "sh10"
hilt.mdl = "models/swtor/arsenic/lightsabers/antiquesocorrolightsaberbesh.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
                pos = ent:LocalToWorld( Vector(0,-0.425,-0.15) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Single Hilt 11"
hilt.Author = "Truce"
hilt.id = "sh11"
hilt.mdl = "models/swtor/arsenic/lightsabers/antiquesocorrolightsabercresh.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -5, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
                pos = ent:LocalToWorld( Vector(0,-0.425,-0.15) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Single Hilt 12"
hilt.Author = "Truce"
hilt.id = "sh12"
hilt.mdl = "models/swtor/arsenic/lightsabers/warden'slightsaber.mdl"
hilt.Spawnable = true
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent, SWEP, ply )
		if not ent.BladeID1 then
			ent.BladeID1 = ent:LookupAttachment( "blade1" )
		end

		local att1 = ent:GetAttachment( ent.BladeID1 )

		if att1 then
			local blades = {
				[1] = {
					pos = att1.Pos,
					dir = att1.Ang:Forward(),
				},
			}
			return blades
		end
	end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Single Hilt 13"
hilt.Author = "Truce"
hilt.id = "sh13"
hilt.mdl = "models/swtor/arsenic/lightsabers/arakydsaber.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
                pos = ent:LocalToWorld( Vector(0,-0.425,-0.15) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Single Hilt 14"
hilt.Author = "Truce"
hilt.id = "sh14"
hilt.mdl = "models/swtor/arsenic/lightsabers/ardentdefender'slightsaber.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
                pos = ent:LocalToWorld( Vector(0,-0.425,-0.15) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Single Hilt 15"
hilt.Author = "Truce"
hilt.id = "sh15"
hilt.mdl = "models/swtor/arsenic/lightsabers/artusianlightsaber.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
                pos = ent:LocalToWorld( Vector(2,-0.425,-0.17) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Single Hilt 16"
hilt.Author = "Truce"
hilt.id = "sh16"
hilt.mdl = "models/swtor/arsenic/lightsabers/ashara'slightsaber.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
                pos = ent:LocalToWorld( Vector(0,-0.425,-0.17) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Single Hilt 17"
hilt.Author = "Truce"
hilt.id = "sh17"
hilt.mdl = "models/swtor/arsenic/lightsabers/blademaster'sattenuatedlightsaber.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
                pos = ent:LocalToWorld( Vector(0,-0.425,-0.15) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Single Hilt 18"
hilt.Author = "Truce"
hilt.id = "sh18"
hilt.mdl = "models/swtor/arsenic/lightsabers/blademaster'sattenuatedshoto.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
                pos = ent:LocalToWorld( Vector(0,-0.425,-0.15) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

------------------------------- Inquisitor & High Inquisitor -----------------------------------------------

local hilt = {}
hilt.PrintName = "Single Hilt 19"
hilt.Author = "Truce"
hilt.id = "sh19"
hilt.mdl = "models/starwars/cwa/lightsabers/lightsideaffiliation.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
                pos = ent:LocalToWorld( Vector(2,-0.55,-0.15) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Single Hilt 20"
hilt.Author = "Truce"
hilt.id = "sh20"
hilt.mdl = "models/starwars/cwa/lightsabers/compressedcrystal.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
                pos = ent:LocalToWorld( Vector(2,-0.55,-0.15) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt ) 

local hilt = {}
hilt.PrintName = "Single Hilt 21"
hilt.Author = "Truce"
hilt.id = "sh21"
hilt.mdl = "models/starwars/cwa/lightsabers/felucia1.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
                pos = ent:LocalToWorld( Vector(2,-0.6,-0.1) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt ) 

local hilt = {}
hilt.PrintName = "Single Hilt 22"
hilt.Author = "Truce"
hilt.id = "sh22"
hilt.mdl = "models/starwars/cwa/lightsabers/felucia2.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
                pos = ent:LocalToWorld( Vector(2,-0.6,-0.1) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt ) 

local hilt = {}
hilt.PrintName = "Single Hilt 23"
hilt.Author = "Truce"
hilt.id = "sh23"
hilt.mdl = "models/starwars/cwa/lightsabers/forked.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
                pos = ent:LocalToWorld( Vector(2,-0.55,-0.2) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt ) 

local hilt = {}
hilt.PrintName = "Single Hilt 24"
hilt.Author = "Truce"
hilt.id = "sh24"
hilt.mdl = "models/starwars/cwa/lightsabers/ganodi.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
                pos = ent:LocalToWorld( Vector(2,-0.5,-0.15) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt ) 

local hilt = {}
hilt.PrintName = "Single Hilt 25"
hilt.Author = "Truce"
hilt.id = "sh25"
hilt.mdl = "models/lightsaber4/lightsaber4.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
                pos = ent:LocalToWorld( Vector(2,-0.425,-0.1) ),
                dir = ent:LocalToWorldAngles( Angle(86,180,-6) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt ) 

local hilt = {}
hilt.PrintName = "Single Hilt 26"
hilt.Author = "Truce"
hilt.id = "sh26"
hilt.mdl = "models/starwars/cwa/lightsabers/gungan.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
                pos = ent:LocalToWorld( Vector(2,-0.6,-0.1) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt ) 

local hilt = {}
hilt.PrintName = "Single Hilt 27"
hilt.Author = "Truce"
hilt.id = "sh27"
hilt.mdl = "models/starwars/cwa/lightsabers/gungi.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
                pos = ent:LocalToWorld( Vector(2,-0.6,-0.1) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt ) 

local hilt = {}
hilt.PrintName = "Single Hilt 28"
hilt.Author = "Truce"
hilt.id = "sh28"
hilt.mdl = "models/starwars/cwa/lightsabers/kashyyyk.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
                pos = ent:LocalToWorld( Vector(2,-0.6,-0.1) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt ) 

local hilt = {}
hilt.PrintName = "Single Hilt 29"
hilt.Author = "Truce"
hilt.id = "sh29"
hilt.mdl = "models/starwars/cwa/lightsabers/petro.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
                pos = ent:LocalToWorld( Vector(2,-0.6,-0.1) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Single Hilt 30"
hilt.Author = "Truce"
hilt.id = "sh30"
hilt.mdl = "models/starwars/cwa/lightsabers/pulsatingblue.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
                pos = ent:LocalToWorld( Vector(2,-0.6,-0.25) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Single Hilt 31"
hilt.Author = "Truce"
hilt.id = "sh31"
hilt.mdl = "models/starwars/cwa/lightsabers/pulsating.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
                pos = ent:LocalToWorld( Vector(2,-0.63,-0.22) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Single Hilt 32"
hilt.Author = "Truce"
hilt.id = "sh32"
hilt.mdl = "models/starwars/cwa/lightsabers/sparklingcrystal.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
                pos = ent:LocalToWorld( Vector(2,-0.6,-0.1) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Single Hilt 33"
hilt.Author = "Truce"
hilt.id = "sh33"
hilt.mdl = "models/unknown/unknown.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
                pos = ent:LocalToWorld( Vector(0,-0.7,-0) ),
                dir = ent:LocalToWorldAngles( Angle(86,180,-6) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Single Hilt 34"
hilt.Author = "Truce"
hilt.id = "sh34"
hilt.mdl = "models/starwars/cwa/lightsabers/zatt.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
                pos = ent:LocalToWorld( Vector(2,-0.475,-0.25) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Single Hilt 35"
hilt.Author = "Truce"
hilt.id = "sh35"
hilt.mdl = "models/swtor/arsenic/lightsabers/blademaster'sshoto.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
                pos = ent:LocalToWorld( Vector(0,-0.425,-0.15) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Single Hilt 36"
hilt.Author = "Truce"
hilt.id = "sh36"
hilt.mdl = "models/swtor/arsenic/lightsabers/challenger'slightsaber.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
                pos = ent:LocalToWorld( Vector(-0.1,-0.425,-0.15) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Single Hilt 37"
hilt.Author = "Truce"
hilt.id = "sh37"
hilt.mdl = "models/swtor/arsenic/lightsabers/chrysopazlightsaber.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
                pos = ent:LocalToWorld( Vector(0,-0.425,-0.15) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Single Hilt 38"
hilt.Author = "Truce"
hilt.id = "sh38"
hilt.mdl = "models/swtor/arsenic/lightsabers/dauntlessavenger'slightsaber.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
                pos = ent:LocalToWorld( Vector(0,-0.425,-0.18) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Single Hilt 39"
hilt.Author = "Truce"
hilt.id = "sh39"
hilt.mdl = "models/swtor/arsenic/lightsabers/defender'slightsaber.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
                pos = ent:LocalToWorld( Vector(0,-0.425,-0.15) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Single Hilt 40"
hilt.Author = "Truce"
hilt.id = "sh40"
hilt.mdl = "models/swtor/arsenic/lightsabers/defianttechnographer'slightsaber.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
                pos = ent:LocalToWorld( Vector(0,-0.425,-0.15) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Single Hilt 41"
hilt.Author = "Truce"
hilt.id = "sh41"
hilt.mdl = "models/swtor/arsenic/lightsabers/defianttechnographer'sshoto.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
                pos = ent:LocalToWorld( Vector(0,-0.425,-0.15) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Single Hilt 43"
hilt.Author = "Truce"
hilt.id = "sh43"
hilt.mdl = "models/swtor/arsenic/lightsabers/derelictlightsaber.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
                pos = ent:LocalToWorld( Vector(0,-0.425,-0.15) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Single Hilt 44"
hilt.Author = "Truce"
hilt.id = "sh44"
hilt.mdl = "models/swtor/arsenic/lightsabers/diabolistlightsaber.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
                pos = ent:LocalToWorld( Vector(2,-0.42,-0.2) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Single Hilt 45"
hilt.Author = "Truce"
hilt.id = "sh45"
hilt.mdl = "models/swtor/arsenic/lightsabers/dragonpearllightsaber.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
                pos = ent:LocalToWorld( Vector(2,-0.425,-0.15) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Single Hilt 46"
hilt.Author = "Truce"
hilt.id = "sh46"
hilt.mdl = "models/swtor/arsenic/lightsabers/fearlessretaliator'slightsaber.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
                pos = ent:LocalToWorld( Vector(2,-0.425,-0.27) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Single Hilt 47"
hilt.Author = "Truce"
hilt.id = "sh47"
hilt.mdl = "models/swtor/arsenic/lightsabers/firenodelightsaber.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
                pos = ent:LocalToWorld( Vector(2,-0.42,-0.27) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Single Hilt 48"
hilt.Author = "Truce"
hilt.id = "sh48"
hilt.mdl = "models/swtor/arsenic/lightsabers/frontierhunter'slightsaber.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
                pos = ent:LocalToWorld( Vector(2,-0.37,-0.18) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Single Hilt 49"
hilt.Author = "Truce"
hilt.id = "sh49"
hilt.mdl = "models/swtor/arsenic/lightsabers/geminimk-4lightsaber.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
                pos = ent:LocalToWorld( Vector(2,-0.4,-0.2) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Single Hilt 50"
hilt.Author = "Truce"
hilt.id = "sh50"
hilt.mdl = "models/swtor/arsenic/lightsabers/ice-jewellightsaber.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
                pos = ent:LocalToWorld( Vector(-0.2,-0.4,-0.25) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Single Hilt 51"
hilt.Author = "Truce"
hilt.id = "sh51"
hilt.mdl = "models/swtor/arsenic/lightsabers/inscrutablelightsaber.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
                pos = ent:LocalToWorld( Vector(2,-0.6,-0.2) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Single Hilt 52"
hilt.Author = "Truce"
hilt.id = "sh52"
hilt.mdl = "models/swtor/arsenic/lightsabers/novalightsaber.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
                pos = ent:LocalToWorld( Vector(1,-0.4, -0.2) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Single Hilt 53"
hilt.Author = "Truce"
hilt.id = "sh53"
hilt.mdl = "models/swtor/arsenic/lightsabers/outlanderlightsaber.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------pos:  y:up   x:left   z:forward -----dir: y = forward, x = nothing, z = right
                pos = ent:LocalToWorld( Vector(0,-0.46,-0.3) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )


--------------------------------------- Inquisitorius Consul -----------------------------------------------

local hilt = {}
hilt.PrintName = "Single Hilt 55"
hilt.Author = "Truce"
hilt.id = "sh55"
hilt.mdl = "models/starwars/cwa/lightsabers/spiralling.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = {--------------------------  y   x   z 
                pos = ent:LocalToWorld( Vector(2,-0.6,-0.3) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Single Hilt 56"
hilt.Author = "Truce"
hilt.id = "sh56"
hilt.mdl = "models/lightsaber2/lightsaber2.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = { -------------------------
            [1] = { --------------------------pos:  y:up   x:left   z:forward -----dir: y = forward, x = nothing, z = right
                pos = ent:LocalToWorld( Vector(2,-0.47,0) ),
                dir = ent:LocalToWorldAngles( Angle(88,180,-4) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Single Hilt 57"
hilt.Author = "Truce"
hilt.id = "sh57"
hilt.mdl = "models/starwars/cwa/lightsabers/talz.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------  y   x   z
                pos = ent:LocalToWorld( Vector(2,-0.6,-0.1) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Single Hilt 58"
hilt.Author = "Truce"
hilt.id = "sh58"
hilt.mdl = "models/starwars/cwa/lightsabers/exile.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------  y   x   z
                pos = ent:LocalToWorld( Vector(2,-0.6,-0.1) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Single Hilt 62"
hilt.Author = "Truce"
hilt.id = "sh62"
hilt.mdl = "models/swtor/arsenic/lightsabers/conqueror'slightsaber.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -180, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------  y   x   z
                pos = ent:LocalToWorld( Vector(-0.1,-0.4,-0.1) ),
                dir = ent:LocalToWorldAngles( Angle(90,179,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Single Hilt 63"
hilt.Author = "Truce"
hilt.id = "sh63"
hilt.mdl = "models/swtor/arsenic/lightsabers/coruscalightsaber.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------  y   x   z 
                pos = ent:LocalToWorld( Vector(-0.2,-0.3,-0.1) ),
                dir = ent:LocalToWorldAngles( Angle(90,179,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Single Hilt 64"
hilt.Author = "Truce"
hilt.id = "sh64"
hilt.mdl = "models/swtor/arsenic/lightsabers/eternalcommandermk-4lightsaber.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------  y   x   z 
                pos = ent:LocalToWorld( Vector(-0.3,-0.3,-0.1) ),
                dir = ent:LocalToWorldAngles( Angle(90,179,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )


local hilt = {}
hilt.PrintName = "Single Hilt 66"
hilt.Author = "Truce"
hilt.id = "sh66"
hilt.mdl = "models/swtor/arsenic/lightsabers/exarch'smk-2lightsaber.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = {--------------------------  y   x   z 
                pos = ent:LocalToWorld( Vector(2,-0.6,-0.1) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Single Hilt 67"
hilt.Author = "Truce"
hilt.id = "sh67"
hilt.mdl = "models/swtor/arsenic/lightsabers/executioner'slightsaber.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, 40, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = {--------------------------  y   x   z 
                pos = ent:LocalToWorld( Vector(-0.4,-0.3,-0.1) ),
                dir = ent:LocalToWorldAngles( Angle(90,179,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Single Hilt 68"
hilt.Author = "Truce"
hilt.id = "sh68"
hilt.mdl = "models/swtor/arsenic/lightsabers/hiridulightsaber.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = {--------------------------  y   x   z 
                pos = ent:LocalToWorld( Vector(0,-0.3,-0.1) ),
                dir = ent:LocalToWorldAngles( Angle(90,179,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Single Hilt 69"
hilt.Author = "Truce"
hilt.id = "sh69"
hilt.mdl = "models/swtor/arsenic/lightsabers/instigator'slightsaber.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = {
                pos = ent:LocalToWorld( Vector(0,-0.5,-0.1) ),
                dir = ent:LocalToWorldAngles( Angle(90,179,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Single Hilt 70"
hilt.Author = "Truce"
hilt.id = "sh70"
hilt.mdl = "models/swtor/arsenic/lightsabers/mytaglightsaber.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = {
                pos = ent:LocalToWorld( Vector(2,-0.6,-0.1) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Single Hilt 71"
hilt.Author = "Truce"
hilt.id = "sh71"
hilt.mdl = "models/swtor/arsenic/lightsabers/blademaster'slightsaber.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = {
                pos = ent:LocalToWorld( Vector(2,-0.6,-0.1) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Single Hilt 72"
hilt.Author = "Truce"
hilt.id = "sh72"
hilt.mdl = "models/lightsaber3/lightsaber3.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent, SWEP, ply )
		if not ent.BladeID1 then
			ent.BladeID1 = ent:LookupAttachment( "blade1" )
		end

        local att1 = ent:GetAttachment( ent.BladeID1 )

		if att1 then
			local blades = {
				[1] = {
					pos = att1.Pos,
					dir = att1.Ang:Forward(),
				},
			}
			return blades
		end
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Single Hilt 73"
hilt.Author = "Truce"
hilt.id = "sh73"
hilt.mdl = "models/swtor/anzati/lightsabers/uchigatana.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, 0, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 0, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
                pos = ent:LocalToWorld( Vector(0.5,-1, 0.9) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Single Hilt 74"
hilt.Author = "Truce"
hilt.id = "sh74"
hilt.mdl = "models/swtor/anzati/lightsabers/new_malgus_simple.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = {
                pos = ent:LocalToWorld( Vector(-1.4,-0.55,-0.5) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Single Hilt 75"
hilt.Author = "Truce"
hilt.id = "sh75"
hilt.mdl = "models/the knowledge seeker/the knowledge seeker.mdl"
hilt.Spawnable = true
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent, SWEP, ply )
		if not ent.BladeID1 then
			ent.BladeID1 = ent:LookupAttachment( "blade1" )
		end

        local att1 = ent:GetAttachment( ent.BladeID1 )

		if att1 then
			local blades = {
				[1] = {
					pos = att1.Pos,
					dir = att1.Ang:Forward(),
				},
			}
			return blades
		end
	end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Single Hilt 76"
hilt.Author = "Truce"
hilt.id = "sh76"
hilt.mdl = "models/lightsaber/lightsaber.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent, SWEP, ply )
		if not ent.BladeID1 then
			ent.BladeID1 = ent:LookupAttachment( "blade1" )
		end

        local att1 = ent:GetAttachment( ent.BladeID1 )

		if att1 then
			local blades = {
				[1] = {
					pos = att1.Pos,
					dir = att1.Ang:Forward(),
				},
			}
			return blades
		end
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Single Hilt 78"
hilt.Author = "Truce"
hilt.id = "ss78"
hilt.mdl = "models/swtor/arsenic/lightsabers/vindicator'slightsaber.mdl"
hilt.Spawnable = true
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent, SWEP, ply )
		if not ent.BladeID1 then
			ent.BladeID1 = ent:LookupAttachment( "blade1" )
		end

		local att1 = ent:GetAttachment( ent.BladeID1 )

		if att1 then
			local blades = {
				[1] = {
					pos = att1.Pos,
					dir = att1.Ang:Forward(),
				},
			}
			return blades
		end
	end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Single Hilt 79"
hilt.Author = "Truce"
hilt.id = "ss79"
hilt.mdl = "models/swtor/arsenic/lightsabers/vengeance'sunsealedlightsaber.mdl"
hilt.Spawnable = true
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent, SWEP, ply )
		if not ent.BladeID1 then
			ent.BladeID1 = ent:LookupAttachment( "blade1" )
		end

		local att1 = ent:GetAttachment( ent.BladeID1 )

		if att1 then
			local blades = {
				[1] = {
					pos = att1.Pos,
					dir = att1.Ang:Forward(),
				},
			}
			return blades
		end
	end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Single Hilt 80"
hilt.Author = "Truce"
hilt.id = "ss80"
hilt.mdl = "models/swtor/arsenic/lightsabers/unstablepeacemaker'slightsaber.mdl"
hilt.Spawnable = true
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent, SWEP, ply )
		if not ent.BladeID1 then
			ent.BladeID1 = ent:LookupAttachment( "blade1" )
		end

		local att1 = ent:GetAttachment( ent.BladeID1 )

		if att1 then
			local blades = {
				[1] = {
					pos = att1.Pos,
					dir = att1.Ang:Forward(),
				},
			}
			return blades
		end
	end,
}
LSCS:RegisterHilt( hilt )

---------------------------------------- hello -------------------------------------------


local hilt = {}
hilt.PrintName = "Training Hilt"
hilt.Author = "Stoneman"
hilt.id = "traininghilt"
hilt.mdl = "models/training/training.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
	GetBladePos = function( ent, SWEP, ply )
		if not ent.BladeID1 then
			ent.BladeID1 = ent:LookupAttachment( "blade1" )
		end

		local att1 = ent:GetAttachment( ent.BladeID1 )

		if att1 then
			local blades = {
				[1] = {
					pos = att1.Pos,
					dir = att1.Ang:Forward(),  length_multiplier = 0.75
				},
			}
			return blades
		end
	end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "GunSaber"
hilt.Author = "Truce"
hilt.id = "gunh"
hilt.mdl = "models/wos/lct/weapons/lightsabers/sabergun.mdl"
hilt.Spawnable = false  -- uncomment to unlist in q-menu
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(1, -1.5, 4),
            ang = Angle(0, 0, -180),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(0.65, -1.3, -3.6),
            ang = Angle(0, 0, 0),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
                pos = ent:LocalToWorld( Vector(16,0.3,4.2) ),
                dir = ent:LocalToWorldAngles( Angle(-90,179,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Training Staff Hilt"
hilt.Author = "Stoneman"
hilt.id = "sst"
hilt.mdl = "models/swtor/anzati/lightsabers/training_double.mdl"
hilt.functiontype = "staff"
hilt.Spawnable = false  -- uncomment to unlist in q-menu
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
	GetBladePos = function( ent, SWEP, ply )
		if not ent.BladeID1 then
			ent.BladeID1 = ent:LookupAttachment( "blade1" )
		end

		if not ent.BladeID2 then
			ent.BladeID2 = ent:LookupAttachment( "blade2" )
		end

		local att1 = ent:GetAttachment( ent.BladeID1 )
		local att2 = ent:GetAttachment( ent.BladeID2 )

		if att1 and att2 then
			local blades = {
				[1] = {
					pos = att1.Pos,
					dir = att1.Ang:Forward(),
				},
				[2] = {
					pos = att2.Pos,
					dir = att2.Ang:Forward(),
				},
			}
			return blades
		end
	end,
}
LSCS:RegisterHilt( hilt )


----------------------------------- Specialiy Saber Types -----------------------------------------------


local hilt = {}
hilt.PrintName = "Greatsaber Hilt 01"
hilt.Author = "Truce"
hilt.id = "sg1"
hilt.mdl = "models/dylanxd/dylanxd.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -2, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
                pos = ent:LocalToWorld( Vector(0.5,-0.5,0) ),
                dir = ent:LocalToWorldAngles( Angle(88,180,-3.5) ):Up(), length_multiplier = 1.2222
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Greatsaber Hilt 02"
hilt.Author = "Truce"
hilt.id = "sg2"
hilt.mdl = "models/swtor/arsenic/lightsabers/senyatirall'slightsaber-cartel.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = {
                pos = ent:LocalToWorld( Vector(0,-0.6,-0.1) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(), length_multiplier = 1.2222
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Greatsaber Hilt 03"
hilt.Author = "Truce"
hilt.id = "sg3"
hilt.mdl = "models/swtor/arsenic/lightsabers/tythianlightsaber.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = {
                pos = ent:LocalToWorld( Vector(0,-0.6,-0.1) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(), length_multiplier = 1.2222
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Greatsaber Hilt 04"
hilt.Author = "Truce"
hilt.id = "gs4"
hilt.mdl = "models/wos/lct/weapons/lightsabers/kingsaber2.mdl"
hilt.Spawnable = true  -- uncomment to unlist in q-menu
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, 2),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = {
                pos = ent:LocalToWorld( Vector(-7,-0,-0.1) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(), length_multiplier = 1.2222
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Saber Pike 01"
hilt.Author = "Truce"
hilt.id = "sp1"
hilt.mdl = "models/donation1/donation1.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -12),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, 1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = {
                pos = ent:LocalToWorld( Vector(-15.75,-2,1) ),
                dir = ent:LocalToWorldAngles( Angle(87,185,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Saber Pike 02"
hilt.Author = "Truce"
hilt.id = "sp2"
hilt.mdl = "models/donation2/donation2.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -12),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, 1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
                pos = ent:LocalToWorld( Vector(-16,-2,1) ),
                dir = ent:LocalToWorldAngles( Angle(87,185,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Saber Pike 03"
hilt.Author = "Truce"
hilt.id = "sp3"
hilt.mdl = "models/pike/pike.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -12),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, 1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = {
                pos = ent:LocalToWorld( Vector(-15.75,-2,1) ),
                dir = ent:LocalToWorldAngles( Angle(87,185,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Saber Pike 04"
hilt.Author = "Truce"
hilt.id = "sp4"
hilt.mdl = "models/bln/anzati/lightsabers/ogarapike.mdl"
hilt.Spawnable = true
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(5, 1, -20),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent, SWEP, ply )
		if not ent.BladeID1 then
			ent.BladeID1 = ent:LookupAttachment( "blade1" )
		end
		local att1 = ent:GetAttachment( ent.BladeID1 )
		if att1 then
			local blades = {
				[1] = {
					pos = att1.Pos,
					dir = att1.Ang:Forward(),
				},
			}
			return blades
		end
	end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Saber Pike 05"
hilt.Author = "Truce"
hilt.id = "sp5"
hilt.mdl = "models/dante/dante.mdl"
hilt.Spawnable = true
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -15),
            ang = Angle(-90, -0, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 8),
            ang = Angle(90, 0, 90),
        },
    },
    GetBladePos = function( ent, SWEP, ply )
		if not ent.BladeID1 then
			ent.BladeID1 = ent:LookupAttachment( "blade1" )
		end

		local att1 = ent:GetAttachment( ent.BladeID1 )

		if att1 and att2 then
			local blades = {
				[1] = {
					pos = att1.Pos,
					dir = att1.Ang:Forward(),
				},
				[2] = {
					pos = att2.Pos,
					dir = att2.Ang:Forward(),
				},
			}
			return blades
		end
	end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Guard Pike"
hilt.Author = "Uriel"
hilt.id = "gpike"
hilt.mdl = "models/epangelmatikes/royalguard/weapon.mdl"
hilt.Spawnable = true  -- uncomment to unlist in q-menu
hilt.info = {
	ParentData = {
        ["RH"] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
		 bone = "ValveBiped.Bip01_R_Hand",
			pos = Vector(3.6, -0.9, 16),
            ang = Angle(-0, -0, 180),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.6, 0.9, -16),
            ang = Angle(0, 0, -180),
        },
    },
  GetBladePos = function( ent ) 
        local blades = {
            [1] = {
                pos = ent:LocalToWorld( Vector(0,-0.3,20) ),
                dir = ent:LocalToWorldAngles( Angle(0,0,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "SaberStaff 01"
hilt.Author = "Truce"
hilt.id = "ss1"
hilt.mdl = "models/swtor/anzati/lightsabers/tulak_double.mdl"
hilt.functiontype = "staff"
hilt.info = {
    ParentData = {
        ["RH"] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -12),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 0),
            ang = Angle(90, 90, 90),
        },
    },
	GetBladePos = function( ent, SWEP, ply )
		if not ent.BladeID1 then
			ent.BladeID1 = ent:LookupAttachment( "blade1" )
		end

		if not ent.BladeID2 then
			ent.BladeID2 = ent:LookupAttachment( "blade2" )
		end

		local att1 = ent:GetAttachment( ent.BladeID1 )
		local att2 = ent:GetAttachment( ent.BladeID2 )

		if att1 and att2 then
			local blades = {
				[1] = {
					pos = att1.Pos,
					dir = att1.Ang:Forward(),
				},
				[2] = {
					pos = att2.Pos,
					dir = att2.Ang:Forward(),
				},
			}
			return blades
		end
	end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "SaberStaff 02"
hilt.Author = "Truce"
hilt.id = "ss2"
hilt.mdl = "models/swtor/anzati/lightsabers/new_malgus_double.mdl"
hilt.functiontype = "staff"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, 0),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 0),
            ang = Angle(90, 90, 90),
        },
    },
	GetBladePos = function( ent, SWEP, ply )
		if not ent.BladeID1 then
			ent.BladeID1 = ent:LookupAttachment( "blade1" )
		end

		if not ent.BladeID2 then
			ent.BladeID2 = ent:LookupAttachment( "blade2" )
		end

		local att1 = ent:GetAttachment( ent.BladeID1 )
		local att2 = ent:GetAttachment( ent.BladeID2 )

		if att1 and att2 then
			local blades = {
				[1] = {
					pos = att1.Pos,
					dir = att1.Ang:Forward(),
				},
				[2] = {
					pos = att2.Pos,
					dir = att2.Ang:Forward(),
				},
			}
			return blades
		end
	end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "SaberStaff 03"
hilt.Author = "Truce"
hilt.id = "ss3"
hilt.mdl = "models/swtor/arsenic/lightsabers/adascorppolesaber.mdl"
hilt.functiontype = "staff"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -15),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 0),
            ang = Angle(90, 90, 90),
        },
    },
	GetBladePos = function( ent, SWEP, ply )
		if not ent.BladeID1 then
			ent.BladeID1 = ent:LookupAttachment( "blade1" )
		end

		if not ent.BladeID2 then
			ent.BladeID2 = ent:LookupAttachment( "blade2" )
		end

		local att1 = ent:GetAttachment( ent.BladeID1 )
		local att2 = ent:GetAttachment( ent.BladeID2 )

		if att1 and att2 then
			local blades = {
				[1] = {
					pos = att1.Pos,
					dir = att1.Ang:Forward(),
				},
				[2] = {
					pos = att2.Pos,
					dir = att2.Ang:Forward(),
				},
			}
			return blades
		end
	end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "SaberStaff 04"
hilt.Author = "Truce"
hilt.id = "ss4"
hilt.mdl = "models/swtor/anzati/blue_gray.mdl"
hilt.functiontype = "staff"
hilt.info = {
    ParentData = {
        ["RH"] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, 1, 1),
            ang = Angle(-90, -90, -30),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 0),
            ang = Angle(90, 90, 90),
        },
    },
	GetBladePos = function( ent, SWEP, ply )
		if not ent.BladeID1 then
			ent.BladeID1 = ent:LookupAttachment( "blade1" )
		end

		if not ent.BladeID2 then
			ent.BladeID2 = ent:LookupAttachment( "blade2" )
		end

		local att1 = ent:GetAttachment( ent.BladeID1 )
		local att2 = ent:GetAttachment( ent.BladeID2 )

		if att1 and att2 then
			local blades = {
				[1] = {
					pos = att1.Pos,
					dir = att1.Ang:Forward(),
				},
				[2] = {
					pos = att2.Pos,
					dir = att2.Ang:Forward(),
				},
			}
			return blades
		end
	end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "SaberStaff 05"
hilt.Author = "Truce"
hilt.id = "ss5"
hilt.mdl = "models/swtor/anzati/lightsabers/custom_dwayne_double.mdl"
hilt.functiontype = "staff"
hilt.Spawnable = false  -- uncomment to unlist in q-menu
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, 0),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 0),
            ang = Angle(90, 90, 90),
        },
    },
	GetBladePos = function( ent, SWEP, ply )
		if not ent.BladeID1 then
			ent.BladeID1 = ent:LookupAttachment( "blade1" )
		end

		if not ent.BladeID2 then
			ent.BladeID2 = ent:LookupAttachment( "blade2" )
		end

		local att1 = ent:GetAttachment( ent.BladeID1 )
		local att2 = ent:GetAttachment( ent.BladeID2 )

		if att1 and att2 then
			local blades = {
				[1] = {
					pos = att1.Pos,
					dir = att1.Ang:Forward(),
				},
				[2] = {
					pos = att2.Pos,
					dir = att2.Ang:Forward(),
				},
			}
			return blades
		end
	end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "SaberStaff 06"
hilt.Author = "Truce"
hilt.id = "ss6"
hilt.mdl = "models/swtor/anzati/lightsabers/custom_fry_double.mdl"
hilt.Spawnable = true  -- uncomment to unlist in q-menu
hilt.functiontype = "staff"
hilt.info = {
    ParentData = {
        ["RH"] = { 
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -0.3, -7),
            ang = Angle(-90, -0, -0),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 0),
            ang = Angle(90, 90, 90),
        },
    },
	GetBladePos = function( ent, SWEP, ply )
		if not ent.BladeID1 then
			ent.BladeID1 = ent:LookupAttachment( "blade1" )
		end

		if not ent.BladeID2 then
			ent.BladeID2 = ent:LookupAttachment( "blade2" )
		end

		local att1 = ent:GetAttachment( ent.BladeID1 )
		local att2 = ent:GetAttachment( ent.BladeID2 )

		if att1 and att2 then
			local blades = {
				[1] = {
					pos = att1.Pos,
					dir = att1.Ang:Forward(),
				},
				[2] = {
					pos = att2.Pos,
					dir = att2.Ang:Forward(),
				},
			}
			return blades
		end
	end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Temple Guard SaberStaff hilt"
hilt.Author = "Truce"
hilt.id = "ss7"
hilt.mdl = "models/twinsaber/twinsaber1.mdl"
hilt.Spawnable = true  -- uncomment to unlist in q-menu
hilt.functiontype = "staff"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, 0),
            ang = Angle(-0, -90, -0),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 0),
            ang = Angle(0, 0, 90),
        },
    },
    GetBladePos = function( ent, swep, ply )
		if not ent.BladeID1 then
			ent.BladeID1 = ent:LookupAttachment( "primary_blade" )
		end
		if not ent.BladeID2 then
			ent.BladeID2 = ent:LookupAttachment( "secondary_blade" )
		end

		local att1 = ent:GetAttachment( ent.BladeID1 )
		local att2 = ent:GetAttachment( ent.BladeID2 )

		if att1 and att2 then
			local blades = {
				[1] = {
					pos = att1.Pos,
					dir = att1.Ang:Up(),
				},
				[2] = {
					pos = att2.Pos,
					dir = att2.Ang:Up(),
				}
			}
			return blades
		end
	end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "The Grand Inquisitor Hilt"
hilt.Author = "Truce"
hilt.id = "ss8"
hilt.mdl = "models/the grand saber/the grand saber1.mdl"
hilt.Spawnable = true  -- uncomment to unlist in q-menu
hilt.functiontype = "staff"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, 0),
            ang = Angle(-0, -90, -0),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 0),
            ang = Angle(0, 0, 90),
        },
    },
    GetBladePos = function( ent, swep, ply )
		if not ent.BladeID1 then
			ent.BladeID1 = ent:LookupAttachment( "primary_blade" )
		end
		if not ent.BladeID2 then
			ent.BladeID2 = ent:LookupAttachment( "secondary_blade" )
		end

		local att1 = ent:GetAttachment( ent.BladeID1 )
		local att2 = ent:GetAttachment( ent.BladeID2 )

		if att1 and att2 then
			local blades = {
				[1] = {
					pos = att1.Pos,
					dir = att1.Ang:Up(),
				},
				[2] = {
					pos = att2.Pos,
					dir = att2.Ang:Up(),
				}
			}
			return blades
		end
	end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "SaberStaff 10"
hilt.Author = "Truce"
hilt.id = "ss10"
hilt.mdl = "models/donation7/donation7.mdl"
hilt.Spawnable = true
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent, SWEP, ply )
		if not ent.BladeID1 then
			ent.BladeID1 = ent:LookupAttachment( "blade1" )
		end

		if not ent.BladeID2 then
			ent.BladeID2 = ent:LookupAttachment( "quillon2" )
		end

		local att1 = ent:GetAttachment( ent.BladeID1 )
		local att2 = ent:GetAttachment( ent.BladeID2 )

		if att1 and att2 then
			local blades = {
				[1] = {
					pos = att1.Pos,
					dir = att1.Ang:Forward(),
				},
				[2] = {
					pos = att2.Pos,
					dir = att2.Ang:Forward(),
				},
			}
			return blades
		end
	end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "SaberStaff 11"
hilt.Author = "Truce"
hilt.id = "ss11"
hilt.mdl = "models/dani/dani.mdl"
hilt.Spawnable = true
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent, SWEP, ply )
		if not ent.BladeID1 then
			ent.BladeID1 = ent:LookupAttachment( "blade1" )
		end

		if not ent.BladeID2 then
			ent.BladeID2 = ent:LookupAttachment( "blade2" )
		end

		local att1 = ent:GetAttachment( ent.BladeID1 )
		local att2 = ent:GetAttachment( ent.BladeID2 )

		if att1 and att2 then
			local blades = {
				[1] = {
					pos = att1.Pos,
					dir = att1.Ang:Forward(),
				},
				[2] = {
					pos = att2.Pos,
					dir = att2.Ang:Forward(),
				},
			}
			return blades
		end
	end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "SaberStaff 12"
hilt.Author = "Truce"
hilt.id = "ss12"
hilt.mdl = "models/borth-twin/borth-twin.mdl"
hilt.Spawnable = true
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent, SWEP, ply )
		if not ent.BladeID1 then
			ent.BladeID1 = ent:LookupAttachment( "blade1" )
		end

		if not ent.BladeID2 then
			ent.BladeID2 = ent:LookupAttachment( "quillon2" )
		end

		local att1 = ent:GetAttachment( ent.BladeID1 )
		local att2 = ent:GetAttachment( ent.BladeID2 )

		if att1 and att2 then
			local blades = {
				[1] = {
					pos = att1.Pos,
					dir = att1.Ang:Forward(),
				},
				[2] = {
					pos = att2.Pos,
					dir = att2.Ang:Forward(),
				},
			}
			return blades
		end
	end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "SaberStaff 13"
hilt.Author = "Truce"
hilt.id = "ss13"
hilt.mdl = "models/swtor/arsenic/lightsabers/vindicator'ssaberstaff.mdl"
hilt.Spawnable = true
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -13),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent, SWEP, ply )
		if not ent.BladeID1 then
			ent.BladeID1 = ent:LookupAttachment( "blade1" )
		end

		if not ent.BladeID2 then
			ent.BladeID2 = ent:LookupAttachment( "blade2" )
		end

		local att1 = ent:GetAttachment( ent.BladeID1 )
		local att2 = ent:GetAttachment( ent.BladeID2 )

		if att1 and att2 then
			local blades = {
				[1] = {
					pos = att1.Pos,
					dir = att1.Ang:Forward(),
				},
				[2] = {
					pos = att2.Pos,
					dir = att2.Ang:Forward(),
				},
			}
			return blades
		end
	end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "SaberStaff 14"
hilt.Author = "Truce"
hilt.id = "ss14"
hilt.mdl = "models/swtor/arsenic/lightsabers/vengeance'sunsealedsaberstaff.mdl"
hilt.Spawnable = true
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -17),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent, SWEP, ply )
		if not ent.BladeID1 then
			ent.BladeID1 = ent:LookupAttachment( "blade1" )
		end

		if not ent.BladeID2 then
			ent.BladeID2 = ent:LookupAttachment( "blade2" )
		end

		local att1 = ent:GetAttachment( ent.BladeID1 )
		local att2 = ent:GetAttachment( ent.BladeID2 )

		if att1 and att2 then
			local blades = {
				[1] = {
					pos = att1.Pos,
					dir = att1.Ang:Forward(),
				},
				[2] = {
					pos = att2.Pos,
					dir = att2.Ang:Forward(),
				},
			}
			return blades
		end
	end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "SaberStaff 15"
hilt.Author = "Truce"
hilt.id = "ss15"
hilt.mdl = "models/trident/trident.mdl"
hilt.Spawnable = true
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent, SWEP, ply )
		if not ent.BladeID1 then
			ent.BladeID1 = ent:LookupAttachment( "blade1" )
		end

		if not ent.BladeID2 then
			ent.BladeID2 = ent:LookupAttachment( "blade2" )
		end

        if not ent.BladeID3 then
			ent.BladeID3 = ent:LookupAttachment( "quillon1" )
		end

        if not ent.BladeID4 then
			ent.BladeID4 = ent:LookupAttachment( "quillon2" )
		end

		if not ent.BladeID5 then
			ent.BladeID5 = ent:LookupAttachment( "quillon3" )
		end

        if not ent.BladeID6 then
			ent.BladeID6 = ent:LookupAttachment( "quillon4" )
		end

		local att1 = ent:GetAttachment( ent.BladeID1 )
		local att2 = ent:GetAttachment( ent.BladeID2 )
        local att3 = ent:GetAttachment( ent.BladeID3 )
        local att4 = ent:GetAttachment( ent.BladeID4 )
        local att5 = ent:GetAttachment( ent.BladeID5 )
        local att6 = ent:GetAttachment( ent.BladeID6 )

		if att1 and att2 and att3 and att4 and att5 and att6 then
			local blades = {
				[1] = {
					pos = att1.Pos,
					dir = att1.Ang:Forward(),
				},
				[2] = {
					pos = att2.Pos,
					dir = att2.Ang:Forward(),
				},
                [3] = {
					pos = att3.Pos,
					dir = att3.Ang:Forward(), length_multiplier = 0.05
				},
                [4] = {
					pos = att4.Pos,
					dir = att4.Ang:Forward(), length_multiplier = 0.05
				},
                [5] = {
					pos = att5.Pos,
					dir = att5.Ang:Forward(), length_multiplier = 0.05
				},
                [6] = {
					pos = att6.Pos,
					dir = att6.Ang:Forward(), length_multiplier = 0.05
				},
			}
			return blades
		end
	end,
}
LSCS:RegisterHilt( hilt )
----------------------------------- Melee Weapons -----------------------------------------------
local hilt = {}
hilt.PrintName = "Electrostaff"
hilt.Author = "Truce"
hilt.id = "electrostaff"
hilt.mdl = "models/merc_electrostaff.mdl"
hilt.Spawnable = false  -- uncomment to unlist in q-menu
hilt.functiontype = "staff"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(4, -1.5, 0),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
    local blades = {
    [1] = {
         pos = ent:LocalToWorld( Vector(-30,0,0) ),
         dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
     },
    [2] = {
         pos = ent:LocalToWorld( Vector(30,0,0) ),
         dir = ent:LocalToWorldAngles( Angle(-90,-180,0) ):Up(),
     },
 }

 return blades
end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Electro Batons hilt"
hilt.Author = "Truce"
hilt.id = "electrobatons"
hilt.Spawnable = false  -- uncomment to unlist in q-menu
hilt.mdl = "models/rising/inqusitor_dagger.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -30),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 30),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = {
                pos = ent:LocalToWorld( Vector(2,-0.6,-0.1) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Electro Hammer hilt"
hilt.Author = "Truce"
hilt.id = "electrohammerh"
hilt.Spawnable = false  -- uncomment to unlist in q-menu
hilt.mdl = "models/rising/inqusitor_hammer.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
                pos = ent:LocalToWorld( Vector(-16,-1.7,0.7) ),
                dir = ent:LocalToWorldAngles( Angle(90,185,0) ):Up(),
            },
            [2] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
            pos = ent:LocalToWorld( Vector(-14, -3.5, 7) ),
            dir = ent:LocalToWorldAngles( Angle(90,185,1) ):Up(),
        },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Rapier"
hilt.Author = "Truce"
hilt.id = "rap"
hilt.mdl = "models/demonssouls/weapons/epee_rapier.mdl"
hilt.Spawnable = false  -- uncomment to unlist in q-menu
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(5, -1.5, -1),
            ang = Angle(90, 0, 90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------  y   x   z
                pos = ent:LocalToWorld( Vector(-0,-0.4,-0.1) ),
                dir = ent:LocalToWorldAngles( Angle(-90,-179,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Tusken Gaffi"
hilt.Author = "Truce"
hilt.id = "tg"
hilt.mdl = "models/plo/cwa/melee/hett_tusken_gaffi.mdl"
hilt.Spawnable = false  -- uncomment to unlist in q-menu
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
                pos = ent:LocalToWorld( Vector(2,-0.5,-0.1) ),
                dir = ent:LocalToWorldAngles( Angle(85,180,-5) ):Up(),
            },
            [2] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
            pos = ent:LocalToWorld( Vector(2,-0.5,-0.1) ),
            dir = ent:LocalToWorldAngles( Angle(-85,-180,-5) ):Up(),
        },
        }

        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Bo Rifle Staff"
hilt.Author = "Truce"
hilt.id = "bo_r"
hilt.mdl = "models/truce/bo_rifle_lscs.mdl"
hilt.Spawnable = false
hilt.info = {
	ParentData = {
		["RH"] = {
			bone = "ValveBiped.Bip01_R_Hand",
			pos = Vector(4.25, -1.5, -1),
			ang = Angle(172, 0, 10),
		},
		["LH"] = {
			bone = "ValveBiped.Bip01_L_Hand",
			pos = Vector(4.25, -1.5, 1),
			ang = Angle(8, 0, -10),
		},
	},
	GetBladePos = function( ent )
		if not ent.BladeID1 then
			ent.BladeID1 = ent:LookupAttachment( "primary_blade" )
		end
		if not ent.BladeID2 then
			ent.BladeID2 = ent:LookupAttachment( "secondary_blade" )
		end

		local att1 = ent:GetAttachment( ent.BladeID1 )
		local att2 = ent:GetAttachment( ent.BladeID2 )

		if att1 and att2 then
			local blades = {
				[1] = {
					pos = att1.Pos,
					dir = att1.Ang:Up(),
				},
				[2] = {
					pos = att2.Pos,
					dir = att2.Ang:Up(),
				}
			}
			return blades
		end
	end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Shock Lance"
hilt.Author = "Miller"
hilt.id = "lance"
hilt.mdl = "models/shock_lance/shock_lance.mdl"
hilt.Spawnable = false  -- uncomment to unlist in q-menu
hilt.info = {
	ParentData = {
		["RH"] = {
			bone = "ValveBiped.Bip01_R_Hand",
			pos = Vector(-1.5, 3, 30),
			ang = Angle(172, 0, 10),
		},
		["LH"] = {
			bone = "ValveBiped.Bip01_L_Hand",
			pos = Vector(4.25, -1.5, 1),
			ang = Angle(8, 0, -10),
		},
	},
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
                pos = ent:LocalToWorld( Vector(-0,0,60) ),
                dir = ent:LocalToWorldAngles( Angle(0,180,0) ):Up(),
            },
        }

        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Lightsaber Shield Hilt"
hilt.Author = "Truce"
hilt.id = "lsh"
hilt.mdl = "models/bshields/dshield.mdl"
hilt.Spawnable = false  -- uncomment to unlist in q-menu
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(11, -12, 5), -- 
            ang = Angle(0, -10, 165),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Forearm",
            pos = Vector(4, 4.56, 8.62), -- 
            ang = Angle(-60, 90, 0),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
                pos = ent:LocalToWorld( Vector(-2.8,-0,-0.1) ),
                dir = ent:LocalToWorldAngles( Angle(-90,180,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Stun Baton"
hilt.Author = "Truce"
hilt.id = "stun"
hilt.mdl = "models/weapons/w_stunbaton.mdl"
hilt.Spawnable = false  -- uncomment to unlist in q-menu
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
                pos = ent:LocalToWorld( Vector(-2.8,-0,-0.1) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "God"
hilt.Author = "Truce"
hilt.id = "god"
hilt.mdl = "models/donation4/donation4.mdl"
hilt.Spawnable = false  -- uncomment to unlist in q-menu
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -12),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, 1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent, SWEP, ply )
		if not ent.BladeID1 then
			ent.BladeID1 = ent:LookupAttachment( "blade1" )
		end

		if not ent.BladeID2 then
			ent.BladeID2 = ent:LookupAttachment( "blade2" )
		end

		if not ent.BladeID3 then
			ent.BladeID3 = ent:LookupAttachment( "blade3" )
		end

        if not ent.BladeID4 then
			ent.BladeID4 = ent:LookupAttachment( "blade4" )
		end
		local att1 = ent:GetAttachment( ent.BladeID1 )
		local att2 = ent:GetAttachment( ent.BladeID2 )
        local att3 = ent:GetAttachment( ent.BladeID3 )
        local att4 = ent:GetAttachment( ent.BladeID4 )

		if att1 and att2 and att3 and att4 then
			local blades = {
				[1] = {
					pos = att1.Pos,
					dir = att1.Ang:Forward(),
				},
				[2] = {
					pos = att2.Pos,
					dir = att2.Ang:Forward(),
				},
                [3] = {
					pos = att3.Pos,
					dir = att3.Ang:Forward(),
				},
                [4] = {
					pos = att4.Pos,
					dir = att4.Ang:Forward(),
				},
			}
			return blades
		end
	end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Vision Katana"
hilt.Author = "truce"
hilt.id = "vk"
hilt.mdl = "models/truce/vision_katana.mdl"
hilt.Spawnable = false  -- uncomment to unlist in q-menu
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, 0),
            ang = Angle(-80, -148, -130),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 0),
            ang = Angle(90, 200, 130),
        },
    },
	GetBladePos = function( ent, swep, ply )
		if not ent.BladeID then
			ent.BladeID = ent:LookupAttachment( "primary_blade" )
		end

		local att = ent:GetAttachment( ent.BladeID )

		if att then
			local blades = {
				[1] = {
					pos = att.Pos,
					dir = att.Ang:Up(),
				}
			}
			return blades
		end
	end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Vision Scabbard"
hilt.Author = "truce"
hilt.id = "vs"
hilt.mdl = "models/truce/scabbard.mdl"
hilt.Spawnable = false  -- uncomment to unlist in q-menu
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, 0),
            ang = Angle(-80, -148, -130),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 0),
            ang = Angle(90, 200, 130),
        },
    },
	GetBladePos = function( ent, swep, ply )
		if not ent.BladeID then
			ent.BladeID = ent:LookupAttachment( "primary_blade" )
		end

		local att = ent:GetAttachment( ent.BladeID )

		if att then
			local blades = {
				[1] = {
					pos = att.Pos,
					dir = att.Ang:Up(),
				}
			}
			return blades
		end
	end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "inv"
hilt.Author = "Truce"
hilt.id = "inv"
hilt.Spawnable = false  -- uncomment to unlist in q-menu
hilt.mdl = "models/fallenlogic/hilts/invisible.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(6, 2, 1),
            ang = Angle(-180, -0, 0),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(6, 1.5, 1),
            ang = Angle(-180, 0, 0),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
                pos = ent:LocalToWorld( Vector(2,-0.6,-0.1) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt ) 

local hilt = {}
hilt.PrintName = "Exotic Cross Guard Hilt"
hilt.Author = "Truce"
hilt.id = "eh1"
hilt.mdl = "models/donation3/donation3.mdl"
hilt.Spawnable = true
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent, SWEP, ply )
		if not ent.BladeID1 then
			ent.BladeID1 = ent:LookupAttachment( "blade1" )
		end

		if not ent.BladeID2 then
			ent.BladeID2 = ent:LookupAttachment( "quillon2" )
		end

		if not ent.BladeID3 then
			ent.BladeID3 = ent:LookupAttachment( "quillon3" )
		end

		local att1 = ent:GetAttachment( ent.BladeID1 )
		local att2 = ent:GetAttachment( ent.BladeID2 )
        local att3 = ent:GetAttachment( ent.BladeID3 )

		if att1 and att2 and att3 then
			local blades = {
				[1] = {
					pos = att1.Pos,
					dir = att1.Ang:Forward(),
				},
				[2] = {
					pos = att2.Pos,
					dir = att2.Ang:Forward(), length_multiplier = 0.07
				},
                [3] = {
					pos = att3.Pos,
					dir = att3.Ang:Forward(), length_multiplier = 0.07
				},
			}
			return blades
		end
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "The Gauntlet"
hilt.Author = "Truce"
hilt.id = "eh2"
hilt.mdl = "models/donation gauntlet/donation gauntlet.mdl"
hilt.Spawnable = true
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, 1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent, SWEP, ply )
		if not ent.BladeID1 then
			ent.BladeID1 = ent:LookupAttachment( "blade1" )
		end

		if not ent.BladeID2 then
			ent.BladeID2 = ent:LookupAttachment( "blade2" )
		end

		local att1 = ent:GetAttachment( ent.BladeID1 )
		local att2 = ent:GetAttachment( ent.BladeID2 )

		if att1 and att2 then
			local blades = {
				[1] = {
					pos = att1.Pos,
					dir = att1.Ang:Forward(),
				},
				[2] = {
					pos = att2.Pos,
					dir = att2.Ang:Forward(),
				},
			}
			return blades
		end
	end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "The Trident Saberstaff"
hilt.Author = "Truce"
hilt.id = "eh3"
hilt.mdl = "models/trident/trident.mdl"
hilt.Spawnable = true
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent, SWEP, ply )
		if not ent.BladeID1 then
			ent.BladeID1 = ent:LookupAttachment( "blade1" )
		end

		if not ent.BladeID2 then
			ent.BladeID2 = ent:LookupAttachment( "blade2" )
		end

        if not ent.BladeID3 then
			ent.BladeID3 = ent:LookupAttachment( "quillon1" )
		end

        if not ent.BladeID4 then
			ent.BladeID4 = ent:LookupAttachment( "quillon2" )
		end

		if not ent.BladeID5 then
			ent.BladeID5 = ent:LookupAttachment( "quillon3" )
		end

        if not ent.BladeID6 then
			ent.BladeID6 = ent:LookupAttachment( "quillon4" )
		end

		local att1 = ent:GetAttachment( ent.BladeID1 )
		local att2 = ent:GetAttachment( ent.BladeID2 )
        local att3 = ent:GetAttachment( ent.BladeID3 )
        local att4 = ent:GetAttachment( ent.BladeID4 )
        local att5 = ent:GetAttachment( ent.BladeID5 )
        local att6 = ent:GetAttachment( ent.BladeID6 )

		if att1 and att2 and att3 and att4 and att5 and att6 then
			local blades = {
				[1] = {
					pos = att1.Pos,
					dir = att1.Ang:Forward(),
				},
				[2] = {
					pos = att2.Pos,
					dir = att2.Ang:Forward(),
				},
                [3] = {
					pos = att3.Pos,
					dir = att3.Ang:Forward(), length_multiplier = 0.8
				},
                [4] = {
					pos = att4.Pos,
					dir = att4.Ang:Forward(), length_multiplier = 0.8
				},
                [5] = {
					pos = att5.Pos,
					dir = att5.Ang:Forward(), length_multiplier = 0.8
				},
                [6] = {
					pos = att6.Pos,
					dir = att6.Ang:Forward(), length_multiplier = 0.8
				},
			}
			return blades
		end
	end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Theo"
hilt.Author = "Truce"
hilt.id = "eh4"
hilt.mdl = "models/theo/theo.mdl"
hilt.Spawnable = true
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -0, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 0, 90),
        },
    },
    GetBladePos = function( ent, SWEP, ply )
		if not ent.BladeID1 then
			ent.BladeID1 = ent:LookupAttachment( "blade1" )
		end

		if not ent.BladeID2 then
			ent.BladeID2 = ent:LookupAttachment( "blade2" )
		end

		local att1 = ent:GetAttachment( ent.BladeID1 )
		local att2 = ent:GetAttachment( ent.BladeID2 )

		if att1 and att2 then
			local blades = {
				[1] = {
					pos = att1.Pos,
					dir = att1.Ang:Forward(),
				},
				[2] = {
					pos = att2.Pos,
					dir = att2.Ang:Forward(),
				},
			}
			return blades
		end
	end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "The Trident"
hilt.Author = "Truce"
hilt.id = "eh5"
hilt.mdl = "models/dante/dante.mdl"
hilt.Spawnable = true
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -15),
            ang = Angle(-90, -0, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 8),
            ang = Angle(90, 0, 90),
        },
    },
    GetBladePos = function( ent, SWEP, ply )
		if not ent.BladeID1 then
			ent.BladeID1 = ent:LookupAttachment( "blade1" )
		end

		if not ent.BladeID2 then
			ent.BladeID2 = ent:LookupAttachment( "blade2" )
		end

        if not ent.BladeID3 then
			ent.BladeID3 = ent:LookupAttachment( "blade3" )
		end

		local att1 = ent:GetAttachment( ent.BladeID1 )
		local att2 = ent:GetAttachment( ent.BladeID2 )
        local att3 = ent:GetAttachment( ent.BladeID3 )

		if att1 and att2 and att3 then
			local blades = {
				[1] = {
					pos = att1.Pos,
					dir = att1.Ang:Forward(),
				},
				[2] = {
					pos = att2.Pos,
					dir = att2.Ang:Forward(),
				},
                [3] = {
					pos = att3.Pos,
					dir = att3.Ang:Forward(),
				},
			}
			return blades
		end
	end,
}
LSCS:RegisterHilt( hilt )

---------------------------------- LEGO -----------------------------------------------------------

local hilt = {}
hilt.PrintName = "Lego"
hilt.Author = "Truce"
hilt.id = "lego"
hilt.mdl = "models/swtor/anzati/lightsabers/lego_lightsaber.mdl"
hilt.Spawnable = false
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -0, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 0, 90),
        },
    },
    GetBladePos = function( ent, SWEP, ply )
		if not ent.BladeID1 then
			ent.BladeID1 = ent:LookupAttachment( "blade1" )
		end

		local att1 = ent:GetAttachment( ent.BladeID1 )

		if att1 then
			local blades = {
				[1] = {
					pos = att1.Pos,
					dir = att1.Ang:Forward(),
				},
			}
			return blades
		end
	end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Lego Saberstaff"
hilt.Author = "Truce"
hilt.id = "legoss"
hilt.mdl = "models/swtor/anzati/lightsabers/lego_lightsaber_dual.mdl"
hilt.Spawnable = false
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -0, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 0, 90),
        },
    },
    GetBladePos = function( ent, SWEP, ply )
		if not ent.BladeID1 then
			ent.BladeID1 = ent:LookupAttachment( "blade1" )
		end
		if not ent.BladeID2 then
			ent.BladeID2 = ent:LookupAttachment( "blade2" )
		end

		local att1 = ent:GetAttachment( ent.BladeID1 )
		local att2 = ent:GetAttachment( ent.BladeID2 )

		if att1 and att2 then
			local blades = {
				[1] = {
					pos = att1.Pos,
					dir = att1.Ang:Forward(),
				},
                [2] = {
					pos = att2.Pos,
					dir = att2.Ang:Forward(),
				},
			}
			return blades
		end
	end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Lego Kylo"
hilt.Author = "Truce"
hilt.id = "legokylo"
hilt.mdl = "models/swtor/anzati/lightsabers/lego_lightsaber_kylo.mdl"
hilt.Spawnable = false
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -0, -0),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 0, 0),
        },
    },
    GetBladePos = function( ent, SWEP, ply )
		if not ent.BladeID1 then
			ent.BladeID1 = ent:LookupAttachment( "blade1" )
		end
		if not ent.BladeID2 then
			ent.BladeID2 = ent:LookupAttachment( "quillon1" )
		end
        if not ent.BladeID3 then
			ent.BladeID3 = ent:LookupAttachment( "quillon2" )
		end

		local att1 = ent:GetAttachment( ent.BladeID1 )
		local att2 = ent:GetAttachment( ent.BladeID2 )
        local att3 = ent:GetAttachment( ent.BladeID3 )

		if att1 and att2 and att3 then
			local blades = {
				[1] = {
					pos = att1.Pos,
					dir = att1.Ang:Forward(),
				},
                [2] = {
					pos = att2.Pos,
					dir = att2.Ang:Forward(), length_multiplier = 0.2
				},
                [3] = {
					pos = att3.Pos,
					dir = att3.Ang:Forward(), length_multiplier = 0.2
				},
			}
			return blades
		end
	end,
}
LSCS:RegisterHilt( hilt )

----------------------------------- Reverse Hilt -----------------------------------------------

local hilt = {}
hilt.PrintName = "Reverse Hilt 01"
hilt.Author = "Truce"
hilt.id = "shr1"
hilt.mdl = "models/sgg/starwars/weapons/w_saber_4_hilt.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, 6.5),
            ang = Angle(90, 90, 90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, -6.5),
            ang = Angle(-90, -90, -90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
                pos = ent:LocalToWorld( Vector(2,-0.6,-0.1) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Reverse Hilt 02"
hilt.Author = "Truce"
hilt.id = "shr2"
hilt.mdl = "models/swtor/arsenic/lightsabers/ardentdefender'slightsaber.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, 6.5),
            ang = Angle(90, 90, 90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, -6.5),
            ang = Angle(-90, -90, -90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
                pos = ent:LocalToWorld( Vector(0,-0.425,-0.15) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Reverse Hilt 03"
hilt.Author = "Truce"
hilt.id = "shr3"
hilt.mdl = "models/swtor/arsenic/lightsabers/blademaster'sattenuatedlightsaber.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, 7),
            ang = Angle(90, 90, 90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, -6.5),
            ang = Angle(-90, -90, -90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
                pos = ent:LocalToWorld( Vector(0,-0.425,-0.15) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Reverse Hilt 04"
hilt.Author = "Truce"
hilt.id = "shr4"
hilt.mdl = "models/swtor/arsenic/lightsabers/novalightsaber.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, 6.5),
            ang = Angle(90, 90, 90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, -6.5),
            ang = Angle(-90, -90, -90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
                pos = ent:LocalToWorld( Vector(1,-0.4, -0.2) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Reverse Hilt 05"
hilt.Author = "Truce"
hilt.id = "shr5"
hilt.mdl = "models/swtor/arsenic/lightsabers/fearlessretaliator'slightsaber.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, -6.5),
            ang = Angle(-90, -90, -90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
                pos = ent:LocalToWorld( Vector(2,-0.425,-0.27) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Reverse Hilt 06"
hilt.Author = "Truce"
hilt.id = "shr6"
hilt.mdl = "models/starwars/cwa/lightsabers/sparklingcrystal.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, 6.5),
            ang = Angle(90, 0, 90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, -6.5),
            ang = Angle(-90, -90, -90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
                pos = ent:LocalToWorld( Vector(2,-0.6,-0.1) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Reverse Hilt 07"
hilt.Author = "Truce"
hilt.id = "shr7"
hilt.mdl = "models/swtor/anzati/lightsabers/uchigatana.mdl"
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, 0, 10),
            ang = Angle(90, 0, 90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, -10),
            ang = Angle(-90, 0, -90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
                pos = ent:LocalToWorld( Vector(0.5,-1, 0.9) ),
                dir = ent:LocalToWorldAngles( Angle(90,180,0) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Night Blade"
hilt.Author = "Truce"
hilt.id = "bot"
hilt.mdl = "models/killersword.mdl"
hilt.Spawnable = false
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.5, -1, -5),
            ang = Angle(0, 0, 180),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------  y   x   z
                pos = ent:LocalToWorld( Vector(-0,-0, 0) ),
                dir = ent:LocalToWorldAngles( Angle(0,0,-0.7) ):Up(),
            },
        }
        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Sawblade"
hilt.Author = "Stoneman"
hilt.id = "sawblade"
hilt.mdl = "models/props_junk/sawblade001a.mdl"
hilt.Spawnable = false
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -6.5),
            ang = Angle(-90, -0, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, -1, 6.5),
            ang = Angle(90, 0, 90),
        },
    },
    GetBladePos = function( ent )
        local blades = {}
        local bladeCount = 8
        local radius = 0.6
        local zOffset = -0.1  -- Z offset to match the original blade position

        for i = 1, bladeCount do
            local angle = (math.pi * 2) * ((i-1) / bladeCount)
            local x = math.cos(angle) * radius
            local y = math.sin(angle) * radius

            -- Each blade points outward from the center
            local pos = ent:LocalToWorld(Vector(0, x, y + zOffset))
            local dir = ent:LocalToWorldAngles(Angle(90, 180 + (angle * 180 / math.pi), 0)):Up()

            blades[i] = {
                pos = pos,
                dir = dir,
                length_multiplier = 0.35
            }
        end

        return blades
    end,
}
LSCS:RegisterHilt( hilt )

hilt.PrintName = "Energy Sword"
hilt.Author = "Truce"
hilt.id = "energysword"
hilt.mdl = "models/koint/custom/halo/weapon/energysword.mdl"
hilt.Spawnable = false  -- uncomment to unlist in q-menu
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -1),
            ang = Angle(-90, -0 -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, 1, 1),
            ang = Angle(90, 0, 90),
        },
    },
    GetBladePos = function( ent, SWEP, ply )
		if not ent.BladeID1 then
			ent.BladeID1 = ent:LookupAttachment( "blade1" )
		end

		if not ent.BladeID2 then
			ent.BladeID2 = ent:LookupAttachment( "blade2" )
		end

		if not ent.BladeID3 then
			ent.BladeID3 = ent:LookupAttachment( "blade3" )
		end

        if not ent.BladeID4 then
			ent.BladeID4 = ent:LookupAttachment( "blade4" )
		end

        if not ent.BladeID5 then
			ent.BladeID5 = ent:LookupAttachment( "quillon1" )
		end

		if not ent.BladeID6 then
			ent.BladeID6 = ent:LookupAttachment( "quillon2" )
		end

		if not ent.BladeID7 then
			ent.BladeID7 = ent:LookupAttachment( "quillon3" )
		end

        if not ent.BladeID8 then
			ent.BladeID8 = ent:LookupAttachment( "quillon4" )
		end

        if not ent.BladeID9 then
			ent.BladeID9 = ent:LookupAttachment( "quillon5" )
		end

        if not ent.BladeID10 then
			ent.BladeID10 = ent:LookupAttachment( "quillon6" )
		end

        if not ent.BladeID11 then
			ent.BladeID11 = ent:LookupAttachment( "quillon7" )
		end

        if not ent.BladeID12 then
			ent.BladeID12 = ent:LookupAttachment( "quillon8" )
		end

        if not ent.BladeID13 then
			ent.BladeID13 = ent:LookupAttachment( "quillon9" )
		end

        if not ent.BladeID14 then
			ent.BladeID14 = ent:LookupAttachment( "quillon10" )
		end

        if not ent.BladeID15 then
			ent.BladeID15 = ent:LookupAttachment( "quillon11" )
		end

        if not ent.BladeID16 then
			ent.BladeID16 = ent:LookupAttachment( "quillon12" )
		end

        if not ent.BladeID17 then
			ent.BladeID17 = ent:LookupAttachment( "quillon13" )
		end

        if not ent.BladeID18 then
			ent.BladeID18 = ent:LookupAttachment( "quillon14" )
		end

		local att1 = ent:GetAttachment( ent.BladeID1 )
		local att2 = ent:GetAttachment( ent.BladeID2 )
        local att3 = ent:GetAttachment( ent.BladeID3 )
        local att4 = ent:GetAttachment( ent.BladeID4 )
		local att5 = ent:GetAttachment( ent.BladeID5 )
		local att6 = ent:GetAttachment( ent.BladeID6 )
        local att7 = ent:GetAttachment( ent.BladeID7 )
        local att8 = ent:GetAttachment( ent.BladeID8 )
        local att9 = ent:GetAttachment( ent.BladeID9 )
        local att10 = ent:GetAttachment( ent.BladeID10 )
        local att11 = ent:GetAttachment( ent.BladeID11 )
        local att12 = ent:GetAttachment( ent.BladeID12 )
        local att13 = ent:GetAttachment( ent.BladeID13 )
        local att14 = ent:GetAttachment( ent.BladeID14 )
        local att15 = ent:GetAttachment( ent.BladeID15 )
        local att16 = ent:GetAttachment( ent.BladeID16 )
        local att17 = ent:GetAttachment( ent.BladeID17 )
        local att18 = ent:GetAttachment( ent.BladeID18 )

		if att1 and att2 and att3 and att4 and att5 and att6 and att7 and att8 and att9 and att10 and att11 and att12 and att13 and att14 and att15 and att16 and att17 and att18 then
			local blades = {
				[1] = {
					pos = att1.Pos,
					dir = att1.Ang:Forward(), length_multiplier = 0.9
				},
				[2] = {
					pos = att2.Pos,
					dir = att2.Ang:Forward(), length_multiplier = 0.9
				},
                [3] = {
					pos = att3.Pos,
					dir = att3.Ang:Forward(), length_multiplier = 0.9
				},
                [4] = {
					pos = att4.Pos,
					dir = att4.Ang:Forward(), length_multiplier = 0.9
				},
                [5] = {
					pos = att5.Pos,
					dir = att5.Ang:Forward(), length_multiplier = 0.1
				},
				[6] = {
					pos = att6.Pos,
					dir = att6.Ang:Forward(), length_multiplier = 0.14
				},
                [7] = {
					pos = att7.Pos,
					dir = att7.Ang:Forward(), length_multiplier = 0.14
				},
                [8] = {
					pos = att8.Pos,
					dir = att8.Ang:Forward(), length_multiplier = 0.14
				},
                [9] = {
					pos = att9.Pos,
					dir = att9.Ang:Forward(), length_multiplier = 0.14
				},
                [10] = {
					pos = att10.Pos,
					dir = att10.Ang:Forward(), length_multiplier = 0.14
				},
                [11] = {
					pos = att11.Pos,
					dir = att11.Ang:Forward(), length_multiplier = 0.14
				},
                [12] = {
					pos = att12.Pos,
					dir = att12.Ang:Forward(), length_multiplier = 0.14
				},
                [13] = {
					pos = att13.Pos,
					dir = att13.Ang:Forward(), length_multiplier = 0.14
				},
                [14] = {
					pos = att14.Pos,
					dir = att14.Ang:Forward(), length_multiplier = 0.14
				},
                [15] = {
					pos = att15.Pos,
					dir = att15.Ang:Forward(), length_multiplier = 0.14
				},
                [16] = {
					pos = att16.Pos,
					dir = att16.Ang:Forward(), length_multiplier = 0.14
				},
                [17] = {
					pos = att17.Pos,
					dir = att17.Ang:Forward(), length_multiplier = 0.14
				},
                [18] = {
					pos = att18.Pos,
					dir = att18.Ang:Forward(), length_multiplier = 0.14
				},
			}
			return blades
		end
	end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Umbrella"
hilt.Author = "Truce"
hilt.id = "umbrella"
hilt.mdl = "models/expgamer/expgamer_umbrella.mdl"
hilt.Spawnable = false  -- uncomment to unlist in q-menu
hilt.info = {
    ParentData = {
        ["RH"] = {
            bone = "ValveBiped.Bip01_R_Hand",
            pos = Vector(3.75, -1.5, -12),
            ang = Angle(-90, -90, -90),
        },
        ["LH"] = {
            bone = "ValveBiped.Bip01_L_Hand",
            pos = Vector(3.75, 1, 6.5),
            ang = Angle(90, 90, 90),
        },
    },
    GetBladePos = function( ent, SWEP, ply )
		if not ent.BladeID1 then
			ent.BladeID1 = ent:LookupAttachment( "blade1" )
		end

		if not ent.BladeID2 then
			ent.BladeID2 = ent:LookupAttachment( "blade2" )
		end

		if not ent.BladeID3 then
			ent.BladeID3 = ent:LookupAttachment( "blade3" )
		end

        if not ent.BladeID4 then
			ent.BladeID4 = ent:LookupAttachment( "blade4" )
		end
        if not ent.BladeID5 then
			ent.BladeID5 = ent:LookupAttachment( "blade5" )
		end

		if not ent.BladeID6 then
			ent.BladeID6 = ent:LookupAttachment( "blade6" )
		end

		if not ent.BladeID7 then
			ent.BladeID7 = ent:LookupAttachment( "blade7" )
		end

        if not ent.BladeID8 then
			ent.BladeID8 = ent:LookupAttachment( "blade8" )
		end
		local att1 = ent:GetAttachment( ent.BladeID1 )
		local att2 = ent:GetAttachment( ent.BladeID2 )
        local att3 = ent:GetAttachment( ent.BladeID3 )
        local att4 = ent:GetAttachment( ent.BladeID4 )
		local att5 = ent:GetAttachment( ent.BladeID5 )
		local att6 = ent:GetAttachment( ent.BladeID6 )
        local att7 = ent:GetAttachment( ent.BladeID7 )
        local att8 = ent:GetAttachment( ent.BladeID8 )
		if att1 and att2 and att3 and att4 and att5 and att6 and att7 and att8 then
			local blades = {
				[1] = {
					pos = att1.Pos,
					dir = att1.Ang:Forward(),
				},
				[2] = {
					pos = att2.Pos,
					dir = att2.Ang:Forward(),
				},
                [3] = {
					pos = att3.Pos,
					dir = att3.Ang:Forward(),
				},
                [4] = {
					pos = att4.Pos,
					dir = att4.Ang:Forward(),
				},
                [5] = {
					pos = att5.Pos,
					dir = att5.Ang:Forward(),
				},
				[6] = {
					pos = att6.Pos,
					dir = att6.Ang:Forward(),
				},
                [7] = {
					pos = att7.Pos,
					dir = att7.Ang:Forward(),
				},
                [8] = {
					pos = att8.Pos,
					dir = att8.Ang:Forward(),
				},
			}
			return blades
		end
	end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Shock Lance"
hilt.Author = "Miller"
hilt.id = "lance"
hilt.mdl = "models/shock_lance/shock_lance.mdl"
hilt.Spawnable = false  -- uncomment to unlist in q-menu
hilt.info = {
	ParentData = {
		["RH"] = {
			bone = "ValveBiped.Bip01_R_Hand",
			pos = Vector(-1.5, 3, 30),
			ang = Angle(172, 0, 10),
		},
		["LH"] = {
			bone = "ValveBiped.Bip01_L_Hand",
			pos = Vector(4.25, -1.5, 1),
			ang = Angle(8, 0, -10),
		},
	},
    GetBladePos = function( ent ) 
        local blades = {
            [1] = { --------------------------pos:  y:down   x:left   z:forward -----dir: y = forward, x = nothing, z = right
                pos = ent:LocalToWorld( Vector(-0,0,60) ),
                dir = ent:LocalToWorldAngles( Angle(0,180,0) ):Up(),
            },
        }

        return blades
    end,
}
LSCS:RegisterHilt( hilt )

local hilt = {}
hilt.PrintName = "Vibro Lance"
hilt.Author = "Blu-x92 / Luna"
hilt.id = "viblance"
hilt.mdl = "models/vibro_lance/vibro_lance.mdl"
hilt.Spawnable = false  -- uncomment to unlist in q-menu
hilt.info = {
	ParentData = {
		["RH"] = {
			bone = "ValveBiped.Bip01_R_Hand",
			pos = Vector(4.25, -1.5, -1),
			ang = Angle(172, -100, 10),
		},
		["LH"] = {
			bone = "ValveBiped.Bip01_L_Hand",
			pos = Vector(4.25, -1.5, 1),
			ang = Angle(8, 0, -10),
		},
	},
    GetBladePos = function( ent, swep, ply )
		if not ent.BladeID1 then
			ent.BladeID1 = ent:LookupAttachment( "primary_blade" )
		end
		if not ent.BladeID2 then
			ent.BladeID2 = ent:LookupAttachment( "secondary_blade" )
		end

		local att1 = ent:GetAttachment( ent.BladeID1 )
		local att2 = ent:GetAttachment( ent.BladeID2 )

		if att1 and att2 then
			local blades = {
				[1] = {
					pos = att1.Pos,
					dir = att1.Ang:Up(),
				},
				[2] = {
					pos = att2.Pos,
					dir = att2.Ang:Up(),
				}
			}
			return blades
		end
	end,
}
LSCS:RegisterHilt( hilt )