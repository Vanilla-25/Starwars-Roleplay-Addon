hook.Add("PlayerLoadout", "SetDefaultRunValues", function(ply)
    timer.Simple(2, function()
        ply.df_runspeed = ply:GetRunSpeed()
    end)
end)

// ============================================================================== //
//                                                                                //
//                         	Assassin / Sentinel			               	          //
//                                                                                //
// ============================================================================== //



// ============================================================================== //
//                                                                                //
//                          		Cloak        			               		  //
//                                                                                //
// ============================================================================== //
local function MakeInvisible( ply )
	if not IsValid( ply ) then return end
	if not ply:Alive() then return end
	//Make them invisible
	ply:SetNWBool("Administrated",true)
	ply:SetNWBool("KyberCorePowers_Cloak",true)
	ply:DrawShadow(false)
	ply:SetMaterial("models/effects/vol_light001")
	ply:SetRenderMode(RENDERMODE_TRANSALPHA)
	ply:Fire("alpha", 0, 0)
	if not ply.KyberCorePower_CloakPrev then ply:SetNoTarget(true) end
	if (IsValid(ply:GetActiveWeapon())) then
		if not ply:GetActiveWeapon().LSCS then return end
		ply:GetActiveWeapon():SetRenderMode(RENDERMODE_TRANSALPHA)
		ply:GetActiveWeapon():Fire("alpha", 0, 0)
		ply:GetActiveWeapon():SetMaterial("models/effects/vol_light001")
	end
end

local function MakeVisible( ply )
	if not IsValid( ply ) then return end
	//Make them visible
	ply:SetNWBool("Administrated",false)
	ply:SetNWBool("KyberCorePowers_Cloak",false)
	ply:DrawShadow(true)
	ply:SetMaterial("")
	ply:SetRenderMode(RENDERMODE_NORMAL)
	ply:Fire("alpha", 255, 0)
	if not ply.KyberCorePower_CloakPrev then ply:SetNoTarget(false) end
	if (IsValid(ply:GetActiveWeapon())) then
		if not ply:GetActiveWeapon().LSCS then return end
		ply:GetActiveWeapon():SetRenderMode(RENDERMODE_NORMAL)
		ply:GetActiveWeapon():Fire("alpha", 255, 0)
		ply:GetActiveWeapon():SetMaterial("")
	end
end

local force = {}
force.PrintName = "Cloak"
force.Author = "Truce"
force.Description = "Use the force to cloak yourself from the senses rendering you invisible for 30 seconds."
force.id = "cloak"
force.Icon = "kybercore/cloak.png"
force.OnClk = function( ply )
	if not ply.KyberCorePower_Cloak then return end
	if ply:lscsGetForce() < 50 then return end
	if not ply:Alive() then
		MakeVisible( ply )
		ply:lscsSetForceRegenAmount( 1.5 )

		ply.KyberCorePower_Cloak = false
		ply.KyberCoreCloaking = CurTime()
		local steam = ply:SteamID64()
		if timer.Exists( "KyberCore_Cloaking" .. steam ) then
			timer.Destroy( "KyberCore_Cloaking" .. steam )
		end
		return
	end
end
force.StartUse = function(ply)
    local Time = CurTime()
    local wep = ply:GetActiveWeapon()
    if not IsValid(wep) or (wep:GetClass() ~= "kc_lscs_personal" and wep:GetClass() ~= "kc_jedi_sentinel" and wep:GetClass() ~= "kc_dark_assassin") then
        local lightsaber = ply:GetWeapon("kc_lscs_personal") or ply:GetWeapon("kc_jedi_sentinel") or ply:GetWeapon("kc_dark_assassin")
        if IsValid(lightsaber) then
            ply:SelectWeapon(lightsaber:GetClass())

            timer.Simple(0.1, function()
                if IsValid(ply) and ply:GetActiveWeapon() == lightsaber then
                    ActivateCloak(ply)
                end
            end)
        else
            ply:ChatPrint("You don't have a lightsaber equipped and cannot activate the cloak.")
			ply:EmitSound("buttons/button10.wav")
            return
        end
    else
        ActivateCloak(ply)
    end
end

function ActivateCloak(ply)
    local Time = CurTime()

    if ply.KyberCorePower_Cloak then
        MakeVisible(ply)
        ply:lscsSetForceRegenAmount(1.5)

        ply.KyberCorePower_Cloak = false
        ply.KyberCorePower_Cloak_Cooldown = Time + 5  -- Set cooldown when cloak ends
        local steam = ply:SteamID64()
        if timer.Exists("KyberCore_Cloaking" .. steam) then
            timer.Destroy("KyberCore_Cloaking" .. steam)
        end
        return
    end

    local CanDo = (ply.KyberCorePower_Cloak_Cooldown or 0) < Time
    if not CanDo then return end

    if ply:lscsGetForce() < 50 then  -- Prevent activation if Force is too low
        ply:ChatPrint("Not enough Force to activate Cloak.")
        ply:EmitSound("buttons/button10.wav")
        return
    end

    ply:lscsTakeForce(50)
    ply.KyberCorePower_Cloak = true
    ply.KyberCorePower_CloakPrev = ply:IsFlagSet(FL_NOTARGET)
    ply.KyberCoreCloaking = CurTime() + 100
    MakeInvisible(ply)

    local steam = ply:SteamID64()
    if timer.Exists("KyberCore_Cloaking" .. steam) then
        timer.Destroy("KyberCore_Cloaking" .. steam)
    end

    timer.Create("KyberCore_Cloaking" .. steam, 1, 105, function()
        if not IsValid(ply) then
            timer.Destroy("KyberCore_Cloaking" .. steam)
            return
        end
        if ply:lscsGetForce() <= 0 then
            MakeVisible(ply)
            ply:lscsSetForceRegenAmount(1.5)
            ply.KyberCorePower_Cloak = false
            ply.KyberCorePower_Cloak_Cooldown = CurTime() + 10 
            timer.Destroy("KyberCore_Cloaking" .. steam)
            ply:ChatPrint("Cloak disabled due to insufficient Force.")
            --ply:EmitSound("buttons/button10.wav")
            return
        end

        -- Disable cloak when timer expires
        if not ply:Alive() or ply.KyberCoreCloaking < CurTime() then
            MakeVisible(ply)
            ply:lscsSetForceRegenAmount(1.5)
            ply.KyberCorePower_Cloak = false
            ply.KyberCorePower_Cloak_Cooldown = CurTime() + 10
            timer.Destroy("KyberCore_Cloaking" .. steam)
            return
        end
        MakeInvisible(ply)
        ply:lscsTakeForce(2.5)
    end)
end

LSCS:RegisterForce( force )

hook.Add("PlayerSwitchWeapon", "DisableCloakOnWeaponSwitch", function(ply, oldWeapon, newWeapon)
    if ply.KyberCorePower_Cloak then
        if newWeapon:GetClass() ~= "weapon_lscs" then
            MakeVisible(ply)
            ply:lscsSetForceRegenAmount(1.5)
            ply.KyberCorePower_Cloak = false
            local steam = ply:SteamID64()
            if timer.Exists("KyberCore_Cloaking" .. steam) then
                timer.Destroy("KyberCore_Cloaking" .. steam)
            end
            ply:ChatPrint("Cloak has been disabled because you switched weapons.")
			ply:EmitSound("buttons/button10.wav")
        end
    end
end)

hook.Add("PlayerPostThink", "DisableCloakOnLightsaberSwing", function(ply)
    if ply.KyberCorePower_Cloak then
        local wep = ply:GetActiveWeapon()
        if IsValid(wep) and (wep:GetClass() == "kc_lscs_personal" or wep:GetClass() == "kc_jedi_sentinel" or wep:GetClass() == "kc_dark_assassin") then
            if ply:KeyDown(IN_ATTACK) then
                MakeVisible(ply)
                ply:lscsSetForceRegenAmount(1.5)
                ply.KyberCorePower_Cloak = false
                local steam = ply:SteamID64()
                if timer.Exists("KyberCore_Cloaking" .. steam) then
                    timer.Destroy("KyberCore_Cloaking" .. steam)
                end
                ply:ChatPrint("Cloak has been disabled because you swung your lightsaber.")
            end
        end
    end
end)
// ============================================================================== //
//                                                                                //
//                          		Force Breach			               		  //
//                                                                                //
// ============================================================================== //
local force = {}
force.PrintName = "Force Breach"
force.Author = "Stoneman"
force.Description = "Use the force to unlock pathways and doors that are normally locked."
force.id = "breach"
force.Icon = "kybercore/breach.png"
force.OnClk = function( ply )
	if not ply.KyberCorePower_Breach then return end
	local Time = CurTime()

	local CanDo = (ply.KyberCorePower_Breach_Timer or 0) < Time
	
	if not CanDo then return end
	ply.KyberCorePower_Breach_Timer = Time + 2

	local tr = util.TraceHull({
		start = ply:GetShootPos(),
		endpos = ply:GetShootPos() + ply:GetAimVector() * 100,
		mins = Vector(-10, -10, -10),
		maxs = Vector(10, 10, 10),
		filter = ply
	})
	local ent = tr.Entity
	local dmg = DamageInfo()

	if not IsValid( ent ) then return end
	dmg:SetAttacker( ply )
	dmg:SetInflictor( ply )
	dmg:SetDamage( 100 )
	dmg:SetDamageType( DMG_PHYSGUN )
	ent:TakeDamageInfo( dmg )
	ply:lscsTakeForce( 10 ) -- take amount of force we need
	if !IsValid( ent ) then return end
	if ent:GetClass()=="func_door" or ent:GetClass()=="prop_door_rotating" or ent:GetClass()=="func_door_rotating" then
		// Make the door entity unlock if it is locked.
		local WasLocked = ent:GetSaveTable().m_bLocked
		if WasLocked then
			ent:Input("Unlock", ply, ply)
		end

		ent:Input("Open", ply, ply)

		// After 10 seconds, make the door entity close if it is open.
		timer.Simple( 10, function()
			if IsValid( ent ) then
				ent:Input("Close", ply, ply)

				// If it was locked, make it lock again.
				if WasLocked then
					ent:Input("Lock", ply, ply)
				end
			end
		end )
	elseif ent:GetClass()=="prop_physics" then
		// Make the door entity fly away.
		local phys = ent:GetPhysicsObject()
		phys:ApplyForceCenter( ply:GetAimVector()*99999 )
	elseif ent:IsNPC() or ent:IsNextBot() then
		// Kill NPC, and make it's ragdoll fly away.
		local dmginfo = DamageInfo()
		dmginfo:SetDamage( 500 )
		dmginfo:SetAttacker( ply )
		dmginfo:SetInflictor( ply )
		dmginfo:SetDamageType( DMG_BLAST )
		ent:TakeDamageInfo( dmginfo )
	end

	LSCS:PlayVCDSequence(ply, "wos_bs_shared_kick", 0.5)
	ply:EmitSound( "physics/metal/metal_box_break1.wav" )
end
force.StartUse = function( ply )
	ply.KyberCorePower_Breach = true
end
force.StopUse = function( ply )
	ply.KyberCorePower_Breach = nil
end
LSCS:RegisterForce( force )


// ============================================================================== //
//                                                                                //
//                          		Force Sprint 			               		  //
//                                                                                //
// ============================================================================== //
local force = {}
force.PrintName = "Force Sprint"
force.Author = "Truce and Stoneman"
force.Description = "Use the force to enhance yourself to go further and faster than others. (+350 Speed)"
force.id = "sprint"
force.Icon = "kybercore/sprint.png"
force.StartUse = function( ply )
	
	if ply:lscsGetForce() < 5 then return end
	local Time = CurTime()

	local CanDo = (ply.KyberCorePower_Speed_Timer or 0) < Time

	if not CanDo then return end
	ply:lscsTakeForce( 30 ) -- take amount of force we need
	ply.KyberCorePower_Speed_Timer = Time + 10
	local available = ply:lscsGetForce()
	ply:EmitSound("npc/combine_gunship/ping_search.wav")

	local speed = ply:GetRunSpeed()
	ply:SetRunSpeed( speed + 150 )
	timer.Simple(5, function()
		ply:SetRunSpeed( speed )
	end)
end
LSCS:RegisterForce( force )


// ============================================================================== //
//                                                                                //
//                          		Force Teleport			               		  //
//                                                                                //
// ============================================================================== //
local force = {}
force.PrintName = "Force Teleport"
force.Author = "Stoneman"
force.Description = "Use the force to teleport yourself to different locations of the users choice."
force.id = "teleport"
force.Icon = "kybercore/teleport.png"
force.OnClk = function( ply )
	if ply:lscsGetForce() < 25 then return end
	
	if not ply.KyberCorePower_Teleport then return end
	local Time = CurTime()
    local CanDo = (ply.KyberCorePower_TeleportCooldown or 0) < Time
	if not CanDo then return end

	ply.KyberCorePower_TeleportCooldown = Time + 2

	if ply:lscsGetForce() < 25 then return end
	if not ply.KyberCorePower_Teleport then return end
	local bFoundEdge = false
	ply:SetNW2Float( "wOS.ShowBlink", CurTime() + 1 )
	local hullTrace = util.TraceHull({
		start = ply:EyePos(),
		endpos = ply:EyePos() + ply:EyeAngles():Forward() * 2400,
		filter = ply,
		mins = Vector(-16, -16, 0),
		maxs = Vector(16, 16, 9)
	})

	local groundTrace = util.TraceHull({
		start = hullTrace.HitPos + Vector(0, 0, 1),
		endpos = hullTrace.HitPos - Vector(0, 0, 1000),
		filter = ply,
		mins = Vector(-16, -16, 0),
		maxs = Vector(16, 16, 1)
	})

	local edgeTrace

	if (hullTrace.Hit and hullTrace.HitNormal.z <= 0) then
		local ledgeForward = Angle(0, hullTrace.HitNormal:Angle().y, 0):Forward();
		edgeTrace = util.TraceEntity({
			start = hullTrace.HitPos - ledgeForward * 33 + Vector(0, 0, 40),
			endpos = hullTrace.HitPos - ledgeForward * 33,
			filter = ply
		}, ply)

		if (edgeTrace.Hit and !edgeTrace.AllSolid) then
			local clearTrace = util.TraceHull({
				start = hullTrace.HitPos,
				endpos = hullTrace.HitPos + Vector(0, 0, 35),
				mins = Vector(-16, -16, 0),
				maxs = Vector(16, 16, 1),
				filter = ply
			})

			bFoundEdge = !clearTrace.Hit
		end
	end

	ply.KyberCorePower_TeleportReady = true
end
force.StartUse = function( ply )
	ply.KyberCorePower_Teleport = true 
end
force.StopUse = function( ply )
	ply.KyberCorePower_Teleport = false
	local speed = 4000
	local bFoundEdge = false

	ply:SetNW2Float("wOS.ShowBlink", 0 )

	local hullTrace = util.TraceHull({
		start = ply:EyePos(),
		endpos = ply:EyePos() + ply:EyeAngles():Forward() * 2400,
		filter = ply,
		mins = Vector(-16, -16, 0),
		maxs = Vector(16, 16, 9)
	})

	local groundTrace = util.TraceEntity({
		start = hullTrace.HitPos + Vector(0, 0, 1),
		endpos = hullTrace.HitPos - (ply:EyePos() - ply:GetPos()),
		filter = ply
	}, ply)

	local edgeTrace

	if (hullTrace.Hit and hullTrace.HitNormal.z <= 0) then
		local ledgeForward = Angle(0, hullTrace.HitNormal:Angle().y, 0):Forward()
		edgeTrace = util.TraceEntity({
			start = hullTrace.HitPos - ledgeForward * 33 + Vector(0, 0, 40),
			endpos = hullTrace.HitPos - ledgeForward * 33,
			filter = ply
		}, ply)

		if (edgeTrace.Hit and !edgeTrace.AllSolid) then
			local clearTrace = util.TraceHull({
				start = hullTrace.HitPos,
				endpos = hullTrace.HitPos + Vector(0, 0, 35),
				mins = Vector(-16, -16, 0),
				maxs = Vector(16, 16, 1),
				filter = ply
			})

			bFoundEdge = !clearTrace.Hit
		end
	end

	if (!bFoundEdge and groundTrace.AllSolid) then
		ply.groundTrace = nil		
		return
	end

	local endPos = ( bFoundEdge and edgeTrace.HitPos ) or groundTrace.HitPos

	if ply.KyberCorePower_TeleportReady then
		ply:SetPos( endPos )
		ply.KyberCorePower_TeleportReady = false
		ply:EmitSound("blink/exit" .. math.random(1, 2) .. ".wav")
		ply:lscsTakeForce( 25 )
	end

	timer.Simple(0.05, function()
		if !ply:IsOnGround() then
			ply.KyberCore_ForceJump_FallDMG = true
		end
	end)

	ply.groundTrace = nil
end
LSCS:RegisterForce( force )


// ============================================================================== //
//                                                                                //
//                          		Shadow Step 			               		  //
//                                                                                //
// ============================================================================== //
local force = {}
force.PrintName = "Shadow Step"
force.Author = "Truce and Stoneman"
force.Description = "Swap positions with a target and cause significant damage to the target."
force.id = "shadowstep"
force.Icon = "kybercore/step.png"
force.StartUse = function( ply )
	if ply:lscsGetForce() < 30 then return end
	local tr = util.TraceLine( {
		start = ply:GetShootPos(),
		endpos = ply:GetShootPos() + ply:GetAimVector() * 10000,
		filter = ply
	} )  
	
	local ent = tr.Entity
	if IsValid(ent) then
		if ent:IsNextBot() or ent:IsNPC() or ent:IsPlayer() then
			ply:lscsTakeForce(30)
			local dmg = DamageInfo()
			if ent:IsNPC() or ent:IsNextBot() then
				dmg:SetDamage(500)
				dmg:SetDamageType(DMG_REMOVENORAGDOLL)
			else
				dmg:SetDamage(100)
				dmg:SetDamageType(DMG_SLASH)
			end
			dmg:SetInflictor(ply)
			dmg:SetAttacker(ply)
			ent:TakeDamageInfo(dmg)
			local pos1 = ply:GetPos()
			local pos2 = ent:GetPos()
			ply:SetPos(pos2)
			ent:SetPos(pos1)
			LSCS:PlayVCDSequence(ply, "wos_bs_shared_vault", 0.4)
		end
	end
end
LSCS:RegisterForce(force)


// ============================================================================== //
//                                                                                //
//                          		Marauder / Guardian			               	  //--------------------------------------------------------------------------------------------------------------------------
//                                                                                //
// ============================================================================== //

// ============================================================================== //
//                                                                                //
//                          		Blade launch			               		  //
//                                                                                //
// ============================================================================== //
local force = {}
force.PrintName = "Blade launch"
force.Author = "Truce"
force.Description = "Launch your Lightsaber"
force.id = "launch"
force.Icon = "entities/blade_launch.png"
force.StartUse = function( ply )
	if ply:lscsGetForce() < 20 then return end
	if ply:InVehicle() then return end
	
	local CurSWEP = ply:GetActiveWeapon()
	local SWEP = ply:GetWeapon( "weapon_lscs" )
    if ply.SNXStatFrozen then return end
	if IsValid( CurSWEP ) then
		if CurSWEP.LSCS then
			SWEP = CurSWEP
		end
	end
	if ply.KyberCorePower_Cloak then
        ply:ChatPrint("You cannot use Blade launch while cloaked!")
		ply:EmitSound("buttons/button10.wav")
        return
    end
	if not IsValid( SWEP ) then return end
	if SWEP:IsBrokenSaber() or SWEP:IsThrown() then return end

	if (ply._lscsNextThrow or 0) > CurTime() then return end

	ply:lscsTakeForce( 0 )
	if IsValid( ply._lscsThrownSaber ) then
		if not ply._lscsThrownSaber.Returning then
			ply._lscsThrownSaber:ResetProgress()
			ply._lscsThrownSaber.Returning = true
		end
	else
		if ply:lscsGetForce() < 20 then return end

		if ply:GetActiveWeapon() ~= SWEP then
			ply:SelectWeapon( "weapon_lscs" )
		end
		LSCS:PlayVCDSequence( ply, "zombie_attack_02", 0.3 )

		local proj = ents.Create("blade_launch")
		proj:SetPos( ply:GetShootPos() - Vector(0,0,20) )
		proj:SetSWEP( SWEP )
		proj:Spawn()
		proj:Activate()

		ply:EmitSound("npc/zombie/claw_miss1.wav")

		SWEP:SetHoldType( "magic" )

		ply._lscsThrownSaber = proj
	end
end
force.StopUse = function( ply )
	ply._lscsNextThrow = CurTime() + 3
	if IsValid( ply._lscsThrownSaber ) then
		ply._lscsThrownSaber:ResetProgress()
		ply._lscsThrownSaber.Returning = true
	end
end

LSCS:RegisterForce( force )


// ============================================================================== //
//                                                                                //
//                          		Force Absorb			               		  //
//                                                                                //
// ============================================================================== //
local force = {}
force.PrintName = "Force Absorb"
force.Author = "Stoneman"
force.Description = "Use the force to absorb any incoming attacks transferring it into your force bar."
force.id = "absorb"
force.Icon = "kybercore/absorb.png"
force.OnClk = function( ply )
	if not ply.KyberCorePower_Absorb then return end
	if not ply:Alive() then
	 	ply.KyberCorePower_Absorb = false
		ply:SetNWBool( "KyberCorePower_Absorb", false )
		ply:lscsSetForceRegenAmount( 1.5 )
		return
	 end

	// If your force is out, turn it off
	if ply:lscsGetForce() < 1 then
		ply.KyberCorePower_Absorb = false
		ply:SetNWBool( "KyberCorePower_Absorb", false )
		return
	end
	ply:lscsTakeForce( 1 )
	ply:SetNWBool( "KyberCorePower_Absorb", true )
end
force.StartUse = function( ply )
	ply.KyberCorePower_Absorb = true 
end
force.StopUse = function( ply )
	ply.KyberCorePower_Absorb = false
	ply:SetNWBool( "KyberCorePower_Absorb", false )
	ply:lscsSetForceRegenAmount( 1 )
end
LSCS:RegisterForce( force )



// ============================================================================== //
//                                                                                //
//                          		Force Brazen			               		  //
//                                                                                //
// ============================================================================== //
local force = {}
force.PrintName = "Force Brazen"
force.Author = "Stoneman"
force.Description = " Use the force to enhance your strikes for a small duration of time."
force.id = "brazen"
force.Icon = "kybercore/brazen.png"
force.StartUse = function( ply )
	// cool down for 10 seconds
	local Time = CurTime()

	local CanDo = (ply.KyberCorePower_BrazenCooldown or 0) < Time
	
	if not CanDo then return end
	ply.KyberCorePower_BrazenCooldown = Time + 10

	if ply:lscsGetForce() < 50 then return end
	ply:lscsTakeForce( 50 )
	
	ply.KyberCorePower_Brazen = true 
	local wep = ply:GetActiveWeapon()
	if wep.LSCS then
		ply.KyberCorePower_BrazenPrev = KyberCore.Config.BaseSaberDamage
	end
	ply:SetNWBool( "KyberCorePower_Brazen", true )
	// Turns off after 10 sec
	timer.Create( "Brazen Timer" .. ply:EntIndex(), 10, 1, function()
		ply.KyberCorePower_Brazen = false
		ply:SetNWBool( "KyberCorePower_Brazen", false )
		if wep.LSCS then
			wep.KyberCoreDamage = ply.KyberCorePower_BrazenPrev
		end
	end )
end
force.OnClk = function( ply )
	if not ply.KyberCorePower_Brazen then return end
	if not ply:Alive() then
		ply.KyberCorePower_Brazen = false
		ply:SetNWBool( "KyberCorePower_Brazen", false )
		return
	end
	// While it is active, you do.. 100% more damage
	local wep = ply:GetActiveWeapon()
	if wep.LSCS then
		wep.KyberCoreDamage = ply.KyberCorePower_BrazenPrev * 2
	end
end
LSCS:RegisterForce( force )


// ============================================================================== //
//                                                                                //
//                          		Force Reflect			               		  //
//                                                                                //
// ============================================================================== //
local force = {}
force.PrintName = "Force Reflect"
force.Author = "Stoneman"
force.Description = "Using the force creates a link to all targets that shoot at the user. Transferring any damage the user receives back to the target."
force.id = "reflect"
force.Icon = "kybercore/reflect.png"
force.OnClk = function(ply)
	if not ply.KyberCorePower_Reflect then return end
	ply:lscsTakeForce( 0 )
	local effectdata = EffectData()
		effectdata:SetOrigin( ply:GetPos() )
		effectdata:SetEntity( ply )
		effectdata:SetColor( 100, 100, 100 )
	util.Effect( "force_block_active", effectdata, true, true )
end
force.StartUse = function( ply )
	// 15 seconds cooldown
	local Time = CurTime()

	local CanDo = (ply.KyberCorePower_ReflectCooldown or 0) < Time

	if not CanDo then return end

	ply.KyberCorePower_ReflectCooldown = Time + 20
	
	ply.KyberCorePower_Reflect = true 
	ply:SetNWBool( "KyberCorePower_Reflect", true )
	// Turns off after 10 sec
	timer.Create( "Reflect Timer" .. ply:EntIndex(), 10, 1, function()
		ply.KyberCorePower_Reflect = false
		ply:SetNWBool( "KyberCorePower_Reflect", false )
	end )

	if ply:lscsGetForce() < 100 then return end
	ply:lscsTakeForce( 100 )
end
LSCS:RegisterForce( force )

hook.Add("PlayerDeath", "ResetReflectOnDeath", function(victim, inflictor, attacker)
    if victim.KyberCorePower_Reflect then
        victim.KyberCorePower_Reflect = false
        victim:SetNWBool("KyberCorePower_Reflect", false)
    end

    -- Make sure to remove any unique timers for that player
    timer.Remove("Reflect Timer" .. victim:EntIndex())
end)
// ============================================================================== //
//                                                                                //
//                          		Force Propulsion		               		  //
//                                                                                //
// ============================================================================== //
local force = {}
force.PrintName = "Force Propulsion"
force.Author = "Stoneman"
force.Description = "Launch a shotgun of concussive force energy towards your targets."
force.id = "propulsion"
force.Icon = "kybercore/propulsion.png"
force.StartUse = function( ply )
	local Time = CurTime()
	local CanDo = (ply.KyberCorePower_Force_Propulsion_Timer or 0) < Time
	if not CanDo then return end
	if ply.KyberCorePower_Cloak then
        ply:ChatPrint("You cannot use Force Propulsion while cloaked!")
		ply:EmitSound("buttons/button10.wav")
        return
    end
	ply.KyberCorePower_Force_Propulsion_Timer = Time + 3
	if ply:lscsGetForce() < 40 then return end
	ply:lscsTakeForce( 40 ) -- take amount of force we need

	
	local tr = util.TraceLine( util.GetPlayerTrace( ply ) )
	local pos = tr.HitPos
	local pi = math.pi
	local bullet = {}
	bullet.Num 		= 40
	bullet.Spread 	= Vector( 0.05, 0.05, 0 )
	bullet.Tracer	= 1
	bullet.Force	= 0						
	bullet.Damage	= 25
	bullet.AmmoType = "Pistol"
	bullet.Entity = ply
	bullet.IgnoreEntity = ply
	bullet.TracerName = "rb655_force_repulse_in"
	ply:EmitSound( "ambient/atmosphere/thunder1.wav" )
	LSCS:PlayVCDSequence(ply, "wos_jedi_forceblast", 0.6)
	local ed = EffectData()
	ed:SetEntity( ply )
	ed:SetScale( 0.4 )

	timer.Simple( 0.2*0.2, function()
		if not IsValid( ply ) then return end
		bullet.Src 		= ply:GetShootPos()
		bullet.Dir 		= ply:GetAimVector()
		ply:FireBullets( bullet )
		ply:EmitSound( "lightsaber/force_repulse.wav" )
		for i=1, 6 do
			timer.Simple( 0.003*i, function()
				if not IsValid( ply ) then return end
				if not ply:Alive() then return end
				ply:EmitSound( "" )
			end )
		end
	end )
	return true
end
LSCS:RegisterForce( force )

// ============================================================================== //
//                                                                                //
//                         		Sorcerer / Consular			                      //--------------------------------------------------------------------------------------------------------------------------
//                                                                                //
// ============================================================================== //




// ============================================================================== //
//                                                                                //
//                          		Force Heal  			               		  //
//                                                                                //
// ============================================================================== //

local force = {}
force.PrintName = "Force Heal"
force.Author = "Stoneman"
force.Description = "Use the force to heal a target."
force.id = "heal"
force.Icon = "entities/item_force_heal.png"
force.OnClk = function( ply )
	if not ply.KyberCorePower_Heal then return end
	local Time = CurTime()

	local CanDo = (ply._lscsNextForce or 20) < Time

	if not CanDo then return end

	ply._lscsNextForce = Time

	if ply:lscsGetForce() < 2.5 then return end -- do we have enough force points ?

	// trace a line from the player's eyes
	local tr = util.TraceLine( {
		start = ply:EyePos(),
		endpos = ply:EyePos() + ply:GetAimVector() * 1000000,
		filter = ply
	} )

	// if we hit something
	if tr.Hit then
		if tr.Entity:Health() >= tr.Entity:GetMaxHealth() then return end

		ply:lscsTakeForce( 2.5 )

		local healthmath = tr.Entity:Health() + (tr.Entity:GetMaxHealth() * 0.075)
		tr.Entity:SetHealth(math.Clamp(healthmath, 0, tr.Entity:GetMaxHealth()))

		local weapon = ply:GetWeapon( "weapon_lscs" )
		local ed = EffectData()
		ed:SetOrigin( ply:GetShootPos() )
		ed:SetEntity( tr.Entity )
		util.Effect( "wos_emerald_lightning", ed, true, true )

		LSCS:PlayVCDSequence(ply, "wos_cast_choke", 0)
		
		if !force.Sound then
			force.Sound = CreateSound( ply, "wos/force_heal.wav" )
			force.Sound:PlayEx( 30, 70 )
		end
		force.Sound:PlayEx( 30, 70 )
		
		timer.Create("HealSound"..ply:SteamID64(), 0.2, 1, function()
			force.Sound:Stop()
			force.Sound = nil
		end)
	end
end
force.StartUse = function( ply )
	ply.KyberCorePower_Heal = true 
end
force.StopUse = function( ply )
	ply.KyberCorePower_Heal = false
end
LSCS:RegisterForce( force )


// ============================================================================== //
//                                                                                //
//                          		Force Revive			               		  //
//                                                                                //
// ============================================================================== //

local force = {}
force.PrintName = "Force Revive"
force.Author = "Stoneman and Truce"
force.Description = "Using the force return the life back to a target and heal the target’s wounds."
force.id = "revive"
force.Icon = "kybercore/revive.png"

force.OnClk = function(ply)
    if not ply.KyberCorePower_Revive then return end
    local Time = CurTime()

    local CanDo = (ply.KyberCorePower_Revive_Time or 0) < Time
    if not CanDo then return end

    if ply:lscsGetForce() < 50 then return end -- Check for enough force points
	
    -- Ragdoll Checks!
	for _, ragdoll in pairs(ents.FindInSphere(ply:GetPos(), 200)) do
		if ragdoll:GetClass() == "prop_ragdoll" then
			if ragdoll.DeathRagdoll or ragdoll:GetNWBool("IsDeathRagdoll", false) then
				local target_ply = ragdoll:GetOwner() or ragdoll:GetNWEntity("DeathRagdoll")
				if IsValid(target_ply) and target_ply:Alive() then return end
				target_ply:Spawn()

				timer.Simple(0.05, function() 
					local eyetrace = ply:GetEyeTraceNoCursor()
					target_ply:SetPos(eyetrace.HitPos + eyetrace.HitNormal * 16) 
				end)

				for k, v in pairs(target_ply.DeathWeapons) do
					target_ply:Give(v)
				end

				target_ply:SetModel(target_ply.DeathModelDefib)

				force.Sound = CreateSound(ply, "weapons/physcannon/superphys_small_zap1.wav")
				force.Sound:PlayEx(30, 70)
			
				ply:lscsTakeForce(50)
				ply.KyberCorePower_Revive_Time = Time + 5			
				break
			end
		end
	end
end

force.StartUse = function(ply)
    ply.KyberCorePower_Revive = true
end

force.StopUse = function(ply)
    ply.KyberCorePower_Revive = false
end

LSCS:RegisterForce(force)


// ============================================================================== //
//                                                                                //
//                          		Group Heal  			               		  //
//                                                                                //
// ============================================================================== //

local force = {}
force.PrintName = "Group Heal"
force.Author = "Stoneman"
force.Description = "Use the force to heal multiple targets including yourself."
force.id = "groupheal"
force.Icon = "kybercore/group_heal.png"
force.StartUse = function( ply )
	if ply:lscsGetForce() < 50 then return end
	local Time = CurTime()
	local CanDo = (ply.KyberCorePower_GroupHealTimer or 0) < Time
	if not CanDo then
		return
	end
	ply:lscsTakeForce( 80 ) -- take amount of force we need
	ply.KyberCorePower_GroupHealTimer = Time + 15
	timer.Simple( 0.5, function()
		LSCS:PlayVCDSequence( ply, "wos_cast_lightning_armed", 0 )
		ply:EmitSound( "wos/force_heal.wav" )
		if not IsValid( ply ) then return end
		// Heal all players in a 500 unit radius
		for k, v in pairs( ents.FindInSphere( ply:GetPos(), 400 ) ) do
			if v:IsPlayer() and v:Alive() then
				if v:Health() >= v:GetMaxHealth() then continue end
				v:SetHealth(v:Health() + v:GetMaxHealth() * 0.5)

				if v:Health() > v:GetMaxHealth() then
					v:SetHealth(v:GetMaxHealth())
				end

				// Makes health effect a lot of times!
				local ed = EffectData()
				ed:SetOrigin( v:GetPos() )
				ed:SetEntity( v )
				timer.Create( "KyberCoreHealingEffect"..v:EntIndex(), 0.1, 10, function()
					util.Effect( "rb655_force_heal", ed, true, true )
				end )
			end
		end
	end )
end
LSCS:RegisterForce( force )


// ============================================================================== //
//                                                                                //
//                          		Judgement Strike			                  //
//                                                                                //
// ============================================================================== //

local force = {}
force.PrintName = "Judgement Strike"
force.Author = "Stoneman and Truce"
force.Description = "Launch a shotgun of concussive force energy towards your targets."
force.id = "judgementstrike"
force.Icon = "kybercore/jstrike.png"
force.StartUse = function( ply )
	local Time = CurTime()
	local CanDo = (ply.KyberCorePower_Judgement_Timer or 0) < Time
	if not CanDo then return end
	if ply:lscsGetForce() < 40 then return end -- Check for enough force points
	ply.KyberCorePower_Judgement_Timer = Time + 7
	ply:lscsTakeForce( 40 ) -- take amount of force we need
	
	
	local tr = util.TraceLine( util.GetPlayerTrace( ply ) )
	local pos = tr.HitPos
	local pi = math.pi
	local bullet = {}
	bullet.Num 		= 1
	bullet.Spread 	= Vector( 0, 0, 0 )
	bullet.Tracer	= 1
	bullet.Force	= 0						
	bullet.Damage	= 650
	bullet.AmmoType = "Pistol"
	bullet.Entity = ply
	bullet.IgnoreEntity = ply
	bullet.TracerName = "thor_thunder"
	--ply:EmitSound( "ambient/atmosphere/thunder1.wav" )
	LSCS:PlayVCDSequence(ply, "wos_jedi_forceblast", 0.55)
	local ed = EffectData()
	ed:SetEntity( ply )
	ed:SetScale( 1 )

	timer.Simple( 0.4*0.4, function()
		if not IsValid( ply ) then return end
		bullet.Src 		= ply:GetShootPos()
		bullet.Dir 		= ply:GetAimVector()
		ply:FireBullets( bullet )
		ply:EmitSound( "npc/strider/fire.wav" )
		for i=1, 6 do
			timer.Simple( 0.003*i, function()
				if not IsValid( ply ) then return end
				if not ply:Alive() then return end
				ply:EmitSound( "" )
			end )
		end
	end )
	return true
end
LSCS:RegisterForce( force )



// ============================================================================== //
//                                                                                //
//                          		Self Revive  			               		  //
//                                                                                //
// ============================================================================== //

local function ForceRevive(ply)
	local deathpos = ply:GetPos()
	local deathangles = ply:GetAngles()
	local deathmodel = ply:GetModel()
	ply:Spawn()

	timer.Simple(0, function()
		ply:lscsSetForce(100)
		ply:SetModel(deathmodel)
		timer.Simple(0.05, function()
			ply:SetPos(deathpos)
			ply:SetAngles(deathangles)
			ply:StripWeapons()
			for k, v in pairs(ply.ForceReviveWeapons) do
				ply:Give(v)
			end
			
			timer.Simple(0.05, function()
				ply:SetHealth(ply:GetMaxHealth() * 0.4)
			end)
		end)
	end)

	-- Enable god mode for 7 seconds
	ply:GodEnable()
	timer.Simple(7, function()
		ply:GodDisable()
	end)
end

local force = {}
force.PrintName = "Self Revive"
force.Author = "Stoneman & Truce"
force.Description = "By sheer will power and whatever remaining force you have left, you bring yourself back from the brink."
force.id = "selfrevive"
force.Icon = "kybercore/self_revive.png"

force.OnClk = function(ply, TIME)
	if not ply._KyberCorePower_SelfRevive then return end
	if ply:Health() <= 0 or not ply:Alive() then
		local ed = EffectData()
		ed:SetEntity(ply)
		ed:SetRadius(5)

		-- Check for a valid death ragdoll
		local pos
		for _, ragdoll in pairs(ents.FindInSphere(ply:GetPos(), 400)) do
			if ragdoll.DeathRagdoll or ragdoll:GetNWBool("IsDeathRagdoll", false) then
				local target_ply = ragdoll:GetOwner() or ragdoll:GetNWEntity("DeathRagdoll")
				if IsValid(target_ply) and not target_ply:Alive() and target_ply == ply then
					pos = ragdoll:GetPos()
				end
			end
		end

		if not pos then return end

		-- Use wos_alcs_bloodtouch effect
		util.Effect("wos_alcs_bloodtouch", ed, true, true)

		ply._KyberCorePower_SelfRevive = false
		timer.Simple(5, function()
			print("Force Revive: " .. ply:Nick())
			ForceRevive(ply)
			ply:EmitSound("ambient/levels/citadel/weapon_disintegrate2.wav", 100, 100)
		end)
	else
		ply.ForceReviveWeapons = {}
		for k, v in pairs(ply:GetWeapons()) do
			if v:IsValid() then
				table.insert(ply.ForceReviveWeapons, v:GetClass())
			end
		end
	end
end

force.StartUse = function(ply)
	if ply._KyberCorePower_SelfRevive then
		ply:ChatPrint("You accept death.")
		ply._KyberCorePower_SelfRevive = false
		return
	else
		-- if ply:lscsGetForce() < 200 then return end -- Check for enough force points
		ply:lscsTakeForce(200) -- Deduct the required force points
		LSCS:PlayVCDSequence( ply, "gesture_disagree", 0.6 )
		ply:ChatPrint("You will come back to life after death.")
		ply:EmitSound( "lightsaber/force_repulse.wav" )
		local effectdata = EffectData()
		effectdata:SetOrigin( ply:GetPos() )
		effectdata:SetEntity( ply )
		util.Effect( "force_heal", effectdata, true, true )
		ply._KyberCorePower_SelfRevive = true
	end
end

LSCS:RegisterForce(force)



// ============================================================================== //
//                                                                                //
//                             		Guard                 		                  //--------------------------------------------------------------------------------------------------------------------------
//                                                                                //
// ============================================================================== //

// ============================================================================== //
//                                                                                //
//                          		Force Bind	W.I.P		               	      //
//                                                                                //
// ============================================================================== //
local force = {}
force.PrintName = "Force Bind"
force.Author = "Truce"
force.Description = "Use the force to Bind your enemies in their track and immobilise them for a 10 seconds."
force.id = "bind"
force.Icon = "kybercore/electric_judgement.png"
force.OnClk = function( ply )
	
	if not ply.KyberCorePower_Bind then return end
	local tr = util.TraceLine( {
		start = ply:GetShootPos(),
		endpos = ply:GetShootPos() + ply:GetAimVector() * 600,
		filter = ply,
		mask = MASK_SHOT_HULL
	} )
	
	if tr.Hit then
		// If it's a player and is alive, make them not able to move.
		if tr.Entity:IsPlayer() and tr.Entity:Alive() or tr.Entity:IsNextBot() then
			if ply:lscsGetForce() < 20 then return end
			
			local ent = tr.Entity
			local ed = EffectData()
			ed:SetOrigin( ply:GetShootPos() )
			ed:SetEntity( ent )
			util.Effect( "wos_emerald_lightning", ed, true, true )

			tr.Entity:Freeze(true)
			timer.Create( "Force Bind Timer" .. tr.Entity:EntIndex(), 10, 1, function() tr.Entity:Freeze(false) end )
			LSCS:PlayVCDSequence(ply, "wos_jedi_forceblast", 0.8)

			// Use 5 force!
			ply:lscsTakeForce( 20 )
		end
	end
end
force.StartUse = function( ply )
	ply.KyberCorePower_Bind = true 
end
force.StopUse = function( ply )
	ply.KyberCorePower_Bind = false
end
LSCS:RegisterForce( force )


// ============================================================================== //
//                                                                                //
//                          		Crippling Slam			               		  //
//                                                                                //
// ============================================================================== //
local force = {}
force.PrintName = "Crippling Slam"
force.Author = "Stoneman"
force.Description = "Slam your enemy to the ground."
force.id = "slam"
force.Icon = "kybercore/slam.png"
force.StartUse = function( ply )
	if not ply:IsOnGround() then return end
	local Time = CurTime()

	local CanDo = (ply.KyberCorePowers_Slam_Time or 0) < Time
	
	if not CanDo then return end

	// Gets player's current movetype
	local movetype = MOVETYPE_WALK

	if ply:GetVelocity():Length2DSqr() < 30 then
		// move type is set to none so the player can't move
		ply:SetMoveType( MOVETYPE_NONE )
		LSCS:PlayVCDSequence( ply, "h_c2_t3", 0 )
		ply.KyberCorePowers_Slam_Time = Time + 15
		timer.Simple( 1.5*0.38, function()
			if not IsValid( ply ) or not ply:Alive() then return end
			
			local ed = EffectData()
			ed:SetEntity( ply )
			local forward = ply:GetForward()
			forward = Vector( forward.x, forward.y, 0 )
			ed:SetStart( forward )
			
			forward = forward*5
			ed:SetOrigin( ply:GetPos() + forward )
			util.Effect( "wos_alcs_electricslam", ed, true, true )
			
			ply:EmitSound( "wos/lightsabers/forceslam.wav" )
			local targets = ents.FindInCone( ply:EyePos(), ply:GetAimVector(), 600, math.cos( math.rad( 25 ) ) )
			for _, ent in ipairs( targets ) do
				if ent == ply then continue end
				if ent:IsPlayer() then
					if ent:InVehicle() then continue end
					local ed2 = EffectData()
					ed2:SetEntity( ent )
					ed2:SetRadius( 2.5 )
					util.Effect( "wos_alcs_electrictouch", ed2, true, true )
					ent:EmitSound( "weapons/stunstick/stunstick_fleshhit2.wav", nil, 75 )
					local entmovetype = MOVETYPE_WALK
					ent:SetMoveType( MOVETYPE_NONE )
					timer.Simple( 5, function()
						if IsValid( ent ) and ent:Alive() then
							ent:SetMoveType( entmovetype )
						end
					end )
				end

				if ent:IsNPC() then
					// do damage
					local dmg = DamageInfo()
					dmg:SetDamage( 600 )
					dmg:SetDamageType( DMG_SLASH )
					dmg:SetAttacker( ply )
					dmg:SetInflictor( ply )
					ent:TakeDamageInfo( dmg )
				end

				if ent.IsStonemanDroids then
					local ed2 = EffectData()
					ed2:SetEntity( ent )
					ed2:SetRadius( 2.5 )
					util.Effect( "wos_alcs_electrictouch", ed2, true, true )
					ent:EmitSound( "weapons/stunstick/stunstick_fleshhit2.wav", nil, 75 )

					local prev_seq = ent:GetSequence()
					// Make the droids play fall animation
					ent:PlaySequence( "fear_reaction" )
					ent:DisableAttack()
					// Make them do normal animation after 2.5 seconds
					timer.Simple( 2.5, function()
						if not IsValid( ent ) then return end
						ent:PlaySequence( prev_seq )
						ent:EnableAttack()
					end )
				end
			end
		end )

		ply:SetMoveType( movetype )
	end
end
LSCS:RegisterForce( force )


// ============================================================================== //
//                                                                                //
//                      		Electric Judgement			                      //
//                                                                                //
// ============================================================================== //
local function ForceFry2( ply, TIME )
	local effectdata = EffectData()
		effectdata:SetOrigin( ply:GetPos() )
		effectdata:SetEntity( ply )
	util.Effect( "force_lightning2", effectdata, true, true )

	local MyPos = ply:GetShootPos()
	local AimVector = ply:GetAimVector()
	local Force = AimVector * 100

	for _, victim in pairs( ents.FindInSphere( MyPos, 1000 ) ) do
		local TargetPos = victim.GetShootPos and victim:GetShootPos() or victim:GetPos()
		local Sub = TargetPos - MyPos
		local ToTarget = Sub:GetNormalized()

		if math.deg( math.acos( math.Clamp( AimVector:Dot( ToTarget ) ,-1,1) ) ) < 14 then
			if util.TraceLine( {start = MyPos,endpos = victim:LocalToWorld( victim:OBBCenter() ),mask = MASK_SHOT,filter = ply,} ).Entity ~= victim then continue end

			local Dist = Sub:Length()

			if IsValid( victim ) and Dist < 1000 then
				if victim:IsPlayer() then
					if hook.Run( "LSCS:PlayerCanManipulate", ply, victim, true ) then continue end
				end

				if victim:GetClass() == "prop_ragdoll" then
					victim:Fire("StartRagdollBoogie")

					if (victim._lscsBoogieTime or 0) < TIME then
						victim._lscsBoogieTime = TIME + 6

						for i = 1, 70 do
							if math.random(1,5) == 1 then continue end

							timer.Simple( i * 0.1, function()
								if not IsValid( victim ) then return end

								local effect = EffectData()
								effect:SetEntity( victim )
								effect:SetMagnitude(30)
								effect:SetScale(30)
								effect:SetRadius(30)
								util.Effect("TeslaHitBoxes", effect)
								victim:EmitSound("Weapon_StunStick.Activate")
							end )
						end
					end
				end

				local DMGtrace = util.TraceHull( {
					start = MyPos,
					endpos = MyPos + AimVector * 800,
					filter = ply,
					mins = Vector( -20, -20, -20 ),
					maxs = Vector( 20, 20, 20 ),
					mask = MASK_SHOT_HULL,
					filter = function( ent ) return ent == victim end
				} )

				local DmgSub = TargetPos - DMGtrace.HitPos
				local DmgPos = DMGtrace.HitPos + DmgSub:GetNormalized() * math.min(DmgSub:Length(),20) + VectorRand(-5,5)

				local dmginfo = DamageInfo()
				dmginfo:SetDamage( 20 )
				dmginfo:SetAttacker( ply )
				dmginfo:SetInflictor( ply ) 
				dmginfo:SetDamageType( bit.bor( DMG_SHOCK, DMG_BULLET ) )
				dmginfo:SetDamagePosition( DmgPos )
				dmginfo:SetDamageForce( Force ) 
				victim:TakeDamageInfo( dmginfo )
			end
		end
	end
end

local force = {}
force.PrintName = "Electric Judgement"
force.Author = "Truce"
force.Description = "Electric Judgment emits as a burst of electric energy directed at a target, intended to neutralize rather than to kill or severely harm."
force.id = "ej"
force.Icon = "entities/item_force_lightning.png"
force.OnClk =  function( ply, TIME )
	if not ply._lscsLightningTime2 then return end

	ply:lscsTakeForce( 2 )

	ForceFry2( ply, TIME )

	if ply._lscsLightningStartTime2 < TIME then
		LSCS:PlayVCDSequence( ply, "gesture_item_give", 0.7 )
	end

	if ply._lscsLightningTime2 < TIME or ply:lscsGetForce() <= 0 or not ply:Alive() or ply:GetObserverMode() ~= OBS_MODE_NONE then
		ply._lscsLightningTime2 = nil
		ply._lscsLightningStartTime2 = nil
	end
end
force.Equip = function( ply ) end
force.UnEquip = function( ply ) end
force.StartUse = function( ply )
	local Time = CurTime()

	if (ply._lscsLightningTime2 or 0) > Time then
		ply._lscsLightningTime2 = nil
		ply._lscsLightningStartTime2 = nil

		return
	end

	if ply:lscsGetForce() < 10 then return end

	local CanDo = (ply._lscsNextForce or 0) < Time and (ply._lscsLightningTime2 or 0) < Time

	if not CanDo then return end

	ply._lscsNextForce = Time + 2

	ply:EmitSound("lscs/force/lightning.mp3")

	ply:lscsTakeForce( 5 )

	ForceFry2( ply, Time )

	if not ply._lscsLightningTime2 then
		ply._lscsLightningTime2 = CurTime() + 5
		ply._lscsLightningStartTime2 = CurTime() + 0.15

		LSCS:PlayVCDSequence( ply, "gesture_signal_forward", 0.1 )
	end
end
force.StopUse = function( ply )
	ply._lscsLightningTime2 = nil
end
LSCS:RegisterForce( force )
