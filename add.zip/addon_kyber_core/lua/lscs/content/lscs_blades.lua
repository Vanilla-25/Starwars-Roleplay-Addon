local blade = {}
blade.PrintName = "White"
blade.Author = "Truce"
blade.id = "bw"
blade.color_blur = Color(0,0,0)
blade.color_core = Color(255,255,255)
blade.length = 45
blade.width = 0.6
blade.widthWiggle = 0.6
blade.material_core_tip = Material( "lscs/effects/lightsaber_tip" )
blade.material_core = Material( "lscs/effects/lightsaber_core" )
blade.material_glow = Material( "lscs/effects/lightsaber_glow" )
blade.material_trail = Material( "lscs/effects/lightsaber_trail" )
blade.dynamic_light = true
blade.no_trail = false
blade.Spawnable = true
blade.sounds = {
    Attack = "saber_hup",
    Attack1 = "saber_spin1",
    Attack2 = "saber_spin2",
    Attack3 = "saber_spin3",
    Activate = "saber_turnon",
    Disable = "saber_turnoff",
    Idle =  "saber_idle4",
}
LSCS:RegisterBlade( blade )

blade.PrintName = "Youngling"
blade.id = "byo"
blade.color_blur = Color(72,72,72)
LSCS:RegisterBlade( blade )

blade.PrintName = "Initiate"
blade.id = "bin"
blade.color_blur = Color(166,196,255)
LSCS:RegisterBlade( blade )

blade.PrintName = "Blue"
blade.id = "bb"
blade.color_blur = Color(77,120,255)
LSCS:RegisterBlade( blade )

blade.PrintName = "Green"
blade.id = "bg"
blade.color_blur = Color(129,226,102)
LSCS:RegisterBlade( blade )

blade.PrintName = "Yellow"
blade.id = "by"
blade.color_blur = Color(255,232,97)
Idle =  "saber_idle2",
LSCS:RegisterBlade( blade )

blade.PrintName = "Pink"
blade.id = "bpk"
blade.color_blur = Color(255,144,255)
LSCS:RegisterBlade( blade )

blade.PrintName = "purple"
blade.id = "bp"
blade.color_blur = Color(164,51,255)
LSCS:RegisterBlade( blade )

blade.PrintName = "Interloper"
blade.id = "bint"
blade.color_blur = Color(255,138,51)
LSCS:RegisterBlade( blade )

blade.PrintName = "Red"
blade.id = "br"
blade.color_blur = Color(255,51,51)
LSCS:RegisterBlade( blade )

blade.PrintName = "Light Red"
blade.id = "blr"
blade.color_blur = Color(100,0,0)
LSCS:RegisterBlade( blade ) 

blade.PrintName = "Purified"
blade.id = "bpure"
blade.color_blur = Color(169,175,183)
blade.color_core = Color(115,126,142)
LSCS:RegisterBlade( blade )

blade.PrintName = "Poop Saber"
blade.id = "bpo"
blade.color_blur = Color(45,23,10)
blade.color_core = Color(45,36,32)
blade.Spawnable = false
LSCS:RegisterBlade( blade )

blade.PrintName = "Cyan"
blade.id = "bc"
blade.color_blur = Color(67,197,255)
blade.color_core = Color(255,255,255)
blade.Spawnable = true
LSCS:RegisterBlade( blade )

blade.PrintName = "Orange"
blade.id = "bo"
blade.color_blur = Color(255,140,0)
blade.color_core = Color(255,255,255)
LSCS:RegisterBlade( blade )

-- Vibroblade
local blade = {}
blade.PrintName = "Vibroblade"
blade.Author = "Stoneman / Linguine"
blade.id = "vibroblade"
blade.width = 0
blade.widthWiggle = 0
blade.length = 32
blade.Spawnable = false
blade.dynamic_light = false
blade.no_trail = true
blade.sounds = {
	Attack = "nanosword_hup",
	Attack1 = "nanosword_hup",
	Attack2 = "nanosword_hup",
	Attack3 = "nanosword_hup",
	Activate = "nanosword_turnon",
	Disable = "nanosword_turnoff",
	Idle =  "",
}
LSCS:RegisterBlade( blade )

local blade = {}
blade.PrintName = "Parry This, Asshole"
blade.Author = "Stoneman"
blade.id = "parrythisasshole"
blade.color_blur = Color(200,0,0)
blade.color_core = Color(255,255,255)
blade.length = 50
blade.width = 5
blade.widthWiggle = 0.6
blade.material_core_tip = Material( "lscs/effects/lightsaber_tip" )
blade.material_core = Material( "lscs/effects/lightsaber_core" )
blade.material_glow = Material( "lscs/effects/lightsaber_glow" )
blade.material_trail = Material( "lscs/effects/lightsaber_trail" )
blade.Spawnable = false
blade.dynamic_light = true
blade.no_trail = false
blade.sounds = {
	Attack = "saber_hup",
	Attack1 = "saber_spin1",
	Attack2 = "saber_spin2",
	Attack3 = "saber_spin3",
	Activate = "saber_turnon",
	Disable = "saber_turnoff",
	Idle =  "lscs/saber/saberhum4.wav",
}
LSCS:RegisterBlade( blade )

-- Electrostaff
local blade = {}
blade.PrintName = "Electrostaff"
blade.Author = "Stoneman / Truce"
blade.id = "electrostaff"
blade.color_blur = Color(200,0,200)
blade.width = 1
blade.widthWiggle = 0
blade.length = 12
blade.Spawnable = false
blade.dynamic_light = false
blade.no_trail = false
blade.sounds = {
	Attack = "nanosword_hup",
	Attack1 = "nanosword_hup",
	Attack2 = "nanosword_hup",
	Attack3 = "nanosword_hup",
	Activate = "nanosword_turnon",
	Disable = "nanosword_turnoff",
	Idle =  "",
}
LSCS:RegisterBlade( blade )

-- Electro Batons
local blade = {}
blade.PrintName = "Electro Batons"
blade.Author = "Stoneman / Truce"
blade.id = "electrobatonsb"
blade.color_blur = Color(200,0,200)
blade.width = 1
blade.widthWiggle = 0
blade.length = 16.3
blade.Spawnable = false
blade.dynamic_light = false
blade.no_trail = false
blade.sounds = {
	Attack = "nanosword_hup",
	Attack1 = "nanosword_hup",
	Attack2 = "nanosword_hup",
	Attack3 = "nanosword_hup",
	Activate = "nanosword_turnon",
	Disable = "nanosword_turnoff",
	Idle =  "",
}
LSCS:RegisterBlade( blade )

-- Electrostaff
local blade = {}
blade.PrintName = "Electrohammer"
blade.Author = "Stoneman / Truce"
blade.id = "hammer"
blade.color_blur = Color(200,0,200)
blade.width = 0.65
blade.widthWiggle = 0
blade.length = 19.1
blade.Spawnable = false
blade.dynamic_light = false
blade.no_trail = false
blade.sounds = {
	Attack = "nanosword_hup",
	Attack1 = "nanosword_hup",
	Attack2 = "nanosword_hup",
	Attack3 = "nanosword_hup",
	Activate = "nanosword_turnon",
	Disable = "nanosword_turnoff",
	Idle =  "",
}
LSCS:RegisterBlade( blade )

-- special case: model based blade
local blade = {}
blade.PrintName = "Nano Particles"
blade.Author = "Blu-x92 / Luna"
blade.id = "nanoparticles"
blade.color_blur = Color(0,127,255)
blade.color_core = Color(0,0,0)
blade.mdl = "models/lscs/weapons/nanosword_bladefx.mdl"
blade.mdl_poseparameter = "blade_retract"
blade.length = 27
blade.dynamic_light = true
blade.no_trail = false
blade.sounds = {
	Attack = "nanosword_hup",
	Attack1 = "nanosword_hup",
	Attack2 = "nanosword_hup",
	Attack3 = "nanosword_hup",
	Activate = "nanosword_turnon",
	Disable = "nanosword_turnoff",
	Idle =  "nanosword_idle",
}
LSCS:RegisterBlade( blade )


local blade = {}
blade.PrintName = "Bo_Rifle"
blade.Author = "Stoneman / Truce"
blade.id = "bo_rifle_b"
blade.color_blur = Color(255,255,0)
blade.width = 0.8
blade.widthWiggle = 0
blade.length = 7.3
blade.Spawnable = false
blade.dynamic_light = false
blade.no_trail = false
blade.sounds = {
	Attack = "nanosword_hup",
	Attack1 = "nanosword_hup",
	Attack2 = "nanosword_hup",
	Attack3 = "nanosword_hup",
	Activate = "nanosword_turnon",
	Disable = "nanosword_turnoff",
	Idle =  "",
}
LSCS:RegisterBlade( blade )

local blade = {}
blade.PrintName = "Rapier"
blade.Author = "Truce"
blade.id = "rapb"
blade.color_blur = Color(0,0,0)
blade.color_core = Color(255,255,255)
blade.length = 45
blade.width = 0
blade.widthWiggle = 0
blade.material_core_tip = Material( "lscs/effects/lightsaber_tip" )
blade.material_core = Material( "lscs/effects/lightsaber_core" )
blade.material_glow = Material( "lscs/effects/lightsaber_glow" )
blade.material_trail = Material( "lscs/effects/lightsaber_trail" )
blade.dynamic_light = false
blade.Spawnable = false
blade.no_trail = true
blade.sounds = {
	Attack = "",
	Attack1 = "",
	Attack2 = "",
	Attack3 = "",
	Activate = "",
	Disable = "",
	Idle =  "",
}
LSCS:RegisterBlade( blade )

local blade = {}
blade.PrintName = "Guard Pike"
blade.Author = "Truce"
blade.id = "grdp"
blade.color_blur = Color(0,0,0)
blade.color_core = Color(255,255,255)
blade.length = 41
blade.width = 0.0
blade.widthWiggle = 0
blade.material_core_tip = Material( "lscs/effects/lightsaber_tip" )
blade.material_core = Material( "lscs/effects/lightsaber_core" )
blade.material_glow = Material( "lscs/effects/lightsaber_glow" )
blade.material_trail = Material( "lscs/effects/lightsaber_trail" )
blade.dynamic_light = false
blade.Spawnable = false
blade.no_trail = true
blade.sounds = {
	Attack = "",
	Attack1 = "",
	Attack2 = "",
	Attack3 = "",
	Activate = "",
	Disable = "",
	Idle =  "",
}
LSCS:RegisterBlade( blade )

----------------------       GS       --------------------------------

local blade = {}
blade.PrintName = "Blue GS"
blade.id = "bbg"
blade.color_blur = Color(77,120,255)
blade.color_core = Color(255,255,255)
blade.length = 60
blade.width = 0.9
blade.widthWiggle = 0.6
blade.material_core_tip = Material( "lscs/effects/lightsaber_tip" )
blade.material_core = Material( "lscs/effects/lightsaber_core" )
blade.material_glow = Material( "lscs/effects/lightsaber_glow" )
blade.material_trail = Material( "lscs/effects/lightsaber_trail" )
blade.dynamic_light = true
blade.no_trail = false
blade.sounds = {
	Attack = "saber_hup",
	Attack1 = "saber_spin1",
	Attack2 = "saber_spin2",
	Attack3 = "saber_spin3",
	Activate = "saber_turnon",
	Disable = "saber_turnoff",
	Idle =  "lscs/saber/saberhum4.wav",
}
LSCS:RegisterBlade( blade )

-- modify previous blade, only change what we need to change
blade.PrintName = "Red GS"
blade.id = "brg"
blade.color_blur = Color(255,51,51)
blade.width = 0.8
blade.widthWiggle = 0.7
blade.length = 60
blade.sounds.Idle = "lscs/saber/saberhum2.wav"
LSCS:RegisterBlade( blade ) -- then register new blade table

-- repeat ^^
blade.PrintName = "Green GS"
blade.id = "bgg"
blade.color_blur = Color(129,226,102)
blade.width = 0.9
blade.widthWiggle = 0.6
blade.length = 60
blade.sounds.Idle = "lscs/saber/saberhum5.wav"
LSCS:RegisterBlade( blade )

-- repeat ^^
blade.PrintName = "Orange GS"
blade.id = "bog"
blade.color_blur = Color(255,140,0)
blade.width = 0.9
blade.widthWiggle = 0.6
blade.length = 60
blade.sounds.Idle = "lscs/saber/saberhum1.wav"
LSCS:RegisterBlade( blade )

-- repeat ^^
blade.PrintName = "Yellow GS"
blade.id = "byg"
blade.color_blur = Color(255,232,97)
blade.width = 0.65
blade.widthWiggle = 1
blade.length = 60
blade.sounds.Idle = "lscs/saber/saberhum3.wav"
LSCS:RegisterBlade( blade )

-- repeat ^^
blade.PrintName = "Pink GS"
blade.id = "bpkg"
blade.color_blur = Color(255,144,255)
blade.width = 0.65
blade.widthWiggle = 1
blade.length = 60
blade.sounds.Idle = "lscs/saber/saberhum3.wav"
LSCS:RegisterBlade( blade )

-- repeat ^^
blade.PrintName = "Cyan GS"
blade.id = "bcg"
blade.color_blur = Color(67,197,255)
blade.width = 0.65
blade.widthWiggle = 1
blade.length = 60
blade.sounds.Idle = "lscs/saber/saberhum3.wav"
LSCS:RegisterBlade( blade )

-- repeat ^^
blade.PrintName = "Purple GS"
blade.id = "bpg"
blade.color_blur = Color(164,51,255)
blade.width = 1
blade.widthWiggle = 0.2
blade.length = 60
blade.sounds.Idle = "lscs/saber/saberhum3.wav"
LSCS:RegisterBlade( blade )

local blade = {}
blade.PrintName = "White GS"
blade.Author = "Truce"
blade.id = "bwg"
blade.color_blur = Color(0,0,0)
blade.color_core = Color(255,255,255)
blade.length = 60
blade.width = 0.9
blade.widthWiggle = 0.2
blade.material_core_tip = Material( "lscs/effects/lightsaber_tip" )
blade.material_core = Material( "lscs/effects/lightsaber_core" )
blade.material_glow = Material( "lscs/effects/lightsaber_glow" )
blade.material_trail = Material( "lscs/effects/lightsaber_trail" )
blade.dynamic_light = true
blade.no_trail = false
blade.sounds = {
	Attack = "saber_hup",
	Attack1 = "saber_spin1",
	Attack2 = "saber_spin2",
	Attack3 = "saber_spin3",
	Activate = "saber_turnon",
	Disable = "saber_turnoff",
	Idle =  "saber_idle4",
}
LSCS:RegisterBlade( blade )


-- Darksaber -- 
local blade = {}
blade.PrintName = "Darksaber Blade"
blade.Author = "Truce"
blade.id = "bsb"
blade.color_blur = Color(255,255,255)
blade.color_core = Color(255,255,255)
blade.length = 42
blade.width = 0.9
blade.widthWiggle = 0
blade.material_core_tip = Material( "lscs/effects/lightsaber_tipblack" )
blade.material_core = Material( "lscs/effects/lightsaber_coreblack" )
blade.material_glow = Material( "lscs/effects/lightsaber_glow" )
blade.material_trail = Material( "lscs/effects/lightsaber_trailblack" )
blade.dynamic_light = true
blade.no_trail = false
blade.sounds = {
	Attack = "darksaber_hup", -- called then the combo file calls SWEP:DoAttackSound() or SWEP:DoAttackSound(nil, NUMBER_HAND) where NUMBER_HAND being SWEP.HAND_LEFT or SWEP.HAND_RIGHT or nil for both sabers
	Activate = "darksaber_turnon",
	Disable = "darksaber_turnoff",
	Idle =  "darksaber_idle",
}
LSCS:RegisterBlade( blade )

local blade = {}
blade.PrintName = "Dark Inner Orange"
blade.Author = "Truce"
blade.id = "dob"
blade.color_blur = Color(255,104,31)
blade.color_core = Color(255,255,255)
blade.length = 45
blade.width = 0.9
blade.widthWiggle = 0
blade.material_core_tip = Material( "lscs/effects/lightsaber_tipblack" )
blade.material_core = Material( "lscs/effects/lightsaber_coreblack" )
blade.material_glow = Material( "lscs/effects/lightsaber_glow" )
blade.material_trail = Material( "lscs/effects/lightsaber_trailblack" )
blade.dynamic_light = true
blade.no_trail = false
blade.sounds = {
	Attack = "darksaber_hup", -- called then the combo file calls SWEP:DoAttackSound() or SWEP:DoAttackSound(nil, NUMBER_HAND) where NUMBER_HAND being SWEP.HAND_LEFT or SWEP.HAND_RIGHT or nil for both sabers
	Activate = "darksaber_turnon",
	Disable = "darksaber_turnoff",
	Idle =  "darksaber_idle",
}
LSCS:RegisterBlade( blade )

local blade = {}
blade.PrintName = "Dark Inner Red"
blade.Author = "Truce"
blade.id = "drb"
blade.color_blur = Color(255,51,51)
blade.color_core = Color(255,255,255)
blade.length = 45
blade.width = 0.9
blade.widthWiggle = 0
blade.material_core_tip = Material( "lscs/effects/lightsaber_tipblack" )
blade.material_core = Material( "lscs/effects/lightsaber_coreblack" )
blade.material_glow = Material( "lscs/effects/lightsaber_glow" )
blade.material_trail = Material( "lscs/effects/lightsaber_trailblack" )
blade.dynamic_light = true
blade.no_trail = false
blade.sounds = {
	Attack = "darksaber_hup", -- called then the combo file calls SWEP:DoAttackSound() or SWEP:DoAttackSound(nil, NUMBER_HAND) where NUMBER_HAND being SWEP.HAND_LEFT or SWEP.HAND_RIGHT or nil for both sabers
	Activate = "darksaber_turnon",
	Disable = "darksaber_turnoff",
	Idle =  "darksaber_idle",
}
LSCS:RegisterBlade( blade )

local blade = {}
blade.PrintName = "Dark Inner Yellow"
blade.Author = "Truce"
blade.id = "dyb"
blade.color_blur = Color(255,232,97)
blade.color_core = Color(255,255,255)
blade.length = 45
blade.width = 0.9
blade.widthWiggle = 0
blade.material_core_tip = Material( "lscs/effects/lightsaber_tipblack" )
blade.material_core = Material( "lscs/effects/lightsaber_coreblack" )
blade.material_glow = Material( "lscs/effects/lightsaber_glow" )
blade.material_trail = Material( "lscs/effects/lightsaber_trailblack" )
blade.dynamic_light = true
blade.no_trail = false
blade.sounds = {
	Attack = "darksaber_hup", -- called then the combo file calls SWEP:DoAttackSound() or SWEP:DoAttackSound(nil, NUMBER_HAND) where NUMBER_HAND being SWEP.HAND_LEFT or SWEP.HAND_RIGHT or nil for both sabers
	Activate = "darksaber_turnon",
	Disable = "darksaber_turnoff",
	Idle =  "darksaber_idle",
}
LSCS:RegisterBlade( blade )

----------------------       Small       --------------------------------
local blade = {}
blade.PrintName = "Blue Shoto"
blade.Author = "Truce"
blade.id = "bbs"
blade.color_blur = Color(77,120,255)
blade.color_core = Color(255,255,255)
blade.length = 35
blade.width = 0.9
blade.widthWiggle = 0.6
blade.material_core_tip = Material( "lscs/effects/lightsaber_tip" )
blade.material_core = Material( "lscs/effects/lightsaber_core" )
blade.material_glow = Material( "lscs/effects/lightsaber_glow" )
blade.material_trail = Material( "lscs/effects/lightsaber_trail" )
blade.dynamic_light = true
blade.no_trail = false
blade.sounds = {
	Attack = "saber_hup",
	Attack1 = "saber_spin1",
	Attack2 = "saber_spin2",
	Attack3 = "saber_spin3",
	Activate = "saber_turnon",
	Disable = "saber_turnoff",
	Idle =  "saber_idle4",
}
LSCS:RegisterBlade( blade )

local blade = {}
blade.PrintName = "White Shoto"
blade.Author = "Truce"
blade.id = "bws"
blade.color_blur = Color(0,0,0)
blade.color_core = Color(255,255,255)
blade.length = 35
blade.width = 0.9
blade.widthWiggle = 0.8
blade.material_core_tip = Material( "lscs/effects/lightsaber_tip" )
blade.material_core = Material( "lscs/effects/lightsaber_core" )
blade.material_glow = Material( "lscs/effects/lightsaber_glow" )
blade.material_trail = Material( "lscs/effects/lightsaber_trail" )
blade.dynamic_light = true
blade.no_trail = false
blade.sounds = {
	Attack = "saber_hup",
	Attack1 = "saber_spin1",
	Attack2 = "saber_spin2",
	Attack3 = "saber_spin3",
	Activate = "saber_turnon",
	Disable = "saber_turnoff",
	Idle =  "saber_idle4",
}
LSCS:RegisterBlade( blade )

-- modify previous blade, only change what we need to change
blade.PrintName = "Red Shoto"
blade.id = "brs"
blade.color_blur = Color(255,51,51)
blade.color_core = Color(255,255,255)
blade.width = 0.8
blade.widthWiggle = 0.7
blade.sounds.Idle = "saber_idle2"
LSCS:RegisterBlade( blade ) -- then register new blade table


-- repeat ^^
blade.PrintName = "Green Shoto"
blade.id = "bgs"
blade.color_blur = Color(129,226,102)
blade.width = 0.9
blade.widthWiggle = 0.6
blade.sounds.Idle = "saber_idle5"
LSCS:RegisterBlade( blade )


-- repeat ^^
blade.PrintName = "Purple Shoto"
blade.id = "bps"
blade.color_blur = Color(164,51,255)
blade.width = 1
blade.widthWiggle = 0.2
blade.sounds.Idle = "saber_idle3"
LSCS:RegisterBlade( blade )

-- repeat ^^
blade.PrintName = "Orange Shoto"
blade.id = "bos"
blade.color_blur = Color(255,140,0)
blade.width = 0.9
blade.widthWiggle = 0.6
blade.sounds.Idle = "saber_idle1"
LSCS:RegisterBlade( blade )

-- repeat ^^
blade.PrintName = "Yellow Shoto"
blade.id = "bys"
blade.color_blur = Color(255,232,97)
blade.width = 0.65
blade.widthWiggle = 1
blade.sounds.Idle = "saber_idle3"
LSCS:RegisterBlade( blade )


-- repeat ^^
blade.PrintName = "Pink Shoto"
blade.id = "bpks"
blade.color_blur = Color(255,144,255)
blade.Author = "Truce"
blade.width = 0.65
blade.widthWiggle = 1
blade.sounds.Idle = "saber_idle3"
LSCS:RegisterBlade( blade )

-- repeat ^^
blade.PrintName = "Cyan Shoto"
blade.id = "bcs"
blade.color_blur = Color(67,197,255)
blade.width = 0.9
blade.widthWiggle = 0.6
blade.sounds.Idle = "saber_idle5"
LSCS:RegisterBlade( blade )
------------------- Smellow -----------------------
blade.PrintName = "Violet"
blade.id = "smellow"
blade.length = 45
blade.width = 0.6
blade.widthWiggle = 0.6
blade.color_blur = Color(153,153,255)
LSCS:RegisterBlade( blade )

---Turqoise---
blade.PrintName = "Turqoise"
blade.id = "Turqoise"
blade.length = 45
blade.width = 0.6
blade.widthWiggle = 0.6
blade.color_blur = Color(64,224,208)
LSCS:RegisterBlade( blade )


---Aqua---
blade.PrintName = "Aqua"
blade.id = "smellowaqua"
blade.length = 45
blade.width = 0.6
blade.widthWiggle = 0.6
blade.color_blur = Color(21,236,186)
LSCS:RegisterBlade( blade )


---Dark Inner Violet---
local blade = {}
blade.PrintName = "Dark Inner Violet"
blade.Author = "Mellow"
blade.id = "dismellow"
blade.color_blur = Color(153,153,255)
blade.color_core = Color(255,255,255)
blade.length = 45
blade.width = 0.9
blade.widthWiggle = 0.3
blade.material_core_tip = Material( "lscs/effects/lightsaber_tipblack" )
blade.material_core = Material( "lscs/effects/lightsaber_coreblack" )
blade.material_glow = Material( "lscs/effects/lightsaber_glow" )
blade.material_trail = Material( "lscs/effects/lightsaber_trailblack" )
blade.dynamic_light = true
blade.no_trail = false
blade.sounds = {
	Attack = "darksaber_hup", -- called then the combo file calls SWEP:DoAttackSound() or SWEP:DoAttackSound(nil, NUMBER_HAND) where NUMBER_HAND being SWEP.HAND_LEFT or SWEP.HAND_RIGHT or nil for both sabers
	Activate = "darksaber_turnon",
	Disable = "darksaber_turnoff",
	Idle =  "darksaber_idle",
}
LSCS:RegisterBlade( blade )


---Dark Inner Purple---
local blade = {}
blade.PrintName = "Dark Inner Purple"
blade.Author = "Mellow"
blade.id = "dismellowpurple"
blade.color_blur = Color(164,51,255)
blade.color_core = Color(255,255,255)
blade.length = 45
blade.width = 0.6
blade.widthWiggle = 0.3
blade.material_core_tip = Material( "lscs/effects/lightsaber_tipblack" )
blade.material_core = Material( "lscs/effects/lightsaber_coreblack" )
blade.material_glow = Material( "lscs/effects/lightsaber_glow" )
blade.material_trail = Material( "lscs/effects/lightsaber_trailblack" )
blade.dynamic_light = true
blade.no_trail = false
blade.sounds = {
	Attack = "darksaber_hup", -- called then the combo file calls SWEP:DoAttackSound() or SWEP:DoAttackSound(nil, NUMBER_HAND) where NUMBER_HAND being SWEP.HAND_LEFT or SWEP.HAND_RIGHT or nil for both sabers
	Activate = "darksaber_turnon",
	Disable = "darksaber_turnoff",
	Idle =  "darksaber_idle",
}
LSCS:RegisterBlade( blade )

---Dark Inner Aqua---
local blade = {}
blade.PrintName = "Dark Inner Aqua"
blade.Author = "Mellow"
blade.id = "dismellowaqua"
blade.color_blur = Color(21,236,186)
blade.color_core = Color(255,255,255)
blade.length = 45
blade.width = 0.9
blade.widthWiggle = 0.3
blade.material_core_tip = Material( "lscs/effects/lightsaber_tipblack" )
blade.material_core = Material( "lscs/effects/lightsaber_coreblack" )
blade.material_glow = Material( "lscs/effects/lightsaber_glow" )
blade.material_trail = Material( "lscs/effects/lightsaber_trailblack" )
blade.dynamic_light = true
blade.no_trail = false
blade.sounds = {
	Attack = "darksaber_hup", -- called then the combo file calls SWEP:DoAttackSound() or SWEP:DoAttackSound(nil, NUMBER_HAND) where NUMBER_HAND being SWEP.HAND_LEFT or SWEP.HAND_RIGHT or nil for both sabers
	Activate = "darksaber_turnon",
	Disable = "darksaber_turnoff",
	Idle =  "darksaber_idle",
}
LSCS:RegisterBlade( blade )

---Dark Inner Purple---
local blade = {}
blade.PrintName = "Dark Inner Pink"
blade.Author = "Mellow"
blade.id = "disurielpink"
blade.color_blur = Color(255,144,255)
blade.color_core = Color(255,255,255)
blade.length = 45
blade.width = 0.6
blade.widthWiggle = 0.3
blade.material_core_tip = Material( "lscs/effects/lightsaber_tipblack" )
blade.material_core = Material( "lscs/effects/lightsaber_coreblack" )
blade.material_glow = Material( "lscs/effects/lightsaber_glow" )
blade.material_trail = Material( "lscs/effects/lightsaber_trailblack" )
blade.dynamic_light = true
blade.no_trail = false
blade.sounds = {
	Attack = "darksaber_hup", -- called then the combo file calls SWEP:DoAttackSound() or SWEP:DoAttackSound(nil, NUMBER_HAND) where NUMBER_HAND being SWEP.HAND_LEFT or SWEP.HAND_RIGHT or nil for both sabers
	Activate = "darksaber_turnon",
	Disable = "darksaber_turnoff",
	Idle =  "darksaber_idle",
}
LSCS:RegisterBlade( blade )

-- Kiba Decayed --

local blade = {}
blade.PrintName = "Decayed Crystal"
blade.Author = "Mellow"
blade.id = "dismellowgrey"
blade.color_blur = Color(128,13,13)
blade.color_core = Color(196,196,196)
blade.length = 45
blade.width = 0.9
blade.widthWiggle = 1
blade.material_core_tip = Material( "lscs/effects/lightsaber_tipblack" )
blade.material_core = Material( "lscs/effects/lightsaber_coreblack" )
blade.material_glow = Material( "lscs/effects/lightsaber_glow" )
blade.material_trail = Material( "lscs/effects/lightsaber_trailblack" )
blade.dynamic_light = true
blade.no_trail = false
blade.sounds = {
	Attack = "darksaber_hup", -- called then the combo file calls SWEP:DoAttackSound() or SWEP:DoAttackSound(nil, NUMBER_HAND) where NUMBER_HAND being SWEP.HAND_LEFT or SWEP.HAND_RIGHT or nil for both sabers
	Activate = "darksaber_turnon",
	Disable = "darksaber_turnoff",
	Idle =  "darksaber_idle",
}
LSCS:RegisterBlade( blade )

-- Kiba Resurrected --

local blade = {}
blade.PrintName = "Resurrected Crystal"
blade.Author = "Mellow"
blade.id = "dismellowresurrected"
blade.color_blur = Color(153,0,153)
blade.color_core = Color(196,196,196)
blade.length = 45
blade.width = 0.9
blade.widthWiggle = 1
blade.material_core_tip = Material( "lscs/effects/lightsaber_tipblack" )
blade.material_core = Material( "lscs/effects/lightsaber_coreblack" )
blade.material_glow = Material( "lscs/effects/lightsaber_glow" )
blade.material_trail = Material( "lscs/effects/lightsaber_trailblack" )
blade.dynamic_light = true
blade.no_trail = false
blade.sounds = {
	Attack = "darksaber_hup", -- called then the combo file calls SWEP:DoAttackSound() or SWEP:DoAttackSound(nil, NUMBER_HAND) where NUMBER_HAND being SWEP.HAND_LEFT or SWEP.HAND_RIGHT or nil for both sabers
	Activate = "darksaber_turnon",
	Disable = "darksaber_turnoff",
	Idle =  "darksaber_idle",
}
LSCS:RegisterBlade( blade )

