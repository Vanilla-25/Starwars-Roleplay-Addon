local THE_FONT = {
	font = "Verdana",
	extended = false,
	size = 20,
	weight = 2000,
	blursize = 0,
	scanlines = 0,
	antialias = true,
	underline = false,
	italic = false,
	strikeout = false,
	symbol = false,
	rotary = false,
	shadow = true,
	additive = false,
	outline = false,
}
surface.CreateFont( "LSCS_FONT", THE_FONT )

THE_FONT.size = 17
surface.CreateFont( "LSCS_FONT_MEDIUM", THE_FONT )

THE_FONT.size = 15
THE_FONT.weight = 500
surface.CreateFont( "LSCS_FONT_SMALL", THE_FONT )

THE_FONT.font = "Ink Free"
THE_FONT.size = 16
THE_FONT.weight = 1000
surface.CreateFont( "LSCS_VERSION", THE_FONT )

THE_FONT.size = 40
THE_FONT.weight = 1000
surface.CreateFont( "LSCS_FONT_MAXIMUM", THE_FONT )

local function bezier(p0, p1, p2, p3, t)
	local e = p0 + t * (p1 - p0)
	local f = p1 + t * (p2 - p1)
	local g = p2 + t * (p3 - p2)

	local h = e + t * (f - e)
	local i = f + t * (g - f)

	local p = h + t * (i - h)

	return p
end

local function DrawFrame( w, h, offset, thickness )
	surface.DrawRect( offset, offset, thickness, h - offset * 2 )
	surface.DrawRect( w - offset - thickness, offset, thickness, h - offset * 2 )

	surface.DrawRect( offset, offset, w - offset * 2 - thickness, thickness )
	surface.DrawRect( offset, h - offset - thickness, w - offset * 2 - thickness, thickness )
end

local function DrawBezier( startPos, endPos )
	local detail = 15
	local p2 = Vector(endPos.x,startPos.y,0)
	local p3 = Vector(startPos.x,endPos.y,0)

	for i = 1,detail do
		local sp = bezier(startPos, p2, p3, endPos, (i - 1) / detail)
		local ep = bezier(startPos, p2, p3, endPos, i / detail)
		surface.DrawLine( sp.x, sp.y, ep.x, ep.y )
	end
end

local Gradient = Material("vgui/gradient-l")
local ClickMat = Material("sun/overlay")

local menu_white_dim = Color(100,100,100,255)
local menu_white = Color(255,255,255,255)
local menu_dark = Color(24,30,54,255)
local menu_dim = Color(37,42,64,255)
local menu_light = Color(46,51,73,255)
local menu_black = Color(31,31,31,255)
local menu_text = Color(0,127,255,255)

local icon_lscs = Material("lscs/ui/icon256.png")

local icon_inventory = Material("lscs/ui/inventory.png")
local icon_hilt = Material("lscs/ui/hilt.png")
local icon_stance = Material("lscs/ui/stance.png")
local icon_force = Material("lscs/ui/force.png")
local icon_settings = Material("lscs/ui/settings.png")
local icon_duel = Material("sos/duel.png")

local icon_check = Material("lscs/ui/check.png")
local icon_cross = Material("lscs/ui/cross.png")

local icon_hand = Material("lscs/ui/hand.png")
local icon_lhand = Material("lscs/ui/hand_l.png")
local icon_rhand = Material("lscs/ui/hand_r.png")

local icon_load_version = Material("gui/html/refresh")
local icon_missing = Material( "lscs/ui/noicon.png" )
local icon_invert = Material( "lscs/ui/logo_invert.png")
local icon_steam = Material("lscs/ui/steam.png")
local icon_youtube = Material("lscs/ui/youtube.png")
local icon_discord = Material("lscs/ui/discord.png")
local icon_github = Material("lscs/ui/github.png")

local zoom_mat = Material( "vgui/zoom" )
local gradient_mat = Material( "gui/gradient" )
local adminMat = Material( "icon16/shield.png" )

local KyberCoreCachedInventory = {}
local KyberCoreCachedInventoryEquipped = {}

CreateClientConVar( "kybercore_selected_tree", "", true, false )
CreateClientConVar( "kybercore_saved_scroll", 0, true, false )

local function BaseButtonClick( self, sound )
	if not self:IsEnabled() then return end

	sound = sound or "ui/buttonclick.wav"

	surface.PlaySound( sound )
	self.smScale = 1
end

local function DrawButtonClick( self, w, h ) 
	local Col = menu_white_dim
	if self:IsHovered() then
		Col = menu_white
	end
	if not self:IsEnabled() then
		Col = menu_text
	end

	self.smScale = self.smScale or 0
	self.smScale = self.smScale - math.min(self.smScale,RealFrameTime() * 3)

	local Size = self.smScale

	if Size > 0.05 then
		surface.DrawCircle( w * 0.5, h * 0.5, (1 - Size) * (w - 25), 150, 200, 255, 255 * Size )
		surface.DrawCircle( w * 0.5, h * 0.5, (1 - Size) * (w - 15), 150, 200, 255, 255 * 0.5 * Size )
		surface.DrawCircle( w * 0.5, h * 0.5, (1 - Size) * (w - 10), 150, 200, 255, 255 * 0.2 * Size )

		surface.SetMaterial( ClickMat )
		surface.SetDrawColor( 150 * Size, 200 * Size, 255 * Size, 255 * Size )
		surface.DrawTexturedRect( w * 0.5 - w * 0.5 * Size * 2, h * 0.5 - h * 0.5 * Size * 2, w * Size * 2, h * Size * 2 )
	end

	return Col
end

local ForceNum = 1
local StanceNum = 1
local Frame
local FrameBarHeight = 24

-- local FrameSizeX = 750
local FrameSizeX = ScrW() * 0.575
-- local FrameSizeY = 480 + FrameBarHeight
local FrameSizeY = ScrH() * 0.6 + FrameBarHeight

local SelectorHeight = ( ScrH() * 0.075 ) * 8
local SelectorWidth = 80
local SelectorWidthActive = 196

local PanelPosX = SelectorWidth
local PanelPosY = FrameBarHeight
local PanelSizeX = FrameSizeX - SelectorWidth
local PanelSizeY = FrameSizeY - FrameBarHeight * 2

function LSCS:SetActivePanel( newpanel )
	if not IsValid( Frame ) then
		LSCS:OpenMenu()
	end

	if IsValid( Frame.PANEL ) then
		Frame.PANEL:Remove()
	end

	Frame:SetSize( FrameSizeX, FrameSizeY )
	Frame:Center()

	Frame.PANEL = newpanel
end

local function BaseButtonClickSB( self, sound )
	sound = sound or "ui/buttonclick.wav"

	surface.PlaySound( sound )

	Frame.buttons = Frame.buttons or {}
	Frame.buttons[ self.ID ] = 1
end

local function DrawButtonClickSB( self, w, h ) 
	local Col = menu_white_dim
	if self:IsHovered() then
		Col = menu_white
	end

	Frame.buttons = Frame.buttons or {}
	Frame.buttons[ self.ID ] = Frame.buttons[ self.ID ] or 0

	Frame.buttons[ self.ID ] = Frame.buttons[ self.ID ] - math.min(Frame.buttons[ self.ID ],RealFrameTime() * 3)

	local Size = Frame.buttons[ self.ID ]

	if Size > 0.05 then
		surface.DrawCircle( w * 0.5, h * 0.5, (1 - Size) * (w - 25), 150, 200, 255, 255 * Size )
		surface.DrawCircle( w * 0.5, h * 0.5, (1 - Size) * (w - 15), 150, 200, 255, 255 * 0.5 * Size )
		surface.DrawCircle( w * 0.5, h * 0.5, (1 - Size) * (w - 10), 150, 200, 255, 255 * 0.2 * Size )

		surface.SetMaterial( ClickMat )
		surface.SetDrawColor( 150 * Size, 200 * Size, 255 * Size, 255 * Size )
		surface.DrawTexturedRect( w * 0.5 - w * 0.5 * Size * 2, h * 0.5 - h * 0.5 * Size * 2, w * Size * 2, h * Size * 2 )
	end

	return Col
end

local function CreateSideBarButton( icon, ID, text )
	local button = vgui.Create( "Button", Frame.SideBar )
	button.text = text or ""
	button:SetText( "" )	
	button:SetSize( SelectorWidthActive,  80 )
	button:SetPos( 0,  (ID - 1) * 80 )
	button.DoClick = function( self )
	end
	button.Paint = function(self, w, h )
		Frame._smSB = Frame._smSB or SelectorWidth

		local xPos = Frame._smSB - 8 - 64

		local Col = DrawButtonClickSB( self, w, h ) 
		if Frame.ID == self.ID then
			Col = menu_text

			draw.DrawText( self.text, "LSCS_FONT", -110 + xPos, h * 0.5 - 10, Col, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER )

			surface.SetMaterial( Gradient )
			surface.SetDrawColor( Col.r, Col.g, Col.b, Col.a )
			surface.DrawTexturedRect( 0, 0, 6, h )
		else
			draw.DrawText( self.text, "LSCS_FONT", -110 + xPos, h * 0.5 - 10, Col, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER )
		end

		surface.SetMaterial( icon )
		surface.SetDrawColor( Col.r, Col.g, Col.b, Col.a )
		surface.DrawTexturedRect( xPos, 8, 64, 64 )
	end
	button.ID = ID

	return button
end

local DuelingButtonDelay = CurTime()

function LSCS:SideBar( Frame )
	if IsValid( Frame.SideBar ) then
		Frame.SideBar:Remove()
	end

	Frame.SideBar = vgui.Create( "DScrollPanel", Frame )
	Frame.SideBar:SetPos( 0, FrameBarHeight )
	Frame.SideBar:SetSize( (Frame:SideBarIsActive() and SelectorWidthActive or SelectorWidth), SelectorHeight )
	Frame.SideBar.Paint = function(self, w, h )
		draw.RoundedBoxEx( 8, 0, 0, w, h, menu_dark, false, false, true, false )
	end

	local VBar = Frame.SideBar:GetVBar()

	VBar:SetWide( 8 )

	// Make scrollbar more fancy
	Frame.SideBar.VBar.Paint = function(self, w, h)
		draw.RoundedBox( 8, 0, 0, w, h, Color(31, 31, 31, 0) )
	end

	Frame.SideBar.VBar.btnUp.Paint = function(self, w, h)
		draw.RoundedBox( 8, 0, 0, w, h, menu_light )
	end

	Frame.SideBar.VBar.btnDown.Paint = function(self, w, h)
		draw.RoundedBox( 8, 0, 0, w, h, menu_light )
	end

	Frame.SideBar.VBar.btnGrip.Paint = function(self, w, h)
		draw.RoundedBox( 8, 0, 0, w, h, menu_light )
	end
	
	local button = CreateSideBarButton( icon_lscs, 1, "Home" )
	button.DoClick = function( self )
		BaseButtonClickSB( self )
		LSCS:BuildMainMenu( Frame )
	end

	-- local button = CreateSideBarButton( icon_inventory, 2, "Inventory" )
	-- button.DoClick = function( self )
	-- 	BaseButtonClickSB( self )
	-- 	LSCS:BuildInventory( Frame )
	-- end

	local button = CreateSideBarButton( icon_inventory, 2, "Skills" )
	button.DoClick = function( self )
		BaseButtonClickSB( self )
		LSCS:BuildSkills( Frame )
	end

	local button = CreateSideBarButton( icon_hilt, 3, "Lightsaber" )
	button.DoClick = function( self )
		BaseButtonClickSB( self )
		LSCS:BuildSaberMenu( Frame )
	end

	local button = CreateSideBarButton( icon_stance, 4, "Stance" )
	button.DoClick = function( self )
		BaseButtonClickSB( self )
		LSCS:BuildStanceMenu( Frame )
	end

	local button = CreateSideBarButton( icon_force, 5, "Force" )
		button.DoClick = function( self )
		BaseButtonClickSB( self )
		LSCS:BuildForceMenu( Frame )
	end

	local button = CreateSideBarButton( icon_duel, 6, "Dueling" )
	button.DoClick = function( self )
		if DuelingButtonDelay > CurTime() then return end
		BaseButtonClickSB( self )
		LSCS:BuildDueling( Frame )
		DuelingButtonDelay = CurTime() + 1
	end
	local button = CreateSideBarButton( icon_settings, 7, "Settings" )
		button.DoClick = function( self )
		BaseButtonClickSB( self )
		LSCS:BuildSettings( Frame )
	end
	
	if not LocalPlayer():IsSuperAdmin() and not KyberCore:IsSystemAdmin( LocalPlayer() ) then return end
	local button = CreateSideBarButton( icon_settings, 8, "Admin" )
	button.DoClick = function( self )
		BaseButtonClickSB( self )
		LSCS:BuildAdmin( Frame )
	end
end

function LSCS:BuildMainMenu( Frame )
    local smMove = 0

    local Panel = vgui.Create( "DPanel", Frame )
    Panel:SetPos( PanelPosX, PanelPosY )
    Panel:SetSize( PanelSizeX, PanelSizeY + FrameBarHeight )
    Panel.Paint = function(self, w, h )
        local Col = Color( 255, 191, 0, 255 ) 
    end

    local mdl = vgui.Create( "DModelPanel", Panel )
    mdl:SetSize( 250, 0)
    mdl:Dock( LEFT )
    mdl:DockMargin( 4, 4, 4, 4 )
    mdl:SetFOV( 30 )
    mdl:SetCamPos( vector_origin )
    mdl:SetDirectionalLight( BOX_RIGHT, Color( 255, 160, 80, 255 ) )
    mdl:SetDirectionalLight( BOX_LEFT, Color( 80, 160, 255, 255 ) )
    mdl:SetAmbientLight( Vector( -64, -64, -64 ) )
    mdl:SetAnimated( true )
    mdl.Angles = angle_zero
    mdl:SetLookAt( Vector( -100, 0, -22 ) )
    mdl:SetModel( LocalPlayer():GetModel() )
    function mdl.Entity:GetPlayerColor() return LocalPlayer():GetPlayerColor() end
    mdl.Entity:SetPos( Vector( -100, 0, -61 ) )

    function mdl:DragMousePress()
        self.PressX, self.PressY = gui.MousePos()
        self.Pressed = true
    end

    function mdl:DragMouseRelease() self.Pressed = false end

    function mdl:LayoutEntity( ent )
        if ( self.bAnimated ) then self:RunAnimation() end

        if ( self.Pressed ) then
            local mx = gui.MousePos()
            self.Angles = self.Angles - Angle( 0, ( ( self.PressX or mx ) - mx ) / 2, 0 )

            self.PressX, self.PressY = gui.MousePos()
        end

        ent:SetAngles( self.Angles )
    end

    mdl.Paint = function(self, w, h )
        local Col = menu_dim
        surface.SetDrawColor( Col.r, Col.g, Col.b, Col.a )
        surface.DrawRect( 0, 0, w, h  )
    
        if not IsValid( self.Entity ) then return end

        local x, y = self:LocalToScreen( 0, 0 )

        self:LayoutEntity( self.Entity )

        local ang = self.aLookAngle
        if not ang then
            ang = ( self.vLookatPos - self.vCamPos ):Angle()
        end

        cam.Start3D( self.vCamPos, ang, self.fFOV, x, y, w, h, 5, self.FarZ )

        render.SuppressEngineLighting( true )
        render.SetLightingOrigin( self.Entity:GetPos() )
        render.ResetModelLighting( self.colAmbientLight.r / 255, self.colAmbientLight.g / 255, self.colAmbientLight.b / 255 )
        render.SetColorModulation( self.colColor.r / 255, self.colColor.g / 255, self.colColor.b / 255 )
        render.SetBlend( ( self:GetAlpha() / 255 ) * ( self.colColor.a / 255 ) ) -- * surface.GetAlphaMultiplier()

        for i = 0, 6 do
            local col = self.DirectionalLight[ i ]
            if ( col ) then
                render.SetModelLighting( i, col.r / 255, col.g / 255, col.b / 255 )
            end
        end

        self:DrawModel()

        render.SuppressEngineLighting( false )
        cam.End3D()

        self.LastPaint = RealTime()
    end

    local NameHeader = vgui.Create( "DPanel", Panel )
    NameHeader:Dock( TOP )
    NameHeader:DockMargin( 4, 4, 4, 4 )
    NameHeader.Paint = function(self, w, h )
        local Col = menu_dim

        surface.SetDrawColor( Col.r, Col.g, Col.b, Col.a )
        surface.DrawRect( 0, 0, w, h )
        draw.SimpleText( LocalPlayer():Nick(), "LSCS_FONT_MEDIUM", w * 0.5, h * 0.5, menu_text, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
    end

    local ProfilePanel = vgui.Create("DPanel", Panel)
    ProfilePanel:SetSize(0, 180)
    ProfilePanel:Dock(TOP)
    ProfilePanel:DockMargin(4, 4, 4, 4)
    ProfilePanel.Paint = function(self, w, h)
        local Col = menu_light
        surface.SetDrawColor(Col.r, Col.g, Col.b, Col.a)
        surface.DrawRect(0, 0, w, h)
    end

    local ply = LocalPlayer()
    local currentXP = ply:GetNWInt("KC_EXP", 0)
    local currentLevel = ply:GetNWInt("KC_EXP_LEVEL", 1)
    local skillPoints = ply:GetNWInt("KC_EXP_POINTS", 0)
    local xpForNextLevel = 0
	local xpForCurrentLevel = 0

    if KyberCore.Config.FixedLeveling then
        xpForNextLevel = KyberCore.Config.FixedXP * currentLevel
		xpForCurrentLevel = KyberCore.Config.FixedXP * (currentLevel - 1)
	else
        xpForNextLevel = KyberCore:CalculateXPForLevel(currentLevel)
        xpForCurrentLevel = KyberCore:CalculateXPForLevel(currentLevel - 1)
    end

    local xpThisLevel = currentXP - xpForCurrentLevel
    local xpNeeded = xpForNextLevel - xpForCurrentLevel
    local progress = math.Clamp(xpThisLevel / xpNeeded, 0, 1)
    
    local StatsSection = vgui.Create("DPanel", ProfilePanel)
    StatsSection:Dock(FILL)
    StatsSection:DockMargin(10, 10, 10, 10)
    StatsSection.Paint = function(self, w, h)
        local Col = menu_dim
        surface.SetDrawColor(Col.r, Col.g, Col.b, Col.a)
        surface.DrawRect(0, 0, w, h)
        
        draw.SimpleText("LEVEL " .. currentLevel, "LSCS_FONT_MEDIUM", 10, 20, menu_text, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        
        local barY = 40
        local barHeight = 20
        surface.SetDrawColor(40, 40, 40, 255)
        surface.DrawRect(10, barY, w-20, barHeight)
        
        local progressWidth = (w-20) * progress
        local glowFactor = 0.5 + math.sin(CurTime() * 2) * 0.1
        
        for i=0, progressWidth do
            local alpha = 155 + 100 * (1 - (i/progressWidth))
            local pulse = 50 * math.sin(CurTime() * 3 + i * 0.02) * glowFactor
            surface.SetDrawColor(menu_text.r + pulse, menu_text.g + pulse, menu_text.b + pulse, alpha)
            surface.DrawRect(10 + i, barY, 1, barHeight)
        end
        
		draw.SimpleText(xpThisLevel .. " / " .. xpNeeded .. " XP", "LSCS_FONT_MEDIUM", w/2, barY + barHeight/2, menu_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

        local iconSize = 24
        local pointsY = 75
        
        surface.SetDrawColor(255, 191, 0, 255)
        surface.DrawRect(10, pointsY, iconSize, iconSize)
        draw.SimpleText("SKILL POINTS: " .. skillPoints, "LSCS_FONT_MEDIUM", 10 + iconSize + 10, pointsY + iconSize/2, menu_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        draw.SimpleText("TOTAL XP: " .. currentXP, "LSCS_FONT_MEDIUM", w-10, h-10, menu_white_dim, TEXT_ALIGN_RIGHT, TEXT_ALIGN_BOTTOM)
    end

    local ContentScroll = vgui.Create("DScrollPanel", Panel)
    ContentScroll:Dock(FILL)
    ContentScroll:DockMargin(4, 4, 4, 4)
    
    local scrollBar = ContentScroll:GetVBar()
    scrollBar:SetWide(8)
    scrollBar.Paint = function(self, w, h) draw.RoundedBox(4, 0, 0, w, h, Color(31, 31, 31, 0)) end
    scrollBar.btnUp.Paint = function(self, w, h) draw.RoundedBox(4, 0, 0, w, h, menu_light) end
    scrollBar.btnDown.Paint = function(self, w, h) draw.RoundedBox(4, 0, 0, w, h, menu_light) end
    scrollBar.btnGrip.Paint = function(self, w, h) draw.RoundedBox(4, 0, 0, w, h, menu_light) end

    -- BONUSES SECTION
    local BonusPanel = vgui.Create("DPanel", ContentScroll)
    BonusPanel:SetSize(0, 100)
    BonusPanel:Dock(TOP)
    BonusPanel:DockMargin(0, 0, 0, 8)
    BonusPanel.Paint = function(self, w, h)
        local Col = menu_light
        surface.SetDrawColor(Col.r, Col.g, Col.b, Col.a)
        surface.DrawRect(0, 0, w, h)
        
        draw.SimpleText("STAT BONUSES", "LSCS_FONT_MEDIUM", 10, 10, menu_text, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
        
        -- Get bonuses
        local bonusHealth = KyberCore:GetBonusHealth(ply) or 0
        local bonusSpeed = KyberCore:GetBonusSpeed(ply) or 0
        local bonusBlockPoints = KyberCore:GetBonusBlockPoints(ply) or 0
        local bonusForce = KyberCore:GetBonusForce(ply) or 0
        
        -- Draw bonus values with icons
        local x = 20
        local y = 40
        local spacing = 120
        
        -- Health
        local healthColor = bonusHealth > 0 and Color(0, 255, 0, 255) or menu_white
        surface.SetDrawColor(255, 0, 0, 255)
        surface.DrawRect(x, y, 16, 16)
        draw.SimpleText("Health: " .. (bonusHealth > 0 and "+" or "") .. bonusHealth, "LSCS_FONT_SMALL", x + 24, y + 8, healthColor, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        
        -- Speed
        local speedColor = bonusSpeed > 0 and Color(0, 255, 0, 255) or menu_white
        surface.SetDrawColor(0, 255, 255, 255)
        surface.DrawRect(x + spacing, y, 16, 16)
        draw.SimpleText("Speed: " .. (bonusSpeed > 0 and "+" or "") .. bonusSpeed, "LSCS_FONT_SMALL", x + spacing + 24, y + 8, speedColor, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        
        -- Block Points
        local blockColor = bonusBlockPoints > 0 and Color(0, 255, 0, 255) or menu_white
        surface.SetDrawColor(255, 255, 0, 255)
        surface.DrawRect(x, y + 30, 16, 16)
        draw.SimpleText("Block: " .. (bonusBlockPoints > 0 and "+" or "") .. bonusBlockPoints, "LSCS_FONT_SMALL", x + 24, y + 30 + 8, blockColor, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        
        -- Force
        local forceColor = bonusForce > 0 and Color(0, 255, 0, 255) or menu_white
        surface.SetDrawColor(0, 128, 255, 255)
        surface.DrawRect(x + spacing, y + 30, 16, 16)
        draw.SimpleText("Force: " .. (bonusForce > 0 and "+" or "") .. bonusForce, "LSCS_FONT_SMALL", x + spacing + 24, y + 30 + 8, forceColor, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
    end
    
    -- OWNED FORMS SECTION
    local FormsPanel = vgui.Create("DPanel", ContentScroll)
    FormsPanel:SetSize(0, 150)  -- Reduced height for horizontal layout
    FormsPanel:Dock(TOP)
    FormsPanel:DockMargin(0, 0, 0, 8)
    FormsPanel.Paint = function(self, w, h)
        local Col = menu_light
        surface.SetDrawColor(Col.r, Col.g, Col.b, Col.a)
        surface.DrawRect(0, 0, w, h)
        
        draw.SimpleText("COMBAT FORMS", "LSCS_FONT_MEDIUM", 10, 10, menu_text, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
    end
    
    -- Container for horizontal scroll buttons and forms
    local FormsScrollContainer = vgui.Create("DPanel", FormsPanel)
    FormsScrollContainer:Dock(FILL)
    FormsScrollContainer:DockMargin(10, 35, 10, 10)
    FormsScrollContainer.Paint = function() end
    
    -- Owned forms horizontal scroll panel
    local FormsScroll = vgui.Create("DHorizontalScroller", FormsScrollContainer)
    FormsScroll:Dock(FILL)
    FormsScroll:SetOverlap(-5)
    FormsScroll:SetMouseInputEnabled(true)
    
    -- Populate forms
    local ownedForms = KyberCore:GetOwnedForms(ply) or {}
    
    if table.IsEmpty(ownedForms) then
        local noForms = vgui.Create("DPanel", FormsScroll)
        noForms:SetSize(PanelSizeX - 100, 30)
        noForms.Paint = function(self, w, h)
            draw.SimpleText("No combat forms available", "LSCS_FONT_SMALL", w/2, h/2, menu_white_dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
        FormsScroll:AddPanel(noForms)
    else
        for formID, formName in pairs(ownedForms) do
            local formEntry = vgui.Create("DPanel")
            formEntry:SetSize(125, 150)
            
            local stance = LSCS:GetStance(formName)
            local name = stance and stance.name or formName
            local equipped = stance and stance.equip:GetBool() or false
            
            formEntry.Paint = function(self, w, h)
                local bgColor = equipped and menu_text or menu_dim
                surface.SetDrawColor(bgColor.r, bgColor.g, bgColor.b, bgColor.a)
                surface.DrawRect(0, 0, w, h)
                
                draw.SimpleText(name, "LSCS_FONT_SMALL", w/2, h - 20, menu_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				if stance and stance.icon and file.Exists("materials/"..stance.icon, "GAME") then
					surface.SetMaterial(Material(stance.icon))
					surface.SetDrawColor(255, 255, 255, 200)
					surface.DrawTexturedRect(w/2 - 24, h/2 - 24, 48, 48)
				end
            end
            
            FormsScroll:AddPanel(formEntry)
        end
    end
    
    -- FORCE POWERS SECTION
    local PowersPanel = vgui.Create("DPanel", ContentScroll)
    PowersPanel:SetSize(0, 120)
    PowersPanel:Dock(TOP)
    PowersPanel:DockMargin(0, 0, 0, 8)
    PowersPanel.Paint = function(self, w, h)
        local Col = menu_light
        surface.SetDrawColor(Col.r, Col.g, Col.b, Col.a)
        surface.DrawRect(0, 0, w, h)
        
        draw.SimpleText("FORCE POWERS", "LSCS_FONT_MEDIUM", 10, 10, menu_text, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
    end
    
    -- Container for horizontal scroll buttons and powers
    local PowersScrollContainer = vgui.Create("DPanel", PowersPanel)
    PowersScrollContainer:Dock(FILL)
    PowersScrollContainer:DockMargin(10, 35, 10, 10)
    PowersScrollContainer.Paint = function() end
    
    -- Force powers horizontal scroll panel
    local PowersScroll = vgui.Create("DHorizontalScroller", PowersScrollContainer)
    PowersScroll:Dock(FILL)
    PowersScroll:SetOverlap(-5)
    PowersScroll:SetMouseInputEnabled(true)
    
    -- Populate powers
    local ownedAbilities = KyberCore:GetOwnedAbilities(ply) or {}
    
    if table.IsEmpty(ownedAbilities) then
        local noPowers = vgui.Create("DPanel")
        noPowers:SetSize(PanelSizeX - 100, 60)
        noPowers.Paint = function(self, w, h)
            draw.SimpleText("No force powers available", "LSCS_FONT_SMALL", w/2, h/2, menu_white_dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
        PowersScroll:AddPanel(noPowers)
    else
        for powerID, powerName in pairs(ownedAbilities) do
            local power = LSCS:GetForceAbility(powerName)
            if not power or not power.id then continue end
            
            local powerCard = vgui.Create("DPanel")
            powerCard:SetSize(150, 90)
            
            local isEnabled = power.equip:GetBool()
            local name = power.name or powerName
            local keybind = input.GetKeyName(power.cmd:GetInt()) or "NONE"

            
            powerCard.Paint = function(self, w, h)
                -- Background
                local bgColor = isEnabled and menu_text or menu_dim
                surface.SetDrawColor(bgColor.r, bgColor.g, bgColor.b, bgColor.a)
                surface.DrawRect(0, 0, w, h)

				-- Power icon
				if power.icon and file.Exists("materials/"..power.icon, "GAME") then
					surface.SetMaterial(Material(power.icon))
					surface.SetDrawColor(255, 255, 255, 200)
					surface.DrawTexturedRect(w/2 - 24, h/2 - 24, 48, 48)
				end
                
                -- Power name
				draw.SimpleText(name, "LSCS_FONT_SMALL", w/2,h - 15, menu_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            end
            
            PowersScroll:AddPanel(powerCard)
        end
    end

    local InfoPanel = vgui.Create("DPanel", Panel)
    InfoPanel:Dock(BOTTOM)
    InfoPanel:SetSize(0, 30)
    InfoPanel:DockMargin(4, 4, 4, 4)
    InfoPanel.Paint = function(self, w, h)
        local Col = menu_dim
        surface.SetDrawColor(Col.r, Col.g, Col.b, Col.a)
        surface.DrawRect(0, 0, w, h)
        
        -- Get version information
        local version = "Unknown"
        if KyberCore and KyberCore.Version then 
            version = KyberCore.Version
        end
        
        -- Draw version with subtle pulsing effect
        local pulse = math.sin(CurTime() * 1.5) * 20
        surface.SetDrawColor(0, 127 + pulse, 255, 50 + pulse)
        surface.DrawRect(2, 2, w-4, h-4)
        
        draw.SimpleText("Kyber Core v" .. version, "LSCS_FONT", w/2, h/2, menu_text, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        
        surface.SetDrawColor(menu_text.r, menu_text.g, menu_text.b, menu_text.a)
        DrawFrame(w, h, 0, 1)
    end

    LSCS:SetActivePanel( Panel )
    LSCS:SideBar( Frame )

    Frame.ID = 1
end

function LSCS:BuildInventory( Frame )
	local ply = LocalPlayer()

	local Panel = vgui.Create( "DPanel", Frame )
	Panel:SetPos( PanelPosX, PanelPosY )
	Panel:SetSize( PanelSizeX, PanelSizeY + FrameBarHeight )
	Panel.Paint = function(self, w, h )
		surface.SetMaterial( ClickMat )
		surface.SetDrawColor( 255, 255, 255, 255 )
		local X, Y = self:CursorPos()
		surface.DrawTexturedRectRotated( X, Y, 512, 512, 0 )

		local Col = menu_light
		surface.SetDrawColor( Col.r, Col.g, Col.b, 240 )
		surface.DrawRect( 0, 0, w, h  )
	end

	local ToolBar = vgui.Create( "DPanel", Panel )
	ToolBar:SetSize( PanelSizeX, 50 )
	ToolBar:Dock( BOTTOM )
	ToolBar:DockMargin( 10, 4, 24, 10 )
	ToolBar.Paint = function(self, w, h )
		local Col = menu_dim

		surface.SetDrawColor( Col.r, Col.g, Col.b, Col.a )
		surface.DrawRect( 0, 0, w, h )
	end

	local Refresh = vgui.Create( "DButton", ToolBar )
	Refresh:SetText("")
	Refresh:SetSize( 130, 100 )
	Refresh:Dock( RIGHT )
	Refresh:DockMargin( 4, 4, 4, 4 )
	Refresh.Paint = function(self, w, h )
		local Col = DrawButtonClick( self, w, h )

		draw.SimpleText( "REFRESH", "LSCS_FONT", w * 0.5, h * 0.5, Col, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )

		surface.SetDrawColor( Col.r, Col.g, Col.b, Col.a )

		DrawFrame( w, h, 0, 2 )
	end
	Refresh.DoClick = function( self )
		BaseButtonClick( self )
		self:SetEnabled( false )

		timer.Simple( 0.2, function()
			if not IsValid( self ) then return end
			self:SetEnabled( true )
			net.Start("KyberCore.InventoryRefresh")
			net.SendToServer()
		end )
	end

	local DropAll = vgui.Create( "DButton", ToolBar )
	DropAll:SetText("")
	DropAll:SetSize( 180, 100 )
	DropAll:Dock( LEFT )
	DropAll:DockMargin( 4, 4, 4, 4 )
	DropAll.SafetyEnabled = 1
	DropAll.Paint = function(self, w, h )
		local Col = DrawButtonClick( self, w, h )

		if self.SafetyEnabled == 1 then
			draw.SimpleText( "DROP ALL", "LSCS_FONT", w * 0.5, h * 0.5, Col, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
		elseif self.SafetyEnabled == 2 then
			draw.SimpleText( "ARE YOU SURE??", "LSCS_FONT", w * 0.5, h * 0.5, Col, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
		else
			Col = Color(255, 0, 0, 255)
			surface.SetMaterial( ClickMat )
			surface.SetDrawColor( 150, 0, 0, 255 )
			surface.DrawTexturedRect( 0, 0, w, h )

			draw.SimpleText( "!!DROP ALL!!", "LSCS_FONT", w * 0.5, h * 0.5, Col, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
		end

		surface.SetDrawColor( Col.r, Col.g, Col.b, Col.a )

		DrawFrame( w, h, 0, 2 )
	end
	DropAll.DoClick = function( self )
		BaseButtonClick( self )

		if self.SafetyEnabled < 3 then
			self:SetEnabled( false )

			timer.Simple( 1, function()
				if not IsValid( self ) then return end
				self:SetEnabled( true )
				self.SafetyEnabled = self.SafetyEnabled + 1
			end )
		else
			self:SetEnabled( false )

			net.Start("lscs_inventory_refresh")
				net.WriteBool( true )
				net.WriteBool( false )
			net.SendToServer()
		end
	end

	local DropUnEq = vgui.Create( "DButton", ToolBar )
	DropUnEq:SetText("")
	DropUnEq:SetSize( 180, 100 )
	DropUnEq:Dock( LEFT )
	DropUnEq:DockMargin( 4, 4, 4, 4 )
	DropUnEq.SafetyEnabled = 1
	DropUnEq.Paint = function(self, w, h )
		local Col = DrawButtonClick( self, w, h )

		if self.SafetyEnabled == 1 then
			draw.SimpleText( "DROP", "LSCS_FONT", w * 0.5, h * 0.5 + 2, Col, TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM )
			draw.SimpleText( "UNEQUIPPED", "LSCS_FONT", w * 0.5, h * 0.5 - 2, Col, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP )
		elseif self.SafetyEnabled == 2 then
			draw.SimpleText( "ARE YOU SURE??", "LSCS_FONT", w * 0.5, h * 0.5, Col, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
		else
			Col = Color(255, 0, 0, 255)
			surface.SetMaterial( ClickMat )
			surface.SetDrawColor( 150, 0, 0, 255 )
			surface.DrawTexturedRect( 0, 0, w, h )

			draw.SimpleText( "!!DROP!!", "LSCS_FONT", w * 0.5, h * 0.5 + 2, Col, TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM )
			draw.SimpleText( "!!UNEQUIPPED!!", "LSCS_FONT", w * 0.5, h * 0.5 - 2, Col, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP )
		end

		surface.SetDrawColor( Col.r, Col.g, Col.b, Col.a )

		DrawFrame( w, h, 0, 2 )
	end
	DropUnEq.DoClick = function( self )
		BaseButtonClick( self )

		if self.SafetyEnabled < 3 then
			self:SetEnabled( false )

			timer.Simple( 1, function()
				if not IsValid( self ) then return end
				self:SetEnabled( true )
				self.SafetyEnabled = self.SafetyEnabled + 1
			end )
		else
			self:SetEnabled( false )

			net.Start("lscs_inventory_refresh")
				net.WriteBool( true )
				net.WriteBool( true )
			net.SendToServer()
		end
	end

	local DScrollPanel = vgui.Create( "DScrollPanel", Panel )
	DScrollPanel:SetSize( PanelSizeX, PanelSizeY - 40 )
	DScrollPanel:Dock( BOTTOM )

	local Inventory = ply:lscsGetInventory()

	local X = 8
	local Y = 8
	for index, class in pairs( Inventory ) do
		local DButton = vgui.Create( "DButton", DScrollPanel )
		DButton:SetText( "" )
		DButton:SetPos( X, Y )
		DButton:SetSize( 128, 128 )

		DButton.SetMaterial = function( self, mat ) 
			if file.Exists( "materials/"..mat, "GAME" ) then
				self.Mat = Material( mat )
			else
				self.Mat = Material( "debug/debugwireframe" )
			end
		end
		DButton.GetMaterial = function( self ) return self.Mat end

		DButton.SetID = function( self, id ) self.ID = id end
		DButton.GetID = function( self ) return self.ID end

		DButton.SetItem = function( self, item ) self.Item = LSCS:ClassToItem( item ) self.ClassName = class end
		DButton.GetItem = function( self ) return self.Item end

		DButton:SetItem( class )
		DButton:SetID( index )
		DButton:SetMaterial( "entities/"..class..".png" )

		DButton.Paint = function(self, w, h )
			if not self:IsEnabled() then
				local Col = menu_dim
				surface.SetDrawColor( Col.r, Col.g, Col.b, Col.a )
				surface.DrawRect( 2, 2, w - 4, h - 4 )
				return
			end

			surface.SetMaterial( self:GetMaterial() )
			surface.SetDrawColor( 255,255,255,255 )
			surface.DrawTexturedRect( 2, 2, w - 4, h - 4 )

			DrawButtonClick( self, w, h ) 

			if not self:IsHovered() and not IsValid( self.menu ) then
				local Col = menu_dark

				surface.SetDrawColor( 0,0,0,100 )
				surface.DrawRect( 2, 2, w - 4, h - 4 )

				surface.SetDrawColor( Color(255,255,255,255) )
				surface.SetMaterial(zoom_mat ) 

				local BoxSize = w - 4
				local xPos = 2
				local yPos = 2

				surface.DrawTexturedRectRotated( xPos + BoxSize * 0.25, yPos + BoxSize * 0.25, BoxSize * 0.5, BoxSize * 0.5, 90 )
				surface.DrawTexturedRectRotated( xPos + BoxSize * 0.75, yPos + BoxSize * 0.25, BoxSize * 0.5, BoxSize * 0.5, 0 )
				surface.DrawTexturedRectRotated( xPos + BoxSize * 0.25, yPos + BoxSize * 0.75, BoxSize * 0.5, BoxSize * 0.5, 180 )
				surface.DrawTexturedRectRotated( xPos + BoxSize * 0.75, yPos + BoxSize * 0.75, BoxSize * 0.5, BoxSize * 0.5, 270 )

				surface.SetDrawColor( Col.r, Col.g, Col.b, Col.a )
				surface.DrawRect( 4, h - 24, w-8, 20  )
		
				local Item = self:GetItem()
				if Item then
					draw.SimpleText( Item.name.." ["..Item.Type.."]", "LSCS_FONT_SMALL", w * 0.5, h - 8, menu_white_dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM )
				else
					draw.SimpleText( self.ClassName, "LSCS_FONT_SMALL", w * 0.5, h - 8, menu_white_dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM )
				end

				local eq = ply:lscsGetEquipped()[ self:GetID() ] 
				if isbool( eq ) then
					surface.SetDrawColor( 255, 191, 0, 255 )
					DrawFrame( w, h, 2, 2 )

					if Item and (Item.type == "hilt" or Item.type == "crystal") then
						if eq == true then
							surface.SetMaterial( icon_rhand )
						else
							surface.SetMaterial( icon_lhand )
						end
					else
						surface.SetMaterial( icon_hand )
					end
					surface.DrawTexturedRect( 4, 4, 64, 64 )

				end
			else
				local Col = menu_light

				surface.SetDrawColor( Col.r, Col.g, Col.b, Col.a )
				surface.DrawRect( 4, h - 24, w-8, 20  )

				local Item = self:GetItem()
				if Item then
					draw.SimpleText( Item.name.." ["..Item.Type.."]", "LSCS_FONT_SMALL", w * 0.5, h - 8, menu_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM )
				else
					draw.SimpleText( self.ClassName, "LSCS_FONT_SMALL", w * 0.5, h - 8, menu_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM )
				end

				Col = menu_text

				if IsValid( self.menu ) then
					surface.SetDrawColor( Col.r, Col.g, Col.b, Col.a )
					DrawFrame( w, h, 2, 2 )
					if isbool( ply:lscsGetEquipped()[ self:GetID() ] ) then
						surface.SetDrawColor( 255, 191, 0, 255 )
						DrawFrame( w, h, 4, 2 )
					end
				else
					if isbool( ply:lscsGetEquipped()[ self:GetID() ] ) then
						surface.SetDrawColor( 255, 191, 0, 255 )
						DrawFrame( w, h, 2, 2 )
					else
						if self:IsHovered() then
							surface.SetDrawColor( Color(255,255,255,255) )
							DrawFrame( w, h, 2, 2 )
						end
					end
				end
			end
		end
		DButton.DoClick = function( self )
			BaseButtonClick( self )

			self.menu = DermaMenu()

			if isbool( ply:lscsGetEquipped()[ self:GetID() ] ) then
				self.menu:AddOption( "Unequip", function()
					if not self.GetItem then return end -- what happened ?

					local Item = self:GetItem()

					if not Item then return end

					if Item.type == "hilt" or Item.type == "crystal" then
						ply:lscsEquipItem( self:GetID(), nil )
						ply:lscsCraftSaber()
					else
						ply:lscsEquipItem( self:GetID(), nil )
					end
				end )
			else
				self.menu:AddOption( "Equip", function()
					if not self.GetItem then return end -- what happened ?

					local Item = self:GetItem()

					if not Item then return end

					if Item.type == "hilt" then
						ply:lscsClearEquipped( "hilt" )
					end

					if Item.type == "crystal" then
						ply:lscsClearEquipped( "crystal" )
					end

					ply:lscsEquipItem( self:GetID(), true )

					if Item.type =="hilt" or Item.type == "crystal" then
						local A, _ = ply:lscsGetHilt()
						local B, _ = ply:lscsGetBlade()
						if A and A ~= "" and B and B ~= "" then
							ply:lscsCraftSaber()
						end
					end
				end )
			end
			self.menu:AddOption( "Drop", function() ply:lscsDropItem( self:GetID() ) self:SetEnabled( false ) end )
			self.menu:Open()
		end
		DButton.DoRightClick = function( self )
		end

		X = X + 128
		if X > (PanelSizeX - 128) then
			X = 8
			Y = Y + 128
		end
	end

	while Y < (PanelSizeY - 128) or X < (PanelSizeX - 128) do
		local Panel = vgui.Create( "DPanel", DScrollPanel )
		Panel:SetPos( X, Y )
		Panel:SetSize( 128, 128 )
		Panel.Paint = function(self, w, h )
			local Col = menu_dim
			surface.SetDrawColor( Col.r, Col.g, Col.b, Col.a )
			surface.DrawRect( 2, 2, w - 4, h - 4 )
		end

		X = X + 128
		if X > (PanelSizeX - 128) then
			if Y < (PanelSizeY - 128) then
				X = 8
			end
			Y = Y + 128
		end
	end

	LSCS:SetActivePanel( Panel )
	LSCS:SideBar( Frame )

	Frame.ID = 2
end

local CrafterButtonPaint = function(self, w, h )
	if self.Item then
		if not self.Mat then
			if file.Exists( "materials/entities/"..self.Item.class..".png", "GAME" ) then
				self.Mat = Material( "entities/"..self.Item.class..".png" )
			else
				self.Mat = Material( "debug/debugwireframe" )
			end
		end

		surface.SetMaterial( self.Mat )
		surface.SetDrawColor( 255, 255, 255 ,255 )
		surface.DrawTexturedRect( 2, h * 0.5 - w * 0.5 - 2, w - 4, w - 4 )

		local IsMainHovered = IsValid(self.Main) and self.Main:IsHovered()
		if self:IsHovered() or IsValid( self.menu ) or IsMainHovered then
			Col = menu_light

			surface.SetDrawColor( Col.r, Col.g, Col.b, Col.a )
			surface.DrawRect( 4, h - 24, w-8, 20  )

			draw.SimpleText( self.Item.name, "LSCS_FONT_SMALL", w * 0.5, h - 8, menu_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM )
		else
			surface.SetDrawColor( Color(255,255,255,255) )
			surface.SetMaterial(zoom_mat ) 
			local BoxSizeX = w - 4
			local BoxSizeY = h - 4
			local xPos = 2
			local yPos = 2

			surface.DrawTexturedRectRotated( xPos + BoxSizeX * 0.25, yPos + BoxSizeY * 0.25, BoxSizeY * 0.5, BoxSizeX * 0.5, 90 )
			surface.DrawTexturedRectRotated( xPos + BoxSizeX * 0.75, yPos + BoxSizeY * 0.25, BoxSizeX * 0.5, BoxSizeY * 0.5, 0 )
			surface.DrawTexturedRectRotated( xPos + BoxSizeX * 0.25, yPos + BoxSizeY * 0.75, BoxSizeX * 0.5, BoxSizeY * 0.5, 180 )
			surface.DrawTexturedRectRotated( xPos + BoxSizeX * 0.75, yPos + BoxSizeY * 0.75, BoxSizeY * 0.5, BoxSizeX * 0.5, 270 )

			Col = menu_dark
			surface.SetDrawColor( Col.r, Col.g, Col.b, Col.a )
			surface.DrawRect( 4, h - 24, w-8, 20  )
	
			draw.SimpleText( self.Item.name, "LSCS_FONT_SMALL", w * 0.5, h - 8, menu_white_dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM )
		end

		local Col = DrawButtonClick( self, w, h )
		
		if IsMainHovered then
			Col = menu_white
		end

		surface.SetDrawColor( Col.r, Col.g, Col.b, Col.a )
		DrawFrame( w, h, 0, 2 )


		local Col = menu_text
		if IsValid( self.menu ) then
			surface.SetDrawColor( Col.r, Col.g, Col.b, Col.a )
			DrawFrame( w, h, 0, 2 )
		end
	else
		local Col = menu_dark
		surface.SetDrawColor( Col.r, Col.g, Col.b, Col.a )
		surface.DrawRect( 0, 0, w, h )

		Col = DrawButtonClick( self, w, h )

		surface.SetMaterial( icon_cross )

		if self:IsHovered() then
			Col = Color(255,0,0,255)
		end
		if IsValid( self.menu ) then
			Col = menu_white
		end

		surface.SetDrawColor( Col.r, Col.g, Col.b, Col.a )

		surface.DrawTexturedRect( 32, 32, 64, 64 )

		DrawFrame( w, h, 0, 2 )

		draw.SimpleText( self.InfoText, "LSCS_FONT", w * 0.5, h - 8, Col, TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM )

		if IsValid( self.menu ) then
			Col = menu_text
			surface.SetDrawColor( Col.r, Col.g, Col.b, Col.a )
			DrawFrame( w, h, 0, 2 )
		end
	end
end

function LSCS:BuildSkills( Frame )
    local ply = LocalPlayer()
    
	// Main Panel
    local Panel = vgui.Create("DPanel", Frame)
    Panel:SetPos(PanelPosX, PanelPosY)
    Panel:SetSize(PanelSizeX, PanelSizeY + FrameBarHeight)
    Panel.Paint = function(self, w, h)
        surface.SetMaterial(ClickMat)
        surface.SetDrawColor(150, 150, 150, 150)
        local X, Y = self:CursorPos()
        surface.DrawTexturedRectRotated(X, Y, 512, 512, 0)
        
        draw.RoundedBoxEx(8, 4, 4, w - 8, h - 8, menu_dim, false, false, false, true)
    end
    
	// XP Math Calculations
	local xp_req = 0
	local currentXP = ply:GetNWInt("KC_EXP", 0)
	local currentLevel = KyberCore:GetLevel(ply)
	local xpForNextLevel, xpForCurrentLevel

    if KyberCore.Config.FixedLeveling then
        xpForNextLevel = KyberCore.Config.FixedXP * currentLevel
        xpForCurrentLevel = KyberCore.Config.FixedXP * (currentLevel - 1)
    else
        xpForNextLevel = KyberCore:CalculateXPForLevel(currentLevel)
        xpForCurrentLevel = KyberCore:CalculateXPForLevel(currentLevel - 1)
    end

    local xpThisLevel = currentXP - xpForCurrentLevel
    local xpNeeded = xpForNextLevel - xpForCurrentLevel
    local xp_to_next = xpNeeded - xpThisLevel

    local Header = vgui.Create("DPanel", Panel)
    Header:SetSize(0, 50)
    Header:Dock(TOP)
    Header:DockMargin(8, 8, 8, 0)
    Header.Paint = function(self, w, h)
        local Col = menu_dark
        surface.SetDrawColor(Col.r, Col.g, Col.b, Col.a)
        surface.DrawRect(0, 0, w, h)
		local currentPoints = ply:GetNWInt("KC_EXP_POINTS", 0)

        draw.SimpleText("Skill Points: " .. currentPoints, "LSCS_FONT", 16, h/2, menu_text, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

		draw.SimpleText("XP: " .. xpThisLevel .. " / " .. xpNeeded .. " (Next Level: " .. xp_to_next .. ")", "LSCS_FONT", w - 16, h/2, menu_text, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
    end
    
	// Tab Container
    local TabContainer = vgui.Create("DPanel", Panel)
    TabContainer:SetSize(0, 40)
    TabContainer:Dock(TOP)
    TabContainer:DockMargin(8, 8, 8, 0)
    TabContainer.Paint = function(self, w, h)
        local Col = menu_dark
        surface.SetDrawColor(Col.r, Col.g, Col.b, Col.a)
        surface.DrawRect(0, 0, w, h)
    end
    
	// Scrolling stuff!
    local btnScrollLeft = vgui.Create("DButton", TabContainer)
    btnScrollLeft:SetText("")
    btnScrollLeft:SetSize(24, 40)
    btnScrollLeft:Dock(LEFT)
    btnScrollLeft.Paint = function(self, w, h)
        local Col = self:IsHovered() and menu_text or menu_light
        surface.SetDrawColor(Col.r, Col.g, Col.b, Col.a)
        surface.DrawRect(0, 0, w, h)
        draw.SimpleText("◀", "LSCS_FONT", w/2, h/2, menu_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    
    local btnScrollRight = vgui.Create("DButton", TabContainer)
    btnScrollRight:SetText("")
    btnScrollRight:SetSize(24, 40)
    btnScrollRight:Dock(RIGHT)
    btnScrollRight.Paint = function(self, w, h)
        local Col = self:IsHovered() and menu_text or menu_light
        surface.SetDrawColor(Col.r, Col.g, Col.b, Col.a)
        surface.DrawRect(0, 0, w, h)
        draw.SimpleText("▶", "LSCS_FONT", w/2, h/2, menu_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    
    local TabScroller = vgui.Create("DHorizontalScroller", TabContainer)
    TabScroller:Dock(FILL)
    TabScroller:SetOverlap(-1)
    TabScroller.Paint = function(self, w, h) end

	function TabScroller:OnMouseWheeled( dlta )
		self.OffsetX = self.OffsetX + dlta * -90
		self:InvalidateLayout( true )

		GetConVar("kybercore_saved_scroll"):SetInt(self.OffsetX or 0)
	
		return true
	end

	function TabScroller:GetScroll()
		return self.OffsetX or 0
	end
    
	// Default tab
	// Get their current skill tree list.
	local skillTreeList = ply.KyberCore_Whitelists or {}
	local activeTab = next(skillTreeList)

    local tabButtons = {}
    
    local function createTab(id)
        local tab = vgui.Create("DButton")
        tab:SetText("")
        tab:SetSize(90, 40)
        
        tab.Paint = function(self, w, h)
            local isActive = activeTab == id
            local Col = isActive and menu_text or menu_dark
            local textCol = isActive and menu_white or menu_white_dim

			// increase the size of the tabs based on text size
			local textSize = surface.GetTextSize(id)
			w = textSize + 86
			tab:SetSize(w, h)
            
            surface.SetDrawColor(Col.r, Col.g, Col.b, Col.a)
            surface.DrawRect(0, 0, w, h)

			// Get icon!
			local skillTree = KyberCore:GetSkillTree(id)
			local icon = skillTree and skillTree.Image or nil

			// Draw the icon if it exists
			if icon and file.Exists("materials/"..icon, "GAME") then
				surface.SetMaterial(Material(icon))
				surface.SetDrawColor(255, 255, 255, 255)
				surface.DrawTexturedRect(4, 4, 32, 32)
			end
            
            // Add icon later TODO
			draw.SimpleText(id, "LSCS_FONT_SMALL", w/2, h/2, textCol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            
            -- Draw an underline for the active tab
            if isActive then
                surface.SetDrawColor(255, 191, 0, 255)
                surface.DrawRect(0, h-3, w, 3)
            end
        end
        
        tab.DoClick = function()
            surface.PlaySound("ui/buttonclick.wav")
            activeTab = id
			GetConVar("kybercore_selected_tree"):SetString(id)
        end
        
        TabScroller:AddPanel(tab)
        tabButtons[id] = tab
        return tab
    end

	local whitelistings = LocalPlayer().KyberCore_Whitelists

    -- Create tabs for all skill trees
	if whitelistings then
		// Sort it alphabetically!
		local sortedWhitelistings = {}
		for k, v in pairs(whitelistings) do
			if v then
				table.insert(sortedWhitelistings, k)
			end
		end
		table.sort(sortedWhitelistings, function(a, b) return a < b end)
		for _, id in ipairs(sortedWhitelistings) do
			if KyberCore.SkillTrees[id] then
				createTab(id)
			end
		end
	end

	if GetConVar("kybercore_selected_tree"):GetString() != "" then
		// If we're not whitelisted to this tree, set it to NOTHING!
		if LocalPlayer().KyberCore_Whitelists then
			if not LocalPlayer().KyberCore_Whitelists[GetConVar("kybercore_selected_tree"):GetString()] then
				GetConVar("kybercore_selected_tree"):SetString("")
			end
			activeTab = GetConVar("kybercore_selected_tree"):GetString()
		end
	end
    
	timer.Simple(0, function()
		if GetConVar("kybercore_saved_scroll"):GetInt() != 0 then
			TabScroller:SetScroll(GetConVar("kybercore_saved_scroll"):GetInt())
		end
	end)

    -- Set up scroll button actions
    local scrollAmount = 90 -- Same as tab width
    
    btnScrollLeft.DoClick = function()
		local scroll = TabScroller:GetScroll()
		TabScroller:SetScroll(scroll - scrollAmount)
        surface.PlaySound("ui/buttonrollover.wav")
    end
    
    btnScrollRight.DoClick = function()
		local scroll = TabScroller:GetScroll()
		TabScroller:SetScroll(scroll + scrollAmount)
        surface.PlaySound("ui/buttonrollover.wav")
    end
		
	// Container for skill trees
	local TreeViewContainer = vgui.Create("DPanel", Panel)
	TreeViewContainer:Dock(FILL)
	TreeViewContainer:DockMargin(8, 8, 8, 8)
    TreeViewContainer.Paint = function(self, w, h)
        -- Draw background image for skill tree
        local currentTree = KyberCore.SkillTrees[activeTab]
        if currentTree and currentTree.Image and file.Exists("materials/"..currentTree.Image, "GAME") then
            local backgroundMaterial = Material(currentTree.Image)
            local bgColor = currentTree.BackgroundColor or Color(255, 255, 255)
            local scale = currentTree.BackgroundSize or 1

			local imgAspect = 1

			if backgroundMaterial then
				local w2 = backgroundMaterial:GetInt("$realwidth")
				local h2 = backgroundMaterial:GetInt("$realheight")
				if w2 and h2 then
					if w > 0 and h > 0 then
						imgAspect = w2 / h2
					end
				end
			end
            
			local imgW, imgH
			local containerAspect = w / h

			if containerAspect > imgAspect then
				imgW = h * scale
				imgH = imgW / imgAspect
			else
				imgH = w * scale
				imgW = imgH * imgAspect
			end
            
            -- Center the image
            local xPos = (w - imgW) / 2
            local yPos = (h - imgH) / 2
            
            surface.SetMaterial(backgroundMaterial)
            surface.SetDrawColor(bgColor.r, bgColor.g, bgColor.b, bgColor.a or 255)
            surface.DrawTexturedRect(xPos, yPos, imgW, imgH)
        end
    end


	// Scrolling!
	local btnTreeScrollLeft = vgui.Create("DButton", TreeViewContainer)
	btnTreeScrollLeft:SetText("")
	btnTreeScrollLeft:SetSize(30, 0)
	btnTreeScrollLeft:Dock(LEFT)
	btnTreeScrollLeft.Paint = function(self, w, h)
		local Col = self:IsHovered() and menu_text or menu_light
		surface.SetDrawColor(Col.r, Col.g, Col.b, Col.a)
		surface.DrawRect(0, 0, w, h)
		
		-- Draw left arrow with pulsing effect if scrollable
		local pulse = TreeView and TreeView:GetScroll() > 0 and 
			math.abs(math.sin(CurTime() * 2)) * 50 or 0
			
		draw.SimpleText("◀", "LSCS_FONT", w/2, h/2, 
			Color(255, 255, 255, 200 + pulse), 
			TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end

	local btnTreeScrollRight = vgui.Create("DButton", TreeViewContainer)
	btnTreeScrollRight:SetText("")
	btnTreeScrollRight:SetSize(30, 0)
	btnTreeScrollRight:Dock(RIGHT)
	btnTreeScrollRight.Paint = function(self, w, h)
		local Col = self:IsHovered() and menu_text or menu_light
		surface.SetDrawColor(Col.r, Col.g, Col.b, Col.a)
		surface.DrawRect(0, 0, w, h)
		
		-- Draw right arrow with pulsing effect if scrollable
		local canScrollMore = TreeView and 
			TreeView:GetScroll() < TreeView:GetCanvas():GetWide() - TreeView:GetWide() + 60
		
		local pulse = canScrollMore and math.abs(math.sin(CurTime() * 2)) * 50 or 0
		
		draw.SimpleText("▶", "LSCS_FONT", w/2, h/2, 
			Color(255, 255, 255, 200 + pulse), 
			TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end

	// Actual view
	local TreeView = vgui.Create("DHorizontalScroller", TreeViewContainer)
	TreeView:Dock(FILL)
	TreeView:SetOverlap(-5)
	TreeView:SetMouseInputEnabled(true)

	local SkillCanvas = vgui.Create("DPanel", TreeView)
	SkillCanvas:SetSize(PanelSizeX - 16, PanelSizeY - 140)
	TreeView:AddPanel(SkillCanvas)

	local scrollStep = 200
	btnTreeScrollLeft.DoClick = function()
		TreeView:SetScroll(-scrollStep)
		surface.PlaySound("ui/buttonrollover.wav")
	end

	btnTreeScrollRight.DoClick = function()
		TreeView:SetScroll(scrollStep)
		surface.PlaySound("ui/buttonrollover.wav")
	end

	// Expand canvas size based on the largest x value in the current tree
	local function UpdateCanvasSize()
		local currentTree = KyberCore.SkillTrees[activeTab]
		if not currentTree then return end

		// Go to the Skills part of the tree
		local skills = currentTree.Skills or {}
		if table.IsEmpty(skills) then return end
		
		// Find the largest x value in the current tree
		local maxX = 0
		for _, skill in pairs(skills) do
			if skill.x > maxX then
				maxX = skill.x
			end
		end

		// Set the canvas size based on the largest x value
		SkillCanvas:SetWide(maxX * (PanelSizeX - 16) + 750)
	end

	SkillCanvas.Paint = function(self, w, h)
		surface.SetDrawColor(menu_text.r, menu_text.g, menu_text.b, 80)
		
		local currentTree = KyberCore.SkillTrees[activeTab]
		if not currentTree then return end

		local skills = currentTree.Skills or {}
		if table.IsEmpty(skills) then return end

		// Connectors between skills
        for skillName, skill in pairs(skills) do
            if skill.Unlocks then
                for unlockedName, _ in pairs(skill.Unlocks) do
                    for _, unlockedSkill in pairs(skills) do
                        if unlockedSkill.Name == unlockedName then
                            surface.SetDrawColor(Color(0, 255, 0, 180))
                            DrawBezier(
                                Vector(skill.x * w, skill.y * h, 0),
                                Vector(unlockedSkill.x * w, unlockedSkill.y * h, 0)
                            )
                            break
                        end
                    end
                end
            end

            // Draw Locks (red)
            if skill.Locks then
                for lockedName, _ in pairs(skill.Locks) do
                    for _, lockedSkill in pairs(skills) do
                        if lockedSkill.Name == lockedName then
                            surface.SetDrawColor(255, 0, 0, 180)
                            DrawBezier(
                                Vector(skill.x * w, skill.y * h, 0),
                                Vector(lockedSkill.x * w, lockedSkill.y * h, 0)
                            )
                            break
                        end
                    end
                end
            end

            if skill.Requirements then
                for connectedName, _ in pairs(skill.Requirements) do
                    for _, connectedSkill in pairs(skills) do
                        if connectedSkill.Name == connectedName then
                            local startX = skill.x * w
                            local startY = skill.y * h
                            local endX = connectedSkill.x * w
                            local endY = connectedSkill.y * h

                            // Draw bezier curve for connections
							surface.SetDrawColor(menu_text.r, menu_text.g, menu_text.b, 180)
                            DrawBezier(
                                Vector(startX, startY, 0), 
                                Vector(endX, endY, 0)
                            )

                            break
                        end
                    end
                end
            end
        end
	end
    
    local hoveredSkill = nil

	local function IsSkillOwned(skill)
		// Check if we own the skill
		return KyberCore:HasSkill(LocalPlayer(), skill.Name) or false
	end

	local function IsSkillUnlocked(skill, skillTree)
		// Check if we can unlock the skill
		local isUnlocked, reason = KyberCore:CanUnlockSkill(LocalPlayer(), skill.Name, skillTree)
		if not reason or reason == "" then
			reason = "LOCKED"
		end

		return isUnlocked, reason
	end

	local function CanAffordSkill(skill, skillTree)
		// Check if we can afford the skill
		return KyberCore:CanAffordSkill(LocalPlayer(), skill.Name, skillTree)
	end

	local menuClickCooldown = 0
    
    -- Function to create skill nodes
    local function CreateSkillNodes()
		UpdateCanvasSize()

		TreeView:SetScroll(0)
		
        -- Clear existing nodes
        for _, child in pairs(SkillCanvas:GetChildren()) do
            child:Remove()
        end
        
        local currentTree = KyberCore.SkillTrees[activeTab]
        if not currentTree then return end

		local skills = currentTree.Skills or {}
		if table.IsEmpty(skills) then return end

        for _, skill in pairs(skills) do
            local nodeSize = 64
            local node = vgui.Create("DButton", SkillCanvas)
            node:SetSize(nodeSize, nodeSize)
            
            node:SetText("")
            node:SetTooltip(skill.name)
            
            node.Paint = function(self, w, h)
                local isHovered = self:IsHovered() or hoveredSkill == skill.Name
                local isOwned = IsSkillOwned(skill)
                local isUnlocked, reason = IsSkillUnlocked(skill, currentTree.Name)
                local canAfford = CanAffordSkill(skill, currentTree.Name)
				
                node:SetPos(skill.x * SkillCanvas:GetWide() - nodeSize/2, skill.y * SkillCanvas:GetTall() - nodeSize/2)

                -- Background circle
                local bgColor = menu_dark
                if isOwned then 
                    bgColor = menu_text
                elseif not isUnlocked then
                    bgColor = menu_black
                elseif isHovered and canAfford and not isOwned then
                    bgColor = Color(0, 200, 100, 255) -- Green for available to purchase
                end
                
                draw.RoundedBox(nodeSize/2, 0, 0, w, h, bgColor)
                
                -- Inner circle/icon
                local iconColor = Color(255, 255, 255, isUnlocked and 255 or 100)
                
                -- Draw skill icon
                if skill.Image and file.Exists("materials/"..skill.Image, "GAME") then
                    surface.SetMaterial(Material(skill.Image))
                    surface.SetDrawColor(iconColor)
                    surface.DrawTexturedRect(8, 8, w-16, h-16)
                end
                
                if isHovered and isUnlocked and not isOwned then
                    surface.SetDrawColor(255, 191, 0, 150)
                    surface.DrawOutlinedRect(0, 0, w, h, 2)
                end

                -- -- Lock icon if not unlocked
                -- if not isUnlocked and not isOwned then
                --     -- Draw a lock symbol in the center
                --     surface.SetDrawColor(150, 150, 150, 100)
                --     surface.DrawRect(w/2-8, h/2-8, 16, 16) -- Lock body
                --     surface.DrawRect(w/2-10, h/2-16, 20, 8) -- Lock top
                -- end
                
                -- Cost indicator
                if not isOwned and isUnlocked then
                    local costColor = canAfford and Color(255, 255, 255, 255) or Color(255, 100, 100, 255)
                    draw.SimpleText(skill.Cost, "LSCS_FONT_SMALL", w/2, h-6, costColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                end

				// If we cannot afford the skill, draw a red cross
				if not canAfford and isUnlocked and not isOwned then
					surface.SetMaterial(icon_cross)
					surface.SetDrawColor(255, 0, 0, 255)
					surface.DrawTexturedRect(w/2-8, h/2-8, 16, 16)
				end
                
                -- Small check mark if owned
                if isOwned then
                    surface.SetMaterial(icon_check)
                    surface.SetDrawColor(255, 255, 255, 255)
                    surface.DrawTexturedRect(w-16, 0, 16, 16)
                end
            end
            
            -- Handle clicking on skills
            node.DoClick = function()
				// Cooldown!
				if CurTime() < menuClickCooldown then return end
				menuClickCooldown = CurTime() + 0.5

				if IsSkillOwned(skill, currentTree.Name) then
					if KyberCore:RefundSkill(skill.Name, currentTree.Name) then
						surface.PlaySound("ui/buttonclick.wav")
					else
						surface.PlaySound("buttons/button10.wav")
					end
				elseif IsSkillUnlocked(skill, currentTree.Name) then
					if KyberCore:UnlockSkill(skill.Name, currentTree.Name) then
						surface.PlaySound("ui/buttonclick.wav")
					else
						surface.PlaySound("buttons/button10.wav")
					end
				else
					// Not unlocked or not enough points.
					surface.PlaySound("buttons/button10.wav")
				end
            end
            
            -- Mouseover effects to show skill info
            node.OnCursorEntered = function()
                hoveredSkill = skill.Name
                surface.PlaySound("ui/buttonrollover.wav")
            end
            
            node.OnCursorExited = function()
                hoveredSkill = nil
            end
        end
    end
    
    -- Skill info panel (shows when hovering over a skill)
    local InfoPanel = vgui.Create("DPanel", Panel)
    InfoPanel:SetSize(0, 120)
    InfoPanel:Dock(BOTTOM)
    InfoPanel:DockMargin(8, 0, 8, 8)
    InfoPanel.Paint = function(self, w, h)
        local Col = menu_dark
        surface.SetDrawColor(Col.r, Col.g, Col.b, Col.a)
        surface.DrawRect(0, 0, w, h)
        
        if hoveredSkill then
            local currentTree = KyberCore.SkillTrees[activeTab]
            if not currentTree then return end

			local skills = currentTree.Skills or {}
			if table.IsEmpty(skills) then return end
            
            -- Find the hovered skill
            for _, skill in pairs(skills) do
                if skill.Name == hoveredSkill then
				    local currentPoints = ply:GetNWInt("KC_EXP_POINTS", 0)

                    -- Draw skill information
                    draw.SimpleText(skill.Name, "LSCS_FONT", 16, 16, menu_text, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)

					local isUnlocked, reason = IsSkillUnlocked(skill, currentTree.Name)
                    
                    -- Status text
                    local status = ""
                    if IsSkillOwned(skill) then
                        status = "LEARNED"
                    elseif not isUnlocked then
						status = reason
                    elseif currentPoints < skill.Cost then
                        status = "NOT ENOUGH POINTS"
                    else
                        status = "AVAILABLE - " .. skill.Cost .. " POINTS"
                    end

					-- Unlocks or Locks text
					if skill.Unlocks and not table.IsEmpty(skill.Unlocks) then
						status = status .. " (UNLOCKS: "
						for unlockedName, _ in pairs(skill.Unlocks) do
							status = status .. unlockedName .. ", "
						end
						status = status:sub(1, -3) .. ")"
					end

					if skill.Locks and not table.IsEmpty(skill.Locks) then
						status = status .. " (LOCKS: "
						for lockedName, _ in pairs(skill.Locks) do
							status = status .. lockedName .. ", "
						end
						status = status:sub(1, -3) .. ")"
					end
                    
                    draw.SimpleText(status, "LSCS_FONT_SMALL", w-16, 16, menu_white_dim, TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)
                    
                    -- Draw multiline description
                    local desc = skill.Description
                    local wrap = 80
                    local y = 40
                    
                    for i = 1, #desc, wrap do
                        local substring = desc:sub(i, i + wrap - 1)
                        draw.SimpleText(substring, "LSCS_FONT_SMALL", 16, y, menu_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
                        y = y + 16
                    end
                    
                    break
                end
            end
        else
            -- Default text when no skill is hovered
            draw.SimpleText("Hover over a skill to view details", "LSCS_FONT", w/2, h/2, menu_white_dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
    end
    
    -- Create nodes initially and when tab changes
    CreateSkillNodes()
    
    -- Update nodes when the tab changes
    Panel.Think = function()
        local lastTab = Panel.lastTab or ""
        if lastTab ~= activeTab then
            CreateSkillNodes()
            Panel.lastTab = activeTab
        end
    end
    
    LSCS:SetActivePanel(Panel)
    LSCS:SideBar(Frame)
    
    Frame.ID = 2
end

function LSCS:ReloadSkillMenu()
	if not IsValid( Frame ) then return end
	if Frame.ID != 2 then return end
	LSCS:BuildSkills( Frame )
end

function LSCS:BuildSaberMenu( Frame )
	local ply = LocalPlayer()
	local HiltR, HiltL = ply:lscsGetHilt()
	local BladeR, BladeL = ply:lscsGetBlade()

	local AAA = 55
	local LHHeight = 195
	// Exact X between AAA and LHHeight
	local Between = (LHHeight - AAA) / 2 + 50
	local ExtraSpace = 32

	local Panel = vgui.Create( "DPanel", Frame )
	Panel:SetPos( PanelPosX, FrameBarHeight )
	-- Panel:SetSize( PanelSizeX, ( PanelSizeY / 2 ) - FrameBarHeight + PanelPosY + ExtraSpace )
	Panel:SetSize( PanelSizeX, PanelSizeY - FrameBarHeight + ExtraSpace )
	Panel.Paint = function(self, w, h )
		surface.SetMaterial( ClickMat )
		surface.SetDrawColor( 150,150,150,150 )
		local X, Y = self:CursorPos()
		surface.DrawTexturedRectRotated( X, Y, 512, 512, 0 )

		draw.RoundedBoxEx( 8, 4, 4, w - 8, h - 8, menu_dim, false, false, false, true )

		draw.SimpleText( "Information", "LSCS_FONT", 8, 14, menu_text, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER )
		draw.SimpleText( "NOTE: For this to work you need a Hilt and a Blade-Crystal in your Inventory and you must have permission to spawn SWEP's", "LSCS_FONT_SMALL", 8, 30, menu_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER )

		if IsValid( self.Main ) and self.Main:IsHovered() then
			local Col = menu_white_dim
			if HiltR and BladeR then
				Col = menu_white
			end
			surface.SetDrawColor( Col.r, Col.g, Col.b, Col.a )
			DrawBezier( Vector(PanelSizeX - 125, Between + 50, 0), Vector(PanelSizeX * 0.5 + 64, 64 + AAA, 0 ) )
			surface.DrawLine( 163, 64 + AAA, PanelSizeX * 0.5 - 64, 64 + AAA )
			Col = menu_white_dim
			if HiltL and BladeL then
				Col = menu_white
			end
			surface.SetDrawColor( Col.r, Col.g, Col.b, Col.a )
			DrawBezier( Vector(PanelSizeX - 125, Between + 50, 0), Vector(PanelSizeX * 0.5 + 64, 64 + LHHeight) )
			surface.DrawLine( 163, 64 + LHHeight, PanelSizeX * 0.5 - 64, 64 + LHHeight )
		else
			local Col = menu_white_dim
			surface.SetDrawColor( Col.r, Col.g, Col.b, Col.a )
			DrawBezier( Vector(PanelSizeX - 125, Between + 50, 0), Vector(PanelSizeX * 0.5 + 64, 64 + AAA, 0 ) )
			surface.DrawLine( 163, 64 + AAA, PanelSizeX * 0.5 - 64, 64 + AAA )
			DrawBezier( Vector(PanelSizeX - 125, Between + 50, 0), Vector(PanelSizeX * 0.5 + 64, 64 + LHHeight) )
			surface.DrawLine( 163, 64 + LHHeight, PanelSizeX * 0.5 - 64, 64 + LHHeight )
		end
	end

	local Main = vgui.Create( "DButton", Panel )
	Main:SetText( "" )
	Main:SetPos( PanelSizeX - 125, Between )
	Main:SetSize( 100, 100 )
	Main.Paint = function(self, w, h )
		local Col = menu_dark
		surface.SetDrawColor( Col.r, Col.g, Col.b, Col.a )
		surface.DrawRect( 0, 0, w, h )

		Col = DrawButtonClick( self, w, h )
		local Col2 = Col

		surface.SetMaterial( icon_check )
		if self:IsHovered() then
			Col2 = Color(0,255,0)
		end
		surface.SetDrawColor( Col2.r, Col2.g, Col2.b, Col2.a )
		surface.DrawTexturedRect( 18, 18, w - 36, h - 36 )

		surface.SetDrawColor( Col.r, Col.g, Col.b, Col.a )
		DrawFrame( w, h, 0, 2 )
	end
	Main.DoClick = function( self )
		BaseButtonClick( self )
		ply:lscsCraftSaber()
		Frame:Remove()
	end
	Panel.Main = Main

	-- RIGHT
	local ButtonHilt = vgui.Create( "DButton", Panel )
	ButtonHilt.InfoText = "Hilt [RH]"
	ButtonHilt:SetText( "" )
	ButtonHilt:SetPos( PanelSizeX * 0.5 - 64, AAA )
	ButtonHilt:SetSize( 128, 128 )
	ButtonHilt.Item = LSCS:GetHilt( HiltR )
	ButtonHilt.Paint = CrafterButtonPaint
	ButtonHilt.DoClick = function( self )
		BaseButtonClick( self )
		if self.Item then
			self.menu = DermaMenu()
			self.menu:AddOption( "Unequip", function()
				ply:lscsClearEquipped( "hilt", true )
				ply:lscsCraftSaber()
			end )
			self.menu:Open()
		else
			self.menu = DermaMenu()
			local Num = 0
			for k, v in pairs( ply:lscsGetInventory() ) do
				if isbool( ply:lscsGetEquipped()[ k ] ) then continue end

				local item = LSCS:ClassToItem( v )
				if item.type == "hilt" then
					Num = Num + 1
					self.menu:AddOption( item.name, function()
						ply:lscsEquipItem( k, true )
					end )
				end
			end
			if Num >= 1 then
				self.menu:Open()
			else
				surface.PlaySound("buttons/button10.wav")
				self.menu:Remove()
			end
		end
	end
	ButtonHilt.Main = Main

	local ButtonBlade = vgui.Create( "DButton", Panel )
	ButtonBlade.InfoText = "Crystal [RH]"
	ButtonBlade:SetText( "" )
	ButtonBlade:SetPos( 35, AAA )
	ButtonBlade:SetSize( 128, 128 )
	ButtonBlade.Item = LSCS:GetBlade( BladeR )
	ButtonBlade.Paint = CrafterButtonPaint
	ButtonBlade.DoClick = function( self )
		BaseButtonClick( self )

		if self.Item then
			self.menu = DermaMenu()
			self.menu:AddOption( "Unequip", function()
				ply:lscsClearEquipped( "crystal", true )
				ply:lscsCraftSaber()
			end )
			self.menu:Open()
		else
			self.menu = DermaMenu()
			local Num = 0
			for k, v in pairs( ply:lscsGetInventory() ) do
				if isbool( ply:lscsGetEquipped()[ k ] ) then continue end

				local item = LSCS:ClassToItem( v )
				if item.type == "crystal" then
					Num = Num + 1
					self.menu:AddOption( item.name, function()
						ply:lscsEquipItem( k, true )
					end )
				end
			end
			if Num >= 1 then
				self.menu:Open()
			else
				surface.PlaySound("buttons/button10.wav")
				self.menu:Remove()
			end
		end
	end
	ButtonBlade.Main = Main

	-- LEFT
	local ButtonHilt = vgui.Create( "DButton", Panel )
	ButtonHilt.InfoText = "Hilt [LH]"
	ButtonHilt:SetText( "" )
	ButtonHilt:SetPos( PanelSizeX * 0.5 - 64, LHHeight )
	ButtonHilt:SetSize( 128, 128 )
	ButtonHilt.Item = LSCS:GetHilt( HiltL )
	ButtonHilt.Paint = CrafterButtonPaint
	ButtonHilt.DoClick = function( self )
		BaseButtonClick( self )
		if self.Item then
			self.menu = DermaMenu()
			self.menu:AddOption( "Unequip", function()
				ply:lscsClearEquipped( "hilt", false )
				ply:lscsCraftSaber()
			end )
			self.menu:Open()
		else
			self.menu = DermaMenu()
			local Num = 0
			for k, v in pairs( ply:lscsGetInventory() ) do
				if isbool( ply:lscsGetEquipped()[ k ] ) then continue end

				local item = LSCS:ClassToItem( v )

				if not item then continue end

				if item.type == "hilt" then
					Num = Num + 1
					self.menu:AddOption( item.name, function()
						ply:lscsEquipItem( k, false )
					end )
				end
			end
			if Num >= 1 then
				self.menu:Open()
			else
				surface.PlaySound("buttons/button10.wav")
				self.menu:Remove()
			end
		end
	end
	ButtonHilt.Main = Main

	local ButtonBlade = vgui.Create( "DButton", Panel )
	ButtonBlade.InfoText = "Crystal [LH]"
	ButtonBlade:SetText( "" )
	ButtonBlade:SetPos( 35, LHHeight )
	ButtonBlade:SetSize( 128, 128 )
	ButtonBlade.Item = LSCS:GetBlade( BladeL )
	ButtonBlade.Paint = CrafterButtonPaint
	ButtonBlade.DoClick = function( self )
		BaseButtonClick( self )
		if self.Item then
			self.menu = DermaMenu()
			self.menu:AddOption( "Unequip", function()
				ply:lscsClearEquipped( "crystal", false )
				ply:lscsCraftSaber()
			end )
			self.menu:Open()
		else
			self.menu = DermaMenu()
			local Num = 0
			for k, v in pairs( ply:lscsGetInventory() ) do
				if isbool( ply:lscsGetEquipped()[ k ] ) then continue end

				local item = LSCS:ClassToItem( v )

				if not item then continue end

				if item.type == "crystal" then
					Num = Num + 1
					self.menu:AddOption( item.name, function()
						ply:lscsEquipItem( k, false )
					end )
				end
			end
			if Num >= 1 then
				self.menu:Open()
			else
				surface.PlaySound("buttons/button10.wav")
				self.menu:Remove()
			end
		end
	end
	ButtonBlade.Main = Main

	// Put InventoryPanel under the saber panel!
	local InventoryPanel = vgui.Create( "DPanel", Panel )
	InventoryPanel:SetPos( 0, ( PanelSizeY / 2 ) + FrameBarHeight )
	InventoryPanel:SetSize( PanelSizeX, ( PanelSizeY / 2 ) - FrameBarHeight )
	InventoryPanel.Paint = function(self, w, h )
		surface.SetMaterial( ClickMat )
		surface.SetDrawColor( 255, 255, 255, 255 )
		local X, Y = self:CursorPos()
		surface.DrawTexturedRectRotated( X, Y, 512, 512, 0 )

		draw.RoundedBoxEx( 8, 4, 4, w - 8, h + 4, menu_dim, false, false, false, true )

		local Col = menu_light
		surface.SetDrawColor( Col.r, Col.g, Col.b, 240 )
		surface.DrawRect( 0, 0, w, h  )
	end

	local ToolBar = vgui.Create( "DPanel", InventoryPanel )
	ToolBar:SetHeight(40)
	ToolBar:Dock( BOTTOM )
	ToolBar:DockMargin( 10, 4, 24, 10 )
	ToolBar.Paint = function(self, w, h )
		local Col = menu_dim

		surface.SetDrawColor( Col.r, Col.g, Col.b, Col.a )
		surface.DrawRect( 0, 0, w, h )
	end

	local Refresh = vgui.Create( "DButton", ToolBar )
	Refresh:SetText("")
	Refresh:SetSize( 130, 100 )
	Refresh:Dock( RIGHT )
	Refresh:DockMargin( 4, 4, 4, 4 )
	Refresh.Paint = function(self, w, h )
		local Col = DrawButtonClick( self, w, h )

		draw.SimpleText( "REFRESH", "LSCS_FONT", w * 0.5, h * 0.5, Col, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )

		surface.SetDrawColor( Col.r, Col.g, Col.b, Col.a )

		DrawFrame( w, h, 0, 2 )
	end
	Refresh.DoClick = function( self )
		BaseButtonClick( self )
		self:SetEnabled( false )

		timer.Simple( 0.2, function()
			if not IsValid( self ) then return end
			self:SetEnabled( true )
			net.Start("KyberCore.InventoryRefresh")
			net.SendToServer()
		end )
	end

	local DropAll = vgui.Create( "DButton", ToolBar )
	DropAll:SetText("")
	DropAll:SetSize( 180, 100 )
	DropAll:Dock( LEFT )
	DropAll:DockMargin( 4, 4, 4, 4 )
	DropAll.SafetyEnabled = 1
	DropAll.Paint = function(self, w, h )
		local Col = DrawButtonClick( self, w, h )

		if self.SafetyEnabled == 1 then
			draw.SimpleText( "DROP ALL", "LSCS_FONT", w * 0.5, h * 0.5, Col, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
		elseif self.SafetyEnabled == 2 then
			draw.SimpleText( "ARE YOU SURE??", "LSCS_FONT", w * 0.5, h * 0.5, Col, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
		else
			Col = Color(255, 0, 0, 255)
			surface.SetMaterial( ClickMat )
			surface.SetDrawColor( 150, 0, 0, 255 )
			surface.DrawTexturedRect( 0, 0, w, h )

			draw.SimpleText( "!!DROP ALL!!", "LSCS_FONT", w * 0.5, h * 0.5, Col, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
		end

		surface.SetDrawColor( Col.r, Col.g, Col.b, Col.a )

		DrawFrame( w, h, 0, 2 )
	end
	DropAll.DoClick = function( self )
		BaseButtonClick( self )

		if self.SafetyEnabled < 3 then
			self:SetEnabled( false )

			timer.Simple( 1, function()
				if not IsValid( self ) then return end
				self:SetEnabled( true )
				self.SafetyEnabled = self.SafetyEnabled + 1
			end )
		else
			self:SetEnabled( false )

			net.Start("lscs_inventory_refresh")
				net.WriteBool( true )
				net.WriteBool( false )
			net.SendToServer()
		end
	end

	local DropUnEq = vgui.Create( "DButton", ToolBar )
	DropUnEq:SetText("")
	DropUnEq:SetSize( 240, 100 )
	DropUnEq:Dock( LEFT )
	DropUnEq:DockMargin( 4, 4, 4, 4 )
	DropUnEq.SafetyEnabled = 1
	DropUnEq.Paint = function(self, w, h )
		local Col = DrawButtonClick( self, w, h )

		if self.SafetyEnabled == 1 then
			draw.SimpleText( "DROP UNEQUIPPED", "LSCS_FONT", w * 0.5, h * 0.5, Col, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
		elseif self.SafetyEnabled == 2 then
			draw.SimpleText( "ARE YOU SURE??", "LSCS_FONT", w * 0.5, h * 0.5, Col, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
		else
			Col = Color(255, 0, 0, 255)
			surface.SetMaterial( ClickMat )
			surface.SetDrawColor( 150, 0, 0, 255 )
			surface.DrawTexturedRect( 0, 0, w, h )

			draw.SimpleText( "!!DROP UNEQUIPPED!!", "LSCS_FONT", w * 0.5, h * 0.5, Col, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
		end

		surface.SetDrawColor( Col.r, Col.g, Col.b, Col.a )

		DrawFrame( w, h, 0, 2 )
	end
	DropUnEq.DoClick = function( self )
		BaseButtonClick( self )

		if self.SafetyEnabled < 3 then
			self:SetEnabled( false )

			timer.Simple( 1, function()
				if not IsValid( self ) then return end
				self:SetEnabled( true )
				self.SafetyEnabled = self.SafetyEnabled + 1
			end )
		else
			self:SetEnabled( false )

			net.Start("lscs_inventory_refresh")
				net.WriteBool( true )
				net.WriteBool( true )
			net.SendToServer()
		end
	end

	local DScrollPanel = vgui.Create( "DScrollPanel", InventoryPanel )
	DScrollPanel:SetSize( PanelSizeX, ( PanelSizeY / 2 ) + FrameBarHeight )
	DScrollPanel:Dock( FILL )
	DScrollPanel:DockMargin( 4, 4, 4, 4 )

	local Inventory = ply:lscsGetInventory()

	local X = 8
	local Y = 8
	for index, class in pairs( Inventory ) do
		local DButton = vgui.Create( "DButton", DScrollPanel )
		DButton:SetText( "" )
		DButton:SetPos( X, Y )
		DButton:SetSize( 128, 128 )

		DButton.SetMaterial = function( self, mat ) 
			if file.Exists( "materials/"..mat, "GAME" ) then
				self.Mat = Material( mat )
			else
				self.Mat = Material( "debug/debugwireframe" )
			end
		end
		DButton.GetMaterial = function( self ) return self.Mat end

		DButton.SetID = function( self, id ) self.ID = id end
		DButton.GetID = function( self ) return self.ID end

		DButton.SetItem = function( self, item ) self.Item = LSCS:ClassToItem( item ) self.ClassName = class end
		DButton.GetItem = function( self ) return self.Item end

		DButton:SetItem( class )
		DButton:SetID( index )
		DButton:SetMaterial( "entities/"..class..".png" )

		DButton.Paint = function(self, w, h )
			if not self:IsEnabled() then
				local Col = menu_dim
				surface.SetDrawColor( Col.r, Col.g, Col.b, Col.a )
				surface.DrawRect( 2, 2, w - 4, h - 4 )
				return
			end

			surface.SetMaterial( self:GetMaterial() )
			surface.SetDrawColor( 255,255,255,255 )
			surface.DrawTexturedRect( 2, 2, w - 4, h - 4 )

			DrawButtonClick( self, w, h ) 

			if not self:IsHovered() and not IsValid( self.menu ) then
				local Col = menu_dark

				surface.SetDrawColor( 0,0,0,100 )
				surface.DrawRect( 2, 2, w - 4, h - 4 )

				surface.SetDrawColor( Color(255,255,255,255) )
				surface.SetMaterial(zoom_mat ) 

				local BoxSize = w - 4
				local xPos = 2
				local yPos = 2

				surface.DrawTexturedRectRotated( xPos + BoxSize * 0.25, yPos + BoxSize * 0.25, BoxSize * 0.5, BoxSize * 0.5, 90 )
				surface.DrawTexturedRectRotated( xPos + BoxSize * 0.75, yPos + BoxSize * 0.25, BoxSize * 0.5, BoxSize * 0.5, 0 )
				surface.DrawTexturedRectRotated( xPos + BoxSize * 0.25, yPos + BoxSize * 0.75, BoxSize * 0.5, BoxSize * 0.5, 180 )
				surface.DrawTexturedRectRotated( xPos + BoxSize * 0.75, yPos + BoxSize * 0.75, BoxSize * 0.5, BoxSize * 0.5, 270 )

				surface.SetDrawColor( Col.r, Col.g, Col.b, Col.a )
				surface.DrawRect( 4, h - 24, w-8, 20  )
		
				local Item = self:GetItem()
				if Item then
					draw.SimpleText( Item.name.." ["..Item.Type.."]", "LSCS_FONT_SMALL", w * 0.5, h - 8, menu_white_dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM )
				else
					draw.SimpleText( self.ClassName, "LSCS_FONT_SMALL", w * 0.5, h - 8, menu_white_dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM )
				end

				local eq = ply:lscsGetEquipped()[ self:GetID() ] 
				if isbool( eq ) then
					surface.SetDrawColor( 255, 191, 0, 255 )
					DrawFrame( w, h, 2, 2 )

					if Item and (Item.type == "hilt" or Item.type == "crystal") then
						if eq == true then
							surface.SetMaterial( icon_rhand )
						else
							surface.SetMaterial( icon_lhand )
						end
					else
						surface.SetMaterial( icon_hand )
					end
					surface.DrawTexturedRect( 4, 4, 64, 64 )

				end
			else
				local Col = menu_light

				surface.SetDrawColor( Col.r, Col.g, Col.b, Col.a )
				surface.DrawRect( 4, h - 24, w-8, 20  )

				local Item = self:GetItem()
				if Item then
					draw.SimpleText( Item.name.." ["..Item.Type.."]", "LSCS_FONT_SMALL", w * 0.5, h - 8, menu_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM )
				else
					draw.SimpleText( self.ClassName, "LSCS_FONT_SMALL", w * 0.5, h - 8, menu_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM )
				end

				Col = menu_text

				if IsValid( self.menu ) then
					surface.SetDrawColor( Col.r, Col.g, Col.b, Col.a )
					DrawFrame( w, h, 2, 2 )
					if isbool( ply:lscsGetEquipped()[ self:GetID() ] ) then
						surface.SetDrawColor( 255, 191, 0, 255 )
						DrawFrame( w, h, 4, 2 )
					end
				else
					if isbool( ply:lscsGetEquipped()[ self:GetID() ] ) then
						surface.SetDrawColor( 255, 191, 0, 255 )
						DrawFrame( w, h, 2, 2 )
					else
						if self:IsHovered() then
							surface.SetDrawColor( Color(255,255,255,255) )
							DrawFrame( w, h, 2, 2 )
						end
					end
				end
			end
		end
		DButton.DoClick = function( self )
			BaseButtonClick( self )

			self.menu = DermaMenu()

			if isbool( ply:lscsGetEquipped()[ self:GetID() ] ) then
				self.menu:AddOption( "Unequip", function()
					if not self.GetItem then return end -- what happened ?

					local Item = self:GetItem()

					if not Item then return end

					if Item.type == "hilt" or Item.type == "crystal" then
						ply:lscsEquipItem( self:GetID(), nil )
						ply:lscsCraftSaber()
					else
						ply:lscsEquipItem( self:GetID(), nil )
					end
				end )
			else
				self.menu:AddOption( "Equip", function()
					if not self.GetItem then return end -- what happened ?

					local Item = self:GetItem()

					if not Item then return end

					if Item.type == "hilt" then
						ply:lscsClearEquipped( "hilt" )
					end

					if Item.type == "crystal" then
						ply:lscsClearEquipped( "crystal" )
					end

					ply:lscsEquipItem( self:GetID(), true )

					if Item.type =="hilt" or Item.type == "crystal" then
						local A, _ = ply:lscsGetHilt()
						local B, _ = ply:lscsGetBlade()
						if A and A ~= "" and B and B ~= "" then
							ply:lscsCraftSaber()
						end
					end
				end )
			end
			self.menu:AddOption( "Drop", function() ply:lscsDropItem( self:GetID() ) self:SetEnabled( false ) end )
			self.menu:Open()
		end
		DButton.DoRightClick = function( self )
		end

		X = X + 128
		if X > (PanelSizeX - 128) then
			X = 8
			Y = Y + 128
		end
	end

	-- local HalvedPanel = PanelSizeY / 2
	while Y < (PanelSizeY - 128) or X < (PanelSizeX - 128) do
		local Panel = vgui.Create( "DPanel", DScrollPanel )
		Panel:SetPos( X, Y )
		Panel:SetSize( 128, 128 )
		Panel.Paint = function(self, w, h )
			local Col = menu_dim
			surface.SetDrawColor( Col.r, Col.g, Col.b, Col.a )
			surface.DrawRect( 2, 2, w - 4, h - 4 )
		end

		X = X + 128
		if X > (PanelSizeX - 128) then
			if Y < (PanelSizeY - 128) then
				X = 8
			end
			Y = Y + 128
		end
	end

	LSCS:SetActivePanel( Panel )
	LSCS:SideBar( Frame )

	Frame.ID = 3
end

function LSCS:BuildStanceMenu( Frame )
	local ply = LocalPlayer()

	if StanceNum > #ply:lscsGetCombo() then
		StanceNum = 1
	end

	local combo = ply:lscsGetCombo( StanceNum )

	local ColHead = menu_text
	local ColText = menu_white

	local LastID

	local Panel = vgui.Create( "DPanel", Frame )
	Panel:SetPos( PanelPosX, PanelPosY )
	Panel:SetSize( PanelSizeX, PanelSizeY + FrameBarHeight )
	Panel.Paint = function(self, w, h )
		draw.RoundedBoxEx( 8, 0, 0, w, h, menu_light, false, false, false, true )

		surface.SetMaterial( ClickMat )
		surface.SetDrawColor( 150,150,150,150 )
		local X, Y = self:CursorPos()
		surface.DrawTexturedRectRotated( X, Y, 512, 512, 0 )
	end

	local mdl = vgui.Create( "DModelPanel", Panel )
	mdl:SetSize( 250, 0)
	mdl:Dock( RIGHT )
	mdl:DockMargin( 4, 4, 4, 4 )
	mdl:SetFOV( 30 )
	mdl:SetCamPos( vector_origin )
	mdl:SetDirectionalLight( BOX_RIGHT, Color( 255, 160, 80, 255 ) )
	mdl:SetDirectionalLight( BOX_LEFT, Color( 80, 160, 255, 255 ) )
	mdl:SetAmbientLight( Vector( -64, -64, -64 ) )
	mdl:SetAnimated( true )
	mdl.Angles = angle_zero
	mdl:SetLookAt( Vector( -100, 0, -22 ) )
	mdl:SetModel( ply:GetModel() )
	function mdl.Entity:GetPlayerColor() return ply:GetPlayerColor() end
	mdl.Entity:SetPos( Vector( -100, 0, -61 ) )

	function mdl:DragMousePress()
		self.PressX, self.PressY = gui.MousePos()
		self.Pressed = true
	end

	function mdl:DragMouseRelease() self.Pressed = false end

	function mdl:LayoutEntity( ent )
		if ( self.bAnimated ) then self:RunAnimation() end

		if ( self.Pressed ) then
			local mx = gui.MousePos()
			self.Angles = self.Angles - Angle( 0, ( ( self.PressX or mx ) - mx ) / 2, 0 )

			self.PressX, self.PressY = gui.MousePos()
		end

		ent:SetAngles( self.Angles )
	end

	mdl.Paint = function(self, w, h )
		local Col = menu_dim
		surface.SetDrawColor( Col.r, Col.g, Col.b, Col.a )
		surface.DrawRect( 0, 0, w, h  )
	
		if not IsValid( self.Entity ) then return end

		local x, y = self:LocalToScreen( 0, 0 )

		self:LayoutEntity( self.Entity )

		local ang = self.aLookAngle
		if not ang then
			ang = ( self.vLookatPos - self.vCamPos ):Angle()
		end

		cam.Start3D( self.vCamPos, ang, self.fFOV, x, y, w, h, 5, self.FarZ )

		render.SuppressEngineLighting( true )
		render.SetLightingOrigin( self.Entity:GetPos() )
		render.ResetModelLighting( self.colAmbientLight.r / 255, self.colAmbientLight.g / 255, self.colAmbientLight.b / 255 )
		render.SetColorModulation( self.colColor.r / 255, self.colColor.g / 255, self.colColor.b / 255 )
		render.SetBlend( ( self:GetAlpha() / 255 ) * ( self.colColor.a / 255 ) ) -- * surface.GetAlphaMultiplier()

		for i = 0, 6 do
			local col = self.DirectionalLight[ i ]
			if ( col ) then
				render.SetModelLighting( i, col.r / 255, col.g / 255, col.b / 255 )
			end
		end

		self:DrawModel()

		render.SuppressEngineLighting( false )
		cam.End3D()

		self.LastPaint = RealTime()
	end

	local descriptionHeader = vgui.Create( "DPanel", Panel )
	descriptionHeader:Dock( TOP )
	descriptionHeader:DockMargin( 4, 4, 0, 0 )
	descriptionHeader.Paint = function(self, w, h )
		local Col = menu_dim

		surface.SetDrawColor( Col.r, Col.g, Col.b, Col.a )
		surface.DrawRect( 0, 0, w, h )
		draw.SimpleText( "Information", "LSCS_FONT", w * 0.5, h * 0.5, menu_text, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )

	end

	local SPB = vgui.Create( "DPanel", Panel )
	SPB:SetSize( 0, 280 )
	SPB:Dock( BOTTOM )
	SPB:DockMargin( 4, 4, 0, 4 )
	SPB.Paint = function(self, w, h )
		local Col = menu_dim
		surface.SetDrawColor( Col.r, Col.g, Col.b, Col.a )
		surface.DrawRect( 0, 0, w, h  )
	end

	local DScrollPanel = vgui.Create( "DScrollPanel", SPB )
	DScrollPanel:Dock( FILL )

	local nice_combo = {}

	for index, obj in pairs( combo.Attacks ) do
		local info = LSCS.ComboInfo[ index ]

		local data = {
			text = info.description,
			name = info.name,
			AttackAnim = (obj.AttackAnimMenu or obj.AttackAnim),
			id = info.order,
		}
		table.insert( nice_combo, data )
	end
	table.sort( nice_combo, function( a, b ) return a.id < b.id end )

	for index, data in ipairs( nice_combo ) do
		local DButton = DScrollPanel:Add( "DButton" )
		DButton.InfoText = data.text
		DButton.InfoName = data.name
		DButton:SetSize(100,50)
		DButton:SetText("")
		DButton:Dock( TOP )
		DButton:DockMargin( 5, 5, 5, 2.5 )
		DButton.Paint = function(self, w, h )
			DrawButtonClick( self, w, h ) 
			local Col = menu_white_dim

			if LastID == index then
				Col = menu_text
				draw.SimpleText( "["..self.InfoName.."]", "LSCS_FONT", w * 0.5, 2, Col, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP )

				surface.SetDrawColor( Col.r, Col.g, Col.b, Col.a )
				DrawFrame( w, h, 0, 2 )
				Col = menu_white
			else
				if self:IsHovered() then
					Col = menu_white
					surface.SetDrawColor( Col.r, Col.g, Col.b, Col.a )
					DrawFrame( w, h, 0, 2 )
				end

				draw.SimpleText( self.InfoName, "LSCS_FONT", w * 0.5, h * 0.5, Col, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )

				return
			end

			local words = string.Explode( "\n", self.InfoText )
			if #words > 1 then
				draw.SimpleText( words[1], "LSCS_FONT_SMALL", w * 0.5, h - 2 - 12, Col, TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM )
				draw.SimpleText( words[2], "LSCS_FONT_SMALL", w * 0.5, h - 2, Col, TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM )
			else
				draw.SimpleText( words[1], "LSCS_FONT_SMALL", w * 0.5, h - 8, Col, TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM )
			end
		end
		DButton.DoClick = function( self )
			BaseButtonClick( self )

			LastID = index

			local model = mdl.Entity
			if IsValid( model ) then
				local seqID = model:LookupSequence( data.AttackAnim )
				model:SetSequence( seqID )
				model:ResetSequence( seqID )
				model:SetCycle( 0 )
			end
		end
	end

	local description = vgui.Create( "DPanel", Panel )
	description:SetSize( 500, 0 )
	description:Dock( LEFT )
	description:DockMargin( 4, 4, 0, 0 )
	description.Paint = function(self, w, h ) 
		local Col = menu_dim
		surface.SetDrawColor( Col.r, Col.g, Col.b, Col.a )
		surface.DrawRect( 0, 0, w, h  )
	end
	local richtext = vgui.Create( "RichText", description )
	richtext:Dock( FILL )
	richtext:InsertColorChange( ColHead.r, ColHead.g, ColHead.b, ColHead.a )
	richtext:AppendText("Name:\n")
	richtext:InsertColorChange( ColText.r, ColText.g, ColText.b, ColText.a )
	richtext:AppendText((combo.name or combo.id).."\n\n")
	richtext:InsertColorChange( ColHead.r, ColHead.g, ColHead.b, ColHead.a )
	richtext:AppendText("Description:\n")
	richtext:InsertColorChange( ColText.r, ColText.g, ColText.b, ColText.a )
	richtext:AppendText((combo.description or "").."\n\n")

	if combo.LeftSaberActive then
		richtext:InsertColorChange( 0,255,0,255 )
		richtext:AppendText("This Stance supports Left Hand Sabers\n\n")
	else
		richtext:InsertColorChange( 255,200,0,255 )
		richtext:AppendText("This Stance does not support Left Hand Sabers\n\n")
	end

	richtext:InsertColorChange( ColHead.r, ColHead.g, ColHead.b, ColHead.a )

	richtext:AppendText("Author:\n")
	richtext:InsertColorChange( ColText.r, ColText.g, ColText.b, ColText.a )
	richtext:AppendText((combo.author or "").."\n\n")
	richtext:InsertColorChange( ColHead.r, ColHead.g, ColHead.b, ColHead.a )

	local Button = vgui.Create( "DButton", Panel )
	Button.Item = combo
	Button:SetText( "" )
	Button:SetSize( 150, 0 )
	Button:Dock( FILL )
	Button:DockMargin( 4, 4, 4, 0 )
	Button.Paint = function( self, w, h )
		local Col = menu_dim
		surface.SetDrawColor( Col.r, Col.g, Col.b, Col.a )
		surface.DrawRect( 0, 0, w, h  )

		CrafterButtonPaint( self, w, h )
	end
	Button.DoClick = function( self )
		BaseButtonClick( self )

		local NumCombo = #ply:lscsGetCombo()

		self.menu = DermaMenu()

		self.menu:AddOption( "view next", function()
			StanceNum = StanceNum + 1
			if StanceNum > NumCombo then
				StanceNum = 1
			end
			combo = ply:lscsGetCombo( StanceNum )
			self.menu:Remove()
			LSCS:RefreshMenu()
		end )
		self.menu:AddOption( "view previous", function()
			StanceNum = StanceNum - 1
			if StanceNum <= 0 then
				StanceNum = NumCombo
			end
			combo = ply:lscsGetCombo( StanceNum )
			self.menu:Remove()
			LSCS:RefreshMenu()
		end )

		local subMenu = self.menu:AddSubMenu("equip")

		local Num = 0
		for k, v in pairs( ply:lscsGetInventory() ) do
			if isbool( ply:lscsGetEquipped()[ k ] ) then continue end

			local item = LSCS:ClassToItem( v )

			if not item then continue end

			if item.type == "stance" then
				Num = Num + 1
				subMenu:AddOption( item.name, function()
					ply:lscsEquipItem( k, true )
				end )
			end
		end

		self.menu:Open()
	end
	Button.DoRightClick = function( self )
		BaseButtonClick( self )

		local NumCombo = #ply:lscsGetCombo()

		StanceNum = StanceNum + 1
		if StanceNum > NumCombo then
			StanceNum = 1
		end
		combo = ply:lscsGetCombo( StanceNum )
		LSCS:RefreshMenu()
	end

	LSCS:SetActivePanel( Panel )
	LSCS:SideBar( Frame )

	Frame.ID = 4

	local ExtraFrame = vgui.Create( "DFrame", Frame )
	ExtraFrame:SetSize( 240, FrameSizeY )
	ExtraFrame:SetPos( PanelPosX + Panel:GetWide(), PanelPosY )
	ExtraFrame:SetTitle( "" )
	ExtraFrame:SetDraggable( false )
	ExtraFrame:ShowCloseButton( false )
	ExtraFrame.Paint = function(self, w, h )
		draw.RoundedBoxEx( 8, 0, 0, w, h, menu_light, false, false, false, true )

		surface.SetMaterial( ClickMat )
		surface.SetDrawColor( 150,150,150,150 )
		local X, Y = self:CursorPos()
		surface.DrawTexturedRectRotated( X, Y, 512, 512, 0 )
	end

	Frame:SetSize( FrameSizeX + 240, FrameSizeY )
	Frame:SetPos( Frame:GetX() - 120, Frame:GetY() )
	// Make equipment menu
	local SPH = vgui.Create( "DPanel", ExtraFrame )
	SPH:Dock( TOP )
	SPH:SetSize( 80, 50 )
	SPH:DockMargin( 4, 4, 4, 0 )
	SPH.Paint = function(self, w, h )
		local Col = menu_dim
		surface.SetDrawColor( Col.r, Col.g, Col.b, Col.a )
		surface.DrawRect( 0, 0, w, h  )

		draw.SimpleText( "Stance", "LSCS_FONT", w * 0.5, h * 0.5, menu_text, TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM )
		draw.SimpleText( "Equipping", "LSCS_FONT", w * 0.5, h * 0.5, menu_text, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP )
	end

	local SPB = vgui.Create( "DPanel", ExtraFrame )
	SPB:SetSize( 230, 0 )
	SPB:Dock( RIGHT )
	SPB:DockMargin( 0, 4, 4, 4 )
	SPB.Paint = function(self, w, h )
		local Col = menu_dim
		surface.SetDrawColor( Col.r, Col.g, Col.b, Col.a )
		surface.DrawRect( 0, 0, w, h  )
	end

	local DScrollPanel = vgui.Create( "DScrollPanel", SPB )
	DScrollPanel:Dock( FILL )
	for ID, item in pairs( KyberCore:GetOwnedForms(ply) ) do
		local stance = LSCS:GetStance( item )
		if stance.id == "default" then return end
		local P = DScrollPanel:Add( "DPanel" )
		P:SetSize( 250, 30 )
		P:Dock( TOP )
		P:DockMargin( 4, 4, 4, 0 )
		P.Paint = function(self, w, h )
			local Col = menu_light

			surface.SetDrawColor( Col.r, Col.g, Col.b, Col.a )
			surface.DrawRect( 0, 0, w, h  )

			draw.SimpleText( stance.name, "LSCS_FONT_SMALL", (w - 100) * 0.5, h * 0.5 - 1, menu_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )

			// Shine P yellow if it's equipped!
			local eq = stance.equip:GetBool()
			if eq then
				surface.SetDrawColor( 255, 191, 0, 255 )
				DrawFrame( w, h, 2, 2 )
			end
		end

		local B = vgui.Create( "Button", P )
		B:SetSize( 45, 30 )
		B:Dock( RIGHT )
		B:DockMargin( 2, 2, 2, 2 )
		B:SetText( "" )
		B.DoClick = function( self, num )
			StanceNum = ID
			combo = ply:lscsGetCombo( StanceNum )
			LSCS:RefreshMenu()
		end
		B.Paint = function(self, w, h)
			local isHovered = self:IsHovered()
			local bgColor = isHovered and menu_text or menu_dim
			local borderColor = isHovered and Color(255, 191, 0, 255) or menu_text
			local textColor = menu_white
			
			-- Background
			draw.RoundedBox(4, 0, 4, w - 4, h - 8, bgColor)
			
			-- Animated border effect
			if isHovered then
				surface.SetDrawColor(255, 191, 0, 225)
				surface.DrawOutlinedRect(0, 4, w - 4, h - 8, 1)
			end
			
			draw.SimpleText( "View", "LSCS_FONT_SMALL", w * 0.5 - 2, h * 0.5 - 1, textColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
		end		

		local C = vgui.Create( "Button", P )
		C:SetSize( 50, 30 )
		C:Dock( RIGHT )
		C:DockMargin( 2, 2, 2, 2 )
		C:SetText( "" )
		if stance.equip:GetInt() == 1 then
			C.StanceText = "On"
		else
			C.StanceText = "Off"
		end
		C.DoClick = function()
			stance.equip:SetBool( not stance.equip:GetBool() )
			if stance.equip:GetInt() == 1 then
				C.StanceText = "On"
			else
				C.StanceText = "Off"
			end
		end
		C.Paint = function(self, w, h )
			local isHovered = self:IsHovered()
			local bgColor = isHovered and menu_text or menu_dim
			local borderColor = isHovered and Color(255, 191, 0, 255) or menu_text
			local textColor = menu_white
			
			-- Background
			draw.RoundedBox(4, 0, 4, w, h - 8, bgColor)
			
			-- Animated border effect
			if isHovered then
				surface.SetDrawColor(255, 191, 0, 225)
				surface.DrawOutlinedRect(0, 4, w, h - 8, 1)
			end
			
			draw.SimpleText( self.StanceText, "LSCS_FONT_SMALL", w * 0.5, h * 0.5 - 1, textColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
		end
	end
end

local function CreateCustomBinder(parent, defaultValue, onChange)
	local binder = vgui.Create("DButton", parent)
	binder:SetSize(100, 30)
	binder:Dock(RIGHT)
	binder:DockMargin(2, 2, 2, 2)
	binder:SetText("")
	
	binder.value = defaultValue or 0
	binder.waitingForKey = false
	binder.alphaOffset = 0
	
	-- Get key name from keycode
	local function getKeyName(keyCode)
		return input.GetKeyName(keyCode) or "NONE"
	end
	
	binder.Paint = function(self, w, h)
		local isHovered = self:IsHovered()
		local isWaiting = self.waitingForKey
		
		-- Background base
		local baseColor = isWaiting and Color(40, 100, 180) or menu_dark
		if isHovered and not isWaiting then
			baseColor = Color(
				math.min(baseColor.r + 20, 255),
				math.min(baseColor.g + 20, 255),
				math.min(baseColor.b + 20, 255)
			)
		end
		
		draw.RoundedBox(4, 0, 0, w, h, baseColor)
		
		-- Animated effects
		if isWaiting then
			-- Pulsing waiting animation
			self.alphaOffset = (self.alphaOffset + 2) % 360
			local pulseAlpha = math.abs(math.sin(CurTime() * 4)) * 100
			
			draw.RoundedBox(4, 2, 2, w-4, h-4, Color(10, 120, 250, 30 + pulseAlpha))
			
			local dots = string.rep(".", math.floor((CurTime() * 2) % 4))
			draw.SimpleText("Press a key" .. dots, "LSCS_FONT_SMALL", w/2, h/2, 
				Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			
			-- Animated border effect
			local borderWidth = 2
			surface.SetDrawColor(0, 200, 255, 150 + pulseAlpha)
			surface.DrawOutlinedRect(0, 0, w, h, borderWidth)
		else
			-- Key display
			local keyName = getKeyName(self.value):upper()
			local keyColor = menu_white
			local bgColor = menu_text
			
			-- Make key badge background
			local keyWidth = math.max(30, surface.GetTextSize(keyName) + 16)
			draw.RoundedBox(4, w/2 - keyWidth/2, 3, keyWidth, h-6, bgColor)
			
			-- Key text
			draw.SimpleText(keyName, "LSCS_FONT_SMALL", w/2, h/2, keyColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			
			-- Hover effects
			if isHovered then
				surface.SetDrawColor(255, 191, 0, 50 + math.abs(math.sin(CurTime() * 3)) * 50)
				surface.DrawOutlinedRect(0, 0, w, h, 2)
				
				-- Click hint
				local hintColor = Color(255, 255, 255, 100 + math.abs(math.sin(CurTime() * 2)) * 50)
				draw.SimpleText("Click to change", "LSCS_FONT_SMALL", w/2, h+8, 
					hintColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
		end
	end
	
	binder.DoClick = function(self)
		if self.waitingForKey then return end
		
		surface.PlaySound("ui/buttonrollover.wav")
		self.waitingForKey = true
		self:RequestFocus()
	end

	binder.DoRightClick = function(self)
		if self.waitingForKey then return end
		
		surface.PlaySound("ui/buttonclickrelease.wav")
		self.value = 0
		
		if onChange then
			onChange(0)
		end
	end
	
	binder.OnKeyCodePressed = function(self, keyCode)
		if not self.waitingForKey then return end
		
		if keyCode == KEY_ESCAPE then
			-- Cancel binding
			surface.PlaySound("ui/buttonclickrelease.wav")
			self.waitingForKey = false
			return
		end
		
		self.waitingForKey = false
		self.value = keyCode
		surface.PlaySound("ui/buttonclick.wav")
		
		if onChange then
			onChange(keyCode)
		end
	end

	binder.Think = function(self)
		if self.waitingForKey then
			if input.IsKeyDown(KEY_ESCAPE) then
				surface.PlaySound("ui/buttonclickrelease.wav")
				self.waitingForKey = false
			end
		end
	end

	binder.OnMousePressed = function(self, mouseCode)
		if mouseCode == MOUSE_LEFT then
			self:DoClick()
		elseif mouseCode == MOUSE_RIGHT then
			self:DoRightClick()
		end

		if not self.waitingForKey then return end

		local mouseToKey = {
			[MOUSE_MIDDLE] = MOUSE_MIDDLE,
            [MOUSE_4]      = MOUSE_4,
            [MOUSE_5]      = MOUSE_5,
		}

		if mouseToKey[mouseCode] then
			self.value = mouseToKey[mouseCode]
			self.waitingForKey = false
			surface.PlaySound("ui/buttonclick.wav")
			
			if onChange then
				onChange(mouseToKey[mouseCode])
			end
		end
	end
	
	binder.SetValue = function(self, val)
		self.value = val
	end
	
	binder.GetValue = function(self)
		return self.value
	end
	
	return binder
end

function LSCS:BuildForceMenu( Frame )
	local ply = LocalPlayer()
	local ForceAbilities = ply:lscsGetForceAbilities()

	if ForceNum > #ForceAbilities then
		ForceNum = 1
	end

	local Force = ForceAbilities[ ForceNum ] and ForceAbilities[ ForceNum ].item or false

	local Panel = vgui.Create( "DPanel", Frame )
	Panel:SetPos( PanelPosX, PanelPosY )
	Panel:SetSize( PanelSizeX, PanelSizeY + FrameBarHeight )
	Panel.Paint = function(self, w, h )
		surface.SetMaterial( ClickMat )
		surface.SetDrawColor( 150,150,150,150 )
		local X, Y = self:CursorPos()
		surface.DrawTexturedRectRotated( X, Y, 512, 512, 0 )
	end

	local L = vgui.Create( "DPanel", Panel )
	L:SetSize( PanelSizeX - 238, 800 )
	L:Dock( LEFT )
	L:DockMargin( 0, 0, 0, 0 )
	L.Paint = function(self, w, h )
	end

	local descriptionHeader = vgui.Create( "DPanel", L )
	descriptionHeader:Dock( TOP )
	descriptionHeader:DockMargin( 4, 4, 0, 0 )
	descriptionHeader.Paint = function(self, w, h )
		local Col = menu_dim

		surface.SetDrawColor( Col.r, Col.g, Col.b, Col.a )
		surface.DrawRect( 0, 0, w, h )
		draw.SimpleText( "Information", "LSCS_FONT", w * 0.5, h * 0.5, menu_text, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
	end

	local SelectBind = vgui.Create( "DPanel", L )
	SelectBind:SetSize( 0, 280 )
	SelectBind:Dock( BOTTOM )
	SelectBind:DockMargin( 4, 4, 0, 4 )
	SelectBind.Paint = function(self, w, h )
		local Col = menu_dim
		surface.SetDrawColor( Col.r, Col.g, Col.b, Col.a )
		surface.DrawRect( 0, 0, w, h  )
	end

	local description = vgui.Create( "DPanel", L )
	description:SetSize( 500, 0 )
	description:Dock( LEFT )
	description:DockMargin( 4, 4, 0, 0 )
	description.Paint = function(self, w, h ) 
		local Col = menu_dim
		surface.SetDrawColor( Col.r, Col.g, Col.b, Col.a )
		surface.DrawRect( 0, 0, w, h  )
	end

	local ColHead = menu_text
	local ColText = menu_white

	local richtext = vgui.Create( "RichText", description )
	richtext:Dock( FILL )
	if Force then
		richtext:InsertColorChange( ColHead.r, ColHead.g, ColHead.b, ColHead.a )
		richtext:AppendText("Name:\n")

		richtext:InsertColorChange( ColText.r, ColText.g, ColText.b, ColText.a )
		richtext:AppendText("Force "..(Force.name or Force.id).."\n\n")

		richtext:InsertColorChange( ColHead.r, ColHead.g, ColHead.b, ColHead.a )
		richtext:AppendText("Description:\n")
		richtext:InsertColorChange( ColText.r, ColText.g, ColText.b, ColText.a )
		richtext:AppendText((Force.description or "").."\n\n")
		richtext:InsertColorChange( ColHead.r, ColHead.g, ColHead.b, ColHead.a )
		richtext:AppendText("Author:\n")
		richtext:InsertColorChange( ColText.r, ColText.g, ColText.b, ColText.a )
		richtext:AppendText((Force.author or "").."\n\n")
		richtext:InsertColorChange( ColHead.r, ColHead.g, ColHead.b, ColHead.a )
	else
		richtext:InsertColorChange( ColHead.r, ColHead.g, ColHead.b, ColHead.a )
		richtext:AppendText("You don't have any Force Powers")
	end

	local Button = vgui.Create( "DButton", L )
	Button.Item = Force
	Button.InfoText = "N/A"
	Button:SetText( "" )
	Button:SetSize( 130, 0 )
	Button:Dock( FILL )
	Button:DockMargin( 4, 4, 4, 0 )
	Button.Paint = function( self, w, h )
		local Col = menu_dim
		surface.SetDrawColor( Col.r, Col.g, Col.b, Col.a )
		surface.DrawRect( 0, 0, w, h  )

		CrafterButtonPaint( self, w, h )
	end
	Button.DoClick = function( self )
		BaseButtonClick( self )

		local NumForce = #ForceAbilities

		self.menu = DermaMenu()

		self.menu:AddOption( "view next", function()
			ForceNum = ForceNum + 1
			if ForceNum > NumForce then
				ForceNum = 1
			end
			self.menu:Remove()
			LSCS:RefreshMenu()
		end )
		self.menu:AddOption( "view previous", function()
			ForceNum = ForceNum - 1
			if ForceNum <= 0 then
				ForceNum = NumForce
			end
			self.menu:Remove()
			LSCS:RefreshMenu()
		end )

		local subMenu = self.menu:AddSubMenu("equip")

		local Num = 0
		for k, v in pairs( ply:lscsGetInventory() ) do
			if isbool( ply:lscsGetEquipped()[ k ] ) then continue end

			local item = LSCS:ClassToItem( v )

			if not item then continue end

			if item.type == "force" then
				Num = Num + 1
				subMenu:AddOption( item.name, function()
					ply:lscsEquipItem( k, true )
				end )
			end
		end

		self.menu:Open()
	end
	Button.DoRightClick = function( self )
		BaseButtonClick( self )

		local NumForce = #ForceAbilities

		ForceNum = ForceNum + 1
		if ForceNum > NumForce then
			ForceNum = 1
		end
		LSCS:RefreshMenu()
	end


	local descriptionHeader = vgui.Create( "DPanel", SelectBind )
	descriptionHeader:Dock( TOP )
	descriptionHeader:DockMargin( 4, 4, 0, 0 )
	descriptionHeader.Paint = function(self, w, h )
		local Col = menu_dim

		surface.SetDrawColor( Col.r, Col.g, Col.b, Col.a )
		surface.DrawRect( 0, 0, w, h )
		draw.SimpleText( "Force Selector Keybinding", "LSCS_FONT", w * 0.5, h * 0.5, menu_text, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
	end

	local ActivatorBG = vgui.Create( "DPanel", SelectBind )
	ActivatorBG:SetSize( 100, 30 )
	ActivatorBG:Dock( TOP )
	ActivatorBG:DockMargin( 4, 4, 4, 0 )
	ActivatorBG.Paint = function(self, w, h )
		local Col = menu_light

		surface.SetDrawColor( Col.r, Col.g, Col.b, Col.a )
		surface.DrawRect( 0, 0, w, h  )

		draw.SimpleText( "Mouse Override (LMB to use Force, Scroll Wheel to select)", "LSCS_FONT_SMALL", (w - 100) * 0.5, h * 0.5 - 1, menu_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
	end
	-- local ActivatorBinder = vgui.Create( "DBinder", ActivatorBG )
	-- ActivatorBinder:SetSize( 100, 30 )
	-- ActivatorBinder:Dock( RIGHT )
	-- ActivatorBinder:DockMargin( 2, 2, 2, 2 )
	-- ActivatorBinder:SetValue( LSCS.ForceSelector.KeyActivate:GetInt() )
	-- ActivatorBinder.OnChange = function( self, num )
	-- 	LSCS.ForceSelector.KeyActivate:SetInt( num )
	-- end

	local ActivatorBinder = CreateCustomBinder(ActivatorBG, LSCS.ForceSelector.KeyActivate:GetInt(), function(num)
		LSCS.ForceSelector.KeyActivate:SetInt(num)
	end)

	ActivatorBinder:SetSize( 100, 30 )
	ActivatorBinder:Dock( RIGHT )
	ActivatorBinder:DockMargin( 2, 2, 2, 2 )

	local Next = vgui.Create( "DPanel", SelectBind )
	Next:SetSize( 250, 30 )
	Next:Dock( TOP )
	Next:DockMargin( 4, 4, 4, 0 )
	Next.Paint = function(self, w, h )
		local Col = menu_light

		surface.SetDrawColor( Col.r, Col.g, Col.b, Col.a )
		surface.DrawRect( 0, 0, w, h  )

		draw.SimpleText( "Next", "LSCS_FONT_SMALL", (w - 100) * 0.5, h * 0.5 - 1, menu_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
	end
	-- local Binder = vgui.Create( "DBinder", Next )
	-- Binder:SetSize( 100, 30 )
	-- Binder:Dock( RIGHT )
	-- Binder:DockMargin( 2, 2, 2, 2 )
	-- Binder:SetValue( LSCS.ForceSelector.KeyNext:GetInt() )
	-- Binder.OnChange = function( self, num )
	-- 	LSCS.ForceSelector.KeyNext:SetInt( num )
	-- end

	local Binder = CreateCustomBinder(Next, LSCS.ForceSelector.KeyNext:GetInt(), function(num)
		LSCS.ForceSelector.KeyNext:SetInt(num)
	end)
	Binder:SetSize( 100, 30 )
	Binder:Dock( RIGHT )
	Binder:DockMargin( 2, 2, 2, 2 )

	local Prev = vgui.Create( "DPanel", SelectBind )
	Prev:SetSize( 250, 30 )
	Prev:Dock( TOP )
	Prev:DockMargin( 4, 4, 4, 0 )
	Prev.Paint = function(self, w, h )
		local Col = menu_light

		surface.SetDrawColor( Col.r, Col.g, Col.b, Col.a )
		surface.DrawRect( 0, 0, w, h  )

		draw.SimpleText( "Previous", "LSCS_FONT_SMALL", (w - 100) * 0.5, h * 0.5 - 1, menu_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
	end
	-- local Binder = vgui.Create( "DBinder", Prev )
	-- Binder:SetSize( 100, 30 )
	-- Binder:Dock( RIGHT )
	-- Binder:DockMargin( 2, 2, 2, 2 )
	-- Binder:SetValue( LSCS.ForceSelector.KeyPrev:GetInt() )
	-- Binder.OnChange = function( self, num )
	-- 	LSCS.ForceSelector.KeyPrev:SetInt( num )
	-- end

	local Binder = CreateCustomBinder(Prev, LSCS.ForceSelector.KeyPrev:GetInt(), function(num)
		LSCS.ForceSelector.KeyPrev:SetInt(num)
	end)
	Binder:SetSize( 100, 30 )
	Binder:Dock( RIGHT )
	Binder:DockMargin( 2, 2, 2, 2 )

	local Use = vgui.Create( "DPanel", SelectBind )
	Use:SetSize( 250, 30 )
	Use:Dock( TOP )
	Use:DockMargin( 4, 4, 4, 0 )
	Use.Paint = function(self, w, h )
		local Col = menu_light

		surface.SetDrawColor( Col.r, Col.g, Col.b, Col.a )
		surface.DrawRect( 0, 0, w, h  )

		draw.SimpleText( "Use", "LSCS_FONT_SMALL", (w - 100) * 0.5, h * 0.5 - 1, menu_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
	end
	-- local Binder = vgui.Create( "DBinder", Use )
	-- Binder:SetSize( 100, 30 )
	-- Binder:Dock( RIGHT )
	-- Binder:DockMargin( 2, 2, 2, 2 )
	-- Binder:SetValue( LSCS.ForceSelector.KeyUse:GetInt() )
	-- Binder.OnChange = function( self, num )
	-- 	LSCS.ForceSelector.KeyUse:SetInt( num )
	-- end

	local Binder = CreateCustomBinder(Use, LSCS.ForceSelector.KeyUse:GetInt(), function(num)
		LSCS.ForceSelector.KeyUse:SetInt(num)
	end)

	Binder:SetSize( 100, 30 )
	Binder:Dock( RIGHT )
	Binder:DockMargin( 2, 2, 2, 2 )


	local SPH = vgui.Create( "DPanel", Panel )
	SPH:SetSize( 0, 50 )
	SPH:Dock( TOP )
	SPH:SetSize( 150, 50 )
	SPH:DockMargin( 4, 4, 4, 0 )
	SPH.Paint = function(self, w, h )
		local Col = menu_dim
		surface.SetDrawColor( Col.r, Col.g, Col.b, Col.a )
		surface.DrawRect( 0, 0, w, h  )

		draw.SimpleText( "Force Power", "LSCS_FONT", w * 0.5, h * 0.5, menu_text, TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM )
		draw.SimpleText( "Binding & Equipping", "LSCS_FONT", w * 0.5, h * 0.5, menu_text, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP )
	end

	local SPB = vgui.Create( "DPanel", Panel )
	SPB:SetSize( 230, 0 )
	SPB:Dock( RIGHT )
	SPB:DockMargin( 0, 4, 4, 4 )
	SPB.Paint = function(self, w, h )
		local Col = menu_dim
		surface.SetDrawColor( Col.r, Col.g, Col.b, Col.a )
		surface.DrawRect( 0, 0, w, h  )
	end

	local DScrollPanel = vgui.Create( "DScrollPanel", SPB )
	DScrollPanel:Dock( FILL )

	for ID, itemID in pairs( KyberCore:GetOwnedAbilities(ply) ) do
		local item = LSCS:GetForceAbility( itemID )
		if item.id then
			local P = DScrollPanel:Add( "DPanel" )
			P:SetSize( 250, 30 )
			P:Dock( TOP )
			P:DockMargin( 4, 4, 4, 0 )
			P.Paint = function(self, w, h )
				local Col = menu_light

				if Force and Force.id == ID then
					Col = menu_text
				end

				surface.SetDrawColor( Col.r, Col.g, Col.b, Col.a )
				surface.DrawRect( 0, 0, w, h  )

				draw.SimpleText( item.name, "LSCS_FONT_SMALL", (w - 100) * 0.5, h * 0.5 - 1, menu_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )

				// Shine P yellow if it's equipped!
				local eq = item.equip:GetBool()
				if eq then
					surface.SetDrawColor( 255, 191, 0, 255 )
					DrawFrame( w, h, 2, 2 )
				end
			end
			
			-- local B = vgui.Create( "DBinder", P )
			-- B:SetSize( 45, 30 )
			-- B:Dock( RIGHT )
			-- B:DockMargin( 2, 2, 2, 2 )
			-- B:SetValue( item.cmd:GetInt() )
			-- B.OnChange = function( self, num )
			-- 	item.cmd:SetInt( num )
			-- 	LSCS:RefreshKeys()
			-- end

			local B = CreateCustomBinder(P, item.cmd:GetInt(), function(num)
				item.cmd:SetInt(num)
				LSCS:RefreshKeys()
			end)

			B:SetSize( 45, 30 )
			B:Dock( RIGHT )
			B:DockMargin( 2, 4, 4, 4 )

			local C = vgui.Create( "Button", P )
			C:SetSize( 50, 30 )
			C:Dock( RIGHT )
			C:DockMargin( 2, 2, 2, 2 )
			C:SetText( "" )
			if item.equip:GetInt() == 1 then
				C.PowerText = "On"
			else
				C.PowerText = "Off"
			end

			C.DoClick = function()
				item.equip:SetBool( not item.equip:GetBool() )
				if item.equip:GetInt() == 1 then
					C.PowerText = "On"
				else
					C.PowerText = "Off"
				end
			end

			C.Paint = function(self, w, h)
				local isHovered = self:IsHovered()
				local bgColor = isHovered and menu_text or menu_dim
				local borderColor = isHovered and Color(255, 191, 0, 255) or menu_text
				local textColor = menu_white
				
				-- Background
				draw.RoundedBox(4, 0, 4, w, h - 8, bgColor)
				
				-- Animated border effect
				if isHovered then
					surface.SetDrawColor(255, 191, 0, 225)
					surface.DrawOutlinedRect(0, 4, w, h - 8, 1)
				end
				
				draw.SimpleText( C.PowerText, "LSCS_FONT_SMALL", w * 0.5, h * 0.5 - 1, textColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
			end
		end
	end

	LSCS:SetActivePanel( Panel )
	LSCS:SideBar( Frame )

	Frame.ID = 5
end

function LSCS:BuildSettings( Frame )
	local Panel = vgui.Create( "DPanel", Frame )
	Panel:SetPos( PanelPosX, PanelPosY )
	Panel:SetSize( PanelSizeX, PanelSizeY + FrameBarHeight )
	Panel.Paint = function(self, w, h )
		surface.SetMaterial( ClickMat )
		surface.SetDrawColor( 150,150,150,150 )
		local X, Y = self:CursorPos()
		surface.DrawTexturedRectRotated( X, Y, 512, 512, 0 )
	end

	local PerfSettings = vgui.Create( "DPanel", Panel )
	PerfSettings:SetSize( 0, 166 )
	PerfSettings:DockMargin( 4, 4, 4, 4 )
	PerfSettings:Dock( TOP )
	PerfSettings.Paint = function(self, w, h )
		surface.SetDrawColor( menu_dim )
		surface.DrawRect( 0, 0, w, h )
	end

	local Header = vgui.Create( "DPanel", PerfSettings )
	Header:SetSize( 0, 40 )
	Header:DockMargin( 4, 4, 4, 4 )
	Header:Dock( TOP )
	Header.Paint = function(self, w, h )
		draw.SimpleText( "Client Settings", "LSCS_FONT", 4, h * 0.5, menu_text, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER )
	end

	local Line = vgui.Create( "DPanel", PerfSettings )
	Line:SetSize( PanelSizeX, 1)
	Line:Dock( TOP )
	Line:DockMargin( 0, 4, 4, 4 )
	Line.Paint = function(self, w, h )
		surface.SetDrawColor( menu_text )
		surface.SetMaterial( gradient_mat )
		surface.DrawTexturedRect( 0, 0, w, h )
	end

	local pLeft = vgui.Create( "DPanel", PerfSettings )
	pLeft:SetSize( PanelSizeX * 0.5, 0 )
	pLeft:DockMargin( 0, 0, 0, 0 )
	pLeft:Dock( LEFT )
	pLeft.Paint = function(self, w, h ) end

	local pRight = vgui.Create( "DPanel", PerfSettings )
	pRight:SetSize( PanelSizeX * 0.5, 0 )
	pRight:DockMargin( 0, 0, 0, 0 )
	pRight:Dock( LEFT )
	pRight.Paint = function(self, w, h ) end

	local T = vgui.Create( "DPanel", pLeft )
	T:Dock( TOP )
	T:DockMargin( 4, 4, 0, 0 )
	T.Paint = function(self, w, h )
		draw.SimpleText( "Performance", "LSCS_FONT_SMALL", 0, h * 0.5, menu_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER )
	end

	local DCheckbox = vgui.Create( "DCheckBoxLabel", pLeft )
	DCheckbox:Dock( TOP )
	DCheckbox:DockMargin( 4, 4, 0, 0 )
	DCheckbox:SetText("Dynamic Light")	
	DCheckbox:SetConVar("lscs_dynamiclight")
	DCheckbox:SizeToContents()

	local DCheckbox = vgui.Create( "DCheckBoxLabel", pLeft )
	DCheckbox:Dock( TOP )
	DCheckbox:DockMargin( 4, 4, 0, 0 )
	DCheckbox:SetText("High Quality Impact Effects")	
	DCheckbox:SetConVar("lscs_impacteffects")
	DCheckbox:SizeToContents()

	local DSlider = vgui.Create( "DNumSlider", pLeft )
	DSlider:Dock( TOP )
	DSlider:DockMargin( 4, 4, 0, 0 )
	DSlider:SetText( "Trail Effect Detail" )
	DSlider:SetMin( 0 )
	DSlider:SetMax( 100 )
	DSlider:SetDecimals( 0 )
	DSlider:SetConVar( "lscs_traildetail" )	

	local T = vgui.Create( "DPanel", pRight )
	T:Dock( TOP )
	T:DockMargin( 4, 4, 0, 0 )
	T.Paint = function(self, w, h )
		draw.SimpleText( "Hud", "LSCS_FONT_SMALL", 0, h * 0.5, menu_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER )
	end

	local DCheckbox = vgui.Create( "DCheckBoxLabel", pRight )
	DCheckbox:Dock( TOP )
	DCheckbox:DockMargin( 4, 4, 0, 0 )
	DCheckbox:SetText("Show HUD")	
	DCheckbox:SetConVar("lscs_drawhud")
	DCheckbox:SizeToContents()

	if LocalPlayer():IsSuperAdmin() then
		local SVSettings = vgui.Create( "DPanel", Panel )
		SVSettings:SetSize( 0, 302 )
		SVSettings:DockMargin( 4, 0, 4, 4 )
		SVSettings:Dock( TOP )
		SVSettings.Paint = function(self, w, h )
			surface.SetDrawColor( menu_dim )
			surface.DrawRect( 0, 0, w, h )
		end

		local Header = vgui.Create( "DPanel", SVSettings )
		Header:SetSize( 0, 40 )
		Header:DockMargin( 4, 4, 4, 4 )
		Header:Dock( TOP )
		Header.Paint = function(self, w, h )
			draw.SimpleText( "Server Settings", "LSCS_FONT", 4, h * 0.5, menu_text, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER )
			surface.SetDrawColor( 255, 255, 255, 255 )
			surface.SetMaterial( adminMat )
			surface.DrawTexturedRect( w - 20,  4, 16, 16 )
		end

		local Line = vgui.Create( "DPanel", SVSettings )
		Line:SetSize( PanelSizeX, 1)
		Line:Dock( TOP )
		Line:DockMargin( 0, 4, 4, 4 )
		Line.Paint = function(self, w, h )
			surface.SetDrawColor( menu_text )
			surface.SetMaterial( gradient_mat )
			surface.DrawTexturedRect( 0, 0, w, h )
		end
		local T = vgui.Create( "DPanel", SVSettings )
		T:Dock( TOP )
		T:DockMargin( 4, 4, 0, 0 )
		T.Paint = function(self, w, h )
			draw.SimpleText( "Saber Attacking", "LSCS_FONT_SMALL", 0, h * 0.5, menu_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER )
		end
		local slider = vgui.Create( "DNumSlider", SVSettings )
		slider:Dock( TOP )
		slider:DockMargin( 4, 4, 0, 0 )
		slider:SetText( "Damage" )
		slider:SetMin( 0 )
		slider:SetMax( 2000 )
		slider:SetDecimals( 0 )
		slider:SetConVar( "lscs_sv_saberdamage" )
		function slider:OnValueChanged( val )
			net.Start("lscs_admin_setconvar")
				net.WriteString("lscs_sv_saberdamage")
				net.WriteString( tostring( val ) )
			net.SendToServer()
		end

		local Line = vgui.Create( "DPanel", SVSettings )
		Line:SetSize( PanelSizeX, 1)
		Line:Dock( TOP )
		Line:DockMargin( 0, 4, 4, 4 )
		Line.Paint = function(self, w, h )
			surface.SetDrawColor( menu_text )
			surface.SetMaterial( gradient_mat )
			surface.DrawTexturedRect( 0, 0, w, h )
		end
		local T = vgui.Create( "DPanel", SVSettings )
		T:Dock( TOP )
		T:DockMargin( 4, 4, 0, 0 )
		T.Paint = function(self, w, h )
			draw.SimpleText( "Saber Bullet Deflecting", "LSCS_FONT_SMALL", 0, h * 0.5, menu_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER )
		end

		local slider = vgui.Create( "DNumSlider", SVSettings )
		slider:Dock( TOP )
		slider:DockMargin( 4, 4, 0, 0 )
		slider:SetText( "Deflect Force Drain Multiplier" )
		slider:SetMin( 0 )
		slider:SetMax( 1 )
		slider:SetDecimals( 2 )
		slider:SetConVar( "lscs_sv_forcedrain_per_bullet_mul" )
		function slider:OnValueChanged( val )
			net.Start("lscs_admin_setconvar")
				net.WriteString("lscs_sv_forcedrain_per_bullet_mul")
				net.WriteString( tostring( val ) )
			net.SendToServer()
		end

		local slider = vgui.Create( "DNumSlider", SVSettings )
		slider:Dock( TOP )
		slider:DockMargin( 4, 4, 0, 0 )
		slider:SetText( "Minimum ForceDrain per Deflect" )
		slider:SetMin( 0 )
		slider:SetMax( 10 )
		slider:SetDecimals( 0 )
		slider:SetConVar( "lscs_sv_forcedrain_per_bullet_min" )
		function slider:OnValueChanged( val )
			net.Start("lscs_admin_setconvar")
				net.WriteString("lscs_sv_forcedrain_per_bullet_min")
				net.WriteString( tostring( val ) )
			net.SendToServer()
		end

		local slider = vgui.Create( "DNumSlider", SVSettings )
		slider:Dock( TOP )
		slider:DockMargin( 4, 4, 0, 0 )
		slider:SetText( "Maximum ForceDrain per Deflect" )
		slider:SetMin( 0 )
		slider:SetMax( 100 )
		slider:SetDecimals( 0 )
		slider:SetConVar( "lscs_sv_forcedrain_per_bullet_max" )
		function slider:OnValueChanged( val )
			net.Start("lscs_admin_setconvar")
				net.WriteString("lscs_sv_forcedrain_per_bullet_max")
				net.WriteString( tostring( val ) )
			net.SendToServer()
		end

		local DCheckbox = vgui.Create( "DCheckBoxLabel", SVSettings )
		DCheckbox:Dock( TOP )
		DCheckbox:DockMargin( 4, 4, 0, 0 )
		DCheckbox:SetText("Player Bullets Interrupt Saber Attack")	
		DCheckbox:SetConVar("lscs_sv_bullet_can_interrupt_attack")
		DCheckbox:SizeToContents()
		function DCheckbox:OnChange( val )
			net.Start("lscs_admin_setconvar")
				net.WriteString("lscs_sv_bullet_can_interrupt_attack")
				net.WriteString( val and "1" or "0" )
			net.SendToServer()
		end
	end

	LSCS:SetActivePanel( Panel )
	LSCS:SideBar( Frame )

	Frame.ID = 7
end

local function CreateCustomLeaderboard( Panel, data )
	// Create buttons for each player. Make it look beautiful
	local LeaderboardPanel = vgui.Create( "DPanel", Panel )
	LeaderboardPanel:SetSize( 0, 600 )
	LeaderboardPanel:DockMargin( 4, 4, 4, 4 )
	LeaderboardPanel:Dock( TOP )
	LeaderboardPanel.Paint = function(self, w, h )
		surface.SetDrawColor( menu_dim )
		surface.DrawRect( 0, 0, w, h )
	end

	local function CreateInternalButton(data, parent, index)
		local BTN = vgui.Create( "DButton", parent )
		BTN:SetSize( 0, 40 )
		BTN:Dock( TOP )
		BTN:DockMargin( 4, 4, 4, 4 )
		BTN:SetText( "" )

		local originalSize = 40
		BTN.ExtendedInfo = false

		local dataSteamID = data.unique_id
		// Get player's Nick from steamID
		local dataName = dataSteamID
		local plyFromSteamID = player.GetBySteamID64( dataSteamID )

		if IsValid( plyFromSteamID ) then
			dataName = plyFromSteamID:Nick()
		end

		// If not, use steam name from steamworks.
		if dataName == dataSteamID then
			steamworks.RequestPlayerInfo( dataSteamID, function( name )
				if name == nil then return end
				dataName = name
			end )
		end

		// If bots, show their name as "Bot"
		if dataName == "" then
			dataName = "Unknown"
		end

		local btnClr = menu_light

		BTN.Paint = function(self, w, h )
			// Four columns. Name is the longest, so we'll make it 40% of the width
			// The rest will be split evenly.
			local ColumnWidths = { 0.1, 0.4, 0.4, 0.1 }
			local Columns = { index, dataName, KyberCore:GetDuelRank(tonumber(data["rating"])), tonumber(data["rating"]) }
			local ColumnX = 0
			// In all four, we actually show the real data.
			for i = 1, 4 do
				local Col = btnClr
				surface.SetDrawColor( Col.r, Col.g, Col.b, Col.a )
				surface.DrawRect( ColumnX, 0, w * ColumnWidths[i], h  )
				draw.SimpleText( Columns[i], "LSCS_FONT_MEDIUM", ColumnX + 4, originalSize * 0.5, menu_text, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER )
				ColumnX = ColumnX + w * ColumnWidths[i]
			end

			// If you're the player, recolor the background to yellow.
			if plyFromSteamID ~= nil and plyFromSteamID == LocalPlayer() then
				btnClr = Color(41,52,102)
			end

			if self.ExtendedInfo then
				// Show the player's wins, losses, win rate
				local wins = tonumber(data["wins"])
				local losses = tonumber(data["losses"])
				local rate = wins + losses > 0 and math.Round( wins / (wins + losses) * 100, 2 ) or 0

				draw.SimpleText( "Wins: "..wins, "LSCS_FONT_MEDIUM", 4, originalSize + 4, menu_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER )
				draw.SimpleText( "Losses: "..losses, "LSCS_FONT_MEDIUM", 4, originalSize + 24, menu_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER )
				draw.SimpleText( "Win Rate: "..rate.."%", "LSCS_FONT_MEDIUM", 4, originalSize + 44, menu_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER )
			end
		end

		local resizedSize = 100

		// Clicking on the button will extend the button to show more information.
		BTN.DoClick = function()
			if BTN:GetTall() == 40 then
				BTN:SetTall( resizedSize )
				LeaderboardPanel:SetTall( LeaderboardPanel:GetTall() + resizedSize - 40 )
				Panel:SetTall( Panel:GetTall() + resizedSize - 40 )
			else
				BTN:SetTall( 40 )
				LeaderboardPanel:SetTall( LeaderboardPanel:GetTall() - resizedSize + 40 )
				Panel:SetTall( Panel:GetTall() - resizedSize + 40 )
			end

			// Show additional information about the player.
			BTN.ExtendedInfo = not BTN.ExtendedInfo
		end
	end

	// Organize the data, from highest to lowest rating
	table.sort( data, function(a, b) return a["rating"] > b["rating"] end )


	for k, v in pairs( data ) do
		CreateInternalButton(v, LeaderboardPanel, k)
	end

	// Resize the panel to fit 10 buttons in total.
	LeaderboardPanel:SetTall( 48 * 10 )

	return LeaderboardPanel
end

function LSCS:BuildDueling( Frame )
	local Panel = vgui.Create( "DScrollPanel", Frame )
	Panel:SetPos( PanelPosX, PanelPosY )
	Panel:SetSize( PanelSizeX, PanelSizeY + FrameBarHeight )
	Panel.Paint = function(self, w, h )
		surface.SetMaterial( ClickMat )
		surface.SetDrawColor( 150,150,150,150 )
		local X, Y = self:CursorPos()
		surface.DrawTexturedRectRotated( X, Y, 512, 512, 0 )
	end

	// Show the player's dueling stats: Name, Dueling Rating, Rank, Wins, Losses, Win Rate
	local ply = LocalPlayer()
	local rating = ply:GetNWInt("KyberCoreDuelingRating", 0) or 0
	local wins = ply:GetNWInt("KyberCoreDuelingWins", 0) or 0
	local losses = ply:GetNWInt("KyberCoreDuelingLosses", 0) or 0
	local rank = KyberCore:GetDuelRank(ply:GetNWInt("KyberCoreDuelingRating", 0)) or 0

	local Stats = vgui.Create( "DPanel", Panel )
	Stats:SetSize( 0, 150 )
	Stats:DockMargin( 4, 4, 4, 4 )
	Stats:Dock( TOP )
	Stats.Paint = function(self, w, h )
		surface.SetDrawColor( menu_dim )
		surface.DrawRect( 0, 0, w, h )
	end

	// Stoneman (Rank) - 1000
	local Header = vgui.Create( "DPanel", Stats )
	Header:SetSize( 0, 40 )
	Header:DockMargin( 4, 4, 4, 4 )
	Header:Dock( TOP )
	Header.Paint = function(self, w, h )
		draw.SimpleText( ply:Nick(), "LSCS_FONT", 4, h * 0.5, menu_text, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER )
		draw.SimpleText( rank.." ("..rating..")", "LSCS_FONT", w - 4, h * 0.5, KyberCore:GetDuelRankColor( rank ), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER )
	end

	// Wins
	local Wins = vgui.Create( "DPanel", Stats )
	Wins:SetSize( 0, 40 )
	Wins:DockMargin( 4, -16, 4, 4 )
	Wins:Dock( TOP )
	Wins.Paint = function(self, w, h )
		draw.SimpleText( "Wins: "..wins, "LSCS_FONT_MEDIUM", 4, h * 0.5, menu_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER )
	end

	// Losses
	local Losses = vgui.Create( "DPanel", Stats )
	Losses:SetSize( 0, 40 )
	Losses:DockMargin( 4, -16, 4, 4 )
	Losses:Dock( TOP )
	Losses.Paint = function(self, w, h )
		draw.SimpleText( "Losses: "..losses, "LSCS_FONT_MEDIUM", 4, h * 0.5, menu_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER )
	end

	// Win Rate
	local WinRatio = vgui.Create( "DPanel", Stats )
	WinRatio:SetSize( 0, 40 )
	WinRatio:DockMargin( 4, -16, 4, 4 )
	WinRatio:Dock( TOP )
	WinRatio.Paint = function(self, w, h )
		local rate = wins + losses > 0 and math.Round( wins / (wins + losses) * 100, 2 ) or 0
		draw.SimpleText( "Win Rate: "..rate.."%", "LSCS_FONT_MEDIUM", 4, h * 0.5, menu_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER )
	end

	// Leaderboards! - Top 10
	local Leaderboards = vgui.Create( "DPanel", Panel )
	Leaderboards:SetSize( 0, 600 )
	Leaderboards:DockMargin( 4, 4, 4, 4 )
	Leaderboards:Dock( TOP )
	Leaderboards.Paint = function(self, w, h )
		surface.SetDrawColor( menu_dim )
		surface.DrawRect( 0, 0, w, h )
	end

	local Header = vgui.Create( "DPanel", Leaderboards )
	Header:SetSize( 0, 40 )
	Header:DockMargin( 4, 4, 4, 4 )
	Header:Dock( TOP )
	Header.Paint = function(self, w, h )
		draw.SimpleText( "Leaderboards - Top 10 Duelists", "LSCS_FONT", 4, h * 0.5, menu_text, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER )
	end

	local Line = vgui.Create( "DPanel", Leaderboards )
	Line:SetSize( PanelSizeX, 1)
	Line:Dock( TOP )
	Line:DockMargin( 0, 4, 4, 4 )
	Line.Paint = function(self, w, h )
		surface.SetDrawColor( menu_text )
		surface.SetMaterial( gradient_mat )
		surface.DrawTexturedRect( 0, 0, w, h )
	end

	// Header to show the columns:
	// # - Name - Rank - Rating

	local Header = vgui.Create( "DPanel", Leaderboards )
	Header:SetSize( 0, 40 )
	Header:DockMargin( 4, 4, 4, 4 )
	Header:Dock( TOP )
	Header.Paint = function(self, w, h )
		// Four columns. Name is the longest, so we'll make it 40% of the width
		// The rest will be split evenly
		local ColumnWidths = { 0.1, 0.4, 0.4, 0.1 }
		local Columns = { "#", "Name", "Rank", "Rating" }
		local ColumnX = 0
		for k, v in pairs( Columns ) do
			draw.SimpleText( v, "LSCS_FONT_MEDIUM", w * ColumnX, h * 0.5, menu_text, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER )
			ColumnX = ColumnX + ColumnWidths[ k ]
		end
	end

	// Ask the server for the leaderboard data!
	net.Start("KyberCore.RequestDuelLeaderboard")
	net.SendToServer()

	net.Receive("KyberCore.RequestDuelLeaderboard", function(len)
		local data = net.ReadData( len )
		if not data then return end
		data = util.Decompress( data )
		data = util.JSONToTable( data )
	
		if not data then return end
		
		if not IsValid( Frame ) then return end
		if Frame.ID == 6 then
			if IsValid( Leaderboards ) then
				local Leaderboard = CreateCustomLeaderboard( Leaderboards, data )
				Leaderboard:SetTall( 600 )
				Leaderboard:SizeToContents()
			end
		end
	end)

	// Resize the panel to fit all the buttons.
	Leaderboards:SetTall( 600 )
	Leaderboards:SizeToContents()

	LSCS:SetActivePanel( Panel )
	LSCS:SideBar( Frame )
	Frame.ID = 6
end

function LSCS:BuildAdmin( Frame )
	local ply = LocalPlayer()
	if not LocalPlayer():IsSuperAdmin() and not KyberCore:IsSystemAdmin(LocalPlayer()) then return end
    -- Main panel
    local Panel = vgui.Create("DPanel", Frame)
    Panel:SetPos(PanelPosX, PanelPosY)
    Panel:SetSize(PanelSizeX, PanelSizeY + FrameBarHeight)
    Panel.Paint = function(self, w, h)
        surface.SetMaterial(ClickMat)
        surface.SetDrawColor(150, 150, 150, 150)
        local X, Y = self:CursorPos()
        surface.DrawTexturedRectRotated(X, Y, 512, 512, 0)
        draw.RoundedBoxEx(8, 0, 0, w, h, menu_dim, false, false, false, true)
    end
    
    -- Header
    local Header = vgui.Create("DPanel", Panel)
    Header:SetSize(0, 40)
    Header:Dock(TOP)
    Header:DockMargin(8, 8, 8, 0)
    Header.Paint = function(self, w, h)
        local Col = menu_dark
        surface.SetDrawColor(Col.r, Col.g, Col.b, Col.a)
        surface.DrawRect(0, 0, w, h)
        
        draw.SimpleText("Kyber Core Admin Panel", "LSCS_FONT", 16, h/2, menu_text, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        
        surface.SetDrawColor(255, 255, 255, 255)
        surface.SetMaterial(adminMat)
        surface.DrawTexturedRect(w - 24, h/2 - 8, 16, 16)
    end
    
    -- Tab buttons container
    local TabContainer = vgui.Create("DPanel", Panel)
    TabContainer:SetSize(0, 40)
    TabContainer:Dock(TOP)
    TabContainer:DockMargin(8, 8, 8, 0)
    TabContainer.Paint = function(self, w, h)
        local Col = menu_dark
        surface.SetDrawColor(Col.r, Col.g, Col.b, Col.a)
        surface.DrawRect(0, 0, w, h)
    end
    
    -- Main content container (holds tabs and player list)
    local ContentPanel = vgui.Create("DPanel", Panel)
    ContentPanel:Dock(FILL)
    ContentPanel:DockMargin(8, 8, 8, 8)
    ContentPanel.Paint = function() end
    
    -- Player list panel (left side)
    local PlayerList = vgui.Create("DPanel", ContentPanel)
    PlayerList:SetSize(275, 0)
    PlayerList:Dock(LEFT)
    PlayerList:DockMargin(0, 0, 8, 0)
    PlayerList.Paint = function(self, w, h)
        draw.RoundedBox(4, 0, 0, w, h, menu_light)
        draw.SimpleText("Player Selection", "LSCS_FONT", w/2, 10, menu_text, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
    end

	local searchHeader = vgui.Create("DPanel", PlayerList)
	searchHeader:SetSize(0, 30)
	searchHeader:Dock(TOP)
	searchHeader:DockMargin(4, 4, 4, 0)
	searchHeader.Paint = function(self, w, h)
		draw.RoundedBox(4, 0, 0, w, h, menu_dark)
	end


	local searchBox = vgui.Create("DTextEntry", searchHeader)
	searchBox:Dock(FILL)
	searchBox:DockMargin(4, 3, 5, 3)
	searchBox:SetPlaceholderText("Search players...")
	searchBox.oldPaint = searchBox.Paint
	searchBox.Paint = function(self, w, h)
		draw.RoundedBox(4, 0, 0, w, h, menu_light)
		self:DrawTextEntryText(menu_white, menu_text, menu_white)
		
		if self:GetValue() == "" and not self:HasFocus() then
			draw.SimpleText(self:GetPlaceholderText(), "LSCS_FONT_SMALL", 5, h/2, menu_white_dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
	end
    
    -- Player scroll panel
    local PlayerScroll = vgui.Create("DScrollPanel", PlayerList)
    PlayerScroll:Dock(FILL)
    PlayerScroll:DockMargin(4, 4, 4, 4)
    
    -- Make scrollbar more fancy
    local VBar = PlayerScroll:GetVBar()
    VBar:SetWide(8)
    VBar.Paint = function(self, w, h)
        draw.RoundedBox(8, 0, 0, w, h, Color(31, 31, 31, 0))
    end
    VBar.btnUp.Paint = function(self, w, h)
        draw.RoundedBox(8, 0, 0, w, h, menu_light)
    end
    VBar.btnDown.Paint = function(self, w, h)
        draw.RoundedBox(8, 0, 0, w, h, menu_light)
    end
    VBar.btnGrip.Paint = function(self, w, h)
        draw.RoundedBox(8, 0, 0, w, h, menu_light)
    end
    
    -- Tab content area (right side)
    local TabContent = vgui.Create("DPanel", ContentPanel)
    TabContent:Dock(FILL)
    TabContent.Paint = function(self, w, h)
        draw.RoundedBox(4, 0, 0, w, h, menu_light)
    end
    
    -- Selected player data
    local selectedPlayer = nil
    
    -- Function to populate player list
    local function PopulatePlayerList(searchFilter)
        PlayerScroll:Clear()
		searchFilter = (searchFilter or ""):lower()
		local visiblePlayers = 0
		for _, player in pairs(player.GetAll()) do
			-- Skip players that don't match the search filter
			if searchFilter ~= "" and not string.find(string.lower(player:Nick()), searchFilter) and
			   not string.find(string.lower(player:SteamID()), searchFilter) then
				continue
			end
			
			visiblePlayers = visiblePlayers + 1
			local button = vgui.Create("DButton", PlayerScroll)
			button:SetText("")
			button:SetSize(0, 40)
			button:Dock(TOP)
			button:DockMargin(2, 2, 2, 2)
			
			-- Existing button code...
			button.Paint = function(self, w, h)
				// If player stops existing, return
				if not IsValid(player) then return end
				local bgColor = menu_dark
				local textColor = menu_white_dim
				
				if selectedPlayer == player then
					bgColor = menu_text
					textColor = Color(255, 255, 255)
				elseif self:IsHovered() then
					bgColor = menu_light
					textColor = menu_white
				end
				
				draw.RoundedBox(4, 0, 0, w, h, bgColor)
				
				-- Draw player info
				draw.SimpleText(player:Nick(), "LSCS_FONT_SMALL", 36, h/2 - 8, textColor, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				
				-- Draw admin status if applicable
				if player:IsSuperAdmin() then
					draw.SimpleText("Super Admin", "LSCS_FONT_SMALL", 36, h/2 + 8, Color(255, 0, 0), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				elseif KyberCore:IsSystemAdmin(player) then
					draw.SimpleText("System Admin", "LSCS_FONT_SMALL", 36, h/2 + 8, Color(255, 191, 0), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				else
					draw.SimpleText("Player", "LSCS_FONT_SMALL", 36, h/2 + 8, textColor, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				end
			end
			
			button.DoClick = function()
				selectedPlayer = player
				surface.PlaySound("ui/buttonclick.wav")
				KyberCoreRefreshTabContent() -- Refresh content when selecting a player
			end
			
			-- Add player avatar
			timer.Simple(0, function()
				if IsValid(button) then
					local avatar = vgui.Create("AvatarImage", button)
					avatar:SetSize(24, 24)
					avatar:SetPos(6, button:GetTall()/2 - 12)
					avatar:SetPlayer(player, 32)
				end
			end)
		end
		
		-- If no players match the search, show a message
		if visiblePlayers == 0 and searchFilter ~= "" then
			local noMatchPanel = vgui.Create("DPanel", PlayerScroll)
			noMatchPanel:SetSize(0, 40)
			noMatchPanel:Dock(TOP)
			noMatchPanel:DockMargin(2, 2, 2, 2)
			noMatchPanel.Paint = function(self, w, h)
				draw.RoundedBox(4, 0, 0, w, h, menu_dark)
				draw.SimpleText("No matching players found", "LSCS_FONT_SMALL", w/2, h/2, menu_white_dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
		end
    end

	searchBox.OnChange = function(self)
		PopulatePlayerList(self:GetValue())
	end

    -- Refresh button at the bottom
    local RefreshButton = vgui.Create("DButton", Panel)
    RefreshButton:SetSize(0, 40)
    RefreshButton:Dock(BOTTOM)
    RefreshButton:DockMargin(8, 0, 8, 8)
    RefreshButton:SetText("")
    RefreshButton.Paint = function(self, w, h)
        local color = self:IsHovered() and menu_text or menu_dark
        draw.RoundedBox(4, 0, 0, w, h, color)
        draw.SimpleText("REFRESH", "LSCS_FONT", w/2, h/2, menu_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    
    RefreshButton.DoClick = function()
        surface.PlaySound("buttons/button16.wav")
        PopulatePlayerList(searchBox:GetValue())
        KyberCoreRefreshTabContent()
    end
    
    -- Tab system
    local activeTab = "admin"
    local tabs = {
        ["whitelist"] = {name = "Whitelisting", desc = "Manage skill tree whitelist access"},
        ["inventory"] = {name = "Inventory", desc = "Manage player inventory items"},
        ["progression"] = {name = "Progression", desc = "Manage XP, level and skill points"},
        ["admin"] = {name = "Admin Access", desc = "Manage admin menu access"}
    }
    
    -- Create tab buttons
    for id, tabInfo in pairs(tabs) do
        local button = vgui.Create("DButton", TabContainer)
        button:SetText("")
        button:SetSize(PanelSizeX/4 - 10, 40)
        button:Dock(LEFT)
        button:DockMargin(4, 0, 4, 0)
        
        button.Paint = function(self, w, h)
            local isActive = activeTab == id
            local bgColor = isActive and menu_text or menu_dark
            local textColor = isActive and menu_white or menu_white_dim
            
            draw.RoundedBox(4, 0, 0, w, h, bgColor)
            draw.SimpleText(tabInfo.name, "LSCS_FONT_SMALL", w/2, h/2, textColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            
            -- Draw underline for active tab
            if isActive then
                surface.SetDrawColor(255, 191, 0, 255)
                surface.DrawRect(0, h-3, w, 3)
            end
        end
        
        button.DoClick = function()
            activeTab = id
            surface.PlaySound("ui/buttonclick.wav")
            KyberCoreRefreshTabContent()
        end
    end
    
    -- Function to refresh tab content based on active tab
    function KyberCoreRefreshTabContent()
        TabContent:Clear()
        
        -- Header showing current tab and description
        local contentHeader = vgui.Create("DPanel", TabContent)
        contentHeader:SetSize(0, 40)
        contentHeader:Dock(TOP)
        contentHeader:DockMargin(8, 8, 8, 0)
        contentHeader.Paint = function(self, w, h)
            draw.RoundedBox(4, 0, 0, w, h, menu_dark)
            draw.SimpleText(tabs[activeTab].name, "LSCS_FONT", 10, h/2 - 8, menu_text, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
            draw.SimpleText(tabs[activeTab].desc, "LSCS_FONT_SMALL", 10, h/2 + 8, menu_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        end
        
        if not IsValid(selectedPlayer) then
			if activeTab != "admin" then
				-- No player selected message
				local noSelection = vgui.Create("DPanel", TabContent)
				noSelection:Dock(FILL)
				noSelection:DockMargin(8, 8, 8, 8)
				noSelection.Paint = function(self, w, h)
					draw.SimpleText("Select a player from the list", "LSCS_FONT", w/2, h/2, menu_white_dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				end

				return
			end
        end
        
        -- Content area
        local contentArea = vgui.Create("DScrollPanel", TabContent)
        contentArea:Dock(FILL)
        contentArea:DockMargin(8, 8, 8, 8)
        
        -- Make scrollbar more fancy
        local VBar = contentArea:GetVBar()
        VBar:SetWide(8)
        VBar.Paint = function(self, w, h)
            draw.RoundedBox(8, 0, 0, w, h, Color(31, 31, 31, 0))
        end
        VBar.btnUp.Paint = function(self, w, h)
            draw.RoundedBox(8, 0, 0, w, h, menu_light)
        end
        VBar.btnDown.Paint = function(self, w, h)
            draw.RoundedBox(8, 0, 0, w, h, menu_light)
        end
        VBar.btnGrip.Paint = function(self, w, h)
            draw.RoundedBox(8, 0, 0, w, h, menu_light)
        end
        
		if IsValid(selectedPlayer) then
			-- Display selected player info panel
			local playerInfo = vgui.Create("DPanel", contentArea)
			playerInfo:SetSize(0, 60)
			playerInfo:Dock(TOP)
			playerInfo:DockMargin(0, 0, 0, 8)
			playerInfo.Paint = function(self, w, h)
				draw.RoundedBox(4, 0, 0, w, h, menu_dark)
				
				if not IsValid(selectedPlayer) then return end
				-- Player information
				draw.SimpleText(selectedPlayer:Nick(), "LSCS_FONT", 60, 15, menu_text, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				draw.SimpleText(selectedPlayer:SteamID(), "LSCS_FONT_SMALL", 60, 35, menu_white_dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				
				-- Level/XP info
				local level = selectedPlayer:GetNWInt("KC_EXP_LEVEL", 1)
				local xp = selectedPlayer:GetNWInt("KC_EXP", 0)
				local points = selectedPlayer:GetNWInt("KC_EXP_POINTS", 0)
				
				draw.SimpleText("Level: " .. level .. " | XP: " .. xp .. " | Points: " .. points, "LSCS_FONT_SMALL", 
					w - 10, h/2, menu_text, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
			end

			timer.Simple(0, function()
				local avatar = vgui.Create("AvatarImage", playerInfo)
				avatar:SetSize(40, 40)
				avatar:SetPos(10, 10)
				avatar:SetPlayer(selectedPlayer, 64)
			end)
		end
        
        -- Tab-specific content
        if activeTab == "whitelist" then
            -- Whitelisting menu
            local whitelistPanel = vgui.Create("DPanel", contentArea)
            whitelistPanel:SetSize(0, 350)
            whitelistPanel:Dock(TOP)

            whitelistPanel.Paint = function(self, w, h)
                draw.RoundedBox(4, 0, 0, w, h + 4, menu_dark)
                draw.SimpleText("Skill Tree Access Management", "LSCS_FONT_MEDIUM", 10, 10, menu_text, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
            end

			local whitelistSearch = vgui.Create("DPanel", whitelistPanel)
			whitelistSearch:SetSize(0, 30)
			whitelistSearch:Dock(TOP)
			whitelistSearch:DockMargin(4, 40, 4, 4)
			whitelistSearch.Paint = function(self, w, h)
				draw.RoundedBox(4, 0, 0, w, h, menu_light)
			end

			local whitelistSearchBox = vgui.Create("DTextEntry", whitelistSearch)
			whitelistSearchBox:Dock(FILL)
			whitelistSearchBox:DockMargin(4, 3, 4, 3)
			whitelistSearchBox:SetPlaceholderText("Search skill trees...")
			whitelistSearchBox.Paint = function(self, w, h)
				draw.RoundedBox(4, 0, 0, w, h, menu_dark)
				self:DrawTextEntryText(menu_white, menu_text, menu_white)
				
				if self:GetValue() == "" and not self:HasFocus() then
					draw.SimpleText(self:GetPlaceholderText(), "LSCS_FONT_SMALL", 5, h/2, menu_white_dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				end
			end

			local whitelistScroll = vgui.Create("DScrollPanel", whitelistPanel)
			whitelistScroll:Dock(FILL)
			whitelistScroll:DockMargin(4, 4, 4, 4)

			-- Style the scrollbar
			local scrollBar = whitelistScroll:GetVBar()
			scrollBar:SetWide(8)
			scrollBar.Paint = function(self, w, h)
				draw.RoundedBox(8, 0, 0, w, h, Color(31, 31, 31, 0))
			end
			scrollBar.btnUp.Paint = function(self, w, h)
				draw.RoundedBox(8, 0, 0, w, h, menu_light)
			end
			scrollBar.btnDown.Paint = function(self, w, h)
				draw.RoundedBox(8, 0, 0, w, h, menu_light)
			end
			scrollBar.btnGrip.Paint = function(self, w, h)
				draw.RoundedBox(8, 0, 0, w, h, menu_light)
			end

			-- Function to populate the skill tree list with search filter
			local function PopulateSkillTreeList(searchTerm)
				whitelistScroll:Clear()
				searchTerm = (searchTerm or ""):lower()
				
				local skillTreeList = KyberCore:GetSkillTrees()
				local y = 0
				local visibleCount = 0

				// Loop through every skill, we need to make this indexed, also sort it alphabetically.
				local skillTreeList = {}
				for _, skillTree in pairs(KyberCore:GetSkillTrees()) do
					// Don't put in exclusive trees.
					if skillTree.Exclusive then continue end
					table.insert(skillTreeList, skillTree)
				end

				// Sort the skill trees alphabetically
				table.sort(skillTreeList, function(a, b) return a.Name < b.Name end)
				
				for _, treeData in ipairs(skillTreeList) do
					local treeId = treeData.Name
					local treeName = treeId
					
					-- Apply search filter
					if searchTerm ~= "" and not string.find(string.lower(treeName), searchTerm) then
						continue
					end
					
					visibleCount = visibleCount + 1
					
					-- Create toggle panel for each skill tree
					local togglePanel = vgui.Create("DPanel", whitelistScroll)
					togglePanel:SetSize(0, 40)
					togglePanel:Dock(TOP)
					togglePanel:DockMargin(10, 5, 10, 5)
					
					togglePanel.Paint = function(self, w, h)
						draw.RoundedBox(4, 0, 0, w, h, menu_light)
						draw.SimpleText(treeName, "LSCS_FONT_MEDIUM", 10, h/2, menu_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
					end
					
					local hasAccess = selectedPlayer.KyberCore_Whitelists and selectedPlayer.KyberCore_Whitelists[treeId] or false
					
					local toggle = vgui.Create("DButton", togglePanel)
					toggle:SetSize(100, 30)
					toggle:Dock(RIGHT)
					toggle:DockMargin(0, 5, 10, 5)
					toggle:SetText("")
					
					toggle.Paint = function(self, w, h)
						local color = hasAccess and Color(0, 200, 0, 200) or Color(200, 0, 0, 200)
						draw.RoundedBox(4, 0, 0, w, h, color)
						draw.SimpleText(hasAccess and "Whitelisted" or "Not Whitelisted", "LSCS_FONT_SMALL", 
							w/2, h/2, menu_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
					end
					
					toggle.DoClick = function()
						if not LocalPlayer():IsSuperAdmin() and not KyberCore:IsSystemAdmin(LocalPlayer()) then return end
						hasAccess = not hasAccess
						
						net.Start("KyberCore.WhitelistSkillTree")
							net.WriteEntity(selectedPlayer)
							net.WriteString(treeId)
							net.WriteBool(hasAccess)
						net.SendToServer()
						
						surface.PlaySound("ui/buttonclick.wav")
					end
					
					y = y + 45
				end
				
				-- Show "no results" message if no skill trees match the search
				if visibleCount == 0 and searchTerm ~= "" then
					local noResults = vgui.Create("DPanel", whitelistScroll)
					noResults:SetSize(0, 40)
					noResults:Dock(TOP)
					noResults:DockMargin(10, 5, 10, 5)
					noResults.Paint = function(self, w, h)
						draw.RoundedBox(4, 0, 0, w, h, menu_light)
						draw.SimpleText("No skill trees found matching: \"" .. searchTerm .. "\"", "LSCS_FONT_SMALL", 
							w/2, h/2, menu_white_dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
					end
				end
			end

			-- Initial population
			PopulateSkillTreeList("")

			if selectedPlayer != LocalPlayer() then
				// Fetch the whitelist data from the server
				net.Start("KyberCore.RequestSkillTreeWhitelist")
					net.WriteEntity(selectedPlayer)
				net.SendToServer()
			end

			net.Receive("KyberCore.RequestSkillTreeWhitelist", function(len)
				local whitelistData = net.ReadData(len)
				if not whitelistData then return end

				whitelistData = util.Decompress(whitelistData)
				whitelistData = util.JSONToTable(whitelistData)
				
				-- Update the selected player's whitelist data
				selectedPlayer.KyberCore_Whitelists = whitelistData
				
				-- Populate the skill tree list with the updated data
				PopulateSkillTreeList(whitelistSearchBox:GetValue())
			end)

			-- Update when search changes
			whitelistSearchBox.OnChange = function(self)
				PopulateSkillTreeList(self:GetValue())
			end
            
        elseif activeTab == "inventory" then
			-- Inventory management - main container
			local invContainer = vgui.Create("DPanel", contentArea)
			invContainer:SetSize(0, 400)
			invContainer:Dock(FILL)
			invContainer:DockMargin(0, 0, 0, 0)
			invContainer.Paint = function()
				draw.RoundedBox(4, 0, 0, contentArea:GetWide(), contentArea:GetTall(), menu_light)
			end
			
			-- Split the panel into two parts: player inventory and item selector
			local leftPanel = vgui.Create("DPanel", invContainer)
			leftPanel:SetSize(0, 0)
			leftPanel:Dock(LEFT)
			leftPanel:SetWide(ContentPanel:GetWide() / 3)
			leftPanel.Paint = function() end
			
			local rightPanel = vgui.Create("DPanel", invContainer)
			rightPanel:SetSize(0, 0)
			rightPanel:Dock(FILL)
			rightPanel:DockMargin(8, 0, 0, 0)
			rightPanel.Paint = function() end
			
			-- PLAYER INVENTORY SECTION (LEFT SIDE)
			local invPanel = vgui.Create("DPanel", leftPanel)
			invPanel:Dock(FILL)
			invPanel:DockMargin(0, 0, 0, 0)
			invPanel.Paint = function(self, w, h)
				draw.RoundedBox(4, 0, 0, w, h, menu_dark)
			end
			
			-- Header for player inventory
			local invHeader = vgui.Create("DPanel", invPanel)
			invHeader:SetSize(0, 40)
			invHeader:Dock(TOP)
			invHeader:DockMargin(4, 4, 4, 4)
			invHeader.Paint = function(self, w, h)
				draw.SimpleText("Player Inventory", "LSCS_FONT_MEDIUM", 10, h/2, menu_text, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			end

			local invFilterPanel = vgui.Create("DPanel", invPanel)
			invFilterPanel:SetSize(0, 40)
			invFilterPanel:Dock(TOP)
			invFilterPanel:DockMargin(4, 0, 4, 4)
			invFilterPanel.Paint = function(self, w, h)
				draw.RoundedBox(4, 0, 0, w, h, menu_light)
			end
			
			local invFilterLabel = vgui.Create("DLabel", invFilterPanel)
			invFilterLabel:SetText("Filter: ")
			invFilterLabel:SetFont("LSCS_FONT_SMALL")
			invFilterLabel:SetTextColor(menu_white)
			invFilterLabel:SetSize(40, 30)
			invFilterLabel:SetPos(10, 5)
			
			local invFilterType = vgui.Create("DComboBox", invFilterPanel)
			invFilterType:SetSize(100, 30)
			invFilterType:SetPos(50, 5)
			invFilterType:SetValue("All Types")
			invFilterType:AddChoice("All Types")
			invFilterType:AddChoice("Hilt")
			invFilterType:AddChoice("Crystal")
			
			local invFilterSearch = vgui.Create("DTextEntry", invFilterPanel)
			invFilterSearch:SetSize(120, 30)
			invFilterSearch:SetPos(160, 5)
			invFilterSearch:SetPlaceholderText("Search...")
			invFilterSearch.Paint = function(self, w, h)
				draw.RoundedBox(4, 0, 0, w, h, menu_dark)
				self:DrawTextEntryText(menu_white, menu_text, menu_white)
				
				if self:GetValue() == "" and not self:HasFocus() then
					draw.SimpleText(self:GetPlaceholderText(), "LSCS_FONT_SMALL", 5, h/2, menu_white_dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				end
			end
			
			-- Create inventory scroll panel
			Frame.invScroll = vgui.Create("DScrollPanel", invPanel)
			Frame.invScroll:Dock(FILL)
			Frame.invScroll:DockMargin(4, 4, 4, 4)
			
			-- Style the scrollbar
			local scrollBar = Frame.invScroll:GetVBar()
			scrollBar:SetWide(8)
			scrollBar.Paint = function(self, w, h)
				draw.RoundedBox(8, 0, 0, w, h, Color(31, 31, 31, 0))
			end
			scrollBar.btnUp.Paint = function(self, w, h)
				draw.RoundedBox(8, 0, 0, w, h, menu_light)
			end
			scrollBar.btnDown.Paint = function(self, w, h)
				draw.RoundedBox(8, 0, 0, w, h, menu_light)
			end
			scrollBar.btnGrip.Paint = function(self, w, h)
				draw.RoundedBox(8, 0, 0, w, h, menu_light)
			end

			KyberCoreCachedInventory = {}
			KyberCoreCachedInventoryEquipped = {}
			Frame.invScroll.PopulatePlayerInventory = function(filter, search, inventory, equips)
				filter = filter or "All Types"
				search = (search or ""):lower()
				
				Frame.invScroll:Clear()

				// Placeholder inventory
				if not inventory or table.IsEmpty(inventory) then
					local placeholder = vgui.Create("DPanel", Frame.invScroll)
					placeholder:Dock(TOP)
					placeholder:SetSize(0, 40)
					placeholder:DockMargin(4, 4, 4, 4)
					placeholder.Paint = function(self, w, h)
						draw.SimpleText("No inventory data...", "LSCS_FONT_SMALL", w/2, h/2, menu_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
					end
				else
					-- Get player's inventory and display it in a grid
					local Inventory = inventory or {}
					local equipped = equips or {}
										
					-- Create grid layout
					local X, Y = 8, 8
					local itemCount = 0
					
					-- Check if inventory is empty
					if table.IsEmpty(Inventory) then
						local noItems = vgui.Create("DPanel", Frame.invScroll)
						noItems:SetSize(Frame.invScroll:GetWide() - 16, 80)
						noItems:SetPos(8, 8)
						noItems.Paint = function(self, w, h)
							draw.SimpleText("Player has no items", "LSCS_FONT_MEDIUM", w/2, h/2, menu_white_dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
						end
					else
						for index, class in pairs(Inventory) do
							local itemData = LSCS:ClassToItem(class) or {name = class, Type = "Unknown", type = "Unknown"}
            
							-- Apply type filter
							if filter ~= "All Types" and itemData.type and string.lower(itemData.type) ~= string.lower(filter) then
								continue
							end
							
							-- Apply search filter
							if search ~= "" and not string.find(string.lower(itemData.name or class), search) then
								continue
							end
							
							itemCount = itemCount + 1
							local itemBtn = vgui.Create("DButton", Frame.invScroll)
							itemBtn:SetText("")
							itemBtn:SetSize(80, 80)
							itemBtn:SetPos(X, Y)
							
							-- Set up item data
							itemBtn.itemID = index
							itemBtn.itemClass = class
							itemBtn.itemData = LSCS:ClassToItem(class) or {name = class, Type = "Unknown"}
							itemBtn.equipped = equipped[itemBtn.itemID]

							-- Set item texture
							if file.Exists("materials/entities/"..class..".png", "GAME") then
								itemBtn.texture = Material("entities/"..class..".png")
							else
								itemBtn.texture = Material("debug/debugwireframe")
							end
							
							-- Paint function
							itemBtn.Paint = function(self, w, h)
								-- Draw item background
								draw.RoundedBox(4, 0, 0, w, h, menu_light)
								
								-- Draw item texture
								surface.SetDrawColor(255, 255, 255, 255)
								surface.SetMaterial(self.texture)
								surface.DrawTexturedRect(2, 2, w - 4, h - 4)
								
								-- Show if item is equipped
								local isEquipped = equipped[self.itemID]
								if isEquipped ~= nil then
									surface.SetDrawColor(255, 191, 0, 255)
									surface.DrawOutlinedRect(0, 0, w, h, 2)
									
									-- Indicate which hand for hilts/crystals
									if self.itemData.type == "hilt" or self.itemData.type == "crystal" then
										local handIcon = isEquipped and icon_rhand or icon_lhand
										surface.SetDrawColor(255, 255, 255, 255)
										surface.SetMaterial(handIcon)
										surface.DrawTexturedRect(4, 4, 24, 24)
									else
										surface.SetDrawColor(255, 255, 255, 255)
										surface.SetMaterial(icon_hand)
										surface.DrawTexturedRect(4, 4, 24, 24)
									end
								end
								
								-- Show hover effect
								if self:IsHovered() then
									draw.RoundedBox(4, 0, 0, w, h, Color(255, 255, 255, 30))
								end
								
								-- Draw item name
								local textHeight = h - 16
								draw.RoundedBox(4, 2, textHeight, w - 4, 14, menu_dark)
								draw.SimpleText(self.itemData.name, "LSCS_FONT_SMALL", w/2, textHeight + 7, menu_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
							end
							
							-- Click handling
							itemBtn.DoClick = function(self)
								-- Create context menu
								local menu = DermaMenu()
								
								-- Toggle equipped state
								if itemBtn.equipped ~= nil then
									menu:AddOption("Unequip", function()
										if not LocalPlayer():IsSuperAdmin() and not KyberCore:IsSystemAdmin(LocalPlayer()) then return end
										net.Start("KyberCore.AdminToggleItemEquip")
											net.WriteEntity(selectedPlayer)
											net.WriteInt(self.itemID, 32)
											net.WriteBool(false) // Unequip
											net.WriteBool(false) // Left hand
										net.SendToServer()
										surface.PlaySound("ui/buttonclick.wav")
										
										timer.Simple(0.5, function()
											if IsValid(RefreshButton) then
												RefreshButton:DoClick()
											end
										end)
									end)
								else
									// Equip right hand
									menu:AddOption("Equip Right Hand", function()
										if not LocalPlayer():IsSuperAdmin() and not KyberCore:IsSystemAdmin(LocalPlayer()) then return end
										net.Start("KyberCore.AdminToggleItemEquip")
											net.WriteEntity(selectedPlayer)
											net.WriteInt(self.itemID, 32)
											net.WriteBool(true) // Right hand
											net.WriteBool(true) // Right hand
										net.SendToServer()
										surface.PlaySound("ui/buttonclick.wav")
										
										timer.Simple(0.5, function()
											if IsValid(RefreshButton) then
												RefreshButton:DoClick()
											end
										end)
									end)

									// Equip left hand
									menu:AddOption("Equip Left Hand", function()
										if not LocalPlayer():IsSuperAdmin() and not KyberCore:IsSystemAdmin(LocalPlayer()) then return end
										
										net.Start("KyberCore.AdminToggleItemEquip")
											net.WriteEntity(selectedPlayer)
											net.WriteInt(self.itemID, 32)
											net.WriteBool(true) // Left hand
											net.WriteBool(false) // Left hand
										net.SendToServer()
										surface.PlaySound("ui/buttonclick.wav")
										
										timer.Simple(0.5, function()
											if IsValid(RefreshButton) then
												RefreshButton:DoClick()
											end
										end)
									end)
								end

								-- Add option to remove this item
								menu:AddOption("Remove Item", function()
									if not LocalPlayer():IsSuperAdmin() and not KyberCore:IsSystemAdmin(LocalPlayer()) then return end
									net.Start("KyberCore.AdminRemoveItem")
										net.WriteEntity(selectedPlayer)
										net.WriteInt(self.itemID, 32)
									net.SendToServer()
									surface.PlaySound("ui/buttonclick.wav")

									timer.Simple(0.5, function()
										if IsValid(RefreshButton) then
											RefreshButton:DoClick()
										end
									end)
								end)
								
								menu:Open()
							end
							
							-- Update grid position for next item
							X = X + 80
							if X > (Frame.invScroll:GetWide() - 80) then
								X = 8
								Y = Y + 80
							end
						end

						if itemCount == 0 then
							local noResults = vgui.Create("DPanel", Frame.invScroll)
							noResults:SetSize(Frame.invScroll:GetWide() - 16, 80)
							noResults:SetPos(8, 8)
							noResults.Paint = function(self, w, h)
								draw.SimpleText("No items match your search", "LSCS_FONT_MEDIUM", w/2, h/2, menu_white_dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
							end
						end
					end
				end
			end

			invFilterType.OnSelect = function(self, index, value)
				Frame.invScroll.PopulatePlayerInventory(value, invFilterSearch:GetValue(), KyberCoreCachedInventory, KyberCoreCachedInventoryEquipped)
			end
			
			invFilterSearch.OnChange = function(self)
				Frame.invScroll.PopulatePlayerInventory(invFilterType:GetValue(), self:GetValue(), KyberCoreCachedInventory, KyberCoreCachedInventoryEquipped)
			end
			
			-- Add action buttons for batch operations
			local actionPanel = vgui.Create("DPanel", leftPanel)
			actionPanel:SetSize(0, 50)
			actionPanel:Dock(BOTTOM)
			actionPanel:DockMargin(0, 8, 0, 0)
			actionPanel.Paint = function(self, w, h)
				draw.RoundedBox(4, 0, 0, w, h, menu_dark)
			end
			
			local clearButton = vgui.Create("DButton", actionPanel)
			clearButton:SetText("")
			clearButton:SetSize(140, 40)
			clearButton:Dock(LEFT)
			clearButton:DockMargin(5, 5, 5, 5)
			clearButton.Paint = function(self, w, h)
				local col = self:IsHovered() and Color(200, 50, 50) or Color(150, 50, 50)
				draw.RoundedBox(4, 0, 0, w, h, col)
				draw.SimpleText("Clear Inventory", "LSCS_FONT_SMALL", w/2, h/2, menu_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
			
			clearButton.DoClick = function()
				if not LocalPlayer():IsSuperAdmin() and not KyberCore:IsSystemAdmin(LocalPlayer()) then return end
				net.Start("KyberCore.AdminClearInventory")
					net.WriteEntity(selectedPlayer)
				net.SendToServer()
				surface.PlaySound("ui/buttonclick.wav")
				
				timer.Simple(0.5, function()
					if IsValid(RefreshButton) then
						RefreshButton:DoClick()
					end
				end)
			end
			
			local unequipAllButton = vgui.Create("DButton", actionPanel)
			unequipAllButton:SetText("")
			unequipAllButton:SetSize(140, 40)
			unequipAllButton:Dock(LEFT)
			unequipAllButton:DockMargin(5, 5, 5, 5)
			unequipAllButton.Paint = function(self, w, h)
				local col = self:IsHovered() and menu_text or menu_dark
				draw.RoundedBox(4, 0, 0, w, h, col)
				draw.SimpleText("Unequip All", "LSCS_FONT_SMALL", w/2, h/2, menu_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
			
			unequipAllButton.DoClick = function()
				if not LocalPlayer():IsSuperAdmin() and not KyberCore:IsSystemAdmin(LocalPlayer()) then return end
				net.Start("KyberCore.AdminUnequipAll")
					net.WriteEntity(selectedPlayer)
				net.SendToServer()
				surface.PlaySound("ui/buttonclick.wav")
				
				timer.Simple(0.5, function()
					if IsValid(RefreshButton) then
						RefreshButton:DoClick()
					end
				end)
			end
			
			-- ITEM SELECTOR SECTION (RIGHT SIDE)
			local itemSelectorPanel = vgui.Create("DPanel", rightPanel)
			itemSelectorPanel:Dock(FILL)
			itemSelectorPanel.Paint = function(self, w, h)
				draw.RoundedBox(4, 0, 0, w, h, menu_dark)
			end
			
			-- Header for item selector
			local selectorHeader = vgui.Create("DPanel", itemSelectorPanel)
			selectorHeader:SetSize(0, 40)
			selectorHeader:Dock(TOP)
			selectorHeader:DockMargin(4, 4, 4, 4)
			selectorHeader.Paint = function(self, w, h)
				draw.SimpleText("Available Items", "LSCS_FONT_MEDIUM", 10, h/2, menu_text, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			end
			
			-- Filter controls
			local filterPanel = vgui.Create("DPanel", itemSelectorPanel)
			filterPanel:SetSize(0, 40)
			filterPanel:Dock(TOP)
			filterPanel:DockMargin(4, 0, 4, 4)
			filterPanel.Paint = function(self, w, h)
				draw.RoundedBox(4, 0, 0, w, h, menu_light)
			end
			
			local filterLabel = vgui.Create("DLabel", filterPanel)
			filterLabel:SetText("Filter: ")
			filterLabel:SetFont("LSCS_FONT_SMALL")
			filterLabel:SetTextColor(menu_white)
			filterLabel:SetSize(40, 30)
			filterLabel:SetPos(10, 5)
			
			local filterType = vgui.Create("DComboBox", filterPanel)
			filterType:SetSize(100, 30)
			filterType:SetPos(50, 5)
			filterType:SetValue("All Types")
			filterType:AddChoice("All Types")
			filterType:AddChoice("Hilt")
			filterType:AddChoice("Crystal")
			
			local filterSearch = vgui.Create("DTextEntry", filterPanel)
			filterSearch:SetSize(120, 30)
			filterSearch:SetPos(160, 5)
			filterSearch:SetPlaceholderText("Search...")
			filterSearch.Paint = function(self, w, h)
				draw.RoundedBox(4, 0, 0, w, h, menu_dark)
				self:DrawTextEntryText(menu_white, menu_text, menu_white)
				
				if self:GetValue() == "" and not self:HasFocus() then
					draw.SimpleText(self:GetPlaceholderText(), "LSCS_FONT_SMALL", 5, h/2, menu_white_dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				end
			end
			
			-- Create item grid
			local itemScroll = vgui.Create("DScrollPanel", itemSelectorPanel)
			itemScroll:Dock(FILL)
			itemScroll:DockMargin(4, 4, 4, 4)
			
			-- Style the scrollbar
			local itemScrollBar = itemScroll:GetVBar()
			itemScrollBar:SetWide(8)
			itemScrollBar.Paint = function(self, w, h)
				draw.RoundedBox(8, 0, 0, w, h, Color(31, 31, 31, 0))
			end
			itemScrollBar.btnUp.Paint = function(self, w, h)
				draw.RoundedBox(8, 0, 0, w, h, menu_light)
			end
			itemScrollBar.btnDown.Paint = function(self, w, h)
				draw.RoundedBox(8, 0, 0, w, h, menu_light)
			end
			itemScrollBar.btnGrip.Paint = function(self, w, h)
				draw.RoundedBox(8, 0, 0, w, h, menu_light)
			end
			
			-- Populate item grid with available items
			local function PopulateItemGrid(filter, search)
				filter = filter or "All Types"
				search = (search or ""):lower()
				
				itemScroll:Clear()
				
				local gridSizeX = math.floor((itemScroll:GetWide() - 16) / 80)
				local X, Y = 8, 8

				// Merge LSCS.Blade and LSCS.Hilt tables for item listing
				local itemList = {}
				for id, item in pairs(LSCS.Blade) do
					itemList[id] = item
				end
				for id, item in pairs(LSCS.Hilt) do
					itemList[id] = item
				end
				
				for id, item in pairs(itemList) do
					-- Skip if no class defined
					if not item.class then continue end
					
					-- Apply type filter
					if filter ~= "All Types" and item.type and string.lower(item.type) ~= string.lower(filter) then
						continue
					end
					
					-- Apply search filter
					if search ~= "" and not string.find(string.lower(item.name or ""), search) then
						continue
					end
					
					local itemBtn = vgui.Create("DButton", itemScroll)
					itemBtn:SetText("")
					itemBtn:SetSize(80, 80)
					itemBtn:SetPos(X, Y)
					
					-- Set up item data
					itemBtn.itemID = id
					itemBtn.itemClass = item.class
					itemBtn.itemData = item
					
					-- Set item texture
					if file.Exists("materials/entities/"..item.class..".png", "GAME") then
						itemBtn.texture = Material("entities/"..item.class..".png")
					else
						itemBtn.texture = Material("debug/debugwireframe")
					end
					
					-- Paint function
					itemBtn.Paint = function(self, w, h)
						-- Draw item background
						draw.RoundedBox(4, 0, 0, w, h, menu_light)
						
						-- Draw item texture
						surface.SetDrawColor(255, 255, 255, 255)
						surface.SetMaterial(self.texture)
						surface.DrawTexturedRect(2, 2, w - 4, h - 4)
						
						-- Show hover effect
						if self:IsHovered() then
							draw.RoundedBox(4, 0, 0, w, h, Color(255, 255, 255, 30))
							
							-- Pulsing outline when hovered
							local pulse = math.abs(math.sin(CurTime() * 3)) * 255
							surface.SetDrawColor(255, 255, 255, pulse)
							surface.DrawOutlinedRect(0, 0, w, h, 1)
						end
						
						-- Draw item type indicator
						if item.type then
							local typeColor = menu_dark
							
							-- Different colors for different item types
							if item.type == "hilt" then
								typeColor = Color(255, 150, 0, 200)
							elseif item.type == "crystal" then
								typeColor = Color(0, 150, 255, 200)
							elseif item.type == "force" then
								typeColor = Color(150, 0, 255, 200)
							elseif item.type == "stance" then
								typeColor = Color(0, 255, 150, 200)
							end
							
							draw.RoundedBox(4, 4, 4, 24, 14, typeColor)
							draw.SimpleText(item.type:sub(1,1):upper(), "LSCS_FONT_SMALL", 16, 11, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
						end
						
						-- Draw item name
						local textHeight = h - 16
						draw.RoundedBox(4, 2, textHeight, w - 4, 14, menu_dark)
						draw.SimpleText(self.itemData.name, "LSCS_FONT_SMALL", w/2, textHeight + 7, menu_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
					end
					
					-- Click handling - give item to player
					itemBtn.DoClick = function(self)
						-- Give item
						if not LocalPlayer():IsSuperAdmin() and not KyberCore:IsSystemAdmin(LocalPlayer()) then return end
						net.Start("KyberCore.AdminGiveItem")
							net.WriteEntity(selectedPlayer)
							net.WriteString(self.itemClass)
						net.SendToServer()
						surface.PlaySound("ui/buttonclick.wav")
						
						-- Visual feedback
						local flash = vgui.Create("DPanel", itemBtn)
						flash:SetSize(80, 80)
						flash:SetPos(0, 0)
						flash.Paint = function(s, w, h)
							local alpha = 255 - (s.startTime and (CurTime() - s.startTime) * 510 or 0)
							if alpha <= 0 then s:Remove() return end
							draw.RoundedBox(4, 0, 0, w, h, Color(255, 255, 255, alpha))
						end

						timer.Simple(0.5, function()
							if IsValid(RefreshButton) then
								RefreshButton:DoClick()
							end
						end)
					end
					
					-- Update grid position for next item
					X = X + 80
					if X > (itemScroll:GetWide() - 80) then
						X = 8
						Y = Y + 80
					end
				end
			end
			
			-- Initialize grid with all items
			timer.Simple(0.05, function()
				if IsValid(Frame.invScroll) and IsValid(itemScroll) then
					Frame.invScroll.PopulatePlayerInventory("All Types", "", KyberCoreCachedInventory, KyberCoreCachedInventoryEquipped)
					PopulateItemGrid()
				end
			end)

			net.Start("KyberCore.RequestInventory")
				net.WriteEntity(selectedPlayer)
			net.SendToServer()
			
			-- Apply filters when changed
			filterType.OnSelect = function(self, index, value)
				PopulateItemGrid(value, filterSearch:GetValue())
			end
			
			filterSearch.OnChange = function(self)
				PopulateItemGrid(filterType:GetValue(), self:GetValue())
			end
        elseif activeTab == "progression" then
            -- Progression management
            local progPanel = vgui.Create("DPanel", contentArea)
            progPanel:SetSize(0, 250)
            progPanel:Dock(TOP)
            
            progPanel.Paint = function(self, w, h)
                draw.RoundedBox(4, 0, 0, w, h, menu_dark)
                draw.SimpleText("Progression Management", "LSCS_FONT_MEDIUM", 10, 10, menu_text, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
                
                -- Current values
                local level = selectedPlayer:GetNWInt("KC_EXP_LEVEL", 1)
                local xp = selectedPlayer:GetNWInt("KC_EXP", 0)
                local points = selectedPlayer:GetNWInt("KC_EXP_POINTS", 0)
            end
            
            -- XP Management
            local xpPanel = vgui.Create("DPanel", progPanel)
            xpPanel:SetSize(0, 50)
            xpPanel:SetPos(10, 110)
            xpPanel:Dock(TOP)
            xpPanel:DockMargin(10, 30, 10, 5)
            
            xpPanel.Paint = function(self, w, h)
                draw.RoundedBox(4, 0, 0, w, h, menu_light)
                draw.SimpleText("XP:", "LSCS_FONT_SMALL", 10, h/2, menu_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
            end
            
            local xpEntry = vgui.Create("DNumberWang", xpPanel)
            xpEntry:SetSize(100, 30)
            xpEntry:SetPos(50, 10)
            xpEntry:SetMinMax(0, 1000000)
            xpEntry:SetValue(0)
            
            local xpAddButton = vgui.Create("DButton", xpPanel)
            xpAddButton:SetSize(80, 30)
            xpAddButton:SetPos(160, 10)
            xpAddButton:SetText("")
            
            xpAddButton.Paint = function(self, w, h)
                local col = self:IsHovered() and menu_text or menu_dark
                draw.RoundedBox(4, 0, 0, w, h, col)
                draw.SimpleText("Add", "LSCS_FONT_SMALL", w/2, h/2, menu_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            end
            
            xpAddButton.DoClick = function()
				if not LocalPlayer():IsSuperAdmin() and not KyberCore:IsSystemAdmin(LocalPlayer()) then return end
                net.Start("KyberCore.AdminAddXP")
                    net.WriteEntity(selectedPlayer)
                    net.WriteInt(xpEntry:GetValue(), 32)
                    net.WriteBool(true) -- Add
                net.SendToServer()
                surface.PlaySound("ui/buttonclick.wav")
            end
            
            local xpSetButton = vgui.Create("DButton", xpPanel)
            xpSetButton:SetSize(80, 30)
            xpSetButton:SetPos(250, 10)
            xpSetButton:SetText("")
            
            xpSetButton.Paint = function(self, w, h)
                local col = self:IsHovered() and menu_text or menu_dark
                draw.RoundedBox(4, 0, 0, w, h, col)
                draw.SimpleText("Set", "LSCS_FONT_SMALL", w/2, h/2, menu_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            end
            
            xpSetButton.DoClick = function()
				if not LocalPlayer():IsSuperAdmin() and not KyberCore:IsSystemAdmin(LocalPlayer()) then return end
                net.Start("KyberCore.AdminSetXP")
                    net.WriteEntity(selectedPlayer)
                    net.WriteInt(xpEntry:GetValue(), 32)
                net.SendToServer()
                surface.PlaySound("ui/buttonclick.wav")
            end
            
            -- Level Management
            local levelPanel = vgui.Create("DPanel", progPanel)
            levelPanel:SetSize(0, 50)
            levelPanel:Dock(TOP)
            levelPanel:DockMargin(10, 5, 10, 5)
            
            levelPanel.Paint = function(self, w, h)
                draw.RoundedBox(4, 0, 0, w, h, menu_light)
                draw.SimpleText("Level:", "LSCS_FONT_SMALL", 10, h/2, menu_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
            end
            
            local levelEntry = vgui.Create("DNumberWang", levelPanel)
            levelEntry:SetSize(100, 30)
            levelEntry:SetPos(50, 10)
            levelEntry:SetMinMax(1, 9999)
            levelEntry:SetValue(1)

			local levelAddButton = vgui.Create("DButton", levelPanel)
			levelAddButton:SetSize(80, 30)
			levelAddButton:SetPos(160, 10)
			levelAddButton:SetText("")
			
			levelAddButton.Paint = function(self, w, h)
				local col = self:IsHovered() and menu_text or menu_dark
				draw.RoundedBox(4, 0, 0, w, h, col)
				draw.SimpleText("Add", "LSCS_FONT_SMALL", w/2, h/2, menu_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
			
			levelAddButton.DoClick = function()
				if not LocalPlayer():IsSuperAdmin() and not KyberCore:IsSystemAdmin(LocalPlayer()) then return end
				net.Start("KyberCore.AdminAddLevel")
					net.WriteEntity(selectedPlayer)
					net.WriteInt(levelEntry:GetValue(), 32)
				net.SendToServer()
				surface.PlaySound("ui/buttonclick.wav")
			end
			
			local levelSetButton = vgui.Create("DButton", levelPanel)
			levelSetButton:SetSize(80, 30)
			levelSetButton:SetPos(250, 10)
			levelSetButton:SetText("")

			levelSetButton.Paint = function(self, w, h)
				local col = self:IsHovered() and menu_text or menu_dark
				draw.RoundedBox(4, 0, 0, w, h, col)
				draw.SimpleText("Set", "LSCS_FONT_SMALL", w/2, h/2, menu_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end

			levelSetButton.DoClick = function()
				if not LocalPlayer():IsSuperAdmin() and not KyberCore:IsSystemAdmin(LocalPlayer()) then return end
				net.Start("KyberCore.AdminSetLevel")
					net.WriteEntity(selectedPlayer)
					net.WriteInt(levelEntry:GetValue(), 32)
				net.SendToServer()
				surface.PlaySound("ui/buttonclick.wav")
			end
            
            -- Skill Points Management
            local pointsPanel = vgui.Create("DPanel", progPanel)
            pointsPanel:SetSize(0, 50)
            pointsPanel:Dock(TOP)
            pointsPanel:DockMargin(10, 5, 10, 5)
            
            pointsPanel.Paint = function(self, w, h)
                draw.RoundedBox(4, 0, 0, w, h, menu_light)
                draw.SimpleText("Points:", "LSCS_FONT_SMALL", 10, h/2, menu_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
            end
            
            local pointsEntry = vgui.Create("DNumberWang", pointsPanel)
            pointsEntry:SetSize(100, 30)
            pointsEntry:SetPos(50, 10)
            pointsEntry:SetMinMax(0, 9999)
            pointsEntry:SetValue(0)
            
            local pointsAddButton = vgui.Create("DButton", pointsPanel)
            pointsAddButton:SetSize(80, 30)
            pointsAddButton:SetPos(160, 10)
            pointsAddButton:SetText("")
            
            pointsAddButton.Paint = function(self, w, h)
                local col = self:IsHovered() and menu_text or menu_dark
                draw.RoundedBox(4, 0, 0, w, h, col)
                draw.SimpleText("Add", "LSCS_FONT_SMALL", w/2, h/2, menu_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            end
            
            pointsAddButton.DoClick = function()
				if not LocalPlayer():IsSuperAdmin() and not KyberCore:IsSystemAdmin(LocalPlayer()) then return end
                net.Start("KyberCore.AdminAddPoints")
                    net.WriteEntity(selectedPlayer)
                    net.WriteInt(pointsEntry:GetValue(), 32)
                    net.WriteBool(true) -- Add
                net.SendToServer()
                surface.PlaySound("ui/buttonclick.wav")
            end
            
            local pointsSetButton = vgui.Create("DButton", pointsPanel)
            pointsSetButton:SetSize(80, 30)
            pointsSetButton:SetPos(250, 10)
            pointsSetButton:SetText("")
            
            pointsSetButton.Paint = function(self, w, h)
                local col = self:IsHovered() and menu_text or menu_dark
                draw.RoundedBox(4, 0, 0, w, h, col)
                draw.SimpleText("Set", "LSCS_FONT_SMALL", w/2, h/2, menu_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            end
            
            pointsSetButton.DoClick = function()
				if not LocalPlayer():IsSuperAdmin() and not KyberCore:IsSystemAdmin(LocalPlayer()) then return end
                net.Start("KyberCore.AdminSetPoints")
                    net.WriteEntity(selectedPlayer)
                    net.WriteInt(pointsEntry:GetValue(), 32)
                net.SendToServer()
                surface.PlaySound("ui/buttonclick.wav")
            end
            
		elseif activeTab == "admin" then
			-- Admin management panel
			local adminPanelContainer = vgui.Create("DPanel", contentArea)
			adminPanelContainer:Dock(FILL)
			adminPanelContainer:SetSize(0, 750)
			adminPanelContainer:DockMargin(0, 0, 0, 0)
			adminPanelContainer.Paint = function() end

			local adminPanelScroll = vgui.Create("DScrollPanel", adminPanelContainer)
			adminPanelScroll:Dock(FILL)
			adminPanelScroll:DockMargin(0, 0, 8, 0)
			adminPanelScroll.Paint = function() end

			local scrollBar = adminPanelScroll:GetVBar()
			scrollBar:SetWide(8)
			scrollBar.Paint = function(self, w, h) draw.RoundedBox(8, 0, 0, w, h, Color(31, 31, 31, 0)) end
			scrollBar.btnUp.Paint = function(self, w, h) draw.RoundedBox(8, 0, 0, w, h, menu_light) end
			scrollBar.btnDown.Paint = function(self, w, h) draw.RoundedBox(8, 0, 0, w, h, menu_light) end
			scrollBar.btnGrip.Paint = function(self, w, h) draw.RoundedBox(8, 0, 0, w, h, menu_light) end

			-- Bottom action panel for the selected player
			local actionPanel = vgui.Create("DPanel", adminPanelContainer)
			actionPanel:SetSize(0, 70)
			actionPanel:Dock(TOP)
			actionPanel:DockMargin(0, 8, 0, 0)
			actionPanel.Paint = function(self, w, h)
				draw.RoundedBox(4, 0, 0, w, h, menu_dark)
				
				-- Display selected player info or instructions
				if IsValid(selectedPlayer) then
					draw.SimpleText("Selected: " .. selectedPlayer:Nick(), "LSCS_FONT_MEDIUM", 16, h/2, menu_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				else
					draw.SimpleText("Select a player to grant/revoke admin privileges", "LSCS_FONT_MEDIUM", 16, h/2, menu_white_dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				end
			end

			-- Add toggle admin button
			if IsValid(selectedPlayer) then
				local isAdmin = (KyberCore.Admins and KyberCore.Admins[selectedPlayer:SteamID64()]) or false
				
				local toggleBtn = vgui.Create("DButton", actionPanel)
				toggleBtn:SetSize(200, 50)
				toggleBtn:Dock(RIGHT)
				toggleBtn:DockMargin(0, 10, 10, 10)
				toggleBtn:SetText("")
				toggleBtn.Paint = function(self, w, h)
					local status = isAdmin
					isAdmin = (KyberCore.Admins and KyberCore.Admins[selectedPlayer:SteamID64()]) or false
					local text = status and "REVOKE" or "GRANT"
					local color = status and Color(200, 50, 50) or Color(50, 200, 50)
					
					if self:IsHovered() then
						color = Color(color.r * 1.2, color.g * 1.2, color.b * 1.2)
					end
					
					draw.RoundedBox(4, 0, 0, w, h, color)
					draw.SimpleText(text, "LSCS_FONT", w/2, h/2, menu_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
					
					-- Pulsing effect when hovered
					if self:IsHovered() then
						local pulse = math.abs(math.sin(CurTime() * 3)) * 2
						surface.SetDrawColor(255, 255, 255, 30 + pulse * 20)
						surface.DrawOutlinedRect(0, 0, w, h, 2)
					end
				end
				
				toggleBtn.DoClick = function()
					if not LocalPlayer():IsSuperAdmin() and not KyberCore:IsSystemAdmin(LocalPlayer()) then return end
					net.Start("KyberCore.ToggleAdminAccess")
						net.WriteString(selectedPlayer:SteamID64())
						net.WriteBool(!isAdmin)
					net.SendToServer()
					
					surface.PlaySound("ui/buttonclick.wav")
					
					-- Refresh the tabs after a short delay
					timer.Simple(0.5, function()
						if IsValid(RefreshButton) then
							RefreshButton:DoClick()
						end
					end)
				end
			end
			
			local adminHeaderPanel = vgui.Create("DPanel", adminPanelScroll)
			adminHeaderPanel:SetSize(0, 50)
			adminHeaderPanel:Dock(TOP)
			adminHeaderPanel:DockMargin(0, 0, 0, 8)
			adminHeaderPanel.Paint = function(self, w, h)
				draw.RoundedBox(4, 0, 0, w, h, menu_dark)
				
				-- Count number of admins
				local adminCount = 0
				if KyberCore.Admins then
					for _, _ in pairs(KyberCore.Admins) do
						adminCount = adminCount + 1
					end
				end
				
				draw.SimpleText("Current Admins (" .. adminCount .. ")", "LSCS_FONT", 16, h/2, menu_text, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			end


			local adminSearchPanel = vgui.Create("DPanel", adminPanelContainer)
			adminSearchPanel:SetSize(0, 40)
			adminSearchPanel:Dock(TOP)
			adminSearchPanel:DockMargin(8, 4, 8, 8)
			adminSearchPanel.Paint = function(self, w, h)
				draw.RoundedBox(4, 0, 0, w, h, menu_light)
			end

			local adminSearchBox = vgui.Create("DTextEntry", adminSearchPanel)
			adminSearchBox:Dock(FILL)
			adminSearchBox:DockMargin(8, 5, 8, 5)
			adminSearchBox:SetPlaceholderText("Search admins by name or SteamID...")
			adminSearchBox.Paint = function(self, w, h)
				draw.RoundedBox(4, 0, 0, w, h, menu_dark)
				self:DrawTextEntryText(menu_white, menu_text, menu_white)
				
				if self:GetValue() == "" and not self:HasFocus() then
					draw.SimpleText(self:GetPlaceholderText(), "LSCS_FONT_SMALL", 5, h/2, menu_white_dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				end
			end

			local function DoesNameMatch(name, searchTerm)
				return string.find(name:lower(), searchTerm:lower()) ~= nil
			end
			
			local function DisplayAdmins(searchTerm)
				// Clear previous admin entries except for adminSearchPanel
				adminPanelScroll:Clear()

				if not KyberCore.Admins or table.IsEmpty(KyberCore.Admins) then
					local noAdminsPanel = vgui.Create("DPanel", adminPanelScroll)
					noAdminsPanel:SetSize(0, 50)
					noAdminsPanel:Dock(TOP)
					noAdminsPanel:DockMargin(8, 8, 8, 4)
					noAdminsPanel.Paint = function(self, w, h)
						draw.RoundedBox(4, 0, 0, w, h, menu_light)
						draw.SimpleText("No administrators found", "LSCS_FONT_MEDIUM", w/2, h/2, menu_white_dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
					end

					return
				end

				-- Create a sorted list of admins
				local adminList = {}
				
				-- Online admins first, then offline
				local onlineAdmins = {}
				local offlineAdmins = {}
				
				for steamID, _ in pairs(KyberCore.Admins) do
					local ply = player.GetBySteamID64(steamID)
					
					if IsValid(ply) then
						if searchTerm and searchTerm ~= "" then
							-- Check if the name or SteamID matches the search term
							if not DoesNameMatch(ply:Nick(), searchTerm) and not DoesNameMatch(steamID, searchTerm) then
								continue
							end
						end

						-- Online admin
						table.insert(onlineAdmins, {
							steamID = steamID,
							name = ply:Nick(),
							online = true,
							player = ply
						})
					else
						local fetchingAdmins = {}

						-- Offline admin - get Steam name
						table.insert(fetchingAdmins, {
							steamID = steamID,
							name = "Loading...",
							online = false
						})
						
						-- Request Steam name
						steamworks.RequestPlayerInfo(steamID, function(name)
							for _, admin in ipairs(fetchingAdmins) do
								if admin.steamID == steamID then
									admin.name = name or "Unknown"
									// If the name matches the search term, add to the list
									if searchTerm and searchTerm ~= "" then
										if DoesNameMatch(admin.name, searchTerm) or DoesNameMatch(admin.steamID, searchTerm) then
											table.insert(offlineAdmins, admin)
										end
									else
										table.insert(offlineAdmins, admin)
									end
								end
							end
						end)
					end
				end
				
				-- Sort each list alphabetically
				table.sort(onlineAdmins, function(a, b) return a.name < b.name end)
				table.sort(offlineAdmins, function(a, b) return a.name < b.name end)
				
				-- Combine the lists with online first
				adminList = {}
				for _, admin in ipairs(onlineAdmins) do
					table.insert(adminList, admin)
				end
				for _, admin in ipairs(offlineAdmins) do
					table.insert(adminList, admin)
				end
				
				-- Category for online admins
				if #onlineAdmins > 0 then
					local onlineCategoryPanel = vgui.Create("DPanel", adminPanelScroll)
					onlineCategoryPanel:SetSize(0, 30)
					onlineCategoryPanel:Dock(TOP)
					onlineCategoryPanel:DockMargin(8, 8, 8, 4)
					onlineCategoryPanel.Paint = function(self, w, h)
						-- Animated highlight
						local pulseVal = math.abs(math.sin(CurTime() * 1.5)) * 20
						surface.SetDrawColor(0, 127 + pulseVal, 255, 30 + pulseVal)
						surface.DrawRect(0, 0, w, h)
						
						draw.RoundedBox(4, 0, 0, w, h, Color(46, 71, 93, 200))
						draw.SimpleText("Online Administrators (" .. #onlineAdmins .. ")", "LSCS_FONT_MEDIUM", 10, h/2, Color(0, 255, 127), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
					end
				end
				
				-- Add online admin entries
				for _, adminData in ipairs(onlineAdmins) do
					local adminPanel = vgui.Create("DPanel", adminPanelScroll)
					adminPanel:SetSize(0, 50)
					adminPanel:Dock(TOP)
					adminPanel:DockMargin(8, 4, 8, 4)
					adminPanel.IsAdminPanel = true
					adminPanel.Paint = function(self, w, h)
						draw.RoundedBox(4, 0, 0, w, h, menu_light)
						
						-- Highlight if hovered
						if self:IsHovered() then
							draw.RoundedBox(4, 1, 1, w-2, h-2, Color(0, 127, 255, 40))
							surface.SetDrawColor(0, 127, 255, 100 + math.abs(math.sin(CurTime() * 3)) * 155)
							surface.DrawOutlinedRect(1, 1, w-2, h-2, 1)
						end
						
						draw.SimpleText(adminData.name, "LSCS_FONT_MEDIUM", 50, 15, menu_text, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
						draw.SimpleText(adminData.steamID, "LSCS_FONT_SMALL", 50, 35, menu_white_dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
						
						-- Online indicator
						local indicatorSize = 12
						draw.RoundedBox(indicatorSize/2, w-indicatorSize-10, h/2-indicatorSize/2, indicatorSize, indicatorSize, Color(0, 255, 0))
					end
					
					-- Add avatar
					timer.Simple(0, function()
						if IsValid(adminPanel) then
							local avatar = vgui.Create("AvatarImage", adminPanel)
							avatar:SetSize(40, 40)
							avatar:SetPos(5, 5)
							avatar:SetPlayer(adminData.player, 64)
						end
					end)
					
					-- Remove button
					local removeBtn = vgui.Create("DButton", adminPanel)
					removeBtn:SetSize(80, 30)
					removeBtn:Dock(RIGHT)
					removeBtn:DockMargin(0, 10, 10, 10)
					removeBtn:SetText("")
					removeBtn.Paint = function(self, w, h)
						local col = self:IsHovered() and Color(255, 100, 100) or Color(200, 50, 50)
						draw.RoundedBox(4, 0, 0, w, h, col)
						draw.SimpleText("Remove", "LSCS_FONT_SMALL", w/2, h/2, menu_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
					end
					
					removeBtn.DoClick = function()
						-- Confirm dialog
						local confirmPanel = vgui.Create("DPanel")
						confirmPanel:SetSize(300, 150)
						confirmPanel:SetPos(adminPanelScroll:GetWide()/2 - 150, adminPanelScroll:GetTall()/2 - 75)
						confirmPanel:MakePopup()
						confirmPanel:Center()
						confirmPanel.Paint = function(self, w, h)
							draw.RoundedBox(8, 0, 0, w, h, Color(30, 30, 30, 250))
							draw.SimpleText("Remove Administrator?", "LSCS_FONT", w/2, 30, menu_text, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
							draw.SimpleText("Are you sure you want to remove:", "LSCS_FONT_SMALL", w/2, 60, menu_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
							draw.SimpleText(adminData.name, "LSCS_FONT_MEDIUM", w/2, 80, Color(255, 100, 100), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
						end
						
						-- Yes button
						local yesBtn = vgui.Create("DButton", confirmPanel)
						yesBtn:SetSize(100, 40)
						yesBtn:SetPos(50, 100)
						yesBtn:SetText("")
						yesBtn.Paint = function(self, w, h)
							local col = self:IsHovered() and Color(255, 50, 50) or Color(200, 50, 50)
							draw.RoundedBox(4, 0, 0, w, h, col)
							draw.SimpleText("Yes, Remove", "LSCS_FONT_SMALL", w/2, h/2, menu_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
						end
						
						yesBtn.DoClick = function()
							if not LocalPlayer():IsSuperAdmin() and not KyberCore:IsSystemAdmin(LocalPlayer()) then return end
							net.Start("KyberCore.ToggleAdminAccess")
								net.WriteString(adminData.steamID)
								net.WriteBool(false)
							net.SendToServer()
							
							surface.PlaySound("ui/buttonclick.wav")
							confirmPanel:Remove()
							
							-- Refresh the tabs after a short delay
							timer.Simple(0.5, function()
								if IsValid(RefreshButton) then
									RefreshButton:DoClick()
								end
							end)
						end
						
						-- No button
						local noBtn = vgui.Create("DButton", confirmPanel)
						noBtn:SetSize(100, 40)
						noBtn:SetPos(150, 100)
						noBtn:SetText("")
						noBtn.Paint = function(self, w, h)
							local col = self:IsHovered() and menu_text or menu_dark
							draw.RoundedBox(4, 0, 0, w, h, col)
							draw.SimpleText("Cancel", "LSCS_FONT_SMALL", w/2, h/2, menu_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
						end
						
						noBtn.DoClick = function()
							surface.PlaySound("ui/buttonclick.wav")
							confirmPanel:Remove()
						end
					end
				end
				
				-- Category for offline admins
				if #offlineAdmins > 0 then
					local offlineCategoryPanel = vgui.Create("DPanel", adminPanelScroll)
					offlineCategoryPanel:SetSize(0, 30) 
					offlineCategoryPanel:Dock(TOP)
					offlineCategoryPanel:DockMargin(8, 8, 8, 4)
					offlineCategoryPanel.Paint = function(self, w, h)
						draw.RoundedBox(4, 0, 0, w, h, Color(70, 70, 90, 200))
						draw.SimpleText("Offline Administrators (" .. #offlineAdmins .. ")", "LSCS_FONT_MEDIUM", 10, h/2, Color(180, 180, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
					end
				end
				
				-- Add offline admin entries
				for _, adminData in ipairs(offlineAdmins) do
					local adminPanel = vgui.Create("DPanel", adminPanelScroll)
					adminPanel:SetSize(0, 50)
					adminPanel:Dock(TOP)
					adminPanel:DockMargin(8, 4, 8, 4)
					adminPanel.IsAdminPanel = true
					
					adminPanel.Paint = function(self, w, h)
						draw.RoundedBox(4, 0, 0, w, h, menu_dim) -- Darker for offline
						
						if self:IsHovered() then
							draw.RoundedBox(4, 1, 1, w-2, h-2, Color(100, 100, 130, 40))
							surface.SetDrawColor(100, 100, 130, 100 + math.abs(math.sin(CurTime() * 3)) * 155)
							surface.DrawOutlinedRect(1, 1, w-2, h-2, 1)
						end
						
						draw.SimpleText(adminData.name, "LSCS_FONT_MEDIUM", 50, 15, menu_white_dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
						draw.SimpleText(adminData.steamID, "LSCS_FONT_SMALL", 50, 35, menu_white_dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
						
						-- Offline indicator
						local indicatorSize = 12
						draw.RoundedBox(indicatorSize/2, w-indicatorSize-10, h/2-indicatorSize/2, indicatorSize, indicatorSize, Color(150, 150, 150))
					end

					// Get steam icon from Steam API
					local avatar = vgui.Create("AvatarImage", adminPanel)
					avatar:SetSize(40, 40)
					avatar:SetPos(5, 5)
					avatar:SetSteamID(adminData.steamID, 64)
					
					-- Remove button
					local removeBtn = vgui.Create("DButton", adminPanel)
					removeBtn:SetSize(80, 30)
					removeBtn:Dock(RIGHT)
					removeBtn:DockMargin(0, 10, 10, 10)
					removeBtn:SetText("")
					removeBtn.Paint = function(self, w, h)
						local col = self:IsHovered() and Color(255, 100, 100) or Color(200, 50, 50)
						draw.RoundedBox(4, 0, 0, w, h, col)
						draw.SimpleText("Remove", "LSCS_FONT_SMALL", w/2, h/2, menu_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
					end
					
					removeBtn.DoClick = function()
						local confirmPanel = vgui.Create("DPanel")
						confirmPanel:SetSize(300, 150)
						confirmPanel:SetPos(adminPanelScroll:GetWide()/2 - 150, adminPanelScroll:GetTall()/2 - 75)
						confirmPanel:MakePopup()
						confirmPanel:Center()
						confirmPanel.Paint = function(self, w, h)
							draw.RoundedBox(8, 0, 0, w, h, Color(30, 30, 30, 250))
							draw.SimpleText("Remove Administrator?", "LSCS_FONT", w/2, 30, menu_text, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
							draw.SimpleText("Are you sure you want to remove:", "LSCS_FONT_SMALL", w/2, 60, menu_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
							draw.SimpleText(adminData.name, "LSCS_FONT_MEDIUM", w/2, 80, Color(255, 100, 100), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
						end
						
						local yesBtn = vgui.Create("DButton", confirmPanel)
						yesBtn:SetSize(100, 40)
						yesBtn:SetPos(50, 100)
						yesBtn:SetText("")
						yesBtn.Paint = function(self, w, h)
							local col = self:IsHovered() and Color(255, 50, 50) or Color(200, 50, 50)
							draw.RoundedBox(4, 0, 0, w, h, col)
							draw.SimpleText("Yes, Remove", "LSCS_FONT_SMALL", w/2, h/2, menu_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
						end
						
						yesBtn.DoClick = function()
							if not LocalPlayer():IsSuperAdmin() and not KyberCore:IsSystemAdmin(LocalPlayer()) then return end
							net.Start("KyberCore.ToggleAdminAccess")
								net.WriteString(adminData.steamID)
								net.WriteBool(false)
							net.SendToServer()
							
							surface.PlaySound("ui/buttonclick.wav")
							confirmPanel:Remove()
							
							timer.Simple(0.5, function()
								if IsValid(RefreshButton) then
									RefreshButton:DoClick()
								end
							end)
						end
						
						local noBtn = vgui.Create("DButton", confirmPanel)
						noBtn:SetSize(100, 40)
						noBtn:SetPos(150, 100)
						noBtn:SetText("")
						noBtn.Paint = function(self, w, h)
							local col = self:IsHovered() and menu_text or menu_dark
							draw.RoundedBox(4, 0, 0, w, h, col)
							draw.SimpleText("Cancel", "LSCS_FONT_SMALL", w/2, h/2, menu_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
						end
						
						noBtn.DoClick = function()
							surface.PlaySound("ui/buttonclick.wav")
							confirmPanel:Remove()
						end
					end
				end
			end

			DisplayAdmins("")

			adminSearchBox.OnChange = function(self)
				local searchTerm = self:GetValue()
				DisplayAdmins(searchTerm)
			end
		end
	end
    
    -- Populate the player list initially
    PopulatePlayerList()
    
    -- Set up initial tab
    KyberCoreRefreshTabContent()

    LSCS:SetActivePanel(Panel)
    LSCS:SideBar(Frame)
    Frame.ID = 8
end

net.Receive( "KyberCore.SendInventory", function(len)
	if not IsValid( Frame ) then return end
	if not IsValid( Frame.invScroll ) then return end
    local compressed = net.ReadData( net.ReadUInt( 32 ) )
    local json = util.Decompress(compressed)
    local data = util.JSONToTable(json, nil, false)

	local compressed2 = net.ReadData( net.ReadUInt( 32 ) )
	local json2 = util.Decompress(compressed2)
	local data2 = util.JSONToTable(json2, nil, false)
	if not data then return end
	KyberCoreCachedInventory = data
	KyberCoreCachedInventoryEquipped = data2
	Frame.invScroll.PopulatePlayerInventory("All Types", "", data, data2)
end )

function LSCS:RefreshMenu()
	if not IsValid( Frame ) then return end

	-- if Frame.ID == 2 then
	-- 	LSCS:BuildInventory( Frame )
	-- end
	if Frame.ID == 2 then
		LSCS:BuildSkills( Frame )
	end
	if Frame.ID == 3 then
		LSCS:BuildSaberMenu( Frame )
	end
	if Frame.ID == 4 then
		LSCS:BuildStanceMenu( Frame )
	end
	if Frame.ID == 5 then
		LSCS:BuildForceMenu( Frame )
	end
	if Frame.ID == 6 then
		LSCS:BuildDueling( Frame )
	end
	if Frame.ID == 7 then
		LSCS:BuildSettings( Frame )
	end

	if not LocalPlayer():IsSuperAdmin() and not KyberCore:IsSystemAdmin( LocalPlayer() ) then return end
	
	if Frame.ID == 8 then
		-- LSCS:BuildAdmin( Frame )
	end
end

function LSCS:OpenMenu()
	if not IsValid( Frame ) then
		Frame = vgui.Create( "DFrame" )
		Frame:SetSize( FrameSizeX, FrameSizeY )
		Frame:SetTitle( "" )
		Frame:SetDraggable( true )
		Frame:SetScreenLock( true )
		Frame:MakePopup()
		Frame:Center()

		// Random text
		local texts = {
			"[Kyber Core] - Parry this, casual!",
			"[Kyber Core] - May the force be with you!",
			"[Kyber Core] - uhh yeah ur mom",
			"[Kyber Core] - I am the Senate!",
			"[Kyber Core] - 1% chatgpt",
			"[Kyber Core] - Hello there!",
			"[Kyber Core] - I have the high ground!",
			"[Kyber Core] - I am your father!",
			"[Kyber Core] - I don't like sand. It's coarse and rough and irritating and it gets everywhere.",
			"[Kyber Core] - I find your lack of faith disturbing.",
			"[Kyber Core] - Do or do not, there is no try.",
			"[Kyber Core] - The force is strong with this one.",
			"[Kyber Core] - I have a bad feeling about this.",
			"[Kyber Core] - Roger roger!",
		}

		local randomtext = math.random( 1, #texts )
		randomtext = texts[ randomtext ]

		Frame.Paint = function(self, w, h )
			draw.RoundedBox( 8, 0, 0, w, h, menu_light )
			draw.RoundedBoxEx( 8, 0, 0, w, FrameBarHeight, menu_dark, true, true, false, false)
			draw.SimpleText( randomtext, "LSCS_FONT", 5, 11, menu_white_dim , TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER )
		end
		Frame.GetSideBar = function(self)
			return self.SideBar 
		end
		Frame.SideBarIsActivated = function( self )
			return self._smSB == SelectorWidthActive
		end
		Frame.SideBarIsActive = function( self )
			return self._isActive == true
		end
		Frame.SideBarSetActive = function( self, active )
			self._isActive = active
		end
		Frame.oldThink = Frame.Think
		Frame.Think = function( self )
			self:oldThink()

			local Rate = RealFrameTime() * 1000
			local Active = self:SideBarIsActive()
			local TargetWidth = Active and SelectorWidthActive or SelectorWidth

			local X, Y = self:CursorPos()

			if Active then
				if X < 0 or X > SelectorWidthActive or Y < 0 or Y > FrameSizeY then
					self:SideBarSetActive( false )
				end
			else
				if X > 0 and X < SelectorWidth and Y > 0 and Y < FrameSizeY then
					self:SideBarSetActive( true )
				end
			end

			self._smSB = self._smSB and (self._smSB + math.Clamp(TargetWidth - self._smSB,-Rate,Rate)) or SelectorWidth

			if self._smSB ~= self.old_smSB then
				self.old_smSB = self._smSB

				local SB = self:GetSideBar()
				if IsValid( SB ) then
					SB:SetSize( self._smSB, SelectorHeight )
				end
			end
		end

		LSCS:BuildMainMenu( Frame )
	end
end

-- list.Set( "DesktopWindows", "LSCSMenu", {
-- 	title = "[LSCS] Menu",
-- 	icon = "lscs/ui/icon64.png",
-- 	init = function( icon, window )
-- 		LSCS:OpenMenu()
-- 	end
-- } )

concommand.Add( "lscs_openmenu", function( ply, cmd, args ) LSCS:OpenMenu() end )
