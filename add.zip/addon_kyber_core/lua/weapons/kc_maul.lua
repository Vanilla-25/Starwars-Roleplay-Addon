AddCSLuaFile()

SWEP.Base = "weapon_lscs_preset"
DEFINE_BASECLASS( "weapon_lscs_preset" )

SWEP.Category			= "[LSCS] - A Class Weapons"
SWEP.PrintName		= "Maul Saber"
SWEP.Author			= "Stoneman / Truce"

SWEP.Slot				= 1
SWEP.SlotPos			= 1

SWEP.Spawnable		= true
SWEP.AdminOnly		= false

SWEP.KyberCoreEventSaber = true

SWEP.PresetBlockpoints = 450
SWEP.PresetForce = 350
SWEP.PresetRightHilt = "maul"
SWEP.PresetLeftHilt = ""
SWEP.PresetRightBlade = "br"
SWEP.PresetLeftBlade = ""
SWEP.PresetDeflectBullets = true

// Settings
SWEP.PresetForceAbilities = {
    "lightning",
	"jump_2",
    "jump_3",
    "launch",
    "brazen",
    "reflect",
    "propulsion",
    "diamondstorm",
    "speed",
    "slow",
}

SWEP.PresetStances = {
    "form1",
	"form3",
    "form6",
}