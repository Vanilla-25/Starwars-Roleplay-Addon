
function SWEP:GetBPDrainPerHit()
	return (self:GetCombo().BPDrainPerHit or 25)
end

function SWEP:GetMaxBlockPoints()
	local combo = self:GetCombo()

	// Max blockpoints override takes priority.
	if combo.MaxBlockPoints then
		return combo.MaxBlockPoints + KyberCore:GetBonusBlockPoints(self:GetOwner())
	end

	// Form blockpoints bonus takes second priority.
	if combo.FormBlockPoints then
		return KyberCore.Config.BaseBlockpoints + KyberCore:GetBonusBlockPoints(self:GetOwner()) + combo.FormBlockPoints
	end

	// Otherwise, use default.
	return KyberCore.Config.BaseBlockpoints + KyberCore:GetBonusBlockPoints(self:GetOwner())
end

function SWEP:GetBlockDistanceNormal()
	return (self:GetCombo().BlockDistanceNormal or 60)
end

function SWEP:GetBlockDistancePerfect()
	return (self:GetCombo().BlockDistancePerfect or 20)
end

function SWEP:DrainBP( amount )
	if amount then
		self:SetBlockPoints( math.Clamp( self:GetBlockPoints() - amount,0, self:GetMaxBlockPoints()) )

		if amount > 0 then
			self.NextBPr = CurTime() + 2
		end
	else
		self.NextBPr = CurTime() + 2
	end
end

if SERVER then
	function SWEP:CalcBPRegen( CurTime )
		local ply = self:GetOwner()

		if not IsValid( ply ) then return end

		if (self.NextBPr or 0) < CurTime then
			self.NextBPr = CurTime + (KyberCore.Config.BlockpointRegenDelay or 0.3)

			local MaxVal = self:GetMaxBlockPoints()
			if KyberCore.Config.UseDefaultLSCSBlockpoints then
				if self:GetGestureTime() < CurTime and ply:OnGround() and ply:GetVelocity():Length() < 225 then
					self:SetBlockPoints( self:GetBlockPoints() + math.min(MaxVal - self:GetBlockPoints(),3) )
				else
					if not ply:OnGround() then
						self:DrainBP( 1 )
					end
				end
			else
				if self:GetGestureTime() < CurTime then
					// Have to go through all the config checks..
					local BPRegen = KyberCore.Config.BaseBlockpointRegen or 1
					local RegenerateBlockpointsInAir = KyberCore.Config.RegenerateBlockpointsInAir or false
					local RegenerateBPWhileRunning = KyberCore.Config.RegenerateBPWhileRunning or false
					local Grounded = ply:OnGround()
					local IsRunning = ply:GetVelocity():Length() >= 240
					local shouldRegen = true

					// No regenerating in the air.
					if not RegenerateBlockpointsInAir and not Grounded then
						shouldRegen = false
					end

					// No regenerating while running.
					if not RegenerateBPWhileRunning and IsRunning then
						shouldRegen = false
					end

					if shouldRegen then
						self:SetBlockPoints( math.Clamp( self:GetBlockPoints() + BPRegen, 0, MaxVal ) )
					end
				end

				if (KyberCore.Config.DrainBlockpointsInAir or true) and not ply:OnGround() then
					self:DrainBP( 1 )
				end
			end
		end

		if self._ResetHitTime and self._ResetHitTime < CurTime then
			self._ResetHitTime = CurTime + 1

			self:AddHit( -0.1 )
		end
	end
end