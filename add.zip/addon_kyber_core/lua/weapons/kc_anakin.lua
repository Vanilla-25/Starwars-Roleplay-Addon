AddCSLuaFile()

SWEP.Base = "weapon_lscs_preset"
DEFINE_BASECLASS( "weapon_lscs_preset" )

SWEP.Category			= "[LSCS] - Jedi Lore Characters"
SWEP.PrintName		= "Anakin Saber"
SWEP.Author			= "Vanilla"

SWEP.Slot				= 1
SWEP.SlotPos			= 1

SWEP.Spawnable		= true
SWEP.AdminOnly		= false

SWEP.KyberCoreEventSaber = true

// Weapon settings!!!
SWEP.PresetBlockpoints = 350
SWEP.PresetForce = 250
SWEP.PresetRightHilt = "ash4"
SWEP.PresetLeftHilt = ""
SWEP.PresetRightBlade = "bb"
SWEP.PresetLeftBlade = ""
SWEP.PresetDeflectBullets = true

// Settings
SWEP.PresetForceAbilities = {
    "jump_2",
	"jump_3",
    "pull",
    "push",
    "absorb",
    "reflect",
    "revive",
}

SWEP.PresetStances = {
    "form5",
}