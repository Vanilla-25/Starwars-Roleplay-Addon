AddCSLuaFile()

SWEP.Base = "weapon_lscs"
DEFINE_BASECLASS( "weapon_lscs" )

SWEP.Category			= "[LSCS] - Melee Weapons"
SWEP.PrintName		= "Personal Lightsaber"
SWEP.Author			= "Stoneman"

SWEP.Slot				= 1
SWEP.SlotPos			= 0

SWEP.Spawnable		= true
SWEP.AdminOnly		= true
SWEP.KyberCoreSaberDamage = 200

hook.Add("KyberCore.SyncSkills", "KyberCore.SkillsSyncing", function(ply) KyberCore:LoadPersonalSaber(ply) end)

if SERVER then
    util.AddNetworkString("KyberCore.PersonalSaberDeployed")
end

// Deploy doesn't fucking run on client 95% of the time, but 100% of the time on server.
// This is a hack, but this is to make sure Deploy runs 100% of the time.
net.Receive("KyberCore.PersonalSaberDeployed", function(len)
    local saber = net.ReadEntity()
    if not saber:IsValid() or not saber:IsWeapon() then return end
    saber:OnSaberSpawned()
end)

function SWEP:OnSaberSpawned()
    local ply = self:GetOwner()

    if SERVER then
        net.Start("KyberCore.PersonalSaberDeployed")
            net.WriteEntity(self)
        net.Send(ply)
    end

    self.KyberCoreSaberDamage = KyberCore.Config.BaseSaberDamage

    // Player's progression might not be valid yet when they spawn with this..
    if ply.KyberCore_Skills then
        KyberCore:LoadPersonalSaber(ply)
    end

    local hilt_right, hilt_left = ply:lscsGetHilt()
	local blade_right, blade_left  = ply:lscsGetBlade()
    
	self:SetHiltR( hilt_right or "" )
	self:SetHiltL( hilt_left or "" )
	self:SetBladeR( blade_right or "" )
	self:SetBladeL( blade_left or "" )
end

function SWEP:Deploy()
    if SERVER then
        self:OnSaberSpawned()
    end
end

// This is a hack. Deploy doesn't run for the first time the weapon is created and switched to or when LSCS crafts the lightsaber.
// So, let's just make it run whenever the weapon is created and is.
SWEP.HasSaberSetup = false
function SWEP:SetupThink()
    if not IsValid(self) then return end
    if not self.HasSaberSetup then
        self:OnSaberSpawned()
        self.HasSaberSetup = true
    end
end