AddCSLuaFile()

SWEP.Base = "weapon_lscs_preset"
DEFINE_BASECLASS( "weapon_lscs_preset" )

SWEP.Category			= "[LSCS] - Melee Weapons"
SWEP.PrintName		= "Bo Rifle Staff"
SWEP.Author			= "Stoneman / Truce"

SWEP.Slot				= 1
SWEP.SlotPos			= 1

SWEP.Spawnable		= true
SWEP.AdminOnly		= false

SWEP.KyberCoreEventSaber = true

SWEP.PresetBlockpoints = 100
SWEP.PresetForce = 100
SWEP.PresetRightHilt = "bo_r"
SWEP.PresetLeftHilt = ""
SWEP.PresetRightBlade = "bo_rifle_b"
SWEP.PresetLeftBlade = ""
SWEP.PresetDeflectBullets = false

// Settings
SWEP.PresetForceAbilities = {}

SWEP.PresetStances = {
    "form1",
    "form6",
}