AddCSLuaFile()

SWEP.Base = "weapon_lscs_preset"
DEFINE_BASECLASS( "weapon_lscs_preset" )

SWEP.Category		= "[LSCS] - A Class Weapons"
SWEP.PrintName		= "Asajj Ventress Sabers [A+]"
SWEP.Author			= "Uriel"

SWEP.Slot				= 1
SWEP.SlotPos			= 1

SWEP.Spawnable		= true
SWEP.AdminOnly		= false

SWEP.KyberCoreEventSaber = true

SWEP.PresetBlockpoints = 400
SWEP.PresetForce = 500
SWEP.PresetRightHilt = "ash5"
SWEP.PresetLeftHilt = "ash5"
SWEP.PresetRightBlade = "br"
SWEP.PresetLeftBlade = "br"
SWEP.PresetDeflectBullets = true

// Settings
SWEP.PresetForceAbilities = {
    "jump_2",
	"jump_3",
    "launch",
    "absorb",
    "brazen",
    "reflect",
    "propulsion",
    "diamondstorm",
    "speed",
    "slow",
    "slam",
    "burnout",
    "pulse",
}

SWEP.PresetStances = {
    "formjk",
    "form2",
}