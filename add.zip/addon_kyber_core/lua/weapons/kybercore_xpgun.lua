if SERVER then
	SWEP.Weight				= 5
	SWEP.AutoSwitchTo			= false
	SWEP.AutoSwitchFrom		= false
end

CreateClientConVar( "kybercore_xp_amount", "50", true, true, "The amount of XP to give when using the XP Gun." )
CreateClientConVar( "kybercore_xp_preset1", "10", true, false, "XP Gun preset 1." )
CreateClientConVar( "kybercore_xp_preset2", "25", true, false, "XP Gun preset 2." )
CreateClientConVar( "kybercore_xp_preset3", "50", true, false, "XP Gun preset 3." )
CreateClientConVar( "kybercore_xp_preset4", "75", true, false, "XP Gun preset 4." )
CreateClientConVar( "kybercore_xp_preset5", "100", true, false, "XP Gun preset 5." )

if CLIENT then
	SWEP.PrintName			= "XP Tablet"	
	SWEP.DrawAmmo 			= false
	SWEP.DrawCrosshair 		= false
	SWEP.ViewModelFOV		= 200
	SWEP.ViewModelFlip		= false
	SWEP.CSMuzzleFlashes	= true
	
	SWEP.Slot				= 2
	SWEP.SlotPos			= 1
	SWEP.IconLetter			= "s"
end

SWEP.Category			= "[LSCS] - Tools"

SWEP.Spawnable				= true
SWEP.AdminSpawnable			= true

SWEP.DrawWeaponInfoBox  	= false

SWEP.Weight					= 5
SWEP.AutoSwitchTo				= false
SWEP.AutoSwitchFrom			= false

SWEP.Primary.ClipSize			= -1
SWEP.Primary.Damage			= -1
SWEP.Primary.DefaultClip		= -1
SWEP.Primary.Automatic			= true
SWEP.Primary.Ammo			= "none"


SWEP.Secondary.ClipSize			= -1
SWEP.Secondary.DefaultClip		= -1
SWEP.Secondary.Damage			= -1
SWEP.Secondary.Automatic		= true
SWEP.Secondary.Ammo			= "none"
SWEP.XPMenu = nil

SWEP.UseHands = true

SWEP.HoldType = "slam"
SWEP.ViewModelFOV = 55
SWEP.ViewModelFlip = false
SWEP.ViewModel = "models/joes/c_datapad.mdl"
SWEP.WorldModel = "models/joes/w_datapad.mdl"
SWEP.ShowViewModel = true

function SWEP:Initialize()
	self:SetHoldType(self.HoldType)

    if CLIENT then
        self.SelectedForceUsers = {}
        self.ForceUsers = {}
    end
end

function SWEP:Deploy()
    return true
end

function SWEP:GetViewModelPosition(pos, ang)
	pos = pos - Vector(0,0,3.5)
	return pos, ang
end

function SWEP:PrimaryAttack()
    if not IsFirstTimePredicted() then return end
    local ply = self:GetOwner()
    if not IsValid(ply) then return end
    if not ply:IsSuperAdmin() and not KyberCore:IsSystemAdmin(ply) then return end

    if SERVER then
        local xp = math.Round(ply:GetInfoNum("kybercore_xp_amount", 0), 0)
        local target = ply:GetEyeTrace().Entity

        if target and target:IsValid() and target:IsPlayer() then
            KyberCore:AddXP(target, xp)
            ply:ChatPrint("You gave " .. target:Nick() .. " " .. xp .. " XP!")

            ply:EmitSound("ui/buttonclick.wav")
        end

        self:SetNextPrimaryFire( CurTime() + 0.5 )
    end
end

function SWEP:SecondaryAttack()
    if not IsFirstTimePredicted() then return end
    local ply = self:GetOwner()
    if not IsValid(ply) then return end
    if not ply:IsSuperAdmin() and not KyberCore:IsSystemAdmin(ply) then return end

    if SERVER then
        local xp = math.Round(ply:GetInfoNum("kybercore_xp_amount", 0), 0)

        KyberCore:AddXP(ply, xp)
        ply:ChatPrint("You gave yourself " .. xp .. " XP!")

        ply:EmitSound("ui/buttonclick.wav")

        self:SetNextSecondaryFire( CurTime() + 0.5 )
    end
end

function SWEP:Reload()
    if not IsFirstTimePredicted() then return end

    if CLIENT then
        self:OpenXPMenu()
    end
end

function SWEP:Holster()
    if CLIENT and IsValid(self.XPMenu) then
        self.XPMenu:Remove()
        self.XPMenu = nil
    end
    return true
end

function SWEP:OnRemove()
    if CLIENT and IsValid(self.XPMenu) then
        self.XPMenu:Remove()
        self.XPMenu = nil
    end
end

function SWEP:OpenXPMenu()
    if not IsValid(self:GetOwner()) then return end
    local ply = self:GetOwner()
    if not IsValid(ply) then return end
    if not ply:IsSuperAdmin() and not KyberCore:IsSystemAdmin(ply) then return end

    if self.XPMenu and IsValid(self.XPMenu) then
        self.XPMenu:Remove()
        self.XPMenu = nil
    end

    if not IsValid(self.XPMenu) then
        self.XPMenu = vgui.Create("KyberCore_XPMenu")
        self.XPMenu:SetWeapon(self)
    end
end

if CLIENT then
    local PRIMARY_COLOR = Color(0,127,255,255)
    local ACCENT_COLOR = Color(31,31,31,255)
    local BACKGROUND_COLOR = Color(37,42,64,255)
    local BUTTON_COLOR = Color(59, 66, 82, 220)
    local BUTTON_HOVER_COLOR = Color(68, 77, 95, 220)
    local TEXT_COLOR = Color(255, 255, 255, 255)
    local SUCCESS_COLOR = Color(72, 199, 142, 220)
    local DANGER_COLOR = Color(255, 88, 88, 220)

    local menu_white_dim = Color(100,100,100,255)
    local menu_white = Color(255,255,255,255)
    local menu_dark = Color(24,30,54,255)
    local menu_dim = Color(37,42,64,255)
    local menu_light = Color(46,51,73,255)
    local menu_black = Color(31,31,31,255)
    local menu_text = Color(0,127,255,255)

    -- Font is from LSCS, thanks Luna!
    local THE_FONT = {
        font = "Verdana",
        extended = false,
        size = 20,
        weight = 2000,
        blursize = 0,
        scanlines = 0,
        antialias = true,
        underline = false,
        italic = false,
        strikeout = false,
        symbol = false,
        rotary = false,
        shadow = true,
        additive = false,
        outline = false,
    }

    THE_FONT.size = 24
    THE_FONT.weight = 700
    surface.CreateFont("KyberCore_XPTitle", THE_FONT)

    THE_FONT.size = 14
    THE_FONT.weight = 600
    surface.CreateFont("KyberCore_XPTitleSmall", THE_FONT)
    
    THE_FONT.size = 18
    THE_FONT.weight = 500
    surface.CreateFont("KyberCore_XPButton", THE_FONT)
    
    THE_FONT.size = 16
    THE_FONT.weight = 400
    surface.CreateFont("KyberCore_XPText", THE_FONT)

    local PANEL = {}
    function PANEL:Init()
        local ply = LocalPlayer()

        self:SetSize(400, 500)
        self:Center()
        self:SetTitle("")
        self:SetDraggable(true)
        self:ShowCloseButton(false)
        
        -- Parent weapon reference
        self.Weapon = nil
        
        -- Close button
        local closeBtn = vgui.Create("DButton", self)
        closeBtn:SetSize(30, 30)
        closeBtn:SetPos(self:GetWide() - 35, 5)
        closeBtn:SetText("")
        closeBtn.Paint = function(s, w, h)
            draw.RoundedBox(4, 0, 0, w, h, s:IsHovered() and DANGER_COLOR or Color(0,0,0,0))
            draw.SimpleText("✕", "KyberCore_XPTitle", w/2, h/2, TEXT_COLOR, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
        closeBtn.DoClick = function()
            self:Remove()
        end
        
        -- Current XP amount section
        local amountLabel = vgui.Create("DLabel", self)
        amountLabel:SetPos(20, 60)
        amountLabel:SetSize(360, 25)
        amountLabel:SetFont("KyberCore_XPTitleSmall")
        amountLabel:SetText("XP Amount to Give:")
        amountLabel:SetTextColor(TEXT_COLOR)
        
        local amountSlider = vgui.Create("DNumSlider", self)
        amountSlider:SetPos(20, 85)
        amountSlider:SetSize(360, 50)
        amountSlider:SetMin(0)
        amountSlider:SetMax(10000)
        amountSlider:SetDecimals(0)
        amountSlider:SetValue(ply:GetInfoNum("kybercore_xp_amount", 100))
        amountSlider.TextArea:SetTextColor(TEXT_COLOR)
        amountSlider.Label:SetTextColor(TEXT_COLOR)
        amountSlider.OnValueChanged = function(s, value)
            RunConsoleCommand("kybercore_xp_amount", math.Round(value))
        end
        
        -- Presets section
        local presetsLabel = vgui.Create("DLabel", self)
        presetsLabel:SetPos(20, 145)
        presetsLabel:SetSize(360, 25)
        presetsLabel:SetFont("KyberCore_XPTitleSmall")
        presetsLabel:SetText("Preset Values (Click to use, Right-click to edit):")
        presetsLabel:SetTextColor(TEXT_COLOR)
        
        -- Create preset buttons
        self.presetButtons = {}
        local startY = 180
        
        for i = 1, 5 do
            local preset = vgui.Create("DButton", self)
            preset:SetPos(20 + (i-1) * 74, startY)
            preset:SetSize(64, 64)
            preset:SetText("")
            preset.buttonindex = i
            local presetValue = ply:GetInfoNum("kybercore_xp_preset" .. i, 0)
                        
            preset.Paint = function(s, w, h)
                presetValue = ply:GetInfoNum("kybercore_xp_preset" .. s.buttonindex, 0)
                local col = s:IsHovered() and BUTTON_HOVER_COLOR or BUTTON_COLOR
                draw.RoundedBox(8, 0, 0, w, h, col)
                draw.RoundedBox(8, 2, 2, w-4, h-4, PRIMARY_COLOR)
                draw.SimpleText(presetValue, "LSCS_FONT", w/2, h/2 - 5, TEXT_COLOR, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                draw.SimpleText("Preset " .. s.buttonindex, "LSCS_FONT_SMALL", w/2, h/2 + 15, TEXT_COLOR, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            end
            
            preset.DoClick = function()
                RunConsoleCommand("kybercore_xp_amount", presetValue)
                amountSlider:SetValue(presetValue)
                surface.PlaySound("ui/buttonclickrelease.wav")
            end
            
            preset.DoRightClick = function()
                self:OpenPresetEditor(i, presetValue)
            end
            
            self.presetButtons[i] = preset
        end
        
        -- Action buttons
        local closeButton = vgui.Create("DButton", self)
        closeButton:SetPos(20, 280)
        closeButton:SetSize(360, 40)
        closeButton:SetText("")
        closeButton.Paint = function(s, w, h)
            draw.RoundedBox(8, 0, 0, w, h, s:IsHovered() and BUTTON_HOVER_COLOR or BUTTON_COLOR)
            draw.SimpleText("Close", "KyberCore_XPButton", w/2, h/2, TEXT_COLOR, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end

        closeButton.DoClick = function()
            self:Remove()
        end
        
        local allForceUsersButton = vgui.Create("DButton", self)
        allForceUsersButton:SetPos(20, 330)
        allForceUsersButton:SetSize(360, 40)
        allForceUsersButton:SetText("")
        allForceUsersButton.Paint = function(s, w, h)
            draw.RoundedBox(8, 0, 0, w, h, s:IsHovered() and BUTTON_HOVER_COLOR or BUTTON_COLOR)
            draw.SimpleText("Give to Force Users", "KyberCore_XPButton", w/2, h/2, TEXT_COLOR, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
        
        allForceUsersButton.DoClick = function()
            if IsValid(self.Weapon) then
                self:OpenForceUserMenu()
            end
            surface.PlaySound("ui/buttonclickrelease.wav")
        end
        
        -- Instructions
        local instructions = vgui.Create("DLabel", self)
        instructions:SetPos(20, 400)
        instructions:SetSize(360, 80)
        instructions:SetFont("KyberCore_XPText")
        instructions:SetText("Left-click: Give XP to target player\nRight-click: Give XP to yourself\nR: Open this menu")
        instructions:SetTextColor(TEXT_COLOR)
        instructions:SetContentAlignment(7) -- Top-left aligned
        
        -- Effect
        self:MakePopup()
    end

    function PANEL:Paint(w, h)
        -- Background
        draw.RoundedBox(8, 0, 0, w, h, BACKGROUND_COLOR)
        
        -- Header
        draw.RoundedBoxEx(8, 0, 0, w, 40, PRIMARY_COLOR, true, true, false, false)
        draw.SimpleText("XP Tablet Configuration", "KyberCore_XPTitle", w/2, 20, TEXT_COLOR, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        
        -- Bottom decoration
        draw.RoundedBoxEx(8, 0, h-4, w, 4, ACCENT_COLOR, false, false, true, true)
    end

    function PANEL:SetWeapon(weapon)
        self.Weapon = weapon
    end

    function PANEL:OpenPresetEditor(presetNum, currentValue)
        local editMenu = vgui.Create("DFrame")
        editMenu:SetSize(250, 120)
        editMenu:Center()
        editMenu:SetTitle("Edit Preset " .. presetNum)
        editMenu:MakePopup()
        
        local editEntry = vgui.Create("DTextEntry", editMenu)
        editEntry:SetPos(20, 40)
        editEntry:SetSize(210, 30)
        editEntry:SetValue(currentValue)
        editEntry:SetNumeric(true)
        
        local saveBtn = vgui.Create("DButton", editMenu)
        saveBtn:SetPos(130, 80)
        saveBtn:SetSize(100, 30)
        saveBtn:SetText("Save")
        saveBtn.DoClick = function()
            local newValue = tonumber(editEntry:GetValue()) or 0
            if newValue < 0 then newValue = 0 end
            if newValue > 1000000 then newValue = 1000000 end
            
            RunConsoleCommand("kybercore_xp_preset" .. presetNum, math.Round(newValue))
            
            editMenu:Remove()
            surface.PlaySound("ui/buttonclickrelease.wav")
        end
        
        local cancelBtn = vgui.Create("DButton", editMenu)
        cancelBtn:SetPos(20, 80)
        cancelBtn:SetSize(100, 30)
        cancelBtn:SetText("Cancel")
        cancelBtn.DoClick = function()
            editMenu:Remove()
        end
    end

    function PANEL:OpenForceUserMenu()
        local forceUserMenu = vgui.Create("KyberCore_UserSelector")
        forceUserMenu:SetSize(500, 600)
        forceUserMenu:Center()
        forceUserMenu:SetWeapon(self.Weapon)
        forceUserMenu:MakePopup()
    end

    vgui.Register("KyberCore_XPMenu", PANEL, "DFrame")

    local FORCE_SELECTOR = {}
    
    function FORCE_SELECTOR:Init()
        local ply = LocalPlayer()
        local xpAmount = ply:GetInfoNum("kybercore_xp_amount", 100)
        
        -- Basic setup
        self:SetSize(500, 1000)
        self:Center()
        self:SetTitle("")
        self:SetDraggable(true)
        self:ShowCloseButton(false)
        
        -- Store weapon reference and selected users
        self.Weapon = nil
        self.SelectedForceUsers = {}
        self.ForceUsers = {}
        
        -- Close button
        local closeBtn = vgui.Create("DButton", self)
        closeBtn:SetSize(30, 30)
        closeBtn:SetPos(self:GetWide() - 35, 5)
        closeBtn:SetText("")
        closeBtn.Paint = function(s, w, h)
            draw.RoundedBox(4, 0, 0, w, h, s:IsHovered() and DANGER_COLOR or Color(0,0,0,0))
            draw.SimpleText("✕", "KyberCore_XPButton", w/2, h/2, TEXT_COLOR, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
        closeBtn.DoClick = function()
            self:Remove()
        end
        
        -- Current XP label
        local currentXPLabel = vgui.Create("DLabel", self)
        currentXPLabel:SetPos(20, 50)
        currentXPLabel:SetSize(460, 30)
        currentXPLabel:SetFont("KyberCore_XPButton")
        currentXPLabel:SetText("Giving " .. xpAmount .. " XP to selected users")
        currentXPLabel:SetTextColor(TEXT_COLOR)
        
        -- Find all force users
        self:PopulateForceUsers()
        
        -- Add action buttons
        local selectAllBtn = vgui.Create("DButton", self)
        selectAllBtn:SetPos(20, 500)
        selectAllBtn:SetSize(220, 40)
        selectAllBtn:SetText("")
        selectAllBtn.Paint = function(s, w, h)
            draw.RoundedBox(8, 0, 0, w, h, s:IsHovered() and BUTTON_HOVER_COLOR or BUTTON_COLOR)
            draw.SimpleText("Select All", "KyberCore_XPButton", w/2, h/2, TEXT_COLOR, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
        selectAllBtn.DoClick = function()
            self:SelectAllUsers()
            surface.PlaySound("ui/buttonclick.wav")
        end
        
        local clearSelectionBtn = vgui.Create("DButton", self)
        clearSelectionBtn:SetPos(260, 500)
        clearSelectionBtn:SetSize(220, 40)
        clearSelectionBtn:SetText("")
        clearSelectionBtn.Paint = function(s, w, h)
            draw.RoundedBox(8, 0, 0, w, h, s:IsHovered() and BUTTON_HOVER_COLOR or BUTTON_COLOR)
            draw.SimpleText("Clear Selection", "KyberCore_XPButton", w/2, h/2, TEXT_COLOR, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
        clearSelectionBtn.DoClick = function()
            self.SelectedForceUsers = {}
            surface.PlaySound("ui/buttonclick.wav")
        end
        
        local confirmBtn = vgui.Create("DButton", self)
        confirmBtn:SetPos(20, 550)
        confirmBtn:SetSize(460, 40)
        confirmBtn:SetText("")
        confirmBtn.Paint = function(s, w, h)
            draw.RoundedBox(8, 0, 0, w, h, s:IsHovered() and SUCCESS_COLOR or BUTTON_COLOR)
            draw.SimpleText("Give " .. xpAmount .. " XP to Selected Users", "KyberCore_XPButton", w/2, h/2, TEXT_COLOR, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
        confirmBtn.DoClick = function()
            self:ConfirmXPDistribution()
        end
    end
    
    function FORCE_SELECTOR:Paint(w, h)
        -- Background
        draw.RoundedBox(8, 0, 0, w, h, BACKGROUND_COLOR)
        
        -- Header
        draw.RoundedBoxEx(8, 0, 0, w, 40, PRIMARY_COLOR, true, true, false, false)
        draw.SimpleText("Force Users - Give XP", "KyberCore_XPTitle", w/2, 20, TEXT_COLOR, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        
        -- Bottom decoration
        draw.RoundedBoxEx(8, 0, h-4, w, 4, ACCENT_COLOR, false, false, true, true)
    end
    
    function FORCE_SELECTOR:SetWeapon(weapon)
        self.Weapon = weapon
    end
    
    function FORCE_SELECTOR:PopulateForceUsers()
        -- Find all force users
        for _, plyUser in pairs(player.GetAll()) do
            local weps = plyUser:GetWeapons()
            for _, wep in pairs(weps) do
                if IsValid(wep) and wep:GetClass() == "kybercore_tablet" then
                    table.insert(self.ForceUsers, plyUser)
                    break
                end
            end
        end
        
        -- Create scrollable panel for users
        local scrollPanel = vgui.Create("DScrollPanel", self)
        scrollPanel:SetPos(20, 90)
        scrollPanel:SetSize(460, 400)
        
        -- Custom scroll bar
        local sbar = scrollPanel:GetVBar()
        sbar:SetWide(10)
        sbar.Paint = function(_, w, h) 
            draw.RoundedBox(4, 0, 0, w, h, Color(30, 30, 30, 100)) 
        end
        sbar.btnUp.Paint = function(_, w, h) 
            draw.RoundedBox(4, 2, 2, w-4, h-4, PRIMARY_COLOR) 
        end
        sbar.btnDown.Paint = function(_, w, h) 
            draw.RoundedBox(4, 2, 2, w-4, h-4, PRIMARY_COLOR) 
        end
        sbar.btnGrip.Paint = function(s, w, h) 
            draw.RoundedBox(4, 2, 2, w-4, h-4, s:IsHovered() and ACCENT_COLOR or PRIMARY_COLOR) 
        end
        
        -- Add player entries
        for i, forceUser in ipairs(self.ForceUsers) do
            local userPanel = vgui.Create("DPanel", scrollPanel)
            userPanel:SetPos(0, (i-1) * 80 + 5)
            userPanel:SetSize(440, 70)
            userPanel.ForceUser = forceUser
            userPanel.ParentSelector = self
            
            userPanel.Paint = function(s, w, h)
                -- Check if user is selected
                local isSelected = s.ParentSelector.SelectedForceUsers[forceUser:SteamID()]
                
                -- Background
                draw.RoundedBox(6, 0, 0, w, h, isSelected and ACCENT_COLOR or BUTTON_COLOR)
                draw.RoundedBox(6, 2, 2, w-4, h-4, BACKGROUND_COLOR)
                
                -- Player information
                local level = KyberCore:GetLevel(forceUser) or 0
                local xp = forceUser:GetNWInt("KC_EXP", 0) or 0
                local skillPoints = forceUser:GetNWInt("KC_EXP_POINTS", 0) or 0
                
                draw.SimpleText(forceUser:Nick(), "KyberCore_XPButton", 70, 15, TEXT_COLOR, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
                draw.SimpleText("Level: " .. level .. " | XP: " .. xp .. " | Points: " .. skillPoints, "KyberCore_XPText", 70, 40, TEXT_COLOR, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
                
                -- Selection indicator
                if isSelected then
                    draw.SimpleText("✓", "KyberCore_XPButton", w - 20, h/2, SUCCESS_COLOR, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                else
                    draw.SimpleText("+", "KyberCore_XPButton", w - 20, h/2, TEXT_COLOR, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                end
            end
            
            -- Add avatar
            local avatar = vgui.Create("AvatarImage", userPanel)
            avatar:SetPos(10, 10)
            avatar:SetSize(50, 50)
            avatar:SetPlayer(forceUser, 64)
            
            -- Make panel clickable
            userPanel:SetMouseInputEnabled(true)
            userPanel.OnMousePressed = function()
                -- Toggle selection
                if self.SelectedForceUsers[forceUser:SteamID()] then
                    self.SelectedForceUsers[forceUser:SteamID()] = nil
                else
                    self.SelectedForceUsers[forceUser:SteamID()] = forceUser
                end
                surface.PlaySound("ui/buttonclick.wav")
            end
        end
    end
    
    function FORCE_SELECTOR:SelectAllUsers()
        for _, plyUser in pairs(self.ForceUsers) do
            if IsValid(plyUser) and plyUser:IsPlayer() then
                self.SelectedForceUsers[plyUser:SteamID()] = plyUser
            end
        end
    end
    
    function FORCE_SELECTOR:ConfirmXPDistribution()
        if not LocalPlayer():IsSuperAdmin() and not KyberCore:IsSystemAdmin(LocalPlayer()) then return end
        local selectedCount = table.Count(self.SelectedForceUsers)
        local xpAmount = LocalPlayer():GetInfoNum("kybercore_xp_amount", 100)

        local users = {}
        for _, plyUser in pairs(self.SelectedForceUsers) do
            if IsValid(plyUser) and plyUser:IsPlayer() then
                table.insert(users, plyUser:SteamID())
            end
        end
        
        if selectedCount > 0 then
            local compressed = util.Compress(util.TableToJSON(users))

            -- Send to server
            net.Start("KyberCore:GiveXPToUsers")
                net.WriteInt(xpAmount, 32)
                net.WriteUInt(#compressed, 32)
                net.WriteData(compressed, #compressed)
            net.SendToServer()
                
            surface.PlaySound("ui/buttonclickrelease.wav")
            
            self:Remove()
        else
            -- No users selected
            surface.PlaySound("ui/buttonrollover.wav")
        end
    end
    
    vgui.Register("KyberCore_UserSelector", FORCE_SELECTOR, "DFrame")

    // Adds a halo to the player you're looking at!
    hook.Add( "PreDrawHalos", "KyberCore:ShowXPHalos", function()
        local ply = LocalPlayer()
        local trace = ply:GetEyeTrace()
        if not ply:Alive() then return end
        if not IsValid(ply) then return end

        local wep = ply:GetActiveWeapon()
        if not IsValid( wep ) then return end

        if ply:GetActiveWeapon():GetClass() == "kybercore_xpgun" then
            if IsValid( trace.Entity ) and trace.Entity:IsPlayer() then
                halo.Add( { trace.Entity }, Color( 255, 255, 255 ), 2, 2, 2, true, true )
            end
        end
    end )
    
    hook.Add( "HUDPaint", "KyberCore:XPGunHUD", function()
        local ply = LocalPlayer()
        local trace = ply:GetEyeTrace()
        if not ply:Alive() then return end
        if not IsValid(ply) then return end

        local wep = ply:GetActiveWeapon()
        if not IsValid( wep ) then return end

        if ply:GetActiveWeapon():GetClass() == "kybercore_xpgun" then
            if IsValid( trace.Entity ) and trace.Entity:IsPlayer() then
                local pos = trace.Entity:GetPos() + Vector( 0, 0, 80 )
                local ang = Angle( 0, LocalPlayer():EyeAngles().y - 90, 90 )
                local xp = math.Round(LocalPlayer():GetInfoNum("stoneos_xp_value", 100),0)
                draw.SimpleText( "Give " .. xp .. " XP?", "KyberCore_XPTitle", pos:ToScreen().x, pos:ToScreen().y, Color( 255, 255, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
            end
        end
    end)
end

if SERVER then
    util.AddNetworkString("KyberCore:GiveXPToUsers")
    net.Receive("KyberCore:GiveXPToUsers", function(len, ply)
        if not ply:IsSuperAdmin() and not KyberCore:IsSystemAdmin(ply) then return end
        local xpAmount = net.ReadInt(32)
        local compressed = net.ReadData(net.ReadUInt(32))
        local selectedUsers = util.JSONToTable(util.Decompress(compressed))

        for _, plyUser in pairs(selectedUsers) do
            local user = player.GetBySteamID(plyUser)
            if IsValid(user) and user:IsPlayer() then
                KyberCore:AddXP(user, xpAmount)
            end
        end
    end)
end