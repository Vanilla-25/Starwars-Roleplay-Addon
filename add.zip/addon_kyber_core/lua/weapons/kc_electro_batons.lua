AddCSLuaFile()

SWEP.Base = "weapon_lscs_preset"
DEFINE_BASECLASS( "weapon_lscs_preset" )

SWEP.Category			= "[LSCS] - Purge Trooper Weapons"
SWEP.PrintName		= "Electro Batons"
SWEP.Author			= "Uriel"

SWEP.Slot				= 1
SWEP.SlotPos			= 1

SWEP.Spawnable		= true
SWEP.AdminOnly		= false

SWEP.KyberCoreEventSaber = true

SWEP.PresetBlockpoints = 100
SWEP.PresetForce = 100
SWEP.PresetRightHilt = "electrobatons"
SWEP.PresetLeftHilt = "electrobatons"
SWEP.PresetRightBlade = "electrobatonsb"
SWEP.PresetLeftBlade = "electrobatonsb"
SWEP.PresetDeflectBullets = false

// Settings
SWEP.PresetForceAbilities = {}

SWEP.PresetStances = {
	"form1",
	"form6",
	"formjk",
}