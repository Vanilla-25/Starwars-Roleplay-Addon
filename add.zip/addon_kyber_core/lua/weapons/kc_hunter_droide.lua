AddCSLuaFile()

SWEP.Base = "weapon_lscs_preset"
DEFINE_BASECLASS( "weapon_lscs_preset" )

SWEP.Category			= "[LSCS] - B Class Weapons"
SWEP.PrintName		= "Hunter Droid Sabers"
SWEP.Author			= "Uriel"

SWEP.Slot				= 1
SWEP.SlotPos			= 1

SWEP.Spawnable		= true
SWEP.AdminOnly		= false

SWEP.KyberCoreEventSaber = true

SWEP.PresetBlockpoints = 400
SWEP.PresetForce = 200
SWEP.PresetRightHilt = "sh5"
SWEP.PresetLeftHilt = "sh4"
SWEP.PresetRightBlade = "br"
SWEP.PresetLeftBlade = "br"
SWEP.PresetDeflectBullets = true

// Settings
SWEP.PresetForceAbilities = {
    "jump_2",
	"jump_3",
	"slow",
    "breach",
    "speed",
}

SWEP.PresetStances = {
    "formjk",
    "form2",
    "form3",
    "form4",
    "form5",
}