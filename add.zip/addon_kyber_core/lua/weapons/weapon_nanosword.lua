AddCSLuaFile()

SWEP.Base = "weapon_lscs_preset"
DEFINE_BASECLASS( "weapon_lscs_preset" )

SWEP.Category			= "[LSCS] - Melee Weapons"
SWEP.PrintName		= "Dragon's Tooth Sword"
SWEP.Author			= "Blu-x92 / Luna"

SWEP.Slot				= 0
SWEP.SlotPos			= 1

SWEP.Spawnable		= true
SWEP.AdminOnly		= false

SWEP.KyberCoreEventSaber = true

// Weapon settings!!!
SWEP.PresetBlockpoints = 100
SWEP.PresetForce = 0
SWEP.PresetRightHilt = "nanosword"
SWEP.PresetLeftHilt = ""
SWEP.PresetRightBlade = "nanoparticles"
SWEP.PresetLeftBlade = ""
SWEP.PresetDeflectBullets = false


SWEP.PresetStances = {
    "form1",
    "form3",
    "form5",
}