AddCSLuaFile()

SWEP.Base = "weapon_lscs_preset"
DEFINE_BASECLASS( "weapon_lscs_preset" )

SWEP.Category			= "[LSCS] - S Class Weapons"
SWEP.PrintName		= "The Darksaber"
SWEP.Author			= "Stoneman / Truce"

SWEP.Slot				= 1
SWEP.SlotPos			= 1

SWEP.Spawnable		= true
SWEP.AdminOnly		= false

SWEP.KyberCoreEventSaber = true

SWEP.PresetBlockpoints = 1200
SWEP.PresetForce = 0
SWEP.PresetRightHilt = "dsh"
SWEP.PresetLeftHilt = ""
SWEP.PresetRightBlade = "bsb"
SWEP.PresetLeftBlade = ""
SWEP.PresetDeflectBullets = false

// Settings
SWEP.PresetForceAbilities = {}

SWEP.PresetStances = {
    "form1",
    "form3",
    "form5",
    "form6",
}