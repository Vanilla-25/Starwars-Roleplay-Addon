AddCSLuaFile()

SWEP.Base = "weapon_lscs_preset"
DEFINE_BASECLASS( "weapon_lscs_preset" )

SWEP.Category			= "[LSCS] - A Class Weapons"
SWEP.PrintName		= "Magna Guard Electrostaff"
SWEP.Author			= "Stoneman / Truce"

SWEP.Slot				= 1
SWEP.SlotPos			= 1

SWEP.Spawnable		= true
SWEP.AdminOnly		= false

SWEP.KyberCoreEventSaber = true

SWEP.PresetBlockpoints = 800
SWEP.PresetForce = 0
SWEP.PresetRightHilt = "electrostaff"
SWEP.PresetLeftHilt = ""
SWEP.PresetRightBlade = "electrostaff"
SWEP.PresetLeftBlade = ""
SWEP.PresetDeflectBullets = false

// Settings
SWEP.PresetForceAbilities = {}

SWEP.PresetStances = {
    "form3",
    "form6",
}
