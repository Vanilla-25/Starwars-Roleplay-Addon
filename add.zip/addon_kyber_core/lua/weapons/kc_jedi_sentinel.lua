AddCSLuaFile()

SWEP.Base = "weapon_lscs_preset"
DEFINE_BASECLASS( "weapon_lscs_preset" )

SWEP.Category			= "[LSCS] - A Class Weapons"
SWEP.PrintName		= "Jar'kai Saber's Sentinel"
SWEP.Author			= "Stoneman / Truce"

SWEP.Slot				= 1
SWEP.SlotPos			= 1

SWEP.Spawnable		= true
SWEP.AdminOnly		= false

SWEP.KyberCoreEventSaber = true

SWEP.PresetBlockpoints = 500
SWEP.PresetForce = 300
SWEP.PresetRightHilt = "sh49"
SWEP.PresetLeftHilt = "sh50"
SWEP.PresetRightBlade = "by"
SWEP.PresetLeftBlade = "by"
SWEP.PresetDeflectBullets = true

// Settings
SWEP.PresetForceAbilities = {
    "jump_2",
    "cloak",
    "breach",
    "sprint",
    "teleport",
    "shadowstep",
    "diamondstorm",
    "sense",
    "slow",
    "lightning",
    "slam",
    "burnout",
    "pulse",
    "sense",
}

SWEP.PresetStances = {
    "form1",
    "form2",
    "form5",
    "formjk"
}