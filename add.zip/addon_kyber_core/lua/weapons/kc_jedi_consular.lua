AddCSLuaFile()

SWEP.Base = "weapon_lscs_preset"
DEFINE_BASECLASS( "weapon_lscs_preset" )

SWEP.Category			= "[LSCS] - B Class Weapons"
SWEP.PrintName		= "Jedi Consular [Saberstaff]"
SWEP.Author			= "Uriel"

SWEP.Slot				= 1
SWEP.SlotPos			= 1

SWEP.Spawnable		= true
SWEP.AdminOnly		= false

SWEP.KyberCoreEventSaber = true

SWEP.PresetBlockpoints = 350
SWEP.PresetForce = 250
SWEP.PresetRightHilt = "ss2"
SWEP.PresetLeftHilt = ""
SWEP.PresetRightBlade = "bg"
SWEP.PresetLeftBlade = ""
SWEP.PresetDeflectBullets = true

// Settings
SWEP.PresetForceAbilities = {
    "jump_2",
	"jump_3",
    "selfheal",
    "speed",
    "repulse",
    "slam",
    "pulse",
}

SWEP.PresetStances = {
    "form1",
    "form3",
    "form6",
}