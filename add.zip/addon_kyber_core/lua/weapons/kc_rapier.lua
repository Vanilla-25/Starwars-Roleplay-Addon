AddCSLuaFile()

SWEP.Base = "weapon_lscs_preset"
DEFINE_BASECLASS( "weapon_lscs_preset" )

SWEP.Category			= "[LSCS] - Melee Weapons"
SWEP.PrintName		= "Rapier"
SWEP.Author			= "Stoneman / Truce"

SWEP.Slot				= 1
SWEP.SlotPos			= 1

SWEP.Spawnable		= true
SWEP.AdminOnly		= false

SWEP.KyberCoreEventSaber = true

SWEP.PresetBlockpoints = 100
SWEP.PresetForce = 100
SWEP.PresetRightHilt = "rap"
SWEP.PresetLeftHilt = ""
SWEP.PresetRightBlade = "rapb"
SWEP.PresetLeftBlade = ""
SWEP.PresetDeflectBullets = false

// Settings
SWEP.PresetForceAbilities = {}

SWEP.PresetStances = {
    "form2",
}