AddCSLuaFile()

SWEP.Base = "weapon_lscs_preset"
DEFINE_BASECLASS( "weapon_lscs_preset" )

SWEP.Category		= "[LSCS] - C Class Weapons"
SWEP.PrintName		= "Jedi Knight Saber"
SWEP.Author			= "Uriel"

SWEP.Slot				= 0
SWEP.SlotPos			= 1

SWEP.Spawnable		= true
SWEP.AdminOnly		= false

SWEP.KyberCoreEventSaber = true

// Weapon settings!!!
SWEP.PresetBlockpoints = 100
SWEP.PresetForce = 100
SWEP.PresetRightHilt = "sh2"
SWEP.PresetLeftHilt = ""
SWEP.PresetRightBlade = "bb"
SWEP.PresetLeftBlade = ""
SWEP.PresetDeflectBullets = true

// Settings
SWEP.PresetForceAbilities = {
    "jump_2",
	"blink",
	"speed",
	"pulse",
}

SWEP.PresetStances = {
    "form1",
    "form2",
    "form6",
}