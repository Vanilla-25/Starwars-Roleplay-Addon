AddCSLuaFile()

SWEP.Base = "weapon_lscs_preset"
DEFINE_BASECLASS( "weapon_lscs_preset" )

SWEP.Category			= "[LSCS] - Training Weapons"
SWEP.PrintName		= "Training: Single Saber"
SWEP.Author			= "Stoneman / Truce"

SWEP.Slot				= 1
SWEP.SlotPos			= 1

SWEP.Spawnable		= true
SWEP.AdminOnly		= false

SWEP.KyberCoreEventSaber = true

SWEP.PresetBlockpoints = 100
SWEP.PresetForce = 100
SWEP.PresetRightHilt = "sh1"
SWEP.PresetLeftHilt = ""
SWEP.PresetRightBlade = "bw"
SWEP.PresetLeftBlade = ""
SWEP.PresetDeflectBullets = true

// Settings
SWEP.PresetForceAbilities = {
    "jump_2",
    "pulse",
    "jump_3",
    "speed",
    "stasis",
    "throw",
    "slow",
    "repair",
    "burnout",
}

SWEP.PresetStances = {
    "form1",
    "form2",
    "form3",
    "form4",
    "form5",
    "form6",
}