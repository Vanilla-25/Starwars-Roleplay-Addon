
SWEP.Base = "weapon_lscs"
DEFINE_BASECLASS( "weapon_lscs" )

SWEP.Category			= "[LSCS] Event Weapons"
SWEP.PrintName		= "Base Preset Saber"
SWEP.Author			= "Stoneman / Truce"

SWEP.Slot				= 0
SWEP.SlotPos			= 1

SWEP.Spawnable		= false
SWEP.AdminOnly		= true
SWEP.KyberCoreEventSaber = true

// Settings
SWEP.PresetForceAbilities = {
	"jump_1",
--	"sprint",
--	"sense"
}

SWEP.PresetStances = {
	"form1",
}

SWEP.PresetBlockpoints = 100
SWEP.PresetForce = 100
SWEP.PresetRightHilt = "sh49"
SWEP.PresetLeftHilt = ""
SWEP.PresetRightBlade = "by"
SWEP.PresetLeftBlade = ""
SWEP.PresetDeflectBullets = true


if SERVER then
	util.AddNetworkString("KyberCore.PresetSaberEquipped")
else
	net.Receive("KyberCore.PresetSaberEquipped", function(len)
		local saber = net.ReadEntity()
		if not saber:IsValid() or not saber:IsWeapon() then return end

		saber:OnSaberSpawned()
	end)
end

function SWEP:Deploy()
	if SERVER then
		self:ServerSaberSpawned()
	end
end

function SWEP:ServerSaberSpawned()
	local ply = self:GetOwner()
	// So clients can do this part too!
	net.Start("KyberCore.PresetSaberEquipped")
		net.WriteEntity(self)
	net.Send(ply)

	self:OnSaberSpawned()
end

function SWEP:OnSaberSpawned()
	local ply = self:GetOwner()

	// Wipe out any old saber data
	ply.m_lscs_combo = nil
	ply.m_equipped_force_lscs = nil

	self:SetHiltR(self.PresetRightHilt or "")
	self:SetHiltL(self.PresetLeftHilt or "")
	self:SetBladeR(self.PresetRightBlade or "")
	self:SetBladeL(self.PresetLeftBlade or "")

	// Set our max blockpoints
	self:SetBlockPoints(self.PresetBlockpoints)

	// Set our max force
	if SERVER then
		ply:lscsSetMaxForce(self.PresetForce)
	end

	// Set our force abilities
	ply.m_equipped_force_lscs = table.Copy(KyberCore:SetupAbilityList(self.PresetForceAbilities)) or {}

	// Set our stances
	ply.m_lscs_combo = table.Copy(self.PresetStances) or {}

	if SERVER then
		ply:lscsSendComboDataTo( ply )
	end

	if CLIENT then
		LSCS:LoadClientSelector()
	end
end

function SWEP:GetMaxBlockPoints()
	local combo = self:GetCombo()

	// If the combo.MaxBlockPoints does not exist, we make it equal to what we have set for that player.
	if combo and combo.MaxBlockPoints then
		return self.PresetBlockpoints + combo.MaxBlockPoints
	else
		return self.PresetBlockpoints
	end
end

if SERVER then
	function SWEP:CanDeflect()
		// Check if our saber can deflect bullets
		if not self.PresetDeflectBullets then
			return false
		end

		if not self:GetActive() or not self:GetCombo().DeflectBullets then
			return false
		end
	
		if hook.Run("LSCS:PreventDeflect", self) then return false end
	
		return (self._nextDeflect or 0) < CurTime()
	end
end

SWEP.HasSaberSetup = false
function SWEP:SetupThink()
    if not IsValid(self) then return end
    if not self.HasSaberSetup then
        self:OnSaberSpawned()
        self.HasSaberSetup = true
    end
end