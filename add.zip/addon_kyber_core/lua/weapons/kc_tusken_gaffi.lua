AddCSLuaFile()

SWEP.Base = "weapon_lscs_preset"
DEFINE_BASECLASS( "weapon_lscs_preset" )

SWEP.Category			= "[LSCS] - Melee Weapons"
SWEP.PrintName		= "Tusken Gaffi"
SWEP.Author			= "Stoneman / Truce"

SWEP.Slot				= 1
SWEP.SlotPos			= 1

SWEP.Spawnable		= true
SWEP.AdminOnly		= false

SWEP.KyberCoreEventSaber = true

SWEP.PresetBlockpoints = 100
SWEP.PresetForce = 100
SWEP.PresetRightHilt = "tg"
SWEP.PresetLeftHilt = ""
SWEP.PresetRightBlade = "vibroblade"
SWEP.PresetLeftBlade = ""
SWEP.PresetDeflectBullets = false

// Settings
SWEP.PresetForceAbilities = {}

SWEP.PresetStances = {
    "form3",
    "form6",
}