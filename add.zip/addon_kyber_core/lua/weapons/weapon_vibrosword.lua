AddCSLuaFile()

SWEP.Base = "weapon_lscs_preset"
DEFINE_BASECLASS( "weapon_lscs_preset" )

SWEP.Category			= "[LSCS] - Melee Weapons"
SWEP.PrintName		= "Vibro Sword"
SWEP.Author			= "Blu-x92 / Luna"

SWEP.Slot				= 1
SWEP.SlotPos			= 1

SWEP.Spawnable		= true
SWEP.AdminOnly		= false

SWEP.KyberCoreEventSaber = true

// Weapon settings!!!
SWEP.PresetBlockpoints = 100
SWEP.PresetForce = 0
SWEP.PresetRightHilt = "vibrosword"
SWEP.PresetLeftHilt = ""
SWEP.PresetRightBlade = "nanoparticles"
SWEP.PresetLeftBlade = ""
SWEP.PresetDeflectBullets = false

// Settings
SWEP.PresetForceAbilities = {}
SWEP.PresetStances = {
    "form1",
    "form2",
    "form3",
    "form4",
    "form5",
}