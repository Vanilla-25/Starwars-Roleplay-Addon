AddCSLuaFile()

SWEP.Base = "weapon_lscs_preset"
DEFINE_BASECLASS( "weapon_lscs_preset" )

SWEP.Category			= "[LSCS] - S Class Weapons"
SWEP.PrintName		= "Dooku Saber"
SWEP.Author			= "Uriel"

SWEP.Slot				= 1
SWEP.SlotPos			= 1

SWEP.Spawnable		= true
SWEP.AdminOnly		= false

SWEP.KyberCoreEventSaber = true

SWEP.PresetBlockpoints = 900
SWEP.PresetForce = 600
SWEP.PresetRightHilt = "dh"
SWEP.PresetLeftHilt = ""
SWEP.PresetRightBlade = "br"
SWEP.PresetLeftBlade = ""
SWEP.PresetDeflectBullets = true

// Settings
SWEP.PresetForceAbilities = {
    "lightning",
	"jump_2",
    "jump_3",
    "launch",
    "absorb",
    "brazen",
    "reflect",
    "propulsion",
	"burnout",
    "diamondstorm",
    "speed",
    "stasis",
	"softchoke",
    "slow",
}

SWEP.PresetStances = {
    "form2",
}