AddCSLuaFile()

SWEP.Base = "weapon_lscs_preset"
DEFINE_BASECLASS( "weapon_lscs_preset" )

SWEP.Category			= "[LSCS] - A Class Weapons"
SWEP.PrintName		= "Sith Force Pike"
SWEP.Author			= "Uriel"

SWEP.Slot				= 1
SWEP.SlotPos			= 1

SWEP.Spawnable		= true
SWEP.AdminOnly		= false

SWEP.KyberCoreEventSaber = true

SWEP.PresetBlockpoints = 300
SWEP.PresetForce = 300
SWEP.PresetRightHilt = "sp3"
SWEP.PresetLeftHilt = ""
SWEP.PresetRightBlade = "br"
SWEP.PresetLeftBlade = ""
SWEP.PresetDeflectBullets = true

// Settings
SWEP.PresetForceAbilities = {
    "jump_2",
	"jump_3",
	"telekenesis",
	"burnout",
	"slow",
	"lightning",
	"judgementstrike",
	"blink",
}

SWEP.PresetStances = {
    "form1",
    "form2",
    "form3",
    "form4",
    "form5",
}