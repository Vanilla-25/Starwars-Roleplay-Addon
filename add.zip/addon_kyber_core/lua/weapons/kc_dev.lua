AddCSLuaFile()

SWEP.Base = "weapon_lscs_preset"
DEFINE_BASECLASS( "weapon_lscs_preset" )

SWEP.Category			= "[LSCS]"
SWEP.PrintName		= "Dev Saber"
SWEP.Author			= "Stoneman / Truce"

SWEP.Slot				= 0
SWEP.SlotPos			= 1

SWEP.Spawnable		= false
SWEP.AdminOnly		= true

SWEP.KyberCoreEventSaber = true

// Weapon settings!!!
SWEP.PresetBlockpoints = 400
SWEP.PresetForce = 400
SWEP.PresetRightHilt = "sh9"
SWEP.PresetLeftHilt = ""
SWEP.PresetRightBlade = "br"
SWEP.PresetLeftBlade = ""
SWEP.PresetDeflectBullets = true

// Settings
SWEP.PresetForceAbilities = {
    "blink",
    "revive",
    "selfrevive",
}

SWEP.PresetStances = {
    "form2",
    "form3",
    "form4",
    "form5",
}