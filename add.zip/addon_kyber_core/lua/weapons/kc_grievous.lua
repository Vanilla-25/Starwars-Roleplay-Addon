AddCSLuaFile()

SWEP.Base = "weapon_lscs_preset"
DEFINE_BASECLASS( "weapon_lscs_preset" )

SWEP.Category			= "[LSCS] - S Class Weapons"
SWEP.PrintName		= "Grievous Sabers [S-]"
SWEP.Author			= "Uriel"

SWEP.Slot				= 1
SWEP.SlotPos			= 1

SWEP.Spawnable		= true
SWEP.AdminOnly		= false

SWEP.KyberCoreEventSaber = true

SWEP.PresetBlockpoints = 900
SWEP.PresetForce = 500
SWEP.PresetRightHilt = "sh1"
SWEP.PresetLeftHilt = "sh2"
SWEP.PresetRightBlade = "bg"
SWEP.PresetLeftBlade = "bb"
SWEP.PresetDeflectBullets = true

// Settings
SWEP.PresetForceAbilities = {
    "jump_2",
	"jump_3",
	"burnout",
	"slam",
	"slow",
	"diamondstorm",
    "sense",
}

SWEP.PresetStances = {
    "formjk",
    "form1",
    "form3",
    "form6",
}