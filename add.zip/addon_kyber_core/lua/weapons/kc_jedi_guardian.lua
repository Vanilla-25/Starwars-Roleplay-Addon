AddCSLuaFile()

SWEP.Base = "weapon_lscs_preset"
DEFINE_BASECLASS( "weapon_lscs_preset" )

SWEP.Category			= "[LSCS] - B Class Weapons"
SWEP.PrintName		= "Jedi Guardian Saber"
SWEP.Author			= "Uriel"

SWEP.Slot				= 1
SWEP.SlotPos			= 1

SWEP.Spawnable		= true
SWEP.AdminOnly		= false

SWEP.KyberCoreEventSaber = true

// Weapon settings!!!
SWEP.PresetBlockpoints = 350
SWEP.PresetForce = 250
SWEP.PresetRightHilt = "sh9"
SWEP.PresetLeftHilt = ""
SWEP.PresetRightBlade = "bb"
SWEP.PresetLeftBlade = ""
SWEP.PresetDeflectBullets = true

// Settings
SWEP.PresetForceAbilities = {
    "jump_2",
	"jump_3",
    "launch",
    "absorb",
    "reflect",
    "propulsion",
    "stasis",
    "slow",
    "pulse",
}

SWEP.PresetStances = {
    "form1",
	"form2",
    "form3",
    "form5",
}