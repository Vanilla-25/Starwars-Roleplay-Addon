KyberCore = KyberCore or {}

///// Forms
function KyberCore:AddKnownForm(ply, form)
    if not form or form == "" then return end
    if not ply:IsValid() or not ply:IsPlayer() then return end

    if not ply.KyberCore_KnownForms then ply.KyberCore_KnownForms = {} end

    // If we already have the form, don't add it again.
    for k, v in pairs(ply.KyberCore_KnownForms) do
        if v == form then return end
    end

    table.insert(ply.KyberCore_KnownForms, form)
end

function KyberCore:RemoveKnownForm(ply, form)
    if not form or form == "" then return end
    if not ply:IsValid() or not ply:IsPlayer() then return end

    if not ply.KyberCore_KnownForms then ply.KyberCore_KnownForms = {} end
    for k, v in pairs(ply.KyberCore_KnownForms) do
        if v == form then
            table.remove(ply.KyberCore_KnownForms, k)
            break
        end
    end

    hook.Run("KyberCore.RemoveKnownForm", ply, form)
end

function KyberCore:ResetKnownForms(ply)
    if not ply:IsValid() or not ply:IsPlayer() then return end
    ply.KyberCore_KnownForms = {}
    ply.m_lscs_combo = {}
end

///// Powers
function KyberCore:AddKnownPower(ply, power)
    if not power or power == "" then return end
    if not ply:IsValid() or not ply:IsPlayer() then return end

    if not ply.KyberCore_KnownPowers then ply.KyberCore_KnownPowers = {} end

    // If we already have the power, don't add it again.
    for k, v in pairs(ply.KyberCore_KnownPowers) do
        if v == power then return end
    end

    table.insert(ply.KyberCore_KnownPowers, power)
end

function KyberCore:RemoveKnownPower(ply, power)
    if not power or power == "" then return end
    if not ply:IsValid() or not ply:IsPlayer() then return end

    if not ply.KyberCore_KnownPowers then ply.KyberCore_KnownPowers = {} end
    for k, v in pairs(ply.KyberCore_KnownPowers) do
        if v == power then
            table.remove(ply.KyberCore_KnownPowers, k)
            break
        end
    end

    hook.Run("KyberCore.RemoveKnownPower", ply, power)
end

function KyberCore:ResetBonuses(ply)
    if not ply:IsValid() or not ply:IsPlayer() then return end
    if SERVER then
        KyberCore:ResetBonusHealth(ply)
        KyberCore:ResetBonusSpeed(ply)
        KyberCore:ResetBonusForce(ply)
        KyberCore:ResetBonusBlockPoints(ply)
    end
end

local meta = FindMetaTable("Player")
function meta:IsKyberCoreForceUser()
    if self:HasWeapon("kybercore_tablet") then return true end
    return false
end

function KyberCore:ResetKnownPowers(ply)
    if not ply:IsValid() or not ply:IsPlayer() then return end
    ply.KyberCore_KnownPowers = {}
    ply.m_equipped_force_lscs = {}
end

function KyberCore:ResetPlayer(ply)
    // Reset all their forcepowers and skills
    KyberCore:ResetKnownPowers(ply)
    KyberCore:ResetKnownForms(ply)
    KyberCore:ResetBonuses(ply)
end

function KyberCore:SetupPlayer(ply)
    if not ply:IsValid() or not ply:IsPlayer() then return end
    if not ply.KyberCore_Skills then ply.KyberCore_Skills = {} end

    // Reset the player's skills and powers. We'll add them back in a second.
    KyberCore:ResetPlayer(ply)

    // Okay. Let's load the player's skills and powers.
    KyberCore:RunPlayerSkills(ply)

    if not ply:IsKyberCoreForceUser() then return end
    
    timer.Simple(0.05, function()
        if not ply:IsValid() or not ply:IsPlayer() then return end
        if not ply:IsKyberCoreForceUser() then return end

        // Ran, let's apply max health / speed / extra force, etc.
        local maxHealth = ply:GetNWInt("KC_ORIGINAL_MAXHP", 100)
        local currentSpeed = ply:GetNWFloat("KC_ORIGINAL_SPEED", 160)
        local currentRunSpeed = ply:GetNWInt("KC_ORIGINAL_RUNSPEED", 240)
        local blockPoints = ply:GetNWInt("KC_ORIGINAL_BLOCKPOINTS", 100)
        local force = ply:GetNWInt("KC_ORIGINAL_FORCE", KyberCore.Config.BaseMaxForce or 100)
        
        if SERVER then
            // Add bonus!
            ply:SetMaxHealth(maxHealth + KyberCore:GetBonusHealth(ply))
            ply:SetHealth(maxHealth + KyberCore:GetBonusHealth(ply))
            -- ply:SetWalkSpeed(currentSpeed + KyberCore:GetBonusSpeed(ply))
            ply:SetRunSpeed(currentRunSpeed + KyberCore:GetBonusSpeed(ply))
            ply:lscsSetMaxForce(force + KyberCore:GetBonusForce(ply))
            ply:lscsSetForce(force + KyberCore:GetBonusForce(ply))

            // Give player the XP Gun if they're a system admin.
            if KyberCore:IsSystemAdmin(ply) then
                ply:Give("kybercore_xpgun")
            end
        end
    end)
end

function KyberCore:SetupAbilityList(forcepowers)
    if not forcepowers or not istable(forcepowers) then return end
    local abilityList = {}
    for _, power in pairs(forcepowers) do
        local temptbl = {}
        local ability = LSCS:GetForceAbility( power )
        if not ability then
            continue
        end

        temptbl.item = ability

        if CLIENT then
            temptbl.icon = ability.icon
        end

        table.insert(abilityList, temptbl)
    end

    return abilityList
end

function KyberCore:GetEquippedAbilities(ply)
    local equipped = {}

	for _, ability in ipairs( KyberCore:GetOwnedAbilities(ply) ) do
        if ply:GetInfoNum("lscs_equip_force_"..ability, 0) == 1 then
            table.insert( equipped, ability )
        end
	end

	return equipped
end

function KyberCore:GetEquippedForms(ply)
    local equipped = {}

    for _, form in ipairs( KyberCore:GetOwnedForms(ply) ) do
        if ply:GetInfoNum("lscs_equip_stance_"..form, 0) == 1 then
            table.insert( equipped, form )
        end
    end

    return equipped
end

function KyberCore:GetOwnedAbilities(ply)
    return ply.KyberCore_KnownPowers or {}
end

function KyberCore:GetOwnedForms(ply)
    return ply.KyberCore_KnownForms or {}
end

function KyberCore:LoadPersonalSaber(ply)
    if not ply:IsValid() or not ply:IsPlayer() then return end
    if not ply:IsKyberCoreForceUser() then return end

    if not ply.KyberCore_Skills then ply.KyberCore_Skills = {} end


    local forms = KyberCore:GetEquippedForms(ply)

    // Give people their forms!
    ply.m_lscs_combo = table.Copy(forms) or {}

    local forcePowers = KyberCore:SetupAbilityList(KyberCore:GetEquippedAbilities(ply))

    // Give people their abilities!
    ply.m_equipped_force_lscs = table.Copy(forcePowers) or {}

    // Reset!
    if SERVER then
        ply:lscsSendComboDataTo( ply )
    end

    if CLIENT then
        LSCS:LoadClientSelector()
    end
end