net.Receive("KyberCore.PlayerLoadout", function()
    // Reset all their forcepowers and skills
    KyberCore:ResetKnownPowers(LocalPlayer())
    KyberCore:ResetKnownForms(LocalPlayer())

    // Begin skills
    KyberCore:RunPlayerSkills(LocalPlayer())
end)

CreateClientConVar("kybercore_shownumber", 0, true, false)

-- concommand.Add("kybercore_shownumbers", function(ply, cmd, args)
--     if not ply:IsValid() or not ply:IsPlayer() then return end
--     if not ply.KyberCoreShowNumbers then
--         ply.KyberCoreShowNumbers = false
--     end

--     ply.KyberCoreShowNumbers = not ply.KyberCoreShowNumbers
-- end)

surface.CreateFont("KyberCore_SmallFont", {
    font = "Arial",
    size = 20,
    weight = 500,
    antialias = true,
})

hook.Add("HUDPaint", "KyberCore.HUDPaint", function()
    local ply = LocalPlayer()
    local showNumbers = GetConVar("kybercore_shownumber"):GetBool()
    if ply:GetActiveWeapon().LSCS and showNumbers then

        // draw how much force you have under your crosshair
        local maxforce = math.Round(ply:lscsGetMaxForce(),0)
        local force = math.Round(ply:lscsGetForce(),0)
        if maxforce > 0 then
            draw.SimpleText("Max Force: " .. maxforce, "KyberCore_SmallFont", ScrW() / 1.065, ScrH() / 1.45 + 20, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end

        if force > 0 then
            draw.SimpleText("Force: " .. force, "KyberCore_SmallFont", ScrW() / 1.065, ScrH() / 1.45 + 40, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
        
        local saber = ply:GetActiveWeapon()
        if not saber then return end

        local maxbp = saber:GetMaxBlockPoints()
        local bp = math.Round(saber:GetBlockPoints(), 0)
        draw.SimpleText("Max Block Points: " .. maxbp, "KyberCore_SmallFont", ScrW() / 1.065, ScrH() / 1.45 + 60, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        draw.SimpleText("Block Points: " .. bp, "KyberCore_SmallFont", ScrW() / 1.065, ScrH() / 1.45 + 80, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
end)