local meta = FindMetaTable("Player")

util.AddNetworkString("KyberCore.PlayerLoadout")

function meta:SetKyberCoreForceUser(isForceUser)
    self:SetNWBool("KC_FORCE_USER", isForceUser)
end

hook.Add("PlayerLoadout", "KyberCore:PlayerLoadout", function(ply)
    // Step 1: Setting original for bonuses!
    timer.Simple(0.05, function()
        ply:SetNWInt("KC_ORIGINAL_MAXHP", ply:GetMaxHealth())
        ply:SetNWInt("KC_ORIGINAL_SPEED", ply:GetWalkSpeed())
        ply:SetNWInt("KC_ORIGINAL_RUNSPEED", ply:GetRunSpeed())
        ply:SetNWInt("KC_ORIGINAL_WALKSPEED", ply:GetWalkSpeed())
        ply:SetNWInt("KC_ORIGINAL_BLOCKPOINTS", 100)
        ply:SetNWInt("KC_ORIGINAL_FORCE", KyberCore.Config.BaseMaxForce or 100)

        // Step 2: Set up the players!
        timer.Simple(0.05, function()
            if not ply:IsValid() then return end
            if not ply:IsPlayer() then return end

            KyberCore:SetupPlayer(ply)
            net.Start("KyberCore.PlayerLoadout")
            net.Send(ply)
        end)
    end)
end)