KyberCore.Dueling = {}

util.AddNetworkString("KyberCore.RequestDuel")
util.AddNetworkString("KyberCore.DuelResponse")
util.AddNetworkString("KyberCore.DuelEnd")
util.AddNetworkString("KyberCore.RoundEnd")
util.AddNetworkString("KyberCore.InitializeDuel")
util.AddNetworkString("KyberCore.RequestDuelLeaderboard")

///////////////////////////////////
//
// Requesting a duel: Serverside
//
///////////////////////////////////

// Requesting a duel through a command first checks if the player can request a duel.

function KyberCore:ResetBlockPoints(ply)
    if not IsValid(ply) then return end

    // Go through all weapons with .LSCS tag
    for k, weapon in pairs(ply:GetWeapons()) do
        if not IsValid(weapon) then continue end
        if not weapon.LSCS then continue end

        // Reset the block points.
        weapon:SetBlockPoints(weapon:GetMaxBlockPoints())
        weapon:SetComboHits(0)
    end
end


local function SendKyberCoreMessage(ply, msg)
    if not IsValid(ply) then return end
    if not msg then return end

    // Send a message in chat to just the player.
    ply:ChatPrint(msg)

    -- local ChatMessage = {
    --     [1] = Color(0,128,255,255),
    --     [2] = "[KyberCore] ",
    --     [3] = Color(255,255,255,255),
    --     [4] = msg,
    -- }

    -- net.Start("SWRPChat")
    --     net.WriteTable(ChatMessage)
    -- net.Send(ply)
end

local function KyberCoreJediWeapons(ply)
    if not IsValid(ply) then return false end

    // Check if the player has a lightsaber
    if ply:HasWeapon("weapon_lscs_personal") then
        return true
    end
    return false
end

local function CanRequestDuel(ply, otherply)
    if not IsValid(ply) or not IsValid(otherply) then
        SendKyberCoreMessage(ply, "Player not found!")
        return false
    end
    
    if ply == otherply then
        SendKyberCoreMessage(ply, "You cannot duel yourself!")
        return false
    end

    if not ply:IsKyberCoreForceUser() then
        SendKyberCoreMessage(ply, "You don't have the right weapons to duel!")
        return false
    end
    
    if not otherply:IsKyberCoreForceUser() then
        SendKyberCoreMessage(ply, otherply:Nick() .. " doesn't have the right weapons to duel!")
        return false
    end

    // Check if the player is already in a duel
    if ply:GetNWBool("KyberCoreInDuel", false) then
        SendKyberCoreMessage(ply, "You are already in a duel!")
        return false
    end

    if otherply:GetNWBool("KyberCoreInDuel", false) then
        SendKyberCoreMessage(ply, otherply:Nick() .. " is already in a duel!")
        return false
    end

    // Check if the player is in a duel request
    if ply:GetNWBool("KyberCoreDuelRequest", false) then
        SendKyberCoreMessage(ply, "You already have a duel request!")
        return false
    end

    if otherply:GetNWBool("KyberCoreDuelRequest", false) then
        SendKyberCoreMessage(ply, otherply:Nick() .. " already has a duel request!")
        return false
    end

    if not ply:Alive() then
        SendKyberCoreMessage(ply, "You are dead!")
        return false
    end

    if not otherply:Alive() then
        SendKyberCoreMessage(ply, otherply:Nick() .. " is dead!")
        return false
    end

    return true
end

local function CleanupDuelRequest(ply, otherply)
    if IsValid(ply) then
        ply:SetNWBool("KyberCoreDuelRequest", false)
        timer.Remove("KyberCoreDuelRequestTimer for " .. ply:SteamID64())
    end

    if IsValid(otherply) then
        otherply:SetNWBool("KyberCoreDuelRequest", false)
        timer.Remove("KyberCoreDuelRequestTimer for " .. otherply:SteamID64())
    end
end

local function CleanupDuels(ply, otherply, winner)
    local dueldata = {}
    if IsValid(ply) and IsValid(otherply) then
        dueldata = KyberCore.Dueling[ply:SteamID64()] or KyberCore.Dueling[otherply:SteamID64()]
    end

    if dueldata then
        KyberCore:EndDuel(dueldata.host, dueldata.guest, winner or nil)
    end
end

local function DuelRequestResponse(response, ply, otherply, ranked)
    if not IsValid(ply) or not IsValid(otherply) then return end
    if not ply:GetNWBool("KyberCoreDuelRequest", false) then return end
    if not otherply:GetNWBool("KyberCoreDuelRequest", false) then return end

    CleanupDuelRequest(ply, otherply)

    if not response then
        SendKyberCoreMessage(otherply, "You have denied " .. ply:Nick() .. "'s duel request!")
        SendKyberCoreMessage(ply, otherply:Nick() .. " has denied your duel request!")
        return
    end

    SendKyberCoreMessage(otherply, "You have accepted " .. ply:Nick() .. "'s duel request! Let the duel begin!")

    KyberCore:StartDuel(ply, otherply, ranked)
end

function KyberCore:RequestDuel(ply, otherply, ranked)
    if not CanRequestDuel(ply, otherply) then return end

    // Run a request to the other player. In this state, no other requests can be made.
    ply:SetNWBool("KyberCoreDuelRequest", true)
    otherply:SetNWBool("KyberCoreDuelRequest", true)

    // Send message to show that the request has been sent.
    SendKyberCoreMessage(ply, "You have sent a duel request to " .. otherply:Nick() .. "!")
    SendKyberCoreMessage(otherply, ply:Nick() .. " has sent you a duel request!")

    // Ask other client to accept or deny
    net.Start("KyberCore.RequestDuel")
        net.WriteEntity(ply)
        net.WriteBool(ranked)
    net.Send(otherply)

    // Already a timer for some reason? Let's override with a new one entirely.
    if timer.Exists("KyberCoreDuelRequestTimer for " .. ply:SteamID64()) then
        timer.Remove("KyberCoreDuelRequestTimer for " .. ply:SteamID64())
    end

    if timer.Exists("KyberCoreDuelRequestTimer for " .. otherply:SteamID64()) then
        timer.Remove("KyberCoreDuelRequestTimer for " .. otherply:SteamID64())
    end

    // The request lasts 15 seconds. If the player does not respond, the request is denied.
    timer.Create("KyberCoreDuelRequestTimer for " .. ply:SteamID64(), 1, 15, function()
        // This runs every second for 15 seconds. If the player suddenly stops being valid, we should stop the timer and the request. Also if the request is no longer valid.
        if not IsValid(ply) or not IsValid(otherply) or not ply:GetNWBool("KyberCoreDuelRequest", false) or not otherply:GetNWBool("KyberCoreDuelRequest", false) then
            CleanupDuelRequest(ply, otherply)
            SendKyberCoreMessage(ply, "The duelist is no longer available!")
            SendKyberCoreMessage(otherply, "The duelist is no longer available!")
            return
        end

        // If the timer runs out, we deny the request.
        if timer.RepsLeft("KyberCoreDuelRequestTimer for " .. ply:SteamID64()) == 0 then
            CleanupDuelRequest(ply, otherply)
            SendKyberCoreMessage(ply, "The duel request has timed out!")
            SendKyberCoreMessage(otherply, "The duel request has timed out!")
        end
    end)

    hook.Run("KyberCore:RequestDuel", ply, otherply, ranked)
end

net.Receive("KyberCore.DuelResponse", function(len, ply)
    local response = net.ReadBool()
    local host = net.ReadEntity()
    local ranked = net.ReadBool()
    local guest = ply

    DuelRequestResponse(response, host, guest, ranked)
end)

// Accept chat command, /duel <player>
hook.Add("PlayerSay", "KyberCoreDuelRequest", function(ply, text)
    // Dueling command!
    if string.StartWith(text, "/uduel") or string.StartWith(text, "!uduel") then
        local otherply = nil

        if string.sub(text, 8) == "" then
            SendKyberCoreMessage(ply, "You need to specify a player to duel!")
            return ""
        end

        for k,v in pairs(player.GetAll()) do
            if string.find(string.lower(v:Nick()), string.lower(string.sub(text, 8))) then
                otherply = v
                break
            end
        end

        if not otherply then
            SendKyberCoreMessage(ply, "Player not found!")
            return ""
        end

        KyberCore:RequestDuel(ply, otherply, false)
        return ""
    end

    if string.StartWith(text, "/rduel") or string.StartWith(text, "!rduel") then
        local otherply = nil

        if string.sub(text, 8) == "" then
            SendKyberCoreMessage(ply, "You need to specify a player to duel!")
            return ""
        end

        for k,v in pairs(player.GetAll()) do
            if string.find(string.lower(v:Nick()), string.lower(string.sub(text, 8))) then
                otherply = v
                break
            end
        end

        if not otherply then
            SendKyberCoreMessage(ply, "Player not found!")
            return ""
        end

        KyberCore:RequestDuel(ply, otherply, true)
        return ""
    end

    // Forfeit command!
    if string.StartWith(text, "/fduel") or string.StartWith(text, "!fduel") then
        // Get the guest too.
        local guest = ply:GetNWEntity("KyberCoreDuelOpponent")

        // First find who is the owner of the duel.
        CleanupDuels(ply, guest, guest)

        // Somehow failed all of that? Let's just end duel for emergency cleanup.
        KyberCore:EndDuel(ply, guest, guest)

        SendKyberCoreMessage(ply, "You have forfeited the duel!")
        
        if not IsValid(guest) then return "" end

        SendKyberCoreMessage(guest, ply:Nick() .. " has forfeited the duel!")
        return ""
    end

    // Force a duel to end, accepts name.
    if string.StartWith(text, "/aduel") or string.StartWith(text, "!aduel") then
        if ply:IsAdmin() or KyberCore.Admins[ply:SteamID()] then

            local otherply = nil

            if string.sub(text, 8) == "" then
                SendKyberCoreMessage(ply, "You need to specify a player to duel!")
                return ""
            end

            for k,v in pairs(player.GetAll()) do
                if string.find(string.lower(v:Nick()), string.lower(string.sub(text, 8))) then
                    otherply = v
                    break
                end
            end

            if not otherply then
                SendKyberCoreMessage(ply, "Player not found!")
                return ""
            end

            CleanupDuels(ply, otherply)

            KyberCore:EndDuel(ply, otherply, nil)

            hook.Run("KyberCore:ForceEndDuel", ply, otherply)
        end
    end
end)

///////////////////////////////////
//
// Dueling system
//
///////////////////////////////////
function KyberCore:StartDuel(ply, otherply, ranked)
    if not IsValid(ply) or not IsValid(otherply) then return end

    // Create dueling data table!
    KyberCore.Dueling[ply:SteamID64()] = {
        host = ply,
        guest = otherply,
        hostwins = 0,
        guestwins = 0,
        round = 1,
        maxrounds = 3,
        ranked = ranked
    }

    // Set up the players for a duel!
    // They are now in a duel!
    ply:SetNWBool("KyberCoreInDuel", true)
    otherply:SetNWBool("KyberCoreInDuel", true)

    // Set up wins!
    ply:SetNWInt("KyberCoreDuelWins", 0)
    otherply:SetNWInt("KyberCoreDuelWins", 0)

    // Set up opponents!
    ply:SetNWEntity("KyberCoreDuelOpponent", otherply)
    otherply:SetNWEntity("KyberCoreDuelOpponent", ply)

    // Dueling logic now in effect! No damage until they are inside a real round.
    ply.KyberCoreInDuelingRound = false
    otherply.KyberCoreInDuelingRound = false

    // Set up the round
    KyberCore:StartRound(ply, otherply)

    hook.Run("KyberCore:StartDuel", ply, otherply)
end

local function RestorePlayer(ply)
    ply:lscsCraftSaber()
    KyberCore:ResetBlockPoints(ply)

    timer.Simple(0.5, function()
        if not IsValid(ply) then return end
        ply:SetHealth(450)
        ply:SetMaxHealth(450)
    end)
end

local function IsDuelValid(ply, otherply)
    // Players stopped being valid:
    if not IsValid(ply) or not IsValid(otherply) then return false end

    // Players stopped being in a duel:
    if not ply:GetNWBool("KyberCoreInDuel", false) then return false end
    if not otherply:GetNWBool("KyberCoreInDuel", false) then return false end

    // Duel data got cleared:
    if not KyberCore.Dueling[ply:SteamID64()] then return false end

    // Round somehow got to 4?
    if KyberCore.Dueling[ply:SteamID64()].round > 4 then return false end

    return true
end

local function StartRoundProper(ply, otherply)
    // Round is now in full force! Allow damage to be dealt!
    ply.KyberCoreInDuelingRound = true
    otherply.KyberCoreInDuelingRound = true

    // Text state to fighting!
    ply:SetNWString("KyberCoreDuelState", "Fighting")
    otherply:SetNWString("KyberCoreDuelState", "Fighting")

    ply:SetNWInt("KyberCoreDuelTimers", 120)
    otherply:SetNWInt("KyberCoreDuelTimers", 120)

    // Override the timer!
    if timer.Exists("KyberCoreDuel Timer for " .. ply:SteamID64()) then
        timer.Remove("KyberCoreDuel Timer for " .. ply:SteamID64())
    end

    timer.Create("KyberCoreDuel Timer for " .. ply:SteamID64(), 1, 120, function()
        if not IsDuelValid(ply, otherply) then KyberCore:EndDuel(ply, otherply, nil) return end

        // Show the round timer on the hud!
        ply:SetNWInt("KyberCoreDuelTimers", timer.RepsLeft("KyberCoreDuel Timer for " .. ply:SteamID64()))
        otherply:SetNWInt("KyberCoreDuelTimers", timer.RepsLeft("KyberCoreDuel Timer for " .. ply:SteamID64()))

        // If we reach 0, end the round.
        if timer.RepsLeft("KyberCoreDuel Timer for " .. ply:SteamID64()) == 0 then
            KyberCore:EndRound(ply, otherply, nil)
        end
    end)
end

// Round Start Functions
local function StartRoundCountdown(ply, otherply)
    // Three second countdown before the round starts
    ply:SetNWInt("KyberCoreDuelTimers", 3)
    otherply:SetNWInt("KyberCoreDuelTimers", 3)

    ply:SetNWString("KyberCoreDuelState", "Starting")
    otherply:SetNWString("KyberCoreDuelState", "Starting")

    // Override previous timer if it exists.
    if timer.Exists("KyberCoreDuel Timer for " .. ply:SteamID64()) then
        timer.Remove("KyberCoreDuel Timer for " .. ply:SteamID64())
    end

    // Start the countdown.
    timer.Create("KyberCoreDuel Timer for " .. ply:SteamID64(), 1, 3, function()
        if not IsDuelValid(ply, otherply) then KyberCore:EndDuel(ply, otherply, nil) return end

        // Show countdowns on the hud!
        ply:SetNWInt("KyberCoreDuelTimers", timer.RepsLeft("KyberCoreDuel Timer for " .. ply:SteamID64()))
        otherply:SetNWInt("KyberCoreDuelTimers", timer.RepsLeft("KyberCoreDuel Timer for " .. ply:SteamID64()))

        // If we reach 0, start the round and start round proper.
        if timer.RepsLeft("KyberCoreDuel Timer for " .. ply:SteamID64()) == 0 then
            StartRoundProper(ply, otherply)
        end
    end)
end

function KyberCore:StartRound(ply, otherply)
    // Keep checking if the duel is still valid.
    if not IsDuelValid(ply, otherply) then KyberCore:EndDuel(ply, otherply, nil) return end
    local dueldata = KyberCore.Dueling[ply:SteamID64()]
    
    // Set up the round
    ply:SetNWInt("KyberCoreDuelRound", dueldata.round)
    otherply:SetNWInt("KyberCoreDuelRound", dueldata.round)

    // Set player stats
    RestorePlayer(ply)
    RestorePlayer(otherply)

    StartRoundCountdown(ply, otherply)
end

local function DecideMatch(ply, otherply)
    if not IsDuelValid(ply, otherply) then return false end
    local dueldata = KyberCore.Dueling[ply:SteamID64()]

    // BO3, if one player has 2 wins, they win the duel.
    if dueldata.hostwins == 2 then
        return dueldata.host
    end

    if dueldata.guestwins == 2 then
        return dueldata.guest
    end

    // If we reach the max rounds, the player with the most wins wins the duel.
    if dueldata.round > dueldata.maxrounds then
        if dueldata.hostwins > dueldata.guestwins then
            return dueldata.host
        elseif dueldata.guestwins > dueldata.hostwins then
            return dueldata.guest
        end
    end

    // Otherwise, match is a draw.
    return nil
end

local function ShouldEndMatch(ply, otherply)
    if not IsDuelValid(ply, otherply) then return false end
    local dueldata = KyberCore.Dueling[ply:SteamID64()]

    // If round is more than max rounds, set state to end duel.
    if dueldata.round > dueldata.maxrounds or dueldata.hostwins == 2 or dueldata.guestwins == 2 then
        return true
    end

    return false
end

function KyberCore:EndRound(ply, otherply, winner)
    if not IsDuelValid(ply, otherply) then KyberCore:EndDuel(ply, otherply, nil) return end

    // Fighting is over! No more damage can be dealt.
    ply.KyberCoreInDuelingRound = false
    otherply.KyberCoreInDuelingRound = false

    local dueldata = KyberCore.Dueling[ply:SteamID64()]

    // Round over! Play a sound.
    ply:SendLua("surface.PlaySound('friends/message.wav')")
    otherply:SendLua("surface.PlaySound('friends/message.wav')")

    // Set the winner.
    if winner == ply then
        dueldata.hostwins = dueldata.hostwins + 1
    elseif winner == otherply then
        dueldata.guestwins = dueldata.guestwins + 1
    end

    // Increment the wins.
    ply:SetNWInt("KyberCoreDuelWins", dueldata.hostwins)
    otherply:SetNWInt("KyberCoreDuelWins", dueldata.guestwins)

    // Increment the round.
    dueldata.round = dueldata.round + 1

    // See if the match should be over! Check wins.
    local matchwinner = DecideMatch(ply, otherply)

    // See if the match should be over! Check rounds.
    local isFinished = ShouldEndMatch(ply, otherply)

    if isFinished then
        ply:SetNWString("KyberCoreDuelState", "End")
        otherply:SetNWString("KyberCoreDuelState", "End")
    else
        ply:SetNWString("KyberCoreDuelState", "RoundEnd")
        otherply:SetNWString("KyberCoreDuelState", "RoundEnd")

        net.Start("KyberCore.RoundEnd")
            net.WriteEntity(winner)
            net.WriteInt(dueldata.round, 8)
        net.Send(ply)

        net.Start("KyberCore.RoundEnd")
            net.WriteEntity(winner)
            net.WriteInt(dueldata.round, 8)
        net.Send(otherply)
    end

    // Begin the 3 second countdown.
    ply:SetNWInt("KyberCoreDuelTimers", 3)
    otherply:SetNWInt("KyberCoreDuelTimers", 3)

    if timer.Exists("KyberCoreDuel Timer for " .. ply:SteamID64()) then
        timer.Remove("KyberCoreDuel Timer for " .. ply:SteamID64())
    end

    timer.Create("KyberCoreDuel Timer for " .. ply:SteamID64(), 1, 3, function()
        if not IsDuelValid(ply, otherply) then KyberCore:EndDuel(ply, otherply, nil) return end

        // Show on the hud.
        ply:SetNWInt("KyberCoreDuelTimers", timer.RepsLeft("KyberCoreDuel Timer for " .. ply:SteamID64()))
        otherply:SetNWInt("KyberCoreDuelTimers", timer.RepsLeft("KyberCoreDuel Timer for " .. ply:SteamID64()))

        // Apply our decision.
        if timer.RepsLeft("KyberCoreDuel Timer for " .. ply:SteamID64()) == 0 then
            if isFinished == true then
                KyberCore:EndDuel(ply, otherply, matchwinner)
                return
            elseif isFinished == false then
                KyberCore:StartRound(ply, otherply)
                return
            end

            // uhh... what happened here.. I guess we'll just end the duel.
            KyberCore:EndDuel(ply, otherply, nil)
        end
    end)
end

function KyberCore:EndDuel(ply, otherply, winner)
    // We're ending the duel! See if we are here just for a cleanup.
    if IsDuelValid(ply, otherply) then
        local dueldata = KyberCore.Dueling[ply:SteamID64()]
    
        // Reset player's stats.
        ply:lscsCraftSaber()
        otherply:lscsCraftSaber()

        // Reset player's health back.
        KyberCore:SetupPlayer(ply)
        KyberCore:SetupPlayer(otherply)

        // Notifications!
        SendKyberCoreMessage(ply, "The duel has ended! The winner is " .. (winner and winner:Nick() or "no one") .. "!")
        SendKyberCoreMessage(otherply, "The duel has ended! The winner is " .. (winner and winner:Nick() or "no one") .. "!")

        // Tell the players that the duel has ended.
        net.Start("KyberCore.DuelEnd")
            net.WriteEntity(winner)
            net.WriteEntity(ply)
        net.Send(ply)

        net.Start("KyberCore.DuelEnd")
            net.WriteEntity(winner)
            net.WriteEntity(ply)
        net.Send(otherply)

        // Set player ratings!
        if winner then
            // Is this ranked mode?
            if dueldata.ranked then

                // Get the loser.
                local loser = nil
                if winner == ply then
                    loser = otherply
                elseif winner == otherply then
                    loser = ply
                end

                // Update the ratings if we have a loser. Otherwise, it is a tie and no ratings are updated.
                if IsValid(loser) then
                    KyberCore:UpdateRating(winner, loser, true)
                    KyberCore:UpdateRating(loser, winner, false)
                end
            end
        end

        // Cleanup the duel.
        KyberCore:CleanupDuel(ply)
        KyberCore:CleanupDuel(otherply)

        hook.Run("KyberCore:EndDuel", ply, otherply, winner)
    else
        // We're here for a cleanup, duel is no longer valid in some way.
        KyberCore:CleanupDuel(ply)
        KyberCore:CleanupDuel(otherply)
    end
end

function KyberCore:CleanupDuel(ply)
    if not IsValid(ply) then return end

    // Set states
    ply:SetNWBool("KyberCoreInDuel", false)
    ply:SetNWBool("KyberCoreDuelRequest", false)
    ply:SetNWInt("KyberCoreDuelWins", 0)
    ply:SetNWEntity("KyberCoreDuelOpponent", nil)
    ply:SetNWInt("KyberCoreDuelRound", 0)
    ply:SetNWInt("KyberCoreDuelTimers", 0)
    ply:SetNWString("KyberCoreDuelState", "")

    // Remove all timers for the player.
    if timer.Exists("KyberCoreDuel Timer for " .. ply:SteamID64()) then
        timer.Remove("KyberCoreDuel Timer for " .. ply:SteamID64())
    end

    // Remove the dueling data.
    KyberCore.Dueling[ply:SteamID64()] = nil
    ply.KyberCoreInDuelingRound = nil
end

hook.Add("KyberCore:PreSaberHit", "KyberCoreDueling: No Damage", function(attacker, victim)
    // We only deal with saber hits when:
    if not IsValid(attacker) or not IsValid(victim) then return end
    if not attacker:IsPlayer() or not victim:IsPlayer() then return end

    // If you are not in a duel, but the victim is in a duel, you cannot attack them.
    if not attacker:GetNWBool("KyberCoreInDuel", false) and victim:GetNWBool("KyberCoreInDuel", false) then return false end
    if not attacker:GetNWBool("KyberCoreInDuel", false) then return end

    // Start the actual checks here:
    // If attacker is not in a round, they cannot deal damage.
    if attacker.KyberCoreInDuelingRound ~= nil and attacker.KyberCoreInDuelingRound == false then return false end

    // If attacker is in duel, they cannot deal damage to anyone else.
    if attacker:GetNWEntity("KyberCoreDuelOpponent") ~= nil and attacker:GetNWEntity("KyberCoreDuelOpponent") ~= victim then return false end

    return true
end)

hook.Add("KyberCore:OnSaberHit", "KyberCoreDueling: No Deaths", function(attacker, victim, dmg)
    // We only deal with saber hits when:
    if not IsValid(attacker) or not IsValid(victim) then return end
    if not attacker:IsPlayer() or not victim:IsPlayer() then return end

    // Only care if the attacker is in a duel.
    if not attacker:GetNWBool("KyberCoreInDuel", false) then return end

    // What.. no damage?
    if not dmg then return end

    // Get the duel data to check!
    local dueldata = KyberCore.Dueling[attacker:SteamID64()] or KyberCore.Dueling[victim:SteamID64()]

    // If the duel data is not valid, don't do anything.
    if not dueldata then return end

    // Get the opponent.
    if not dueldata.host or not dueldata.guest then return end

    local opponent = nil
    if attacker == dueldata.host then
        opponent = dueldata.guest
    elseif attacker == dueldata.guest then
        opponent = dueldata.host
    end

    if not IsValid(opponent) then return end

    // Check if we're hitting the opponent.
    if opponent == victim then
        // We are. If the damage is lethal..
        if victim:Health() - dmg:GetDamage() <= 0 then
            victim:SetHealth(450)
            dmg:SetDamage(0)

            // The opponent landed the killing blow, so they win the round!
            // Check who is the host and who is the guest.
            if attacker == dueldata.host then
                KyberCore:EndRound(attacker, opponent, attacker)
            elseif opponent == dueldata.host then
                KyberCore:EndRound(opponent, attacker, attacker)
            end
            return
        end
    end
end)

// Duel ends when the player disconnects, or dies.
hook.Add("PlayerDeath", "KyberCoreDueling: End Duel To Death", function(ply)
    if not ply then return end

    local opponent = ply:GetNWEntity("KyberCoreDuelOpponent")

    CleanupDuels(ply, opponent, nil)
end)

// Disconnecting from the server ends the duel.
hook.Add("PlayerDisconnected", "KyberCoreDueling: End Duel To Disconnect", function(ply)
    if not ply then return end
    
    local opponent = ply:GetNWEntity("KyberCoreDuelOpponent")

    KyberCore:EndDuel(ply, opponent, nil)
end)

///////////////////////////////////
//
// DR (Dueling Rating)
//
///////////////////////////////////
// Basically a simple ELO system.
function KyberCore:UpdateRating(ply, opponent, result)
    // We just won or lost against the other player. Update the rating.
    // If we win against a player with a higher rating, we gain more rating. Or if we win against a player with a lower rating, we gain less rating. If similar, middle rating.
    if not IsValid(ply) or not IsValid(opponent) then return end
    if result == nil then return end

    // Players do not have a rating? Let's just return. Don't want to mess with the database.
    local plyRating = ply:GetNWInt("KyberCoreDuelingRating", 1500)
    local opponentRating = opponent:GetNWInt("KyberCoreDuelingRating", 1500)

    // If we don't have a rating, we don't update the rating. Something went wrong in setting up this player.
    if not plyRating or not opponentRating then return end

    // Calculate the rating difference.
    local ratingDifference = opponentRating - plyRating
    
    // Based on the rating differences, we calculate the gain or loss.
    local updateAmount = 0
    
    if result == true then
        // If we're winning
        if ratingDifference > 2000 then
            updateAmount = 50
        elseif ratingDifference < -2000 then
            updateAmount = 10
        else
            updateAmount = 10 + ((ratingDifference + 2000) / 4000) * 40
        end
    elseif result == false then
        // If we're losing
        if ratingDifference > 2000 then
            updateAmount = 10
        elseif ratingDifference < -2000 then
            updateAmount = 50
        else
            updateAmount = 50 - ((ratingDifference + 2000) / 4000) * 40
        end
    end

    // Round to the nearest whole number.
    updateAmount = math.Round(updateAmount)
    local newRating = 0

    if result == true then
        newRating = plyRating + updateAmount
        SendKyberCoreMessage(ply, "+ " .. updateAmount .. " DR")
    elseif result == false then
        newRating = plyRating - updateAmount
        SendKyberCoreMessage(ply, "- " .. updateAmount .. " DR")
    end

    // Cap at 15000
    if newRating > 15000 then newRating = 15000 end

    // Can't be negative.
    if newRating < 0 then newRating = 0 end

    // Set the new rating.
    ply:SetNWInt("KyberCoreDuelingRating", newRating)

    // Check the database first. If the player does not have a rating, we insert one.
    if KyberCore.Config.SaveLocal then
        local data = sql.Query("SELECT * FROM kybercore_duels WHERE unique_id = '" .. ply:SteamID64() .. "'")
        if not data then
            sql.Query("INSERT INTO kybercore_duels (unique_id, rating, wins, losses) VALUES ('" .. ply:SteamID64() .. "', '" .. newRating .. "', '0', '0')")
        end
    else
        KyberCore.DB.Query("SELECT * FROM kybercore_duels WHERE unique_id = '" .. ply:SteamID64() .. "'", function(data)
            if table.IsEmpty(data) then
                KyberCore.DB.Query("INSERT INTO kybercore_duels (unique_id, rating, wins, losses) VALUES ('" .. ply:SteamID64() .. "', '" .. newRating .. "', '0', '0')")
            end
        end)
    end

    local wins = ply:GetNWInt("KyberCoreDuelingWins", 0)
    local losses = ply:GetNWInt("KyberCoreDuelingLosses", 0)

    if result == true then
        wins = wins + 1
    elseif result == false then
        losses = losses + 1
    end

    ply:SetNWInt("KyberCoreDuelingWins", wins)
    ply:SetNWInt("KyberCoreDuelingLosses", losses)

    if KyberCore.Config.SaveLocal then
        sql.Query("UPDATE kybercore_duels SET rating = " .. newRating .. ", wins = " .. wins .. ", losses = " .. losses .. " WHERE unique_id = '" .. ply:SteamID64() .. "'")
    else
        KyberCore.DB.Query("UPDATE kybercore_duels SET rating = " .. newRating .. ", wins = " .. wins .. ", losses = " .. losses .. " WHERE unique_id = '" .. ply:SteamID64() .. "'")
    end

    hook.Run("KyberCore:UpdateRating", ply, opponent, newRating)

    // Show the rating change in chat!
    SendKyberCoreMessage(ply, "Your new rating is " .. ply:GetNWInt("KyberCoreDuelingRating", 1000))
end

function KyberCore:InitializeDRData(ply)
    if not IsValid(ply) then return end

    // Grab from the database!
    if KyberCore.Config.SaveLocal then
        local data = sql.Query("SELECT * FROM kybercore_duels WHERE unique_id = '" .. ply:SteamID64() .. "'")
        if not data then
            sql.Query("INSERT INTO kybercore_duels (unique_id, rating, wins, losses) VALUES ('" .. ply:SteamID64() .. "', '1500', '0', '0')")
            ply:SetNWInt("KyberCoreDuelingRating", 1500)
            ply:SetNWInt("KyberCoreDuelingWins", 0)
            ply:SetNWInt("KyberCoreDuelingLosses", 0)
            return
        end
    else
        // Query the database for the player.
        KyberCore.DB.Query("SELECT * FROM kybercore_duels WHERE unique_id = '" .. ply:SteamID64() .. "'", function(data)
            if not table.IsEmpty(data) then 
                // If the player has a rating, we set it to the rating.
                ply:SetNWInt("KyberCoreDuelingRating", data[1].rating)
                ply:SetNWInt("KyberCoreDuelingWins", data[1].wins)
                ply:SetNWInt("KyberCoreDuelingLosses", data[1].losses)
            end
        end)
    end
end

hook.Add("KyberCore:ClientFullyLoaded", "KyberCore:LoadDuel", function(ply)
    if ply:IsValid() and ply:IsPlayer() then
        KyberCore:InitializeDRData(ply)
    end
end)

net.Receive("KyberCore.RequestDuelLeaderboard", function(len, ply)
    if not IsValid(ply) then return end

    if KyberCore.Config.SaveLocal then
        local data = sql.Query("SELECT * FROM kybercore_duels ORDER BY rating DESC LIMIT 10")
        if isbool(data) then return end
        if not data then return end
        if table.IsEmpty(data) then return end

        // Turn into JSON and send to the client.
        local newLeaderboard = util.Compress(util.TableToJSON(data))

        net.Start("KyberCore.RequestDuelLeaderboard")
            net.WriteData(newLeaderboard, #newLeaderboard)
        net.Send(ply)
    else
        KyberCore.DB.Query("SELECT * FROM kybercore_duels ORDER BY rating DESC LIMIT 10", function(data)
            if isbool(data) then return end
            if not data then return end
            if table.IsEmpty(data) then return end
    
            // Turn into JSON and send to the client.
            local newLeaderboard = util.Compress(util.TableToJSON(data))

            net.Start("KyberCore.RequestDuelLeaderboard")
                net.WriteData(newLeaderboard, #newLeaderboard)
            net.Send(ply)
        end)
    end
end)

local RESET_DUEL_REQUESTS = 0

util.AddNetworkString("KyberCore.ResetDuelRanks")
net.Receive("KyberCore.ResetDuelRanks", function(len, ply)
    if not ply:IsAdmin() and not KyberCore:IsSystemAdmin(ply) then return end
    // You gotta do it three times!
    RESET_DUEL_REQUESTS = RESET_DUEL_REQUESTS + 1

    if RESET_DUEL_REQUESTS < 3 then
        SendKyberCoreMessage(ply, "ARE YOU SURE? This will reset all duel ranks and ratings for all players and clear the entire leaderboard! This CANNOT be reversed!")
        SendKyberCoreMessage(ply, "To confirm, do this command " .. (3 - RESET_DUEL_REQUESTS) .. " more times!")
        return
    end

    if KyberCore.Config.SaveLocal then
        sql.Query("DELETE FROM kybercore_duels")
    else
        KyberCore.DB.Query("DELETE FROM kybercore_duels")
    end

    for k,v in pairs(player.GetAll()) do
        v:SetNWInt("KyberCoreDuelingRating", 1500)
        v:SetNWInt("KyberCoreDuelingWins", 0)
        v:SetNWInt("KyberCoreDuelingLosses", 0)
    end

    hook.Run("KyberCore:ResetDuelRanks", ply)
    SendKyberCoreMessage(ply, "All duel ranks and ratings have been reset.")
end)

-- // Debug commands:
-- concommand.Add("KyberCore_setrating", function(ply, cmd, args)
--     if not args[1] or not args[2] then return end
--     local target = nil

--     for k,v in pairs(player.GetAll()) do
--         if string.find(string.lower(v:Nick()), string.lower(args[1])) then
--             target = v
--             break
--         end
--     end

--     if not target then return end

--     target:SetNWInt("KyberCoreDuelingRating", tonumber(args[2]))
--     SendKyberCoreMessage(target, "Setting " .. target:Nick() .. "'s rating to " .. args[2])

--     KyberCore.DB.Query("UPDATE kybercore_duels SET rating = " .. args[2] .. " WHERE unique_id = '" .. target:SteamID64() .. "'")
-- end)

-- concommand.Add("KyberCore_resetrating", function(ply, cmd, args)
--     // find the player
--     local target = nil
--     for k,v in pairs(player.GetAll()) do
--         if string.find(string.lower(v:Nick()), string.lower(args[1])) then
--             target = v
--             break
--         end
--     end

--     if not target then return end

--     KyberCore.DB.Query("DELETE FROM kybercore_duels WHERE unique_id = '" .. target:SteamID64() .. "'")
--     SendKyberCoreMessage(target, "Your rating has been reset!")

--     target:SetNWInt("KyberCoreDuelingRating", 1500)
-- end)