///////////////////////////////////
//
// Requesting a duel: Clientside
//
///////////////////////////////////
local DuelRequestor = nil

local THE_FONT = {
	font = "Oxanium",
	extended = false,
	size = 25,
	weight = 1000,
	blursize = 0,
	scanlines = 0,
	antialias = true,
	underline = false,
	italic = false,
	strikeout = false,
	symbol = false,
	rotary = false,
	shadow = false,
	additive = false,
	outline = false,
}
surface.CreateFont( "KyberCore_DuelRequest_Large", THE_FONT )

local THE_FONT = {
	font = "Oxanium",
	extended = false,
	size = 20,
	weight = 1000,
	blursize = 0,
	scanlines = 0,
	antialias = true,
	underline = false,
	italic = false,
	strikeout = false,
	symbol = false,
	rotary = false,
	shadow = false,
	additive = false,
	outline = false,
}
surface.CreateFont( "KyberCore_DuelRequest_Medium", THE_FONT )

local THE_FONT = {
	font = "Oxanium",
	extended = false,
	size = 15,
	weight = 2000,
	blursize = 0,
	scanlines = 0,
	antialias = true,
	underline = false,
	italic = false,
	strikeout = false,
	symbol = false,
	rotary = false,
	shadow = false,
	additive = false,
	outline = false,
}
surface.CreateFont( "KyberCore_DuelRequest", THE_FONT )

local KyberCoreDuelingRanks = {}

///////////////////////////////////
//
// Ranks
//
///////////////////////////////////
function KyberCore:CreateRank(data)
    KyberCoreDuelingRanks[data.name] = data
end

local rank = {}
rank.name = "Novice"
rank.min = 0
rank.max = 2000
rank.color = Color(187, 134, 28)
KyberCore:CreateRank(rank)

local rank = {}
rank.name = "Apprentice"
rank.min = 2000
rank.max = 4000
rank.color = Color(205, 210, 208)
KyberCore:CreateRank(rank)

local rank = {}
rank.name = "Seasoned"
rank.min = 4000
rank.max = 6000
rank.color = Color(64, 168, 185)
KyberCore:CreateRank(rank)

local rank = {}
rank.name = "Expert"
rank.min = 6000
rank.max = 8000
rank.color = Color(240, 152, 243)
KyberCore:CreateRank(rank)

local rank = {}
rank.name = "Master"
rank.min = 8000
rank.max = 10000
rank.color = Color(56, 56, 252)
KyberCore:CreateRank(rank)

local rank = {}
rank.name = "Champion"
rank.min = 10000
rank.max = 999999
rank.color = Color(237, 48, 44)
KyberCore:CreateRank(rank)

///////////////////////////////////

local PANEL = {}
function PANEL:Init()
    if DuelRequestor then
        DuelRequestor:Remove()
    end

    // At the start, smoothly slide in from the left.
    self:SetSize(ScrW() * 0.35, ScrH() * 0.19)
    self:SetPos(ScrW() * 0.025 - 1000, ScrH() * 0.475)
    self:SetDraggable(false)
    self:ShowCloseButton(false)
    self:SetTitle("")

    self:MoveTo(ScrW() * 0.025, ScrH() * 0.475, 2, 0, 0.1)
    self.Paint = function(self, w, h)
        draw.RoundedBox(0, 0, 0, w, h, Color(42, 47, 71, 0))
    end
end

function PANEL:PopulateLabels()
    // Completely black background for the entire panel.
    self.RequestPanel = vgui.Create("DPanel", self)
    self.RequestPanel:SetSize(self:GetWide(), self:GetTall())
    self.RequestPanel.Paint = function(self, w, h)
        draw.RoundedBox(0, 0, 0, w, h, Color(42, 47, 71, 255))
    end

    self.Background2 = vgui.Create("DPanel", self.RequestPanel)
    self.Background2:Dock(FILL)
    self.Background2:DockMargin(10, 10, 10, 0)
    self.Background2.Paint = function(self, w, h)
        draw.RoundedBox(0, 0, 0, w, h + 35, Color(32, 37, 62, 255))
    end

    local labelText = "Unranked Duel Request"
    if self.Ranked then
        labelText = "Ranked Duel Request"
    end

    self.Label = vgui.Create("DLabel", self.RequestPanel)
    self.Label:SetText(labelText)
    self.Label:SetFont("KyberCore_DuelRequest_Large")
    self.Label:SizeToContents()
    self.Label:Center()
    self.Label:AlignTop(30)

    // Player information: Avatar, name
    self.Avatar = vgui.Create("AvatarImage", self.RequestPanel)
    self.Avatar:SetSize(64, 64)
    self.Avatar:AlignLeft(30)
    self.Avatar:AlignTop(70)
    self.Avatar:SetPlayer(self.Ply, 64)

    self.PlayerName = vgui.Create("DLabel", self.RequestPanel)
    self.PlayerName:SetText(self.Ply:Nick())
    self.PlayerName:SetFont("KyberCore_DuelRequest")
    self.PlayerName:SizeToContents()
    self.PlayerName:AlignTop(90)
    self.PlayerName:AlignLeft(110)

    // Second player information: Avatar, name
    self.Avatar2 = vgui.Create("AvatarImage", self.RequestPanel)
    self.Avatar2:SetSize(64, 64)
    self.Avatar2:AlignRight(30)
    self.Avatar2:AlignTop(70)
    self.Avatar2:SetPlayer(self.OtherPlayer, 64)

    self.PlayerName2 = vgui.Create("DLabel", self.RequestPanel)
    self.PlayerName2:SetText(self.OtherPlayer:Nick())
    self.PlayerName2:SetFont("KyberCore_DuelRequest")
    self.PlayerName2:SizeToContents()
    self.PlayerName2:AlignTop(90)
    self.PlayerName2:AlignRight(110)

    // Two labels, Press [X] to accept, Press [Y] to deny
    self.AcceptLabel = vgui.Create("DLabel", self.RequestPanel)
    self.AcceptLabel:SetText("Press [O] to accept.")
    self.AcceptLabel:SetFont("KyberCore_DuelRequest_Medium")
    self.AcceptLabel:SizeToContents()
    self.AcceptLabel:Center()
    self.AcceptLabel:AlignBottom(30)
    self.AcceptLabel:AlignLeft(30)
    self.AcceptLabel:SetColor(Color(155, 255, 40))

    if self.Ranked then
        // Ranks are based on DR range. Let's find the rank of the player.
        local plyRank = {}
        for k, v in pairs(KyberCoreDuelingRanks) do
            if self.Ply:GetNWInt("KyberCoreDuelingRating") >= v.min and self.Ply:GetNWInt("KyberCoreDuelingRating") <= v.max then
                plyRank = v
            end
        end

        local otherRank = {}
        for k, v in pairs(KyberCoreDuelingRanks) do
            if self.OtherPlayer:GetNWInt("KyberCoreDuelingRating") >= v.min and self.OtherPlayer:GetNWInt("KyberCoreDuelingRating") <= v.max then
                otherRank = v
            end
        end

        // If we can't find the rank, they are novice.
        if table.IsEmpty(plyRank) then
            plyRank = KyberCoreDuelingRanks["Novice"]
        end

        if table.IsEmpty(otherRank) then
            otherRank = KyberCoreDuelingRanks["Novice"]
        end

        self.RankLabel = vgui.Create("DLabel", self.RequestPanel)
        self.RankLabel:SetText(plyRank.name)
        self.RankLabel:SetFont("KyberCore_DuelRequest")
        self.RankLabel:SizeToContents()
        self.RankLabel:Center()
        self.RankLabel:AlignTop(70)
        self.RankLabel:AlignLeft(110)
        self.RankLabel:SetColor(plyRank.color)

        self.RankLabel2 = vgui.Create("DLabel", self.RequestPanel)
        self.RankLabel2:SetText(otherRank.name)
        self.RankLabel2:SetFont("KyberCore_DuelRequest")
        self.RankLabel2:SizeToContents()
        self.RankLabel2:Center()
        self.RankLabel2:AlignTop(70)
        self.RankLabel2:AlignRight(110)
        self.RankLabel2:SetColor(otherRank.color)

        self.DRLabel = vgui.Create("DLabel", self.RequestPanel)
        self.DRLabel:SetText("(" .. self.Ply:GetNWInt("KyberCoreDuelingRating") .. ")")
        self.DRLabel:SetFont("KyberCore_DuelRequest")
        self.DRLabel:SizeToContents()
        self.DRLabel:Center()
        self.DRLabel:AlignTop(110)
        self.DRLabel:AlignLeft(110)
        self.DRLabel:SetColor(plyRank.color)

        self.DRLabel2 = vgui.Create("DLabel", self.RequestPanel)
        self.DRLabel2:SetText("(" .. self.OtherPlayer:GetNWInt("KyberCoreDuelingRating") .. ")")
        self.DRLabel2:SetFont("KyberCore_DuelRequest")
        self.DRLabel2:SizeToContents()
        self.DRLabel2:Center()
        self.DRLabel2:AlignTop(110)
        self.DRLabel2:AlignRight(110)
        self.DRLabel2:SetColor(otherRank.color)
    end
    
    self.DenyLabel = vgui.Create("DLabel", self.RequestPanel)
    self.DenyLabel:SetText("Press [P] to deny.")
    self.DenyLabel:SetFont("KyberCore_DuelRequest_Medium")
    self.DenyLabel:SizeToContents()
    self.DenyLabel:Center()
    self.DenyLabel:AlignBottom(30)
    self.DenyLabel:AlignRight(30)
    self.DenyLabel:SetColor(Color(255, 150, 150))

    hook.Add("PlayerButtonDown", "KyberCore:RequestDuel", function(ply, key)
        if ply == self.Ply then
            if key == KEY_O then
                net.Start("KyberCore.DuelResponse")
                    net.WriteBool(true)
                    net.WriteEntity(self.OtherPlayer)
                    net.WriteBool(self.Ranked)
                net.SendToServer()
                hook.Remove("PlayerButtonDown", "KyberCore:RequestDuel")
                timer.Remove("KyberCore:RequestDuel:Timeout")

                // Remove after 2 seconds when we finish sliding out.
                self:MoveTo(ScrW() * 0.025 - 1000, ScrH() * 0.475, 2, 0, 0.1)
                timer.Simple(1, function()
                    self:Remove()
                end)
            elseif key == KEY_P then
                net.Start("KyberCore.DuelResponse")
                    net.WriteBool(false)
                    net.WriteEntity(self.OtherPlayer)
                    net.WriteBool(self.Ranked)
                net.SendToServer()
                hook.Remove("PlayerButtonDown", "KyberCore:RequestDuel")
                timer.Remove("KyberCore:RequestDuel:Timeout")

                // Remove after 2 seconds when we finish sliding out.
                self:MoveTo(ScrW() * 0.025 - 1000, ScrH() * 0.475, 2, 0, 0.1)
                timer.Simple(1, function()
                    self:Remove()
                end)
            end
        end
    end)

    local timeLeft = 15
    if timer.Exists("KyberCore:RequestDuel:Timeout") then
        timer.Remove("KyberCore:RequestDuel:Timeout")
    end

    self.TimeoutBar = vgui.Create("DProgress", self)
    self.TimeoutBar:SetSize(self:GetWide(), 10)
    self.TimeoutBar:AlignBottom(0)
    self.TimeoutBar:SetFraction(timeLeft / 15)
    self.TimeoutBar.Paint = function(self, w, h)
        draw.RoundedBox(0, 0, 0, w, h, Color(42, 47, 71, 255))

        if timer.Exists("KyberCore:RequestDuel:Timeout") then
            timeLeft = timer.TimeLeft("KyberCore:RequestDuel:Timeout")
            self:SetFraction(timeLeft / 15)

            // Slowly change color from blue to red.
            local color = Color(82, 163, 255)
            local r = Lerp(1 - (timeLeft / 15), 82, 255)
            local g = Lerp(1 - (timeLeft / 15), 163, 0)
            local b = Lerp(1 - (timeLeft / 15), 255, 0)
            draw.RoundedBox(0, 0, 0, w * self:GetFraction(), h, Color(r, g, b, 255))
        end
    end
    
    timer.Create("KyberCore:RequestDuel:Timeout", 15, 1, function()
        if IsValid(self) then
            hook.Remove("PlayerButtonDown", "KyberCore:RequestDuel")

            // Remove after 2 seconds when we finish sliding out.
            self:MoveTo(ScrW() * 0.025 - 1000, ScrH() * 0.475, 2, 0, 0.1)
            timer.Simple(1, function()
                self:Remove()
            end)
        end
    end)
end
vgui.Register("KyberCore.DuelResponder", PANEL, "DFrame")

net.Receive("KyberCore.RequestDuel", function()
    local ply = LocalPlayer()
    local otherply = net.ReadEntity()
    local ranked = net.ReadBool()
    DuelRequestor = vgui.Create("KyberCore.DuelResponder")
    DuelRequestor.OtherPlayer = otherply
    DuelRequestor.Ply = ply
    DuelRequestor.Ranked = ranked or false

    DuelRequestor:PopulateLabels()
end)

///////////////////////////////////
//
// Duel hud
//
///////////////////////////////////
local function DrawDuelHud()
    local ply = LocalPlayer()
    if not ply:GetNWBool("KyberCoreInDuel") then return end

    local hostwins = ply:GetNWInt("KyberCoreDuelWins")
    local guest = ply:GetNWEntity("KyberCoreDuelOpponent")
    if not IsValid(guest) then return end
    local guestwins = guest:GetNWInt("KyberCoreDuelWins")

    local w, h = ScrW(), ScrH()

    // TODO: Fancier!
    // Show round number

    -- draw.RoundedBox(0, w / 2 - 100, h / 9, w / 9.5, h / 11, Color(42, 47, 71, 125))

    local currentText = "Round " .. ply:GetNWInt("KyberCoreDuelRound")

    if ply:GetNWString("KyberCoreDuelState") == "Fighting" then
        currentText = "Round " .. ply:GetNWInt("KyberCoreDuelRound")
    elseif ply:GetNWString("KyberCoreDuelState") == "RoundEnd" then
        currentText = "Round " .. ply:GetNWInt("KyberCoreDuelRound") .. " over!"
    elseif ply:GetNWString("KyberCoreDuelState") == "Starting" then
        currentText = "Round " .. ply:GetNWInt("KyberCoreDuelRound") .. " starting soon!"
    elseif ply:GetNWString("KyberCoreDuelState") == "End" then
        currentText = "Duel Over!"
    end

    draw.SimpleText(currentText, "KyberCore_DuelRequest_Large", w / 2, h / 7.8, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    
    // Show wins: Host | Guest
    draw.SimpleText(hostwins .. " | " .. guestwins, "KyberCore_DuelRequest_Large", w / 2, h / 6.5, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    
    // Timers at the center of the screen from networked values
    local timers = ply:GetNWInt("KyberCoreDuelTimers")

    draw.SimpleText(timers, "KyberCore_DuelRequest_Large", w / 2, h / 5.5, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
end

hook.Add("HUDPaint", "KyberCore:DrawDuelHud", DrawDuelHud)

///////////////////////////////////
//
// Duel Transitions
//
///////////////////////////////////
local DuelTransition = nil

local PANEL = {}
function PANEL:Init()
    if DuelTransition then
        DuelTransition:Remove()
    end

    self:SetSize(ScrW() * 0.1, ScrH() * 0.1)
    self:SetPos(-ScrW(), ScrH() * 0.275 - (self:GetTall() / 2))
    self:SetDraggable(false)
    self:ShowCloseButton(false)
    self:SetTitle("")

    self.Paint = function(self, w, h)
        draw.RoundedBox(0, 0, 0, w, h, Color(42, 47, 71, 0))
    end

    // Delete after 3 seconds!
    timer.Simple(5, function()
        if IsValid(self) then
            self:Remove()
        end
    end)
end

function PANEL:PopulatePanel()
    self.Panel = vgui.Create("DPanel", self)
    self.Panel:SetSize(self:GetWide(), self:GetTall())
    self.Panel.Paint = function(self, w, h)
        draw.RoundedBox(0, 0, 0, w, h, Color(42, 47, 71, 100))
    end

    self.Background2 = vgui.Create("DPanel", self.Panel)
    self.Background2:Dock(FILL)
    self.Background2:DockMargin(10, 10, 10, 10)
    self.Background2.Paint = function(self, w, h)
        draw.RoundedBox(0, 0, 0, w, h, Color(32, 37, 62, 100))
    end

    local winMessage = "Draw!"

    if self.Winner == LocalPlayer() then
        winMessage = "You won the round!"
    else
        if IsValid(self.Winner) then
            winMessage = self.Winner:Nick() .. " won the round!"
        end
    end

    // Winner text
    self.WinnerText = vgui.Create("DLabel", self.Panel)
    self.WinnerText:SetText(winMessage)
    self.WinnerText:SetFont("KyberCore_DuelRequest_Medium")
    self.WinnerText:SizeToContents()
    self.WinnerText:Center()
    self.WinnerText:AlignBottom(60)

    // Round number
    self.RoundLabel = vgui.Create("DLabel", self.Panel)
    self.RoundLabel:SetText("Get ready for round " .. self.Round)
    self.RoundLabel:SetFont("KyberCore_DuelRequest_Medium")
    self.RoundLabel:SizeToContents()
    self.RoundLabel:Center()
    self.RoundLabel:AlignBottom(30)

    // Make the entire panel longer to fit the text
    if self.WinnerText:GetWide() > self.RoundLabel:GetWide() then
        self:SetSize(ScrW() * 0.1 + self.WinnerText:GetWide(), ScrH() * 0.1)
        self.Panel:SetSize(self:GetWide(), self:GetTall())
        self:SetPos(-ScrW(), ScrH() * 0.275 - (self:GetTall() / 2))
        self.WinnerText:Center()
        self.WinnerText:AlignBottom(60)
        self.RoundLabel:Center()
        self.RoundLabel:AlignBottom(30)
    else
        self:SetSize(ScrW() * 0.1 + self.RoundLabel:GetWide(), ScrH() * 0.1)
        self.Panel:SetSize(self:GetWide(), self:GetTall())
        self:SetPos(-ScrW(), ScrH() * 0.275 - (self:GetTall() / 2))
        self.WinnerText:Center()
        self.WinnerText:AlignBottom(60)
        self.RoundLabel:Center()
        self.RoundLabel:AlignBottom(30)
    end

    // Move to the middle of the screen
    self:MoveTo(ScrW() / 2 - (self:GetWide() / 2), ScrH() * 0.275 - (self:GetTall() / 2), 2, 0, 0.1)

    // After 1 second, slide out to the right.
    timer.Simple(3, function()
        if IsValid(self) then
            self:MoveTo(ScrW() + 50, ScrH() * 0.275 - (self:GetTall() / 2), 2, 0, 0.1)
            timer.Simple(1, function()
                if IsValid(self) then
                    self:Remove()
                end
            end)
        end
    end)
end

vgui.Register("KyberCore.DuelTransition", PANEL, "DFrame")

net.Receive("KyberCore.RoundEnd", function()
    local winner = net.ReadEntity()
    local round = net.ReadInt(8)
    DuelTransition = vgui.Create("KyberCore.DuelTransition")
    DuelTransition.Winner = winner
    DuelTransition.Round = round
    DuelTransition:PopulatePanel()
end)

///////////////////////////////////
//
// Duel Result
//
///////////////////////////////////
local DuelResult = nil

local PANEL = {}

function PANEL:Init()
    if DuelResult then
        DuelResult:Remove()
    end

    self:SetSize(ScrW() * 0.25, ScrH() * 0.6)
    self:SetPos(ScrW() / 6 - (self:GetWide() / 2), ScrH() + self:GetTall())
    self:SetDraggable(false)
    self:ShowCloseButton(true)
    self:SetTitle("")

    self:MoveTo(ScrW() / 6 - (self:GetWide() / 2), ScrH() / 2 - (self:GetTall() / 2), 2, 0, 0.1)

    self.Paint = function(self, w, h)
        draw.RoundedBox(0, 0, 0, w, h, Color(0, 0, 0, 0))
    end

    timer.Simple(3, function()
        if IsValid(self) then
            self:MoveTo(ScrW() / 6 - (self:GetWide() / 2), ScrH() + self:GetTall(), 2, 0, 0.1)
            timer.Simple(1, function()
                if IsValid(self) then
                    self:Remove()
                end
            end)
        end
    end)
end

function PANEL:PopulatePanel()
    self.Panel = vgui.Create("DPanel", self)
    self.Panel:SetSize(self:GetWide(), self:GetTall())
    self.Panel.Paint = function(self, w, h)
        draw.RoundedBox(0, 0, 0, w, h, Color(42, 47, 71, 255))
    end

    self.Background2 = vgui.Create("DPanel", self.Panel)
    self.Background2:Dock(FILL)
    self.Background2:DockMargin(10, 10, 10, 10)
    self.Background2.Paint = function(self, w, h)
        draw.RoundedBox(0, 0, 0, w, h, Color(32, 37, 62, 255))
    end

    -- if LocalPlayer() == self.Winner then
    --     surface.PlaySound(table.Random(winsounds))
    -- else
    --     surface.PlaySound(table.Random(losesounds))
    -- end

    self.WinnerText = vgui.Create("DLabel", self.Panel)
    self.WinnerText:SetText("Winner: " .. self.Winner:Nick())
    self.WinnerText:SetFont("KyberCore_DuelRequest_Large")
    self.WinnerText:SizeToContents()
    self.WinnerText:Center()
    self.WinnerText:AlignBottom(80)

    // Player information: Show player model of the winner
    self.WinnerModel = vgui.Create("DModelPanel", self.Panel)
    self.WinnerModel:SetSize(self:GetWide(), self:GetTall())
    self.WinnerModel:CenterHorizontal()
    self.WinnerModel:SetModel(self.Winner:GetModel())
    self.WinnerModel:SetLookAt(Vector(0, 0, 50))
    self.WinnerModel:SetCamPos(Vector(50, 50, 75))
    self.WinnerModel:SetAnimated(true)
    self.WinnerModel:SetAnimSpeed(0.25)
    self.WinnerModel:GetEntity():SetSequence(self.Winner:LookupSequence("taunt_cheer"))
    self.WinnerModel:AlignBottom(100)

    local plyRank = KyberCore:GetDuelRank(self.Winner:GetNWInt("KyberCoreDuelingRating"))

    // Player information: DR and rank
    self.DRRankLabel = vgui.Create("DLabel", self.Panel)
    self.DRRankLabel:SetText(plyRank)
    self.DRRankLabel:SetFont("KyberCore_DuelRequest_Medium")
    self.DRRankLabel:SizeToContents()
    self.DRRankLabel:Center()
    self.DRRankLabel:AlignBottom(115)
    self.DRRankLabel:SetColor(KyberCore:GetDuelRankColor(plyRank))

    self.DRLabel = vgui.Create("DLabel", self.Panel)
    self.DRLabel:SetText("(" .. self.Winner:GetNWInt("KyberCoreDuelingRating") .. ")")
    self.DRLabel:SetFont("KyberCore_DuelRequest_Medium")
    self.DRLabel:SizeToContents()
    self.DRLabel:Center()
    self.DRLabel:AlignBottom(52)
    self.DRLabel:SetColor(KyberCore:GetDuelRankColor(plyRank))

    local panel = self

    // Make the model not rotate
    self.WinnerModel.LayoutEntity = function(self, ent)
        if not IsValid(panel) then return end
        if not IsValid(ent) then return end
        if not IsValid(panel.Winner) then return end
        ent:SetAngles(Angle(0, 30, 0))

        panel.DRRankLabel:SetText(plyRank)
        panel.DRLabel:SetText("(" .. panel.Winner:GetNWInt("KyberCoreDuelingRating") .. ")")

        // Get bodygroup and skin, set it to the model
        local bodygroup = panel.Winner:GetBodyGroups()
        local skin = panel.Winner:GetSkin()
        if bodygroup != nil then
            for k, v in pairs(bodygroup) do
                ent:SetBodygroup(v.id, panel.Winner:GetBodygroup(v.id))
            end
        end

        if skin != nil then
            ent:SetSkin(skin)
        end

        self:RunAnimation()

        // Start animation at 0.25
        if ent:GetCycle() < 0.2 then
            ent:SetCycle(0.2)
        end

        // Make animation loop halfway
        if ent:GetCycle() >= 0.8 then
            ent:SetCycle(0.2)
        end
        return
    end

    // Win or lost text
    self.WinText = vgui.Create("DLabel", self.Panel)
    if LocalPlayer() == self.Winner then
        self.WinText:SetColor(Color(155, 255, 40))
        self.WinText:SetText("You won the duel!")
    else
        self.WinText:SetColor(Color(255, 150, 150))
        self.WinText:SetText("You lost the duel!")
    end

    self.WinText:SetFont("KyberCore_DuelRequest_Large")
    self.WinText:SizeToContents()
    self.WinText:Center()
    self.WinText:AlignBottom(20)
end

net.Receive("KyberCore.DuelEnd", function()
    local ply = LocalPlayer()
    local winner = net.ReadEntity()
    local loser = net.ReadEntity()

    if not IsValid(winner) or not IsValid(loser) then return end
    
    DuelResult = vgui.Create("KyberCore.DuelResult")
    DuelResult.Winner = winner
    DuelResult.Loser = loser

    DuelResult:PopulatePanel()
end)

vgui.Register("KyberCore.DuelResult", PANEL, "DFrame")

local function MakeChatCommand(text)
    local message = {}
    message[1] = Color(0,128,255,255)
    message[2] = "[KyberCore] "
    message[3] = Color(255,255,255,255)
    message[4] = text

    chat.AddText(unpack(message))
end

concommand.Add("KyberCore_show_mmr", function(ply, cmd, args)
    local ply = LocalPlayer()

    if not args[1] then
        MsgC(Color(255, 0, 0), "Usage: KyberCore_show_mmr <player>\n")
        return
    end

    local target = nil
    // Find a target
    for k, v in pairs(player.GetAll()) do
        if string.find(string.lower(v:Nick()), string.lower(args[1])) then
            target = v
        end
    end

    if not target then 
        MakeChatCommand("Player not found.")
        return
    end

    local dr = target:GetNWInt("KyberCoreDuelingRating", 0)
    if dr == 0 then
        MakeChatCommand("Failed to find MMR for " .. target:Nick())
        return
    end

    local rank = KyberCore:GetDuelRank(dr)
    MakeChatCommand(target:Nick() .. "'s MMR: " .. dr .. ", wins: " .. target:GetNWInt("KyberCoreDuelingWins", 0) .. ", losses: " .. target:GetNWInt("KyberCoreDuelingLosses", 0) .. ", rank: " .. rank)
end)

function KyberCore:GetDuelRank(rating)
    local rank = "Novice"
    for k, v in pairs(KyberCoreDuelingRanks) do
        if rating >= v.min and rating <= v.max then
            rank = v.name
        end
    end
    return rank
end

function KyberCore:GetDuelRankColor(rank)
    for k, v in pairs(KyberCoreDuelingRanks) do
        if v.name == rank then
            return v.color
        end
    end
    return Color(255, 255, 255)
end

function KyberCore:GetDuelRankMinDR(rank)
    for k, v in pairs(KyberCoreDuelingRanks) do
        if v.name == rank then
            return v.min
        end
    end
    return 0
end

function KyberCore:GetDuelRankMaxDR(rank)
    for k, v in pairs(KyberCoreDuelingRanks) do
        if v.name == rank then
            return v.max
        end
    end
    return 0
end

hook.Add("InitPostEntity", "KyberCore2:Initialize:Client", function()
    net.Start("KyberCore.InitializeDuel")
    net.SendToServer()
end)

concommand.Add("kybercore_reset_ranks", function(ply, cmd, args)
    // You must be a superadmin or system admin to use this command.
    if not ply:IsSuperAdmin() and not KyberCore:IsSystemAdmin(ply) then
        MakeChatCommand("You do not have permission to use this command.")
        return
    end

    // You must also do this THREE times before it will reset, just in case!
    if args[1] == "reset" and args[2] == "ranks" and args[3] == "now" then
        net.Start("KyberCore.ResetDuelRanks")
        net.SendToServer()
    else
        MakeChatCommand("You must type 'kybercore_reset_ranks reset ranks now' to reset all ranks.")
    end
end)