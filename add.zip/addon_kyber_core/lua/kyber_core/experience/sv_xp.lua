KyberCore = KyberCore or {}
util.AddNetworkString("KyberCore.AdminAddXP")
util.AddNetworkString("KyberCore.AdminAddLevel")
util.AddNetworkString("KyberCore.AdminAddPoints")
util.AddNetworkString("KyberCore.AdminSetXP")
util.AddNetworkString("KyberCore.AdminSetLevel")
util.AddNetworkString("KyberCore.AdminSetPoints")

net.Receive("KyberCore.AdminAddXP", function(len, ply)
    local target = net.ReadEntity()
    local amount = net.ReadInt(32)

    if not target or not target:IsValid() or not target:IsPlayer() then return end
    if not amount or amount <= 0 then return end

    // We must be either superadmin or we must be part of the admin list.
    if not ply:IsSuperAdmin() and not KyberCore:IsSystemAdmin(ply) then return end

    KyberCore:AddXP(target, amount)

    hook.Run("KyberCore:AdminPlayerXPAdded", target, ply, amount)
end)

net.Receive("KyberCore.AdminAddLevel", function(len, ply)
    local target = net.ReadEntity()
    local amount = net.ReadInt(32)

    if not target or not target:IsValid() or not target:IsPlayer() then return end
    if not amount or amount <= 0 then return end

    // We must be either superadmin or we must be part of the admin list.
    if not ply:IsSuperAdmin() and not KyberCore:IsSystemAdmin(ply) then return end

    KyberCore:SetLevel(target, KyberCore:GetLevel(target) + amount)
    KyberCore:ResyncExperience(target)
    KyberCore:SaveExperience(ply)

    hook.Run("KyberCore:AdminPlayerLevelAdded", target, ply, amount)
end)

net.Receive("KyberCore.AdminAddPoints", function(len, ply)
    local target = net.ReadEntity()
    local amount = net.ReadInt(32)

    if not target or not target:IsValid() or not target:IsPlayer() then return end
    if not amount or amount <= 0 then return end

    // We must be either superadmin or we must be part of the admin list.
    if not ply:IsSuperAdmin() and not KyberCore:IsSystemAdmin(ply) then return end

    KyberCore:SetPoints(target, KyberCore:GetPoints(target) + amount)
    KyberCore:SaveExperience(ply)

    hook.Run("KyberCore:AdminPlayerPointsAdded", target, ply, amount)
end)

net.Receive("KyberCore.AdminSetXP", function(len, ply)
    local target = net.ReadEntity()
    local amount = net.ReadInt(32)

    if not target or not target:IsValid() or not target:IsPlayer() then return end
    if not amount or amount < 0 then return end

    // We must be either superadmin or we must be part of the admin list.
    if not ply:IsSuperAdmin() and not KyberCore:IsSystemAdmin(ply) then return end

    KyberCore:SetXP(target, amount)
    KyberCore:ResyncLevel(target)
    KyberCore:SaveExperience(ply)

    hook.Run("KyberCore:AdminPlayerXPSet", target, ply, amount)
end)

net.Receive("KyberCore.AdminSetLevel", function(len, ply)
    local target = net.ReadEntity()
    local amount = net.ReadInt(32)

    if not target or not target:IsValid() or not target:IsPlayer() then return end
    if not amount or amount <= 0 then return end

    // We must be either superadmin or we must be part of the admin list.
    if not ply:IsSuperAdmin() and not KyberCore:IsSystemAdmin(ply) then return end

    KyberCore:SetLevel(target, amount)
    KyberCore:ResyncExperience(target)
    KyberCore:SaveExperience(ply)

    hook.Run("KyberCore:AdminPlayerLevelSet", target, ply, amount)
end)

net.Receive("KyberCore.AdminSetPoints", function(len, ply)
    local target = net.ReadEntity()
    local amount = net.ReadInt(32)

    if not target or not target:IsValid() or not target:IsPlayer() then return end
    if not amount or amount < 0 then return end

    // We must be either superadmin or we must be part of the admin list.
    if not ply:IsSuperAdmin() and not KyberCore:IsSystemAdmin(ply) then return end

    KyberCore:SetPoints(target, amount)
    KyberCore:SaveExperience(ply)

    hook.Run("KyberCore:AdminPlayerPointsSet", target, ply, amount)
end)

// Player Experience System!
function KyberCore:AddXP(ply, amount)
    if not ply:IsValid() or not ply:IsPlayer() then return end

    if not amount or amount <= 0 then return end
    amount = tonumber(amount)
    amount = math.floor(amount)

    local currentXP = KyberCore:GetXP(ply) or 0
    local currentLevel = KyberCore:GetLevel(ply) or 1
    local newXP = currentXP + amount    

    if KyberCore.Config.FixedLeveling then
        local newLevel = math.floor(newXP / KyberCore.Config.FixedXP) + 1
        
        if newLevel > currentLevel then
            local diff = newLevel - currentLevel
            KyberCore:LevelUp(ply, diff, currentLevel)
        end
    else
        // Calculate!
        local newLevel = KyberCore:CalculateLevelFromXP(newXP)
        
        if newLevel > currentLevel then
            local diff = newLevel - currentLevel
            KyberCore:LevelUp(ply, diff, currentLevel)
        end
    end

    ply:SetNWInt("KC_EXP", newXP)

    ply:SendLua("notification.AddLegacy('KyberCore: You gained ".. amount .." XP!', NOTIFY_GENERIC, 5)")
    ply:SendLua("LocalPlayer():EmitSound('buttons/button14.wav')")

    // Save to the database!
    KyberCore:SaveExperience(ply)

    hook.Run("KyberCore:PlayerXPAdded", ply, amount)
end

function KyberCore:LevelUp(ply, newLevel, currentLevel)
    if not ply:IsValid() or not ply:IsPlayer() then return end

    if not newLevel or newLevel <= 0 then return end
    newLevel = tonumber(newLevel)
    newLevel = math.floor(newLevel)
    
    // Get them new points!
    local currentPoints = KyberCore:GetPoints(ply) or 0
    local newPoints = currentPoints + (newLevel * KyberCore.Config.PointsPerLevel)
    ply:SetNWInt("KC_EXP_POINTS", newPoints)
    ply:SetNWInt("KC_EXP_LEVEL", KyberCore:GetLevel(ply) + newLevel)

    ply:SendLua("notification.AddLegacy('KyberCore: You leveled up to level ".. KyberCore:GetLevel(ply) .."!', NOTIFY_GENERIC, 5)")
    ply:SendLua("LocalPlayer():EmitSound('buttons/button14.wav')")

    hook.Run("KyberCore:PlayerLevelUp", ply, newLevel, currentLevel)
end

function KyberCore:ResetProgress(ply)
    if not ply:IsValid() or not ply:IsPlayer() then return end

    ply:SetNWInt("KC_EXP", 0)
    ply:SetNWInt("KC_EXP_LEVEL", 1)
    ply:SetNWInt("KC_EXP_POINTS", 0)

    // Save to the database!
    KyberCore:SaveExperience(ply)

    hook.Run("KyberCore:PlayerProgressReset", ply)
end

// Setters
function KyberCore:ResyncExperience(ply)
    // When we set level, we should set the XP to that level so the math doesn't get messed up.
    if not ply:IsValid() or not ply:IsPlayer() then return end
    if not ply:GetNWInt("KC_EXP_LEVEL") or ply:GetNWInt("KC_EXP_LEVEL") <= 0 then return end

    local level = ply:GetNWInt("KC_EXP_LEVEL")
    local xp = 0
    if KyberCore.Config.FixedLeveling then
        xp = (level - 1) * KyberCore.Config.FixedXP
    else
        xp = KyberCore:CalculateXPForLevel(level)
    end

    ply:SetNWInt("KC_EXP", xp)
    ply:SetNWInt("KC_EXP_POINTS", KyberCore:GetPoints(ply) or 0)
    ply:SetNWInt("KC_EXP_LEVEL", level)
end

function KyberCore:ResyncLevel(ply)
    // When we set XP, we should set the level to that XP so the math doesn't get messed up.
    if not ply:IsValid() or not ply:IsPlayer() then return end
    if not ply:GetNWInt("KC_EXP") or ply:GetNWInt("KC_EXP") <= 0 then return end

    local xp = ply:GetNWInt("KC_EXP")
    local level = 1
    if KyberCore.Config.FixedLeveling then
        level = math.floor(xp / KyberCore.Config.FixedXP) + 1
    else
        level = KyberCore:CalculateLevelFromXP(xp)
    end

    ply:SetNWInt("KC_EXP", xp)
    ply:SetNWInt("KC_EXP_POINTS", KyberCore:GetPoints(ply) or 0)
    ply:SetNWInt("KC_EXP_LEVEL", level)
end

function KyberCore:SetXP(ply, amount)
    if not ply:IsValid() or not ply:IsPlayer() then return end

    if not amount or amount < 0 then return end
    amount = tonumber(amount)
    amount = math.floor(amount)

    ply:SetNWInt("KC_EXP", amount)
end

function KyberCore:SetLevel(ply, level)
    if not ply:IsValid() or not ply:IsPlayer() then return end

    if not level or level <= 0 then return end
    level = tonumber(level)
    level = math.floor(level)

    ply:SetNWInt("KC_EXP_LEVEL", level)
end

function KyberCore:SetPoints(ply, points)
    if not ply:IsValid() or not ply:IsPlayer() then return end

    if not points or points < 0 then return end
    points = tonumber(points)
    points = math.floor(points)

    ply:SetNWInt("KC_EXP_POINTS", points)
end