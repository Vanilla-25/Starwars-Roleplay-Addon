KyberCore = KyberCore or {}

function KyberCore:GetXP(ply)
    if not ply:IsValid() or not ply:IsPlayer() then return end

    local currentXP = ply:GetNWInt("KC_EXP", 0)
    return currentXP
end

function KyberCore:GetLevel(ply)
    if not ply:IsValid() or not ply:IsPlayer() then return end

    local currentLevel = ply:GetNWInt("KC_EXP_LEVEL", 1)
    return currentLevel
end

function KyberCore:GetPoints(ply)
    if not ply:IsValid() or not ply:IsPlayer() then return end

    local currentPoints = ply:GetNWInt("KC_EXP_POINTS", 0)
    return currentPoints
end

function KyberCore:CalculateLevelFromXP(totalXP)
    local level = 1
    local xpForNextLevel = KyberCore.Config.XPFormula(level)
    local xpProgress = 0

    while xpProgress + xpForNextLevel <= totalXP do
        xpProgress = xpProgress + xpForNextLevel
        level = level + 1
        xpForNextLevel = KyberCore.Config.XPFormula(level)
    end

    return level
end

function KyberCore:CalculateXPLeftForLevel(totalXP, level)
    local level = 1
    local xpForNextLevel = KyberCore.Config.XPFormula(level)
    local xpProgress = 0

    while xpProgress + xpForNextLevel <= totalXP do
        xpProgress = xpProgress + xpForNextLevel
        level = level + 1
        xpForNextLevel = KyberCore.Config.XPFormula(level)
    end

    local xpLeft = xpForNextLevel - (totalXP - xpProgress)
    return xpLeft
end

function KyberCore:CalculateXPForLevel(level)
    local totalXP = 0
    for i = 1, level do
        totalXP = totalXP + KyberCore.Config.XPFormula(i)
    end

    return totalXP
end