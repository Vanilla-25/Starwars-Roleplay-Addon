KyberCore = KyberCore or {}
MsgC(Color(183, 0, 255), "[Kyber Core] Loading Experience...\n")

////// Database Support //////
function KyberCore:SaveExperienceMySQL(ply)
    // Grab the data from the player.
    local steamID = ply:SteamID64()
    local currentXP = ply:GetNWInt("KC_EXP", 0)
    local currentLevel = ply:GetNWInt("KC_EXP_LEVEL", 1)
    local currentPoints = ply:GetNWInt("KC_EXP_POINTS", 0)

    if KyberCore.Config.Developer then
        MsgC(Color(183, 0, 255), "[KyberCore] Saving experience for player: ", ply:Nick(), " (", steamID, ") - XP: ", currentXP, ", Level: ", currentLevel, ", Points: ", currentPoints, "\n")
    end

    // Save to the database.
    local query = "UPDATE kybercore_experience SET experience = '" .. currentXP .. "', level = '" .. currentLevel .. "', points = '" .. currentPoints .. "' WHERE unique_id = '" .. steamID .. "'"
    KyberCore.DB.Query(query)
end

function KyberCore:LoadExperienceMySQL(ply)
    // Grab from the database.
    local steamID = ply:SteamID64()
    local query = "SELECT * FROM kybercore_experience WHERE unique_id = '" .. steamID .. "'"
    local result = KyberCore.DB.Query(query, function(result)
        if result and #result > 0 then
            local data = result[1]
            ply:SetNWInt("KC_EXP", tonumber(data.experience) or 0)
            ply:SetNWInt("KC_EXP_LEVEL", tonumber(data.level) or 0)
            ply:SetNWInt("KC_EXP_POINTS", tonumber(data.points) or 0)

            // Print to console for debugging.
            if KyberCore.Config.Developer then
                MsgC(Color(183, 0, 255), "[KyberCore] Loaded experience for player: ", ply:Nick(), " (", steamID, ") - XP: ", data.experience, ", Level: ", data.level, ", Points: ", data.points, "\n")
            end
        else
            // No data found, initialize it.
            KyberCore:SetupExperienceMySQL(ply)
        end
    end)
end

function KyberCore:SetupExperienceMySQL(ply)
    // Create player's experience table.
    local steamID = ply:SteamID64()

    // Let's save it all to the database.
    local query = "INSERT INTO kybercore_experience (unique_id, experience, level, points) VALUES ('" .. steamID .. "', '0', '1', '0')"
    KyberCore.DB.Query(query)

    // Initialize the data!
    ply:SetNWInt("KC_EXP", 0)
    ply:SetNWInt("KC_EXP_LEVEL", 1)
    ply:SetNWInt("KC_EXP_POINTS", 0)

    if KyberCore.Config.Developer then
        MsgC(Color(183, 0, 255), "[KyberCore] Welcome to KyberCore! ", ply:Nick(), " (", steamID, ") - XP: 0, Level: 1, Points: 0\n")
    end
end

////// Local Saving Support //////
function KyberCore:SaveExperienceLocal(ply)
    // Grab the data from the player.
    local steamID = ply:SteamID64()
    local currentXP = ply:GetNWInt("KC_EXP", 0)
    local currentLevel = ply:GetNWInt("KC_EXP_LEVEL", 1)
    local currentPoints = ply:GetNWInt("KC_EXP_POINTS", 0)

    if KyberCore.Config.Developer then
        MsgC(Color(183, 0, 255), "[KyberCore] Saving experience for player: ", ply:Nick(), " (", steamID, ") - XP: ", currentXP, ", Level: ", currentLevel, ", Points: ", currentPoints, "\n")
    end

    // Save to the database.
    local query = "UPDATE kybercore_experience SET experience = '" .. currentXP .. "', level = '" .. currentLevel .. "', points = '" .. currentPoints .. "' WHERE unique_id = '" .. steamID .. "'"
    sql.Query(query)
end

function KyberCore:LoadExperienceLocal(ply)
    // Grab from the database.
    local steamID = ply:SteamID64()
    local query = "SELECT * FROM kybercore_experience WHERE unique_id = '" .. steamID .. "'"
    local result = sql.Query(query)

    // Check if the result is valid and not empty.
    if result and #result > 0 then
        local data = result[1]
        ply:SetNWInt("KC_EXP", tonumber(data.experience) or 0)
        ply:SetNWInt("KC_EXP_LEVEL", tonumber(data.level) or 0)
        ply:SetNWInt("KC_EXP_POINTS", tonumber(data.points) or 0)

        // Print to console for debugging.
        if KyberCore.Config.Developer then
            MsgC(Color(183, 0, 255), "[KyberCore] Loaded experience for player: ", ply:Nick(), " (", steamID, ") - XP: ", data.experience, ", Level: ", data.level, ", Points: ", data.points, "\n")
        end
    else
        // No data found, initialize it.
        KyberCore:SetupExperienceLocal(ply)
    end
end

function KyberCore:SetupExperienceLocal(ply)
    // Create player's experience table.
    local steamID = ply:SteamID64()

    // Let's save it all to the local sql.
    local query = "INSERT INTO kybercore_experience (unique_id, experience, level, points) VALUES ('" .. steamID .. "', '0', '1', '0')"
    sql.Query(query)

    // Initialize the data!
    ply:SetNWInt("KC_EXP", 0)
    ply:SetNWInt("KC_EXP_LEVEL", 1)
    ply:SetNWInt("KC_EXP_POINTS", 0)

    if KyberCore.Config.Developer then
        MsgC(Color(183, 0, 255), "[KyberCore] Welcome to KyberCore! ", ply:Nick(), " (", steamID, ") - XP: 0, Level: 1, Points: 0\n")
    end
end

function KyberCore:SaveExperience(ply)
    if KyberCore.Config.SaveLocal then
        self:SaveExperienceLocal(ply)
    else
        self:SaveExperienceMySQL(ply)
    end
end

function KyberCore:LoadExperience(ply)
    if KyberCore.Config.SaveLocal then
        self:LoadExperienceLocal(ply)
    else
        self:LoadExperienceMySQL(ply)
    end
end

function KyberCore:SetupExperience(ply)
    if KyberCore.Config.SaveLocal then
        self:SetupExperienceLocal(ply)
    else
        self:SetupExperienceMySQL(ply)
    end
end

hook.Add("KyberCore:ClientFullyLoaded", "KyberCore:LoadPlayerExperience", function(ply)
    if ply:IsValid() and ply:IsPlayer() then
        KyberCore:LoadExperience(ply)
    end
end)