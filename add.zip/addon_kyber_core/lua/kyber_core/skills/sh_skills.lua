KyberCore = KyberCore or {}
KyberCore.Skills = KyberCore.Skills or {}

// Global skill list getters:
function KyberCore:GetSkill(skillName)
    if not skillName then return end
    return self.Skills[skillName] or nil
end

function KyberCore:GetSkillFromTree(treeName, skillName)
    if not treeName or not skillName then return end
    local tree = self.SkillTrees[treeName]
    return tree and tree.Skills and tree.Skills[skillName] or nil
end

function KyberCore:GetSkills()
    return self.Skills
end

function KyberCore:GetSkillTree(treeName)
    if not treeName then return end
    return self.SkillTrees[treeName] or nil
end

function KyberCore:GetSkillTrees()
    return self.SkillTrees
end

function KyberCore:GetSkillCost(treeName, skillName)
    local skill = (treeName and skillName) and KyberCore:GetSkillFromTree(treeName, skillName) or nil
    return skill and skill.Cost or 0
end

// Player skill getters:
function KyberCore:GetPlayerSkills(ply)
    return ply.KyberCore_Skills
end

// Valid checkers!
function KyberCore:IsValidSkillTree(treeName)
    if not treeName then return false end
    return self.SkillTrees[treeName] and true or false
end

function KyberCore:HasSkill(ply, skillName)
    if not skillName or ply.KyberCore_Skills == nil then return false end
    for _, skill in pairs(ply.KyberCore_Skills) do
        if skill == skillName then return true end
    end

    return false
end

function KyberCore:IsSkillPartOfTree(skillName, treeName)
    if not skillName or not treeName then return false end
    if not self.SkillTrees[treeName] and not self.SkillTrees[treeName]["Skills"][skillName] then return false end
    return true
end

function KyberCore:CanUnlockSkill(ply, skillName, skillTree)
    local skill = KyberCore:GetSkillFromTree(skillTree, skillName)
    if not skill then return end

    // Can't unlock a skill we don't have, or from a skill tree it's not from.
    if not KyberCore:IsSkillPartOfTree(skillName, skillTree) then return false end
    if not KyberCore:IsWhitelisted(ply, skillTree) then return false end
    local ownedSkills = KyberCore:GetPlayerSkills(ply)

    // Lock check: Highest priority.
    for _, ownedSkill in pairs(ownedSkills) do
        local otherSkill = KyberCore:GetSkillFromTree(skillTree, ownedSkill)
        if otherSkill and otherSkill.Locks and otherSkill.Locks[skillName] then
            return false, "LOCKED BY " .. ownedSkill
        end
    end

    // Unlock check: Second highest priority.
    for _, ownedSkill in pairs(ownedSkills) do
        local otherSkill = KyberCore:GetSkillFromTree(skillTree, ownedSkill)
        if otherSkill and otherSkill.Unlocks and otherSkill.Unlocks[skillName] then
            return true, "UNLOCKED BY " .. ownedSkill
        end
    end

    // Requirement check: Lowest priority.
    if skill.Requirements then
        for requirement, _ in pairs(skill.Requirements) do
            if not KyberCore:HasSkill(ply, requirement) then
                return false, "REQUIRES " .. requirement
            end
        end
    end

    return true
end

function KyberCore:CanAffordSkill(ply, skillName, skillTree)
    local skill = KyberCore:GetSkillFromTree(skillTree, skillName)
    if not skill then return end

    // Check if we can afford the skill
    if skill.Cost then
        local currentPoints = KyberCore:GetPoints(ply) or 0
        if not currentPoints or currentPoints < 0 then return false end
        if currentPoints < skill.Cost then return false end
    end

    return true
end

function KyberCore:CanRefundSkill(ply, skillName, skillTree)
    if not skillName or not skillTree then return false end
    if not KyberCore:IsWhitelisted(ply, skillTree) then return false end
    if not KyberCore:HasSkill(ply, skillName) then return false end

    local skill = KyberCore:GetSkillFromTree(skillTree, skillName)
    if not skill then return false end

    local tree = KyberCore:GetSkillTree(skillTree)
    if not tree or not tree.Skills then return false end

    for otherSkillName, data in pairs(tree.Skills) do
        if data.Requirements and data.Requirements[skillName] and KyberCore:HasSkill(ply, otherSkillName) then
            return false
        end
    end

    if skill.Unlocks then
        for unlockedSkillName, _ in pairs(skill.Unlocks) do
            if KyberCore:HasSkill(ply, unlockedSkillName) then
                return false
            end
        end
    end

    return true
end

/// Runs every skill on the player.
function KyberCore:RunPlayerSkills(ply)
    if not ply:IsValid() or not ply:IsPlayer() then return end
    if not ply.KyberCore_Skills then ply.KyberCore_Skills = {} return end
    for index, skillName in ipairs(ply.KyberCore_Skills) do
        local skill = KyberCore:GetSkill(skillName)
        if skill then
            skill.Func(ply)
        end
    end

    hook.Run("KyberCore.RunPlayerSkills", ply)
end

function KyberCore:RunSingleSkill(ply, skillName)
    if not ply:IsValid() or not ply:IsPlayer() then return end

    local skill = KyberCore:GetSkill(skillName)
    if skill then
        skill.Func(ply)
    end

    hook.Run("KyberCore.RunPlayerSkills", ply)
end

///// BONUSES /////
function KyberCore:GetBonusHealth(ply)
    if not ply:IsValid() or not ply:IsPlayer() then return end

    local currentBonusHealth = ply:GetNWInt("KC_BONUS_HEALTH", 0)
    return currentBonusHealth
end

function KyberCore:GetBonusSpeed(ply)
    if not ply:IsValid() or not ply:IsPlayer() then return end

    local currentBonusSpeed = ply:GetNWInt("KC_BONUS_SPEED", 0)
    return currentBonusSpeed
end

function KyberCore:GetBonusBlockPoints(ply)
    if not ply:IsValid() or not ply:IsPlayer() then return end

    local currentBonusBlockPoints = ply:GetNWInt("KC_BONUS_BLOCKPOINTS", 0)
    return currentBonusBlockPoints
end

function KyberCore:GetBonusForce(ply)
    if not ply:IsValid() or not ply:IsPlayer() then return end

    local currentForcePoints = ply:GetNWInt("KC_BONUS_FORCE", 0)
    return currentForcePoints
end
