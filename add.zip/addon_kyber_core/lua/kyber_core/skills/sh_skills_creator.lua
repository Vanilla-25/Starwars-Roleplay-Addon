KyberCore = KyberCore or {}
KyberCore.Skills = KyberCore.Skills or {}

//// Making new skills: This is the actual skills themselves, so what people get.
function KyberCore:AddSkill(data)
    if not data or not data.Name or not data.Description or not data.Image then
        if KyberCore.Config.Developer then
            MsgC(Color(255, 0, 0), "[Kyber Core] Invalid skill data provided.\n")
            debug.Trace()
        end
        return
    end

    self.Skills[data.Name] = {
        Name = data.Name,
        Description = data.Description,
        Image = data.Image,
        Func = data.Func 
    }
    
    if KyberCore.Config.Developer then
        MsgC(Color(0, 255, 255), "[Kyber Core] Adding skill " .. data.Name .. "\n")
    end
end

//// Making new skill trees. This is what people whitelist to.
function KyberCore:AddSkillTree(data)
    if not data then
        if KyberCore.Config.Developer then
            MsgC(Color(255, 0, 0), "[Kyber Core] Tried to add a skill tree, but didn't provide any data.\n")
            debug.Trace()
        end
        return
    end

    if not data.Name then
        if KyberCore.Config.Developer then
            MsgC(Color(255, 0, 0), "[Kyber Core] Tried to add a skill tree, but didn't provide a name.\n")
            debug.Trace()
        end
        return
    end

    if not data.Image then
        if KyberCore.Config.Developer then
            MsgC(Color(255, 0, 0), "[Kyber Core] Tried to add a skill tree, but didn't provide an image.\n")
            debug.Trace()
        end
        return
    end

    self.SkillTrees[data.Name] = {
        Name = data.Name,
        Description = data.Description or "",
        Image = data.Image,
        BackgroundImage = data.BackgroundImage or "",
        BackgroundColor = data.BackgroundColor or Color(255, 255, 255, 255),
        BackgroundSize = data.BackgroundSize or 1,
        Skills = data.Skills or {},
        Exclusive = data.Exclusive or false,
        Func = data.Func 
    }

    if KyberCore.Config.Developer then
        MsgC(Color(191, 255, 0), "[Kyber Core] Adding skill tree " .. data.Name .. "\n")
    end
end

//// This is how we populate the tree.
function KyberCore:AddSkillToTree(treeName, skill)
    // Skill checks. Skills shouldn't work if it isn't valid.
    if not treeName then
        if KyberCore.Config.Developer then
            MsgC(Color(255, 0, 0), "[Kyber Core] Tried to add a skill to tree, but didn't provide a tree name.\n")
            debug.Trace()
        end
        return
    end

    if not skill or not skill.Name then
        if KyberCore.Config.Developer then
            MsgC(Color(255, 0, 0), "[Kyber Core] Tried to add a skill to tree, but didn't provide a skill.\n")
            debug.Trace()
        end
        return
    end

    local skillName = skill.Name
    if not self.SkillTrees[treeName] then
        if KyberCore.Config.Developer then
            MsgC(Color(255, 0, 0), "[Kyber Core] Tried to add " .. skillName .. " to a non-existent tree: " .. treeName .. "\n")
            debug.Trace()
        end
        return
    end

    if not self.Skills[skillName] then
        if KyberCore.Config.Developer then
            MsgC(Color(255, 0, 0), "[Kyber Core] Tried to add a non-existent skill: " .. skillName .. " to tree " .. treeName .. "\n")
            debug.Trace()
        end
        return
    end

    local newSkill = {
        Name = skillName,
        x = skill.x or 0,
        y = skill.y or 0,
        Description = self.Skills[skillName].Description,
        Image = self.Skills[skillName].Image,
        Cost = skill.Cost or 1,
    }

    if skill.Requirements then
        local temp_req_tbl = {}
        for _, requirement in pairs(skill.Requirements) do
            temp_req_tbl[requirement] = true
        end

        newSkill.Requirements = temp_req_tbl
    end

    if skill.Locks then
        local temp_lock_tbl = {}
        for _, lock in pairs(skill.Locks) do
            temp_lock_tbl[lock] = true
        end

        newSkill.Locks = temp_lock_tbl
    end

    if skill.Unlocks then
        local temp_unlock_tbl = {}
        for _, unlock in pairs(skill.Unlocks) do
            temp_unlock_tbl[unlock] = true
        end

        newSkill.Unlocks = temp_unlock_tbl
    end

    self.SkillTrees[treeName].Skills[skillName] = newSkill
    
    if KyberCore.Config.Developer then
        MsgC(Color(200, 0, 255), "[Kyber Core] Adding skill " .. skillName .. " to tree " .. treeName .. "\n")
    end
end

function KyberCore:ReloadSkills()
    if not KyberCore.RefreshTimeout then
        KyberCore.RefreshTimeout = CurTime()
    end

    if CurTime() < KyberCore.RefreshTimeout then
        MsgC(Color(255, 0, 0), "[Kyber Core] Cooldown hit!\n")
        return
    end

    MsgC(Color(183, 0, 255), "[Kyber Core] Reloading skills...\n")

    self.RefreshTimeout = CurTime() + 1.5

    KyberCore.Skills = {}
    KyberCore.SkillTrees = {}

    local directory = "kyber_core/skills/skilltrees"
    local files, _ = file.Find(directory .. "/*", "LUA")

    // Load everything within shared.
	for _, fileName in pairs(files) do
		local relativePath = directory .. "/" .. fileName
        AddCSLuaFile(relativePath)
        include(relativePath)
	end

    // If we have the menu up, we should refresh it, for quality of life.
    if CLIENT then
        if LSCS then
            LSCS:ReloadSkillMenu()
        end
    end
end

KyberCore:ReloadSkills()