KyberCore = KyberCore or {}

util.AddNetworkString("KyberCore.SyncSkills")
util.AddNetworkString("KyberCore.UnlockSkill")
util.AddNetworkString("KyberCore.RefundSkill")
util.AddNetworkString("KyberCore.RunSingleSkill")

///// HEALTH /////
function KyberCore:SetBonusHealth(ply, amount)
    if not ply:IsValid() or not ply:IsPlayer() then return end
    if not amount or amount <= 0 then return end
    amount = tonumber(amount)
    amount = math.floor(amount)

    ply:SetNWInt("KC_BONUS_HEALTH", amount)
end

function KyberCore:ResetBonusHealth(ply)
    if not ply:IsValid() or not ply:IsPlayer() then return end

    ply:SetNWInt("KC_BONUS_HEALTH", 0)
end

function KyberCore:AddBonusHealth(ply, amount)
    if not ply:IsValid() or not ply:IsPlayer() then return end
    if not amount or amount <= 0 then return end
    amount = tonumber(amount)
    amount = math.floor(amount)

    local currentBonusHealth = self:GetBonusHealth(ply) or 0
    local newBonusHealth = currentBonusHealth + amount

    ply:SetNWInt("KC_BONUS_HEALTH", newBonusHealth)
end

//////////////////////////
///// MOVEMENT SPEED /////
//////////////////////////
function KyberCore:SetBonusSpeed(ply, amount)
    if not ply:IsValid() or not ply:IsPlayer() then return end
    if not amount or amount <= 0 then return end
    amount = tonumber(amount)
    amount = math.floor(amount)

    ply:SetNWInt("KC_BONUS_SPEED", amount)
end

function KyberCore:ResetBonusSpeed(ply)
    if not ply:IsValid() or not ply:IsPlayer() then return end

    ply:SetNWInt("KC_BONUS_SPEED", 0)
end

function KyberCore:AddBonusSpeed(ply, amount)
    if not ply:IsValid() or not ply:IsPlayer() then return end
    if not amount or amount <= 0 then return end
    amount = tonumber(amount)
    amount = math.floor(amount)

    local currentBonusSpeed = self:GetBonusSpeed(ply) or 0
    local newBonusSpeed = currentBonusSpeed + amount

    ply:SetNWInt("KC_BONUS_SPEED", newBonusSpeed)
end

////////////////////////
///// BLOCK POINTS /////
////////////////////////
function KyberCore:SetBonusBlockPoints(ply, amount)
    if not ply:IsValid() or not ply:IsPlayer() then return end
    if not amount or amount <= 0 then return end
    amount = tonumber(amount)
    amount = math.floor(amount)

    ply:SetNWInt("KC_BONUS_BLOCKPOINTS", amount)
end

function KyberCore:ResetBonusBlockPoints(ply)
    if not ply:IsValid() or not ply:IsPlayer() then return end

    ply:SetNWInt("KC_BONUS_BLOCKPOINTS", 0)
end

function KyberCore:AddBonusBlockPoints(ply, amount)
    if not ply:IsValid() or not ply:IsPlayer() then return end
    if not amount or amount <= 0 then return end
    amount = tonumber(amount)
    amount = math.floor(amount)

    local currentBonusBlockPoints = self:GetBonusBlockPoints(ply) or 0
    local newBonusBlockPoints = currentBonusBlockPoints + amount

    ply:SetNWInt("KC_BONUS_BLOCKPOINTS", newBonusBlockPoints)
end

/////////////////
///// FORCE /////
/////////////////
function KyberCore:SetBonusForce(ply, amount)
    if not ply:IsValid() or not ply:IsPlayer() then return end
    if not amount or amount <= 0 then return end
    amount = tonumber(amount)
    amount = math.floor(amount)

    ply:SetNWInt("KC_BONUS_FORCE", amount)
end

function KyberCore:ResetBonusForce(ply)
    if not ply:IsValid() or not ply:IsPlayer() then return end

    ply:SetNWInt("KC_BONUS_FORCE", 0)
end

function KyberCore:AddBonusForce(ply, amount)
    if not ply:IsValid() or not ply:IsPlayer() then return end
    if not amount or amount <= 0 then return end
    amount = tonumber(amount)
    amount = math.floor(amount)

    local currentForcePoints = self:GetBonusForce(ply) or 0
    local newForcePoints = currentForcePoints + amount

    ply:SetNWInt("KC_BONUS_FORCE", newForcePoints)
end

net.Receive("KyberCore.UnlockSkill", function(len, ply)
    local skillName = net.ReadString()
    local skillTree = net.ReadString()
    KyberCore:UnlockSkill(ply, skillName, skillTree)
end)

net.Receive("KyberCore.RefundSkill", function(len, ply)
    local skillName = net.ReadString()
    local skillTree = net.ReadString()
    if skillTree == "" then skillTree = nil end
    KyberCore:RefundSkill(ply, skillName, skillTree)
end)

function KyberCore:UnlockSkill(ply, skillName, skillTree)
    if not KyberCore:CanUnlockSkill(ply, skillName, skillTree) then return end
    if not KyberCore:CanAffordSkill(ply, skillName, skillTree) then return end
    KyberCore:AddOwnedSkill(ply, skillName)

    // Remove the points from the player
    local currentPoints = KyberCore:GetPoints(ply) or 0
    local skill = KyberCore:GetSkillFromTree(skillTree, skillName)
    if skill.Cost then
        local newPoints = currentPoints - skill.Cost
        KyberCore:SetPoints(ply, newPoints)
        KyberCore:SaveExperience(ply)
    end
end

function KyberCore:RefundSkill(ply, skillName, skillTree)
    if not KyberCore:CanRefundSkill(ply, skillName, skillTree) then return end
    KyberCore:RemoveOwnedSkill(ply, skillName)

    // Refund the points to the player
    local currentPoints = KyberCore:GetPoints(ply) or 0
    local skill = KyberCore:GetSkillFromTree(skillTree, skillName)
    if skill.Cost then
        local newPoints = currentPoints + skill.Cost
        KyberCore:SetPoints(ply, newPoints)
        KyberCore:SaveExperience(ply)
    end
end

// Used when we add a NEW skill to the player.
function KyberCore:AddOwnedSkill(ply, skillName)
    if not ply:IsValid() or not ply:IsPlayer() then return end
    if not skillName or skillName == "" then return end

    if not ply.KyberCore_Skills then ply.KyberCore_Skills = {} end
    for k, v in pairs(ply.KyberCore_Skills) do
        if v == skillName then return end
    end
    
    table.insert(ply.KyberCore_Skills, skillName)

    KyberCore:SyncSkills(ply)
    KyberCore:SaveSkills(ply, skillName)
end

// Used when we load a skill from the database.
function KyberCore:LoadOwnedSkill(ply, skillName)
    if not ply:IsValid() or not ply:IsPlayer() then return end
    if not skillName or skillName == "" then return end
        
    if not ply.KyberCore_Skills then ply.KyberCore_Skills = {} end
    for k, v in pairs(ply.KyberCore_Skills) do
        if v == skillName then return end
    end

    table.insert(ply.KyberCore_Skills, skillName)
end

function KyberCore:RemoveOwnedSkill(ply, skillName)
    if not ply:IsValid() or not ply:IsPlayer() then return end
    if not skillName or skillName == "" then return end

    if not ply.KyberCore_Skills then ply.KyberCore_Skills = {} end
    for i, skill in ipairs(ply.KyberCore_Skills) do
        if skill == skillName then
            table.remove(ply.KyberCore_Skills, i)
            break
        end
    end

    KyberCore:RemoveSkills(ply, skillName)
    KyberCore:SyncSkills(ply)
end

function KyberCore:RemoveOwnedSkillNoSave(ply, skillName)
    if not ply:IsValid() or not ply:IsPlayer() then return end
    if not skillName or skillName == "" then return end

    if not ply.KyberCore_Skills then ply.KyberCore_Skills = {} end
    for i, skill in ipairs(ply.KyberCore_Skills) do
        if skill == skillName then
            table.remove(ply.KyberCore_Skills, i)
            break
        end
    end
end

function KyberCore:RefundSkillTree(ply, skillTree)
    if not ply:IsValid() or not ply:IsPlayer() then return end
    if not skillTree or skillTree == "" then return end
    local tempSkills = table.Copy(ply.KyberCore_Skills)
    local refunds = 0
    for index, skill in pairs(tempSkills) do
        if KyberCore.SkillTrees[skillTree]["Skills"][skill] then
            // Get the skill's cost, so we know how much to refund.
            local skillCost = KyberCore.Skills[skill].Cost or 0
            refunds = refunds + skillCost
            KyberCore:RemoveSkills(ply, skill)
            KyberCore:RemoveOwnedSkillNoSave(ply, skill)
        end
    end
    // Give the player the points back.
    local currentPoints = KyberCore:GetPoints(ply) or 0
    local newPoints = currentPoints + refunds
    KyberCore:SetPoints(ply, newPoints)
    KyberCore:SyncSkills(ply)
end

function KyberCore:SyncSkills(ply)
    if not ply:IsValid() or not ply:IsPlayer() then return end

    // Compress!
    if not ply.KyberCore_Skills then ply.KyberCore_Skills = {} end
    
    local compressedSkills = util.Compress(util.TableToJSON(ply.KyberCore_Skills))
    net.Start("KyberCore.SyncSkills")
        net.WriteData(compressedSkills, #compressedSkills)
    net.Send(ply)

    // Run all the skills, right here!
    KyberCore:SetupPlayer(ply)
    hook.Run("KyberCore.SyncSkills", ply, ply.KyberCore_Skills)
end