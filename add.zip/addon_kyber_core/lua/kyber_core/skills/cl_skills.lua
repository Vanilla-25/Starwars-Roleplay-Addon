KyberCore = KyberCore or {}

function KyberCore:UnlockSkill(skillName, skillTree)
    if not skillName or not skillTree then return end
    if not KyberCore:CanUnlockSkill(LocalPlayer(), skillName, skillTree) then return false end
    if not KyberCore:CanAffordSkill(LocalPlayer(), skillName, skillTree) then return false end

    net.Start("KyberCore.UnlockSkill")
        net.WriteString(skillName)
        net.WriteString(skillTree or "")
    net.SendToServer()

    return true
end

function KyberCore:RefundSkill(skillName, skillTree)
    if not skillName or not skillTree then return end
    if not KyberCore:HasSkill(LocalPlayer(), skillName) then return false end
    if not KyberCore:CanRefundSkill(LocalPlayer(), skillName, skillTree) then return false end

    net.Start("KyberCore.RefundSkill")
        net.WriteString(skillName)
        net.WriteString(skillTree)
    net.SendToServer()

    return true
end

net.Receive("KyberCore.SyncSkills", function(len)
    local compressedSkills = net.ReadData(len)
    local skills = util.Decompress(compressedSkills)
    skills = util.JSONToTable(skills)

    LocalPlayer().KyberCore_Skills = skills
    KyberCore:SetupPlayer(LocalPlayer())
    
    hook.Run("KyberCore.SyncSkills", LocalPlayer(), skills)
end)

// STONEOS CUSTOM HOOKS!

hook.Add( "PreDrawHalos", "KyberCore.BrazenHalo", function()
    local brazen = {}
    local absorb = {}
    local radiance = {}

    for _,ply in pairs( player.GetAll() ) do
		if not IsValid( ply ) then continue end
		if not ply:Alive() then continue end
        if ply:GetNWBool("KyberCorePower_Brazen", false) then
            table.insert( brazen, ply )
        end

        if ply:GetNWBool("KyberCorePower_Absorb", false) then
            table.insert( absorb, ply )
        end

        if ply:GetNWBool("KyberCorePower_Radiance", false) then
            table.insert( radiance, ply )
        end

	end

	if #brazen > 0 then
		halo.Add( brazen, Color( 255, 0, 0, 175 ), 5, 5, 3, true, false )
	end

    if #absorb > 0 then
        halo.Add( absorb, Color( 0, 255, 75, 175), 5, 5, 3, true, false )
    end

    if #radiance > 0 then
        halo.Add( radiance, Color( 150, 20, 1023, 175), 5, 5, 3, true, false )
    end

end)
