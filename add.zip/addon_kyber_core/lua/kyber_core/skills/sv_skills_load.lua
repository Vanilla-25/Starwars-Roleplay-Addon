KyberCore = KyberCore or {}
KyberCore.Skills = KyberCore.Skills or {}
function KyberCore:SaveSkillsMySQL(ply, skill)
    // Grab the data from the player.
    local steamID = ply:SteamID64()
    skill = sql.SQLStr(skill, true)

    if KyberCore.Config.Developer then
        MsgC(Color(183, 0, 255), "[KyberCore] Saving skill for player: ", ply:Nick(), " (", steamID, ") - Skill: ", skill, "\n")
    end

    // Save to the database.
    local query = "INSERT INTO kybercore_skills (unique_id, skills) VALUES ('" .. steamID .. "', '" .. skill .. "')"
    KyberCore.DB.Query(query)
end

function KyberCore:RemoveSkillsMySQL(ply, skill)
    // Remove from the database.
    local steamID = ply:SteamID64()
    skill = sql.SQLStr(skill, true)

    if KyberCore.Config.Developer then
        MsgC(Color(255, 0, 0), "[KyberCore] Removing skill for player: ", ply:Nick(), " (", steamID, ") - Skill: ", skill, "\n")
    end

    local query = "DELETE FROM kybercore_skills WHERE unique_id = '" .. steamID .. "' AND skills = '" .. skill .. "'"
    KyberCore.DB.Query(query)
end

function KyberCore:LoadSkillsMySQL(ply)
    // Grab from the database.
    local steamID = ply:SteamID64()
    local query = "SELECT * FROM kybercore_skills WHERE unique_id = '" .. steamID .. "'"
    KyberCore.DB.Query(query, function(result)
        if result and #result > 0 then
            for _, skills in ipairs(result) do
                local skill = skills.skills
                // If the skill doesn't exist, then oop! Let's complain about it.
                if not KyberCore.Skills[skill] then
                    if KyberCore.Config.Developer then
                        MsgC(Color(255, 0, 0), "[Kyber Core] Tried to load a non-existent skill: " .. skill .. "\n") 
                    end
                    // We should remove this instead.
                    KyberCore:RemoveSkills(ply, skill)
                    continue
                end
                KyberCore:LoadOwnedSkill(ply, skill)
            end
        end

        KyberCore:SyncSkills(ply)
    end)
end

function KyberCore:SaveSkillsLocal(ply, skill)
    // Save to the database.
    skill = sql.SQLStr(skill, true)

    local steamID = ply:SteamID64()
    // INSERT, but only if it doesn't exist.
    local query = "INSERT INTO kybercore_skills (unique_id, skills) VALUES ('" .. steamID .. "', '" .. skill .. "')"
    sql.Query(query)
end

function KyberCore:RemoveSkillsLocal(ply, skill)
    // Remove from the database.
    skill = sql.SQLStr(skill, true)

    local steamID = ply:SteamID64()
    local query = "DELETE FROM kybercore_skills WHERE unique_id = '" .. steamID .. "' AND skills = '" .. skill .. "'"
    sql.Query(query)
end

function KyberCore:LoadSkillsLocal(ply)
    ply.KyberCore_Skills = {}
    // Grab from the database.
    local steamID = ply:SteamID64()
    local query = "SELECT * FROM kybercore_skills WHERE unique_id = '" .. steamID .. "'"
    local result = sql.Query(query)
    if result and #result > 0 then
        for _, skills in ipairs(result) do
            local skill = skills.skills
            // If the skill doesn't exist, then oop! Let's complain about it.
            if not KyberCore.Skills[skill] then
                if KyberCore.Config.Developer then
                    MsgC(Color(255, 0, 0), "[Kyber Core] Tried to load a non-existent skill: " .. skill .. "\n") 
                end
                // We should remove this instead.
                KyberCore:RemoveSkills(ply, skill)
                continue
            end
            KyberCore:LoadOwnedSkill(ply, skill)
        end
    end

    KyberCore:SyncSkills(ply)
end

function KyberCore:SaveSkills(ply, skill)
    if KyberCore.Config.SaveLocal then
        self:SaveSkillsLocal(ply, skill)
    else
        self:SaveSkillsMySQL(ply, skill)
    end
end

function KyberCore:RemoveSkills(ply, skill)
    if KyberCore.Config.SaveLocal then
        self:RemoveSkillsLocal(ply, skill)
    else
        self:RemoveSkillsMySQL(ply, skill)
    end
end

function KyberCore:LoadSkills(ply)
    if KyberCore.Config.SaveLocal then
        self:LoadSkillsLocal(ply)
    else
        self:LoadSkillsMySQL(ply)
    end
end

hook.Add("KyberCore:ClientFullyLoaded", "KyberCore:LoadPlayerSkills", function(ply)
    if ply:IsValid() and ply:IsPlayer() then
        KyberCore:LoadSkills(ply)
    end
end)