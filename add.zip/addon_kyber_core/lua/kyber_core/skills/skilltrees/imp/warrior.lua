//////////////////////
// Skill Tree Registry
//////////////////////
local skillTreeName = "Pathway: Warrior"

local skillTree = {}
skillTree.Name = skillTreeName
skillTree.Description = "The Way of the Warrior"
skillTree.Image = "entities/blade_launch.png"
skillTree.BackgroundColor = Color(0, 0, 255, 180)
skillTree.BackgroundSize = 0.4
KyberCore:AddSkillTree(skillTree)

////////////////////
// Skill Registry
////////////////////

local skill = {}
skill.Name = "Saber launch"
skill.Description = "Use the force to throw your saber and control it with the force."
skill.Image = "entities/blade_launch.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "launch")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Brazen"
skill.Description = "Use the force to enhance your strikes for a small duration of time doubling the damage of your strikes."
skill.Image = "kybercore/brazen.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "brazen")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Slow"
skill.Description = "Using the force cloud some of the target's senses and slow them down making them easier to hit."
skill.Image = "kybercore/slow.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "slow")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Propulsion"
skill.Description = "Launch a shotgun of concussive force energy towards your targets."
skill.Image = "kybercore/propulsion.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "propulsion")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Burn Out"
skill.Description = "Use the force to exert a small torrent of flames from your palm burning those that come into touch."
skill.Image = "kybercore/burnout.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "burnout")
end
KyberCore:AddSkill(skill)
  
local skill = {}
skill.Name = "Stamina Increase for Warrior 1"
skill.Description = "Increase max stamina by +5."
skill.Image = "kybercore/stamina.png"
skill.Func = function(ply)
    if SERVER then
        KyberCore:AddBonusBlockPoints(ply, 5)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Increase for Warrior 1"
skill.Description = "Increases maximum force by +15"
skill.Image = "kybercore/force_increase.png"
skill.Func = function(ply)
    if SERVER then 
        KyberCore:AddBonusForce(ply, 15)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Speed Increase for Warrior 1"
skill.Description = "Increase run speed by +5"
skill.Image = "entities/speed.png"
skill.Func = function(ply)
    if SERVER then
        KyberCore:AddBonusSpeed(ply, 5)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Stamina Increase for Warrior 2"
skill.Description = "Increase max stamina by +5."
skill.Image = "kybercore/stamina.png"
skill.Func = function(ply)
    if SERVER then
        KyberCore:AddBonusBlockPoints(ply, 5)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Increase for Warrior 2"
skill.Description = "Increases maximum force by +15"
skill.Image = "kybercore/force_increase.png"
skill.Func = function(ply)
    if SERVER then 
        KyberCore:AddBonusForce(ply, 15)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Speed Increase for Warrior 2"
skill.Description = "Increase run speed by +5"
skill.Image = "entities/speed.png"
skill.Func = function(ply)
    if SERVER then
        KyberCore:AddBonusSpeed(ply, 5)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Stamina Increase for Warrior 3"
skill.Description = "Increase max stamina by +10."
skill.Image = "kybercore/stamina.png"
skill.Func = function(ply)
    if SERVER then
        KyberCore:AddBonusBlockPoints(ply, 10)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Stamina Increase for Warrior 4"
skill.Description = "Increase max stamina by +10."
skill.Image = "kybercore/stamina.png"
skill.Func = function(ply)
    if SERVER then
        KyberCore:AddBonusBlockPoints(ply, 10)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Increase for Warrior 3"
skill.Description = "Increases maximum force by +15"
skill.Image = "kybercore/force_increase.png"
skill.Func = function(ply)
    if SERVER then 
        KyberCore:AddBonusForce(ply, 15)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Speed Increase for Warrior 3"
skill.Description = "Increase run speed by +5"
skill.Image = "entities/speed.png"
skill.Func = function(ply)
    if SERVER then
        KyberCore:AddBonusSpeed(ply, 5)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Stamina Increase for Warrior 5"
skill.Description = "Increase max stamina by +15."
skill.Image = "kybercore/stamina.png"
skill.Func = function(ply)
    if SERVER then
        KyberCore:AddBonusBlockPoints(ply, 15)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Increase for Warrior 4"
skill.Description = "Increases maximum force by +15"
skill.Image = "kybercore/force_increase.png"
skill.Func = function(ply)
    if SERVER then 
        KyberCore:AddBonusForce(ply, 15)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Speed Increase for Warrior 4"
skill.Description = "Increase run speed by +5"
skill.Image = "entities/speed.png"
skill.Func = function(ply)
    if SERVER then
        KyberCore:AddBonusSpeed(ply, 5)
    end
end
KyberCore:AddSkill(skill)

///////////////////////////
// Skill Tree Config
///////////////////////////

local skill = {}
skill.Name = "Saber launch"
skill.x = 0.05
skill.y = 0.5
skill.Cost = 1
skill.Requirements = {
    "Force Jump",
    "Form I: Shii-Cho",
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Brazen"
skill.x = 0.32
skill.y = 0.08
skill.Cost = 4
skill.Requirements = {
    "Force Increase for Warrior 2",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Slow"
skill.x = 0.32
skill.y = 0.9
skill.Cost = 4
skill.Requirements = {
    "Speed Increase for Warrior 2",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Propulsion"
skill.x = 0.62
skill.y = 0.5
skill.Cost = 8
skill.Requirements = {
    "Force Increase for Warrior 4",
    "Stamina Increase for Warrior 4",
    "Speed Increase for Warrior 4",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Burn Out"
skill.x = 0.7
skill.y = 0.5
skill.Cost = 12
skill.Requirements = {
    "Force Propulsion",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Stamina Increase for Warrior 1"
skill.x = 0.13
skill.y = 0.5
skill.Cost = 2
skill.Requirements = {
    "Saber launch",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Increase for Warrior 1"
skill.x = 0.15
skill.y = 0.12
skill.Cost = 2
skill.Requirements = {
    "Stamina Increase for Warrior 1",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Speed Increase for Warrior 1"
skill.x = 0.15
skill.y = 0.88
skill.Cost = 2
skill.Requirements = {
    "Stamina Increase for Warrior 1",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Stamina Increase for Warrior 2"
skill.x = 0.20
skill.y = 0.5
skill.Cost = 3
skill.Requirements = {
    "Stamina Increase for Warrior 1",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Increase for Warrior 2"
skill.x = 0.23
skill.y = 0.25
skill.Cost = 3
skill.Requirements = {
    "Stamina Increase for Warrior 2",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Speed Increase for Warrior 2"
skill.x = 0.23
skill.y = 0.75
skill.Cost = 3
skill.Requirements = {
    "Stamina Increase for Warrior 2",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Increase for Warrior 3"
skill.x = 0.4
skill.y = 0.25
skill.Cost = 5
skill.Requirements = {
    "Force Brazen",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Speed Increase for Warrior 3"
skill.x = 0.4
skill.y = 0.75
skill.Cost = 5
skill.Requirements = {
    "Force Slow",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Stamina Increase for Warrior 3"
skill.x = 0.32
skill.y = 0.5
skill.Cost = 4
skill.Requirements = {
    "Stamina Increase for Warrior 2",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Stamina Increase for Warrior 4"
skill.x = 0.45
skill.y = 0.5
skill.Cost = 6
skill.Requirements = {
    "Stamina Increase for Warrior 3",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Increase for Warrior 4"
skill.x = 0.5
skill.y = 0.12
skill.Cost = 7
skill.Requirements = {
    "Stamina Increase for Warrior 5",
}
skill.Unlocks = {
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Stamina Increase for Warrior 5"
skill.x = 0.53
skill.y = 0.5
skill.Cost = 7
skill.Requirements = {
    "Stamina Increase for Warrior 4",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Speed Increase for Warrior 4"
skill.x = 0.5
skill.y = 0.85
skill.Cost = 7
skill.Requirements = {
    "Stamina Increase for Warrior 5",
}
skill.Unlocks = {
}
KyberCore:AddSkillToTree(skillTreeName, skill)

if KyberCore.Config.Developer then
    KyberCore:ReloadSkills()
end
