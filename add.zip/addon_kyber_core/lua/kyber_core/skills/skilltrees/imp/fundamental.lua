//////////////////////
// Skill Tree Registry
//////////////////////
local skillTreeName = "Fundamental"

local skillTree = {}
skillTree.Name = skillTreeName
skillTree.Description = "This is the Way"
skillTree.Image = "wos/skilltrees/fundamental.jpg"
KyberCore:AddSkillTree(skillTree)

////////////////////
// Skill Registry
////////////////////

local skill = {}
skill.Name = "Form I: Shii-Cho"
skill.Description = "Teaches the basic moves of attack, parry and block."
skill.Image = "kybercore/form1.png"
skill.Func = function(ply)
    KyberCore:AddKnownForm(ply, "form1")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Jump"
skill.Description = "Use the force to Jump up to areas which are normally out of range."
skill.Image = "entities/item_force_jump.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "jump_2")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Push"
skill.Description = "Use the force to send a target flying backwards from the user."
skill.Image = "entities/item_force_push.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "push")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Pull"
skill.Description = "Use the force to send a target flying towards the user."
skill.Image = "entities/item_force_pull.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "pull")
end
KyberCore:AddSkill(skill)

///////////////////////////
// Skill Tree Config
///////////////////////////
local skill = {}
skill.Name = "Form I: Shii-Cho"
skill.x = 0.15
skill.y = 0.5
skill.Cost = 0
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Jump"
skill.x = 0.29
skill.y = 0.5
skill.Cost = 1
skill.Requirements = {
    "Form I: Shii-Cho",
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Push"
skill.x = 0.41
skill.y = 0.5
skill.Cost = 2
skill.Requirements = {
    "Force Jump",
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Pull"
skill.x = 0.57
skill.y = 0.5
skill.Cost = 3
skill.Requirements = {
    "Force Push",
}
KyberCore:AddSkillToTree(skillTreeName, skill)



if KyberCore.Config.Developer then
    KyberCore:ReloadSkills()
end