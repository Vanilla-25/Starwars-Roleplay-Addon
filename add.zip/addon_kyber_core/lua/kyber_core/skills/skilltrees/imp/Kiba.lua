//////////////////////
// Skill Tree Registry
//////////////////////
local skillTreeName = "Pathway: Sovereign Protector"

local skillTree = {}
skillTree.Name = skillTreeName
skillTree.Description = "The Enforcer Crushes All"
skillTree.Image = "kybercore/burnout.png"
KyberCore:AddSkillTree(skillTree)

////////////////////
// Skill Registry
////////////////////

local skill = {}
skill.Name = "Form 5: Shien (Vader)"
skill.Description = "The modified version of Form V, utilised by Vader due to his 'unique' circumstances."
skill.Image = "kybercore/form5.png"
skill.Func = function(ply)
    KyberCore:AddKnownForm(ply, "form5v")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "SP Speed Increase"
skill.Description = "Increase max speed by +100."
skill.Image = "entities/speed.png"
skill.Func = function(ply)
    if SERVER then
        KyberCore:AddBonusSpeed(ply, 100)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "SP Stamina Increase"
skill.Description = "Increase max stamina by +400."
skill.Image = "kybercore/stamina.png"
skill.Func = function(ply)
    if SERVER then
        KyberCore:AddBonusBlockPoints(ply, 400)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "SP Force Increase"
skill.Description = "Increases maximum force by +250."
skill.Image = "kybercore/force_increase.png"
skill.Func = function(ply)
    if SERVER then 
        KyberCore:AddBonusForce(ply, 250)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Leap"
skill.Description = "Use the force to Leap up to areas which are out of range even those who are jumping."
skill.Image = "entities/item_force_leap.png"
skill.Func = function(ply)
    if SERVER then 
        KyberCore:AddKnownPower(ply, "jump_3")
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Self Revive"
skill.Description = "By sheer will power and whatever remaining force you have left you bring yourself back from the brink."
skill.Image = "kybercore/self_revive.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "selfrevive")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Radiance"
skill.Description = "Flood your body with radiant energy, greatly enhancing your speed and force control for a short time."
skill.Image = "kybercore/radiance.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "rad")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Boulder Throw"
skill.Description = "Call upon raw telekinetic might to summon and hurl a massive boulder at your enemies."
skill.Image = "kybercore/boulder.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "boulderthrow")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Blink"
skill.Description = "Use the force to teleport yourself to different locations of the users choice."
skill.Image = "kybercore/teleport.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "blink")
 end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Electric Judgement"
skill.Description = "Electric Judgement emits as a burst of electric energy directed at a target, intended to neutralize rather than to kill or severely harm."
skill.Image = "entities/item_force_lightning.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "ej")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Group Heal"
skill.Description = "Use the force to heal multiple targets including yourself."
skill.Image = "kybercore/group_heal.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "groupheal")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Heal"
skill.Description = "Use the force to heal a target."
skill.Image = "entities/item_force_heal.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "heal")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Stasis"
skill.Description = "Use the force to freeze your enemies in their track and immobilise them for a few seconds."
skill.Image = "kybercore/stasis.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "stasis")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Slow"
skill.Description = "Using the force cloud some of the target's senses and slow them down making them easier to hit."
skill.Image = "kybercore/slow.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "slow")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Barrier"
skill.Description = "Create a protective barrier using the force."
skill.Image = "kybercore/barrier.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "bar")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Telekenesis"
skill.Description = "Allows you to gain full control of a target and be able to manipulate the target in certain ways e.g. pick them up and throw them."
skill.Image = "kybercore/telekenesis.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "telekenesis")
end
KyberCore:AddSkill(skill)


///////////////////////////
// Skill Tree Config
///////////////////////////
local skill = {}
skill.Name = "Form 5: Shien (Vader)"
skill.x = 0.05
skill.y = 0.2
skill.Cost = 0
skill.Requirements = {
    "Form I: Shii-Cho",
}
KyberCore:AddSkillToTree(skillTreeName, skill)


local skill = {}
skill.Name = "SP Speed Increase"
skill.x = 0.05
skill.y = 0.5
skill.Cost = 0
skill.Requirements = {
    "Form I: Shii-Cho",
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "SP Stamina Increase"
skill.x = 0.2
skill.y = 0.5
skill.Cost = 0
skill.Requirements = {
    "SP Speed Increase",
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "SP Force Increase"
skill.x = 0.4
skill.y = 0.5
skill.Cost = 0
skill.Requirements = {
    "SP Stamina Increase",
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Barrier"
skill.x = 0.6
skill.y = 0.5
skill.Cost = 0
skill.Requirements = {
    "SP Force Increase",
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Telekenesis"
skill.x = 0.8
skill.y = 0.5
skill.Cost = 0
skill.Requirements = {
    "Force Barrier",
}
KyberCore:AddSkillToTree(skillTreeName, skill)


local skill = {}
skill.Name = "Force Leap"
skill.x = 0.22
skill.y = 0.8
skill.Cost = 0
skill.Requirements = {
    "SP Speed Increase",
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Self Revive"
skill.x = 0.22
skill.y = 0.2
skill.Cost = 0
skill.Requirements = {
    "SP Speed Increase",
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Radiance"
skill.x = 0.35
skill.y = 0.8
skill.Cost = 0
skill.Requirements = {
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Boulder Throw"
skill.x = 0.35
skill.y = 0.2
skill.Cost = 0
skill.Requirements = {
    "Self Revive",
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Blink"
skill.x = 0.48
skill.y = 0.8
skill.Cost = 0
skill.Requirements = {
    "Force Radiance",
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Heal"
skill.x = 0.62
skill.y = 0.8
skill.Cost = 0
skill.Requirements = {
    "Force Blink",
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Group Heal"
skill.x = 0.75
skill.y = 0.8
skill.Cost = 0
skill.Requirements = {
    "Force Heal",
}
KyberCore:AddSkillToTree(skillTreeName, skill)


local skill = {}
skill.Name = "Electric Judgement"
skill.x = 0.48
skill.y = 0.2
skill.Cost = 0
skill.Requirements = {
    "Boulder Throw",
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Slow"
skill.x = 0.62
skill.y = 0.2
skill.Cost = 0
skill.Requirements = {
    "Electric Judgement",
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Stasis"
skill.x = 0.75
skill.y = 0.2
skill.Cost = 0
skill.Requirements = {
    "Force Slow",
}
KyberCore:AddSkillToTree(skillTreeName, skill)


if KyberCore.Config.Developer then
    KyberCore:ReloadSkills()
end