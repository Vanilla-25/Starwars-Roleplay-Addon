//////////////////////
// Skill Tree Registry
//////////////////////
local skillTreeName = "Pathway: Sorcerer"

local skillTree = {}
skillTree.Name = skillTreeName
skillTree.Description = "The Way of the Sorcerer"
skillTree.Image = "entities/item_force_lightning.png"
skillTree.BackgroundColor = Color(0, 0, 255, 180)
skillTree.BackgroundSize = 0.7
KyberCore:AddSkillTree(skillTree)

////////////////////
// Skill Registry
////////////////////

local skill = {}
skill.Name = "Lightning"
skill.Description = "A Dark Side ability that fires Lightning Bolts out of your Hand"
skill.Image = "entities/item_force_lightning.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "lightning")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Heal"
skill.Description = "Use the force to heal a target"
skill.Image = "entities/item_force_heal.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "heal")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Replenish"
skill.Description = "A Dark Side ability that regains Force from Health"
skill.Image = "entities/item_force_replenish.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "replenish")
end
KyberCore:AddSkill(skill)

local forceChoke = {}
skill.Name = "Force Blink"
skill.Description = "Use the force to teleport yourself to different locations of the users choice."
skill.Image = "kybercore/teleport.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "blink")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Group Lightning"
skill.Description = "A Dark Side ability that fires Lightning Bolts out of your Hand."
skill.Image = "entities/item_force_lightning.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "grouplightning")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Group heal"
skill.Description = "Use the force to heal multiple targets including yourself."
skill.Image = "kybercore/group_heal.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "groupheal")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Judgement Strike"
skill.Description = "Using the force to send out a strike of lightning from your hand towards a target."
skill.Image = "kybercore/jstrike.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "judgementstrike")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Self Heal"
skill.Description = "Using the force to slowly heal oneself. While not as fast as Force Heal can be useful in a pinch."
skill.Image = "kybercore/self_heal.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "selfheal")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Diamond Storm"
skill.Description = "It's just a force shotgun"
skill.Image = "entities/item_force_diamondstorm.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "diamondstorm")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Increase for Sorcerer 2"
skill.Description = "Increases maximum force by +5"
skill.Image = "kybercore/force_increase.png"
skill.Func = function(ply)
    if SERVER then 
        KyberCore:AddBonusForce(ply, 5)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Increase for Sorcerer 1"
skill.Description = "Increases maximum force by +15"
skill.Image = "kybercore/force_increase.png"
skill.Func = function(ply)
    if SERVER then 
        KyberCore:AddBonusForce(ply, 15)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Increase for Sorcerer 3"
skill.Description = "Increases maximum force by +5"
skill.Image = "kybercore/force_increase.png"
skill.Func = function(ply)
    if SERVER then 
        KyberCore:AddBonusForce(ply, 5)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Increase for Sorcerer 5"
skill.Description = "Increases maximum force by +20"
skill.Image = "kybercore/force_increase.png"
skill.Func = function(ply)
    if SERVER then 
        KyberCore:AddBonusForce(ply, 20)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Increase for Sorcerer 4"
skill.Description = "Increases maximum force by +20"
skill.Image = "kybercore/force_increase.png"
skill.Func = function(ply)
    if SERVER then 
        KyberCore:AddBonusForce(ply, 20)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Increase for Sorcerer 6"
skill.Description = "Increases maximum force by +20"
skill.Image = "kybercore/force_increase.png"
skill.Func = function(ply)
    if SERVER then 
        KyberCore:AddBonusForce(ply, 20)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Increase for Sorcerer 7"
skill.Description = "Increases maximum force by +25"
skill.Image = "kybercore/force_increase.png"
skill.Func = function(ply)
    if SERVER then 
        KyberCore:AddBonusForce(ply, 25)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Increase for Sorcerer 8"
skill.Description = "Increases maximum force by +25"
skill.Image = "kybercore/force_increase.png"
skill.Func = function(ply)
    if SERVER then 
        KyberCore:AddBonusForce(ply, 25)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Increase for Sorcerer 9"
skill.Description = "Increases maximum force by +25"
skill.Image = "kybercore/force_increase.png"
skill.Func = function(ply)
    if SERVER then 
        KyberCore:AddBonusForce(ply, 25)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Increase for Sorcerer 11"
skill.Description = "Increases maximum force by +30"
skill.Image = "kybercore/force_increase.png"
skill.Func = function(ply)
    if SERVER then 
        KyberCore:AddBonusForce(ply, 30)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Increase for Sorcerer 10"
skill.Description = "Increases maximum force by +30"
skill.Image = "kybercore/force_increase.png"
skill.Func = function(ply)
    if SERVER then 
        KyberCore:AddBonusForce(ply, 30)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Increase for Sorcerer 12"
skill.Description = "Increases maximum force by +30"
skill.Image = "kybercore/force_increase.png"
skill.Func = function(ply)
    if SERVER then 
        KyberCore:AddBonusForce(ply, 30)
    end
end
KyberCore:AddSkill(skill)

///////////////////////////
// Skill Tree Config
///////////////////////////

local skill = {}
skill.Name = "Lightning"
skill.x = 0.05
skill.y = 0.5
skill.Cost = 1
skill.Requirements = {
  	"Form I: Shii-Cho",
	"Force Jump",
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Heal"
skill.x = 0.05
skill.y = 0.08
skill.Cost = 1
skill.Requirements = {
    "Lightning",
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Self Heal"
skill.x = 0.32
skill.y = 0.5
skill.Cost = 4
skill.Requirements = {
    "Force Increase for Sorcerer 4",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Group heal"
skill.x = 0.32
skill.y = 0.08
skill.Cost = 4
skill.Requirements = {
    "Force Increase for Sorcerer 5",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Judgement Strike"
skill.x = 0.32
skill.y = 0.9
skill.Cost = 4
skill.Requirements = {
    "Force Increase for Sorcerer 6",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Group Lightning"
skill.x = 0.62
skill.y = 0.5
skill.Cost = 8
skill.Requirements = {
    "Force Increase for Sorcerer 10",
    "Force Increase for Sorcerer 11",
    "Force Increase for Sorcerer 12",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Increase for Sorcerer 2"
skill.x = 0.15
skill.y = 0.12
skill.Cost = 1
skill.Requirements = {
    "Force Increase for Sorcerer 1",
}
skill.Unlocks = {
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Increase for Sorcerer 1"
skill.x = 0.13
skill.y = 0.5
skill.Cost = 1
skill.Requirements = {
    "Lightning",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Increase for Sorcerer 3"
skill.x = 0.15
skill.y = 0.88
skill.Cost = 1
skill.Requirements = {
    "Force Increase for Sorcerer 1",
}
skill.Unlocks = {
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Increase for Sorcerer 5"
skill.x = 0.23
skill.y = 0.25
skill.Cost = 3
skill.Requirements = {
    "Force Increase for Sorcerer 4",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Increase for Sorcerer 4"
skill.x = 0.20
skill.y = 0.5
skill.Cost = 3
skill.Requirements = {
    "Force Increase for Sorcerer 1",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Increase for Sorcerer 6"
skill.x = 0.23
skill.y = 0.75
skill.Cost = 3
skill.Requirements = {
    "Force Increase for Sorcerer 4",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Increase for Sorcerer 7"
skill.x = 0.4
skill.y = 0.25
skill.Cost = 5
skill.Requirements = {
    "Group heal",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Increase for Sorcerer 8"
skill.x = 0.4
skill.y = 0.75
skill.Cost = 5
skill.Requirements = {
    "Judgement Strike",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Increase for Sorcerer 9"
skill.x = 0.43
skill.y = 0.6
skill.Cost = 5
skill.Requirements = {
    "Self Heal",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Increase for Sorcerer 11"
skill.x = 0.5
skill.y = 0.12
skill.Cost = 6
skill.Requirements = {
    "Force Increase for Sorcerer 10",
}
skill.Unlocks = {
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Increase for Sorcerer 10"
skill.x = 0.53
skill.y = 0.5
skill.Cost = 6
skill.Requirements = {
    "Force Increase for Sorcerer 9",
  	"Force Blink",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Increase for Sorcerer 12"
skill.x = 0.5
skill.y = 0.85
skill.Cost = 6
skill.Requirements = {
    "Force Increase for Sorcerer 10",
}
skill.Unlocks = {
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Replenish"
skill.x = 0.05
skill.y = 0.9
skill.Cost = 1
skill.Requirements = {
    "Lightning",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Blink"
skill.x = 0.43
skill.y = 0.4
skill.Cost = 5
skill.Requirements = {
    "Self Heal",
}
skill.Unlocks = {
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Lightning"
skill.x = 0.05
skill.y = 0.5
skill.Cost = 1
skill.Requirements = {
  "Form I: Shii-Cho",
}
skill.Unlocks = {
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Diamond Storm"
skill.x = 0.7
skill.y = 0.5
skill.Cost = 12
skill.Requirements = {
  "Group Lightning"
}
KyberCore:AddSkillToTree(skillTreeName, skill)

if KyberCore.Config.Developer then
    KyberCore:ReloadSkills()
end
