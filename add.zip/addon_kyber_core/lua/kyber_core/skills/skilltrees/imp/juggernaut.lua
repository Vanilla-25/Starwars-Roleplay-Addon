//////////////////////
// Skill Tree Registry
//////////////////////
local skillTreeName = "Pathway: Juggernaut"

local skillTree = {}
skillTree.Name = skillTreeName
skillTree.Description = "The Way of the Juggernaut"
skillTree.Image = "entities/item_force_immunity.png"
skillTree.BackgroundColor = Color(0, 0, 255, 180)
skillTree.BackgroundSize = 0.4
KyberCore:AddSkillTree(skillTree)

////////////////////
// Skill Registry
////////////////////

local skill = {}
skill.Name = "Force Absorb"
skill.Description = "Use the force to absorb any incoming attacks transferring it into your force bar."
skill.Image = "kybercore/absorb.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "absorb")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Barrier"
skill.Description = "Create a protective barrier using the Force."
skill.Image = "kybercore/barrier.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "bar")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Repulse"
skill.Description = "Draw upon the surrounding force to send out a concussive force blast from the user. The longer you hold the charge the more damage it can do."
skill.Image = "kybercore/repulse.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "repulse")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Pulse"
skill.Description = "Unleash a destructive stream of force energy across the ground harming those that come into contact with it."
skill.Image = "kybercore/pulse.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "pulse")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Immunity"
skill.Description = "Incoming Force Power attacks are absorbed and regain Force Points. Also gives a permanent immunity against incoming Force Powers as long your own Force Points are above 50% even when this Power is not activated. Only the weak minded don't learn this ability."
skill.Image = "entities/item_force_immunity.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "immunity")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Crippling Slam"
skill.Description = "Slam your enemy to the ground."
skill.Image = "kybercore/slam.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "slam")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Health Increase for Juggernaut 1"
skill.Description = "Increase max Health by +25."
skill.Image = "entities/heal.png"
skill.Func = function(ply)
    if SERVER then
        KyberCore:AddBonusHealth(ply, 25)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Increase for Juggernaut 1"
skill.Description = "Increases maximum Force by +15"
skill.Image = "kybercore/force_increase.png"
skill.Func = function(ply)
    if SERVER then 
        KyberCore:AddBonusForce(ply, 15)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Stamina Increase for Juggernaut 1"
skill.Description = "Increase max Stamina by +5."
skill.Image = "kybercore/stamina.png"
skill.Func = function(ply)
    if SERVER then
        KyberCore:AddBonusBlockPoints(ply, 5)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Health Increase for Juggernaut 2"
skill.Description = "Increase max Health by +25."
skill.Image = "entities/heal.png"
skill.Func = function(ply)
    if SERVER then
        KyberCore:AddBonusHealth(ply, 25)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Increase for Juggernaut 2"
skill.Description = "Increases maximum Force by +15"
skill.Image = "kybercore/force_increase.png"
skill.Func = function(ply)
    if SERVER then 
        KyberCore:AddBonusForce(ply, 15)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Health Increase for Juggernaut 3"
skill.Description = "Increase max Health by +30."
skill.Image = "entities/heal.png"
skill.Func = function(ply)
    if SERVER then
        KyberCore:AddBonusHealth(ply, 30)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Stamina Increase for Juggernaut 2"
skill.Description = "Increase max Stamina by +5."
skill.Image = "kybercore/stamina.png"
skill.Func = function(ply)
    if SERVER then
        KyberCore:AddBonusBlockPoints(ply, 5)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Increase for Juggernaut 3"
skill.Description = "Increase max Force by +15."
skill.Image = "kybercore/force_increase.png"
skill.Func = function(ply)
    if SERVER then
        KyberCore:AddBonusForce(ply, 15)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Health Increase for Juggernaut 4"
skill.Description = "Increases maximum Health by +35"
skill.Image = "entities/heal.png"
skill.Func = function(ply)
    if SERVER then 
        KyberCore:AddBonusHealth(ply, 35)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Increase for Juggernaut 4"
skill.Description = "Increase max Force by +20."
skill.Image = "kybercore/force_increase.png"
skill.Func = function(ply)
    if SERVER then
        KyberCore:AddBonusForce(ply, 20)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Health Increase for Juggernaut 5"
skill.Description = "Increases maximum Health by +35"
skill.Image = "entities/heal.png"
skill.Func = function(ply)
    if SERVER then 
        KyberCore:AddBonusHealth(ply, 35)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Stamina Increase for Juggernaut 3"
skill.Description = "Increase max Stamina by +10."
skill.Image = "kybercore/stamina.png"
skill.Func = function(ply)
    if SERVER then
        KyberCore:AddBonusBlockPoints(ply, 10)
    end
end
KyberCore:AddSkill(skill)

///////////////////////////
// Skill Tree Config
///////////////////////////

local skill = {}
skill.Name = "Force Absorb"
skill.x = 0.05
skill.y = 0.5
skill.Cost = 1
skill.Requirements = {
    "Force Jump",
    "Form I: Shii-Cho",
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Barrier"
skill.x = 0.32
skill.y = 0.5
skill.Cost = 4
skill.Requirements = {
    "Health Increase for Juggernaut 2",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Repulse"
skill.x = 0.32
skill.y = 0.08
skill.Cost = 4
skill.Requirements = {
    "Force Increase for Juggernaut 2",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Pulse"
skill.x = 0.32
skill.y = 0.9
skill.Cost = 4
skill.Requirements = {
    "Health Increase for Juggernaut 3"
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Immunity"
skill.x = 0.62
skill.y = 0.5
skill.Cost = 8
skill.Requirements = {
    "Stamina Increase for Juggernaut 3",
    "Force Increase for Juggernaut 4",
    "Health Increase for Juggernaut 5",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Crippling Slam"
skill.x = 0.7
skill.y = 0.5
skill.Cost = 12
skill.Requirements = {
	"Force Immunity",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Health Increase for Juggernaut 1"
skill.x = 0.13
skill.y = 0.5
skill.Cost = 2
skill.Requirements = {
    "Force Absorb"
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Increase for Juggernaut 1"
skill.x = 0.15
skill.y = 0.12
skill.Cost = 2
skill.Requirements = {
    "Health Increase for Juggernaut 1",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Stamina Increase for Juggernaut 1"
skill.x = 0.15
skill.y = 0.88
skill.Cost = 2
skill.Requirements = {
    "Health Increase for Juggernaut 1",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Health Increase for Juggernaut 2"
skill.x = 0.20
skill.y = 0.5
skill.Cost = 3
skill.Requirements = {
    "Health Increase for Juggernaut 1",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Increase for Juggernaut 2"
skill.x = 0.23
skill.y = 0.25
skill.Cost = 3
skill.Requirements = {
    "Health Increase for Juggernaut 2",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Health Increase for Juggernaut 3"
skill.x = 0.23
skill.y = 0.75
skill.Cost = 3
skill.Requirements = {
    "Health Increase for Juggernaut 2",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Increase for Juggernaut 3"
skill.x = 0.4
skill.y = 0.25
skill.Cost = 5
skill.Requirements = {
    "Force Repulse",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Stamina Increase for Juggernaut 2"
skill.x = 0.4
skill.y = 0.75
skill.Cost = 5
skill.Requirements = {
    "Force Pulse",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Health Increase for Juggernaut 4"
skill.x = 0.45
skill.y = 0.5
skill.Cost = 6
skill.Requirements = {
    "Force Barrier",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Health Increase for Juggernaut 5"
skill.x = 0.53
skill.y = 0.5
skill.Cost = 6
skill.Requirements = {
    "Health Increase for Juggernaut 4",
}
skill.Unlocks = {
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Increase for Juggernaut 4"
skill.x = 0.5
skill.y = 0.12
skill.Cost = 7
skill.Requirements = {
    "Health Increase for Juggernaut 5",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Stamina Increase for Juggernaut 3"
skill.x = 0.5
skill.y = 0.85
skill.Cost = 7
skill.Requirements = {
    "Health Increase for Juggernaut 5",
}
skill.Unlocks = {
}
KyberCore:AddSkillToTree(skillTreeName, skill)

if KyberCore.Config.Developer then
    KyberCore:ReloadSkills()
end