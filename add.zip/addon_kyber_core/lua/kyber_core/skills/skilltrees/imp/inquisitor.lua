//////////////////////
// Skill Tree Registry
//////////////////////
local skillTreeName = "Pathway: Inquisitor"

local skillTree = {}
skillTree.Name = skillTreeName
skillTree.Description = "The way of the Inquisitor"
skillTree.Image = "kybercore/burnout.png"
KyberCore:AddSkillTree(skillTree)

////////////////////
// Skill Registry
////////////////////

local skill = {}
skill.Name = "Force Sense"
skill.Description = "Use the force to enhance your vision seeing things that most cannot."
skill.Image = "entities/item_force_sense.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "sense")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Telekenesis"
skill.Description = "Allows you to gain full control of a target and be able to manipulate the target in certain ways e.g. pick them up and throw them."
skill.Image = "kybercore/telekenesis.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "telekenesis")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Throw"
skill.Description = "Throw your lightsaber at enemies, striking from a distance."
skill.Image = "entities/item_force_throw.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "throw")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Reflect"
skill.Description = "Using the force creates a link to all targets that shoot at the user. Transferring any damage the user receives back to the target."
skill.Image = "kybercore/reflect.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "reflect")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Stasis"
skill.Description = "Use the force to freeze your enemies in their track and immobilise them for a few seconds."
skill.Image = "kybercore/stasis.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "stasis")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Health Increase for Inquisitors 1"
skill.Description = "Increase max health by +20."
skill.Image = "entities/heal.png"
skill.Func = function(ply)
    if SERVER then
        KyberCore:AddBonusHealth(ply, 20)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Health Increase for Inquisitors 2"
skill.Description = "Increase max health by +20."
skill.Image = "entities/heal.png"
skill.Func = function(ply)
    if SERVER then
        KyberCore:AddBonusHealth(ply, 20)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Stamina Increase for Inquisitors 1"
skill.Description = "Increase max stamina by +5."
skill.Image = "kybercore/stamina.png"
skill.Func = function(ply)
    if SERVER then
        KyberCore:AddBonusBlockPoints(ply, 5)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Stamina Increase for Inquisitors 2"
skill.Description = "Increase max stamina by +10."
skill.Image = "kybercore/stamina.png"
skill.Func = function(ply)
    if SERVER then
        KyberCore:AddBonusBlockPoints(ply, 10)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Stamina Increase for Inquisitors 3"
skill.Description = "Increase max stamina by +10."
skill.Image = "kybercore/stamina.png"
skill.Func = function(ply)
    if SERVER then
        KyberCore:AddBonusBlockPoints(ply, 10)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Increase for Inquisitors 1"
skill.Description = "Increase maximum force by +10."
skill.Image = "kybercore/force_increase.png"
skill.Func = function(ply)
    if SERVER then
        KyberCore:AddBonusForce(ply, 10)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Increase for Inquisitors 2"
skill.Description = "Increase maximum force by +10."
skill.Image = "kybercore/force_increase.png"
skill.Func = function(ply)
    if SERVER then
        KyberCore:AddBonusForce(ply, 10)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Increase for Inquisitors 3"
skill.Description = "Increase maximum force by +20."
skill.Image = "kybercore/force_increase.png"
skill.Func = function(ply)
    if SERVER then
        KyberCore:AddBonusForce(ply, 20)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Speed Increase for Inquisitors 1"
skill.Description = "Increase run speed by +10"
skill.Image = "entities/speed.png"
skill.Func = function(ply)
    if SERVER then
        KyberCore:AddBonusSpeed(ply, 10)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Speed Increase for Inquisitors 2"
skill.Description = "Increase run speed by +10"
skill.Image = "entities/speed.png"
skill.Func = function(ply)
    if SERVER then
        KyberCore:AddBonusSpeed(ply, 10)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Speed Increase for Inquisitors 3"
skill.Description = "Increase run speed by +15"
skill.Image = "entities/speed.png"
skill.Func = function(ply)
    if SERVER then
        KyberCore:AddBonusSpeed(ply, 15)
    end
end
KyberCore:AddSkill(skill)

///////////////////////////
// Skill Tree Config
///////////////////////////

local skill = {}
skill.Name = "Force Sense"
skill.x = 0.18
skill.y = 0.5
skill.Cost = 3
skill.Requirements = {
    "Stamina Increase for Inquisitors 1",
  	"Health Increase for Inquisitors 1",
  	"Health Increase for Inquisitors 2",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Telekenesis"
skill.x = 0.32
skill.y = 0.5
skill.Cost = 5
skill.Requirements = {
  	"Speed Increase for Inquisitors 1",
  	"Force Increase for Inquisitors 1",
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Reflect"
skill.x = 0.62
skill.y = 0.5
skill.Cost = 8
skill.Requirements = {
  	"Speed Increase for Inquisitors 3",
  	"Force Increase for Inquisitors 3",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Stasis"
skill.x = 0.7
skill.y = 0.5
skill.Cost = 12
skill.Requirements = {
  	"Force Reflect"
}
KyberCore:AddSkillToTree(skillTreeName, skill)

if KyberCore.Config.Developer then
    KyberCore:ReloadSkills()
end

local skill = {}
skill.Name = "Stamina Increase for Inquisitors 1"
skill.x = 0.05
skill.y = 0.5
skill.Cost = 2
skill.Requirements = {
    "Form I: Shii-Cho",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Health Increase for Inquisitors 1"
skill.x = 0.08
skill.y = 0.15
skill.Cost = 2
skill.Requirements = {
    "Stamina Increase for Inquisitors 1",
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Health Increase for Inquisitors 2"
skill.x = 0.08
skill.y = 0.85
skill.Cost = 2
skill.Requirements = {
    "Stamina Increase for Inquisitors 1",
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Speed Increase for Inquisitors 1"
skill.x = 0.23
skill.y = 0.20
skill.Cost = 4
skill.Requirements = {
    "Stamina Increase for Inquisitors 1",
  	"Force Sense",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)


local skill = {}
skill.Name = "Force Increase for Inquisitors 1"
skill.x = 0.23
skill.y = 0.80
skill.Cost = 4
skill.Requirements = {
    "Stamina Increase for Inquisitors 1",
  	"Force Sense",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Stamina Increase for Inquisitors 2"
skill.x = 0.32
skill.y = 0.1
skill.Cost = 5
skill.Requirements = {
  	"Speed Increase for Inquisitors 1",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Speed Increase for Inquisitors 2"
skill.x = 0.43
skill.y = 0.3
skill.Cost = 7
skill.Requirements = {
    "Stamina Increase for Inquisitors 2",
  	"Force Telekenesis",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Increase for Inquisitors 2"
skill.x = 0.43
skill.y = 0.7
skill.Cost = 7
skill.Requirements = {
  	"Stamina Increase for Inquisitors 3",
  	"Force Telekenesis",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Stamina Increase for Inquisitors 3"
skill.x = 0.32
skill.y = 0.9
skill.Cost = 5
skill.Requirements = {
  	"Force Increase for Inquisitors 1",
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Speed Increase for Inquisitors 3"
skill.x = 0.53
skill.y = 0.15
skill.Cost = 7
skill.Requirements = {
    "Speed Increase for Inquisitors 2",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Increase for Inquisitors 3"
skill.x = 0.53
skill.y = 0.85
skill.Cost = 7
skill.Requirements = {
  	"Force Increase for Inquisitors 2",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

if KyberCore.Config.Developer then
    KyberCore:ReloadSkills()
end