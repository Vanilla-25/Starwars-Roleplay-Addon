//////////////////////
// Skill Tree Registry
//////////////////////
local skillTreeName = "Force Chokes"

local skillTree = {}
skillTree.Name = skillTreeName
skillTree.Description = "Force Chokes"
skillTree.Image = "kybercore/slow.png"
KyberCore:AddSkillTree(skillTree)

////////////////////
// Skill Registry
////////////////////

local skill = {}
skill.Name = "Force Choke"
skill.Description = "Force Choke."
skill.Image = "kybercore/soft_cho.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "softchoke")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Expert Choke"
skill.Description = "Super Choke."
skill.Image = "kybercore/soft_cho.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "choke")
end
KyberCore:AddSkill(skill)

///////////////////////////
// Skill Tree Config
///////////////////////////

local skill = {}
skill.Name = "Force Choke"
skill.x = 0.399
skill.y = 0.5
skill.Cost = 0
skill.Requirements = {
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Expert Choke"
skill.x = 0.5
skill.y = 0.5
skill.Cost = 0
skill.Requirements = {
}
KyberCore:AddSkillToTree(skillTreeName, skill)

if KyberCore.Config.Developer then
    KyberCore:ReloadSkills()
end