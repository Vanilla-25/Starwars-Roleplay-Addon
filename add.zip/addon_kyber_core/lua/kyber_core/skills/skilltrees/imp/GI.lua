//////////////////////
// Skill Tree Registry
//////////////////////
local skillTreeName = "Pathway: Grand Inquisitor"

local skillTree = {}
skillTree.Name = skillTreeName
skillTree.Description = "The Inquisitor of Grand, Working below the Enforcer"
skillTree.Image = "kybercore/revive.png"
KyberCore:AddSkillTree(skillTree)

////////////////////
// Skill Registry
////////////////////

local skill = {}
skill.Name = "Form: Butterfly"
skill.Description = "Butterfly Stance. Not easy to control but hit's hard when used correctly. Works best with a Saber in both Hands."
skill.Image = "kybercore/jarkai.png"
skill.Func = function(ply)
    KyberCore:AddKnownForm(ply, "butterfly")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Vlad'vari Aura"
skill.Description = "Engulfs you in the aura of an ancient one, making you an impenetrable fortress."
skill.Image = "kybercore/flame.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "cursed_aura")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Shockwave"
skill.Description = "Releases a burst of lightning around you, damaging nearby enemies.."
skill.Image = "kybercore/repair.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "forceshockwave")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Crush"
skill.Description = "Lifts and crushes a single enemy using the Force."
skill.Image = "kybercore/diam.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "forcecrush")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Lightning Aura"
skill.Description = "Activates a powerful electric aura that boosts speed and health."
skill.Image = "kybercore/lightning.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "lightningaura")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Flaming Aura"
skill.Description = "Engulf yourself in flames, slowing yourself down but greatly increaseing resistance."
skill.Image = "kybercore/lightning.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "flamingaura")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Mind Trick"
skill.Description = "Disoriented, you are."
skill.Image = "kybercore/mindtrick.jpg"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "mindtrick")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Rewind"
skill.Description = "Pull yourself back in time over a short amount of time."
skill.Image = "entities/item_force_heal.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "rewind")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Displacement"
skill.Description = "Cheers love, the cavalry's here!"
skill.Image = "entities/item_force_heal.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "rewind")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Diamond Hurricane"
skill.Description = "By the power of the elements, I... destroy you."
skill.Image = "kybercore/diam.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "diamondhurricane")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Super-kick"
skill.Description = "Fuck you."
skill.Image = "entities/item_force_breach.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "superkick")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Leap"
skill.Description = "Launch yourself with the Force to reach areas beyond normal jumping range."
skill.Image = "entities/item_force_leap.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "jump_3")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Grand Inquisitor Health Increase"
skill.Description = "Increase max health by +150."
skill.Image = "entities/heal.png"
skill.Func = function(ply)
    if SERVER then
        KyberCore:AddBonusHealth(ply, 150)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Grand Inquisitor Stamina Increase"
skill.Description = "Increase max stamina by +200."
skill.Image = "kybercore/stamina.png"
skill.Func = function(ply)
    if SERVER then
        KyberCore:AddBonusBlockPoints(ply, 200)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Grand Inquisitor Force Increase"
skill.Description = "Increases maximum force by +400."
skill.Image = "kybercore/force_increase.png"
skill.Func = function(ply)
    if SERVER then 
        KyberCore:AddBonusForce(ply, 600)
    end
end
KyberCore:AddSkill(skill)

///////////////////////////
// Skill Tree Config
///////////////////////////

local skill = {}
skill.Name = "Grand Inquisitor Health Increase"
skill.x = 0.08
skill.y = 0.5
skill.Cost = 0
skill.Requirements = {
    "Form I: Shii-Cho",
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Grand Inquisitor Stamina Increase"
skill.x = 0.15
skill.y = 0.7
skill.Cost = 0
skill.Requirements = {
    "Grand Inquisitor Health Increase",
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Grand Inquisitor Force Increase"
skill.x = 0.15
skill.y = 0.3
skill.Cost = 0
skill.Requirements = {
    "Grand Inquisitor Health Increase",
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Shockwave"
skill.x = 0.22
skill.y = 0.5
skill.Cost = 0
skill.Requirements = {
	"Grand Inquisitor Force Increase",
	"Grand Inquisitor Stamina Increase"
}
KyberCore:AddSkillToTree(skillTreeName, skill)

if KyberCore.Config.Developer then
    KyberCore:ReloadSkills()
end
local skill = {}
skill.Name = "Mind Trick"
skill.x = 0.30
skill.y = 0.3
skill.Cost = 0
skill.Requirements = {
	"Force Shockwave"
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Rewind"
skill.x = 0.30
skill.y = 0.7
skill.Cost = 0
skill.Requirements = { 
	"Force Shockwave"
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Displacement"
skill.x = 0.38
skill.y = 0.5
skill.Cost = 0
skill.Requirements = { 
	"Mind Trick",
	"Force Rewind"
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Diamond Hurricane"
skill.x = 0.38
skill.y = 0.8
skill.Cost = 0
skill.Requirements = {
	"Force Displacement"
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Crush"
skill.x = 0.38
skill.y = 0.2
skill.Cost = 0
skill.Requirements = {
	"Force Displacement"
}
KyberCore:AddSkillToTree(skillTreeName, skill)


local skill = {}
skill.Name = "Flaming Aura"
skill.x = 0.45
skill.y = 0.3
skill.Cost = 0
skill.Requirements = {
	"Force Displacement"
}
KyberCore:AddSkillToTree(skillTreeName, skill)


local skill = {}
skill.Name = "Lightning Aura"
skill.x = 0.45
skill.y = 0.7
skill.Cost = 0
skill.Requirements = {
	"Force Displacement"
}
KyberCore:AddSkillToTree(skillTreeName, skill)


local skill = {}
skill.Name = "Super-kick"
skill.x = 0.53
skill.y = 0.5
skill.Cost = 0
skill.Requirements = {
	"Lightning Aura",
	"Flaming Aura"
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Leap"
skill.x = 0.53
skill.y = 0.2
skill.Cost = 0
skill.Requirements = {
	"Super-kick"
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Form: Butterfly"
skill.x = 0.53
skill.y = 0.8
skill.Cost = 0
skill.Requirements = {
    "Super-kick",
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Vlad'vari Aura"
skill.x = 0.6
skill.y = 0.5
skill.Cost = 0
skill.Requirements = {
    "Super-kick",
}
KyberCore:AddSkillToTree(skillTreeName, skill)


if KyberCore.Config.Developer then
    KyberCore:ReloadSkills()
end