//////////////////////
// Skill Tree Registry
//////////////////////
local skillTreeName = "Burn Out"

local skillTree = {}
skillTree.Name = skillTreeName
skillTree.Description = "Burn Out"
skillTree.Image = "kybercore/burnout.png"
KyberCore:AddSkillTree(skillTree)

////////////////////
// Skill Registry
////////////////////

local skill = {}
skill.Name = "Burn Out"
skill.Description = "Use the force to exert a small torrent of flames from your palm burning those that come into touch."
skill.Image = "kybercore/burnout.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "burnout")
end
KyberCore:AddSkill(skill)

///////////////////////////
// Skill Tree Config
///////////////////////////

local skill = {}
skill.Name = "Burn Out"
skill.x = 0.399
skill.y = 0.5
skill.Cost = 1
skill.Requirements = {
}
KyberCore:AddSkillToTree(skillTreeName, skill)

if KyberCore.Config.Developer then
    KyberCore:ReloadSkills()
end