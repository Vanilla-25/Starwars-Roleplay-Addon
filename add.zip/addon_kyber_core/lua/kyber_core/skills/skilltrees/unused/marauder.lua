//////////////////////
// Skill Tree Registry
//////////////////////
local skillTreeName = "Pathway: Marauder"

local skillTree = {}
skillTree.Name = skillTreeName
skillTree.Description = "The Way of the Marauder"
skillTree.Image = "entities/blade_launch.png"
skillTree.BackgroundColor = Color(0, 0, 255, 180)
skillTree.BackgroundSize = 0.4
KyberCore:AddSkillTree(skillTree)

////////////////////
// Skill Registry
////////////////////

local skill = {}
skill.Name = "Saber launch"
skill.Description = "Use the force to throw your saber and control it with the force."
skill.Image = "entities/blade_launch.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "launch")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Absorb"
skill.Description = "Use the force to absorb any incoming attacks transferring it into your force bar."
skill.Image = "kybercore/absorb.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "absorb")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Brazen"
skill.Description = "Use the force to enhance your strikes for a small duration of time doubling the damage of your strikes."
skill.Image = "kybercore/brazen.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "brazen")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Reflect"
skill.Description = "Using the force creates a link to all targets that shoot at the user.           Transferring any damage the user receives back to the target."
skill.Image = "kybercore/reflect.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "reflect")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Propulsion"
skill.Description = "Launch a shotgun of concussive force energy towards your targets."
skill.Image = "kybercore/propulsion.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "propulsion")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Increase for Marauder 1"
skill.Description = "Increases maximum force by +5"
skill.Image = "kybercore/force_increase.png"
skill.Func = function(ply)
    if SERVER then 
        KyberCore:AddBonusForce(ply, 5)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Increase for Marauder 2"
skill.Description = "Increases maximum force by +15"
skill.Image = "kybercore/force_increase.png"
skill.Func = function(ply)
    if SERVER then 
        KyberCore:AddBonusForce(ply, 15)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Increase for Marauder 3"
skill.Description = "Increases maximum force by +5"
skill.Image = "kybercore/force_increase.png"
skill.Func = function(ply)
    if SERVER then 
        KyberCore:AddBonusForce(ply, 5)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Increase for Marauder 4"
skill.Description = "Increases maximum force by +20"
skill.Image = "kybercore/force_increase.png"
skill.Func = function(ply)
    if SERVER then 
        KyberCore:AddBonusForce(ply, 20)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Increase for Marauder 5"
skill.Description = "Increases maximum force by +20"
skill.Image = "kybercore/force_increase.png"
skill.Func = function(ply)
    if SERVER then 
        KyberCore:AddBonusForce(ply, 20)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Increase for Marauder 6"
skill.Description = "Increases maximum force by +20"
skill.Image = "kybercore/force_increase.png"
skill.Func = function(ply)
    if SERVER then 
        KyberCore:AddBonusForce(ply, 20)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Increase for Marauder 7"
skill.Description = "Increases maximum force by +25"
skill.Image = "kybercore/force_increase.png"
skill.Func = function(ply)
    if SERVER then 
        KyberCore:AddBonusForce(ply, 25)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Increase for Marauder 8"
skill.Description = "Increases maximum force by +25"
skill.Image = "kybercore/force_increase.png"
skill.Func = function(ply)
    if SERVER then 
        KyberCore:AddBonusForce(ply, 25)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Increase for Marauder 9"
skill.Description = "Increases maximum force by +25"
skill.Image = "kybercore/force_increase.png"
skill.Func = function(ply)
    if SERVER then 
        KyberCore:AddBonusForce(ply, 25)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Increase for Marauder 10"
skill.Description = "Increases maximum force by +30"
skill.Image = "kybercore/force_increase.png"
skill.Func = function(ply)
    if SERVER then 
        KyberCore:AddBonusForce(ply, 30)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Increase for Marauder 11"
skill.Description = "Increases maximum force by +30"
skill.Image = "kybercore/force_increase.png"
skill.Func = function(ply)
    if SERVER then 
        KyberCore:AddBonusForce(ply, 30)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Increase for Marauder 12"
skill.Description = "Increases maximum force by +30"
skill.Image = "kybercore/force_increase.png"
skill.Func = function(ply)
    if SERVER then 
        KyberCore:AddBonusForce(ply, 30)
    end
end
KyberCore:AddSkill(skill)

///////////////////////////
// Skill Tree Config
///////////////////////////

local skill = {}
skill.Name = "Saber launch"
skill.x = 0.05
skill.y = 0.5
skill.Cost = 2
skill.Requirements = {
    "Force Jump",
    "Form I: Shii-Cho",
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Absorb"
skill.x = 0.32
skill.y = 0.5
skill.Cost = 5
skill.Requirements = {
    "Force Increase for Marauder 5",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Brazen"
skill.x = 0.32
skill.y = 0.08
skill.Cost = 5
skill.Requirements = {
    "Force Increase for Marauder 4",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Propulsion"
skill.x = 0.32
skill.y = 0.9
skill.Cost = 5
skill.Requirements = {
    "Force Increase for Marauder 6",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Reflect"
skill.x = 0.62
skill.y = 0.5
skill.Cost = 10
skill.Requirements = {
    "Force Increase for Marauder 10",
    "Force Increase for Marauder 11",
    "Force Increase for Marauder 12",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Increase for Marauder 1"
skill.x = 0.15
skill.y = 0.12
skill.Cost = 3
skill.Requirements = {
    "Force Increase for Marauder 2",
}
skill.Unlocks = {
    "Force Brazen",
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Increase for Marauder 2"
skill.x = 0.13
skill.y = 0.5
skill.Cost = 2
skill.Requirements = {
    "Saber launch",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Increase for Marauder 3"
skill.x = 0.15
skill.y = 0.85
skill.Cost = 3
skill.Requirements = {
    "Force Increase for Marauder 2",
}
skill.Unlocks = {
    "Force Propulsion",
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Increase for Marauder 4"
skill.x = 0.23
skill.y = 0.25
skill.Cost = 5
skill.Requirements = {
    "Force Increase for Marauder 5",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Increase for Marauder 5"
skill.x = 0.20
skill.y = 0.5
skill.Cost = 5
skill.Requirements = {
    "Force Increase for Marauder 2",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Increase for Marauder 6"
skill.x = 0.23
skill.y = 0.75
skill.Cost = 5
skill.Requirements = {
    "Force Increase for Marauder 5",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Increase for Marauder 7"
skill.x = 0.4
skill.y = 0.25
skill.Cost = 6
skill.Requirements = {
    "Force Brazen",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Increase for Marauder 8"
skill.x = 0.4
skill.y = 0.75
skill.Cost = 6
skill.Requirements = {
    "Force Propulsion",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Increase for Marauder 9"
skill.x = 0.45
skill.y = 0.5
skill.Cost = 6
skill.Requirements = {
    "Force Absorb",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Increase for Marauder 10"
skill.x = 0.5
skill.y = 0.12
skill.Cost = 7
skill.Requirements = {
    "Force Increase for Marauder 11",
}
skill.Unlocks = {
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Increase for Marauder 11"
skill.x = 0.53
skill.y = 0.5
skill.Cost = 7
skill.Requirements = {
    "Force Increase for Marauder 9",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Increase for Marauder 12"
skill.x = 0.5
skill.y = 0.85
skill.Cost = 7
skill.Requirements = {
    "Force Increase for Marauder 11",
}
skill.Unlocks = {
}
KyberCore:AddSkillToTree(skillTreeName, skill)

if KyberCore.Config.Developer then
    KyberCore:ReloadSkills()
end
