//////////////////////
// Skill Tree Registry
//////////////////////
local skillTreeName = "Mellow Custom shiz"

local skillTree = {}
skillTree.Name = skillTreeName
skillTree.Description = "Releases a burst of lightning around you, damaging nearby enemies."
skillTree.Image = "entities/item_force_fuck.png"
skillTree.Exclusive = false
KyberCore:AddSkillTree(skillTree)


local skill = {}
skill.Name = "Mind Trick"
skill.Description = "You will call me the cutest inquisitor alive."
skill.Image = "kybercore/mindtrick.jpg"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "mindtrick")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "KAMEHAMEHA"
skill.Description = "DIE."
skill.Image = "kybercore/bad_batch_nose_art.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "kamehameha")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Divine Sorcery"
skill.Description = "You will call me the cutest inquisitor alive."
skill.Image = "kybercore/jerry.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "divine_sorcery")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Teleport"
skill.Description = "Literally just teleport?."
skill.Image = "kybercore/mindtrick.jpg"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "teleport")
end
KyberCore:AddSkill(skill)


local skill = {}
skill.Name = "Judgement Cut"
skill.Description = "Unleash a flurry of slashes around you, shredding nearby enemies over time."
skill.Image = "kybercore/judgement.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "judgement_cut")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Auto Parry"
skill.Description = "You're not even in my league."
skill.Image = "entities/item_force_boulderthrow.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "autoparry")
end
KyberCore:AddSkill(skill)


local skill = {}
skill.Name = "Group Lightning"
skill.Description = "A Dark Side ability that fires Lightning Bolts out of your Hand."
skill.Image = "entities/item_force_lightning.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "grouplightning")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Rewind and Displacement"
skill.Description = "Cheers love, the cavalry's here!"
skill.Image = "entities/item_force_heal.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "rewind")
    KyberCore:AddKnownPower(ply, "displacement")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Diamond Hurricane"
skill.Description = "Absolutely fucking destroy someone infront of you."
skill.Image = "kybercore/diam.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "diamondhurricane")
end
KyberCore:AddSkill(skill)

////////////////////
// Skill Registry
////////////////////

local skill = {}
skill.Name = "Force Shockwave"
skill.Description = "Releases a burst of lightning around you, damaging nearby enemies.."
skill.Image = "kybercore/repair.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "forceshockwave")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Crush"
skill.Description = "Lifts and crushes a single enemy using the Force."
skill.Image = "kybercore/diam.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "forcecrush")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Tears of Denial"
skill.Description = "Resist Death"
skill.Image = "kybercore/tears_of_denial.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "tears")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Lightning Aura"
skill.Description = "Activates a powerful electric aura that boosts speed and health."
skill.Image = "kybercore/lightning.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "lightningaura")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Lightning Overclock"
skill.Description = "Push your lightning aura beyond safe limits, greatly boosting your power but at a cost."
skill.Image = "kybercore/lightning.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "lightningoverclock")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Flaming Aura"
skill.Description = "Activates a powerful electric aura that boosts speed and health."
skill.Image = "kybercore/lightning.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "flamingaura")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Group Force Choke"
skill.Description = "Choke multiple enemies in a radius."
skill.Image = "kybercore/soft_cho.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "groupchoke")
end
KyberCore:AddSkill(skill)

///////////////////////////
// Skill Tree Config
///////////////////////////

local skill = {}
skill.Name = "Force Shockwave"
skill.x = 0.399
skill.y = 0.5
skill.Cost = 0
skill.Requirements = {
}
KyberCore:AddSkillToTree(skillTreeName, skill)

if KyberCore.Config.Developer then
    KyberCore:ReloadSkills()
end
local skill = {}
skill.Name = "Mind Trick"
skill.x = 0.32
skill.y = 0.35
skill.Cost = 0
skill.Requirements = {
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Rewind and Displacement"
skill.x = 0.46
skill.y = 0.35
skill.Cost = 0
skill.Requirements = { "Mind Trick" }
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Diamond Hurricane"
skill.x = 0.05
skill.y = 0.75
skill.Cost = 0
skill.Requirements = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Crush"
skill.x = 0.5
skill.y = 0.5
skill.Cost = 0
skill.Requirements = {
}
KyberCore:AddSkillToTree(skillTreeName, skill)


local skill = {}
skill.Name = "Flaming Aura"
skill.x = 0.450
skill.y = 0.7
skill.Cost = 0
skill.Requirements = {
}
KyberCore:AddSkillToTree(skillTreeName, skill)


local skill = {}
skill.Name = "Lightning Aura"
skill.x = 0.355
skill.y = 0.7
skill.Cost = 0
skill.Requirements = {
}
KyberCore:AddSkillToTree(skillTreeName, skill)


local skill = {}
skill.Name = "Lightning Overclock"
skill.x = 0.480
skill.y = 0.7
skill.Cost = 0
skill.Requirements = {
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Judgement Cut"
skill.x = 0.700
skill.y = 0.7
skill.Cost = 0
skill.Requirements = {
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Divine Sorcery"
skill.x = 0.3
skill.y = 0.4
skill.Cost = 0
skill.Requirements = {
}
KyberCore:AddSkillToTree(skillTreeName, skill)


local skill = {}
skill.Name = "Group Lightning"
skill.x = 0.455
skill.y = 0.2
skill.Cost = 0
skill.Requirements = {
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Auto Parry"
skill.x = 0.655
skill.y = 0.4
skill.Cost = 0
skill.Requirements = {
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Teleport"
skill.x = 0.355
skill.y = 0.4
skill.Cost = 0
skill.Requirements = {
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "KAMEHAMEHA"
skill.x = 0.7
skill.y = 0.4
skill.Cost = 0
skill.Requirements = {
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Tears of Denial"
skill.x = 0.2
skill.y = 0.4
skill.Cost = 0
skill.Requirements = {
}
KyberCore:AddSkillToTree(skillTreeName, skill)


local skill = {}
skill.Name = "Group Force Choke"
skill.x = 0.400
skill.y = 0.2
skill.Cost = 0
skill.Requirements = {
}
KyberCore:AddSkillToTree(skillTreeName, skill)

if KyberCore.Config.Developer then
    KyberCore:ReloadSkills()
end