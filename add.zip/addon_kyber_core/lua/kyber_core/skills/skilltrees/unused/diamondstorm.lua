//////////////////////
// Skill Tree Registry
//////////////////////
local skillTreeName = "Diamond Storm"

local skillTree = {}
skillTree.Name = skillTreeName
skillTree.Description = "Diamond Storm"
skillTree.Image = "entities/item_force_diamondstorm.png"
KyberCore:AddSkillTree(skillTree)

////////////////////
// Skill Registry
////////////////////

local skill = {}
skill.Name = "Diamond Storm"
skill.Description = "It's just a force shotgun"
skill.Image = "entities/item_force_diamondstorm.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "diamondstorm")
end
KyberCore:AddSkill(skill)

///////////////////////////
// Skill Tree Config
///////////////////////////

local skill = {}
skill.Name = "Diamond Storm"
skill.x = 0.399
skill.y = 0.5
skill.Cost = 1
skill.Requirements = {
}
KyberCore:AddSkillToTree(skillTreeName, skill)

if KyberCore.Config.Developer then
    KyberCore:ReloadSkills()
end