//////////////////////
// Skill Tree Registry
//////////////////////
local skillTreeName = "Pathway: Sorcerer"

local skillTree = {}
skillTree.Name = skillTreeName
skillTree.Description = "The Way of the Sorcerer"
skillTree.Image = "entities/item_force_heal.png"
skillTree.BackgroundColor = Color(0, 255, 0, 180)
skillTree.BackgroundSize = 0.7
KyberCore:AddSkillTree(skillTree)

////////////////////
// Skill Registry
////////////////////

local skill = {}
skill.Name = "Force Heal"
skill.Description = "Use the force to heal a target"
skill.Image = "entities/item_force_heal.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "heal")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Revive"
skill.Description = "Using the force return the life back to a target and heal the target’s wounds."
skill.Image = "kybercore/revive.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "revive")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Group heal"
skill.Description = "Use the force to heal multiple targets including yourself."
skill.Image = "kybercore/group_heal.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "groupheal")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Judgement Strike"
skill.Description = "Using the force to send out a strike of lightning from your hand towards a target."
skill.Image = "kybercore/jstrike.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "judgementstrike")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Self Revive"
skill.Description = "By sheer will power and whatever remaining force you have left you bring yourself back from the brink."
skill.Image = "kybercore/self_revive.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "selfrevive")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Increase for Sorcerer 1"
skill.Description = "Increases maximum force by +5"
skill.Image = "kybercore/force_increase.png"
skill.Func = function(ply)
    if SERVER then 
        KyberCore:AddBonusForce(ply, 5)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Increase for Sorcerer 2"
skill.Description = "Increases maximum force by +15"
skill.Image = "kybercore/force_increase.png"
skill.Func = function(ply)
    if SERVER then 
        KyberCore:AddBonusForce(ply, 15)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Increase for Sorcerer 3"
skill.Description = "Increases maximum force by +5"
skill.Image = "kybercore/force_increase.png"
skill.Func = function(ply)
    if SERVER then 
        KyberCore:AddBonusForce(ply, 5)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Increase for Sorcerer 4"
skill.Description = "Increases maximum force by +20"
skill.Image = "kybercore/force_increase.png"
skill.Func = function(ply)
    if SERVER then 
        KyberCore:AddBonusForce(ply, 20)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Increase for Sorcerer 5"
skill.Description = "Increases maximum force by +20"
skill.Image = "kybercore/force_increase.png"
skill.Func = function(ply)
    if SERVER then 
        KyberCore:AddBonusForce(ply, 20)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Increase for Sorcerer 6"
skill.Description = "Increases maximum force by +20"
skill.Image = "kybercore/force_increase.png"
skill.Func = function(ply)
    if SERVER then 
        KyberCore:AddBonusForce(ply, 20)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Increase for Sorcerer 7"
skill.Description = "Increases maximum force by +25"
skill.Image = "kybercore/force_increase.png"
skill.Func = function(ply)
    if SERVER then 
        KyberCore:AddBonusForce(ply, 25)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Increase for Sorcerer 8"
skill.Description = "Increases maximum force by +25"
skill.Image = "kybercore/force_increase.png"
skill.Func = function(ply)
    if SERVER then 
        KyberCore:AddBonusForce(ply, 25)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Increase for Sorcerer 9"
skill.Description = "Increases maximum force by +25"
skill.Image = "kybercore/force_increase.png"
skill.Func = function(ply)
    if SERVER then 
        KyberCore:AddBonusForce(ply, 25)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Increase for Sorcerer 10"
skill.Description = "Increases maximum force by +30"
skill.Image = "kybercore/force_increase.png"
skill.Func = function(ply)
    if SERVER then 
        KyberCore:AddBonusForce(ply, 30)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Increase for Sorcerer 11"
skill.Description = "Increases maximum force by +30"
skill.Image = "kybercore/force_increase.png"
skill.Func = function(ply)
    if SERVER then 
        KyberCore:AddBonusForce(ply, 30)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Increase for Sorcerer 12"
skill.Description = "Increases maximum force by +30"
skill.Image = "kybercore/force_increase.png"
skill.Func = function(ply)
    if SERVER then 
        KyberCore:AddBonusForce(ply, 30)
    end
end
KyberCore:AddSkill(skill)

///////////////////////////
// Skill Tree Config
///////////////////////////

local skill = {}
skill.Name = "Force Heal"
skill.x = 0.05
skill.y = 0.5
skill.Cost = 2
skill.Requirements = {
    "Force Jump",
    "Form I: Shii-Cho",
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Revive"
skill.x = 0.32
skill.y = 0.5
skill.Cost = 5
skill.Requirements = {
    "Force Increase for Sorcerer 5",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Group heal"
skill.x = 0.32
skill.y = 0.08
skill.Cost = 5
skill.Requirements = {
    "Force Increase for Sorcerer 4",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Judgement Strike"
skill.x = 0.32
skill.y = 0.9
skill.Cost = 5
skill.Requirements = {
    "Force Increase for Sorcerer 6",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Self Revive"
skill.x = 0.62
skill.y = 0.5
skill.Cost = 10
skill.Requirements = {
    "Force Increase for Sorcerer 10",
    "Force Increase for Sorcerer 11",
    "Force Increase for Sorcerer 12",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Increase for Sorcerer 1"
skill.x = 0.15
skill.y = 0.12
skill.Cost = 3
skill.Requirements = {
    "Force Increase for Sorcerer 2",
}
skill.Unlocks = {
    "Group heal",
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Increase for Sorcerer 2"
skill.x = 0.13
skill.y = 0.5
skill.Cost = 2
skill.Requirements = {
    "Force Heal",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Increase for Sorcerer 3"
skill.x = 0.15
skill.y = 0.85
skill.Cost = 3
skill.Requirements = {
    "Force Increase for Sorcerer 2",
}
skill.Unlocks = {
    "Judgement Strike",
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Increase for Sorcerer 4"
skill.x = 0.23
skill.y = 0.25
skill.Cost = 5
skill.Requirements = {
    "Force Increase for Sorcerer 5",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Increase for Sorcerer 5"
skill.x = 0.20
skill.y = 0.5
skill.Cost = 5
skill.Requirements = {
    "Force Increase for Sorcerer 2",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Increase for Sorcerer 6"
skill.x = 0.23
skill.y = 0.75
skill.Cost = 5
skill.Requirements = {
    "Force Increase for Sorcerer 5",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Increase for Sorcerer 7"
skill.x = 0.4
skill.y = 0.25
skill.Cost = 6
skill.Requirements = {
    "Group heal",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Increase for Sorcerer 8"
skill.x = 0.4
skill.y = 0.75
skill.Cost = 6
skill.Requirements = {
    "Judgement Strike",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Increase for Sorcerer 9"
skill.x = 0.45
skill.y = 0.5
skill.Cost = 6
skill.Requirements = {
    "Force Revive",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Increase for Sorcerer 10"
skill.x = 0.5
skill.y = 0.12
skill.Cost = 7
skill.Requirements = {
    "Force Increase for Sorcerer 11",
}
skill.Unlocks = {
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Increase for Sorcerer 11"
skill.x = 0.53
skill.y = 0.5
skill.Cost = 7
skill.Requirements = {
    "Force Increase for Sorcerer 9",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Increase for Sorcerer 12"
skill.x = 0.5
skill.y = 0.85
skill.Cost = 7
skill.Requirements = {
    "Force Increase for Sorcerer 11",
}
skill.Unlocks = {
}
KyberCore:AddSkillToTree(skillTreeName, skill)

if KyberCore.Config.Developer then
    KyberCore:ReloadSkills()
end
