//////////////////////
// Skill Tree Registry
//////////////////////
local skillTreeName = "Force Blink"

local skillTree = {}
skillTree.Name = skillTreeName
skillTree.Description = "Use the force to teleport yourself to different locations of the users choice."
skillTree.Image = "kybercore/teleport.png"
KyberCore:AddSkillTree(skillTree)

////////////////////
// Skill Registry
////////////////////

local skill = {}
skill.Name = "Force Blink"
skill.Description = "Use the force to teleport yourself to different locations of the users choice."
skill.Image = "kybercore/teleport.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "blink")
end
KyberCore:AddSkill(skill)

///////////////////////////
// Skill Tree Config
///////////////////////////

local skill = {}
skill.Name = "Force Blink"
skill.x = 0.399
skill.y = 0.5
skill.Cost = 1
skill.Requirements = {
}
KyberCore:AddSkillToTree(skillTreeName, skill)

if KyberCore.Config.Developer then
    KyberCore:ReloadSkills()
end