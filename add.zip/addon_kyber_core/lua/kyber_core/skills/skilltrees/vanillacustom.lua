//////////////////////
// Skill Tree Registry
//////////////////////
local skillTreeName = "Pathway: <3"

local skillTree = {}
skillTree.Name = skillTreeName
skillTree.Description = "vanillacustom"
skillTree.Image = "kybercore/form7.png"
skillTree.BackgroundColor = Color(128, 0, 128, 180)
skillTree.BackgroundSize = 0.7
KyberCore:AddSkillTree(skillTree)

////////////////////
// Skill Registry
////////////////////

local skill = {}
skill.Name = "Form VII: Vaapad"
skill.Description = "Vicious and unpredictable, Form 7 requires a user to attack unleashing their passion and emotion."
skill.Image = "kybercore/form7.png"
skill.Func = function(ply)
    KyberCore:AddKnownForm(ply, "form7")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Barrier"
skill.Description = "Create a protective barrier using the Force."
skill.Image = "kybercore/barrier.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "bar")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Radiance"
skill.Description = "Flood your body with radiant energy, greatly enhancing your speed and force control for a short time."
skill.Image = "kybercore/radiance.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "rad")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Boulder Throw"
skill.Description = "Call upon raw telekinetic might to summon and hurl a massive boulder at your enemies."
skill.Image = "kybercore/boulder.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "boulderthrow")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "???"
skill.Description = "Please keep this as secret or lost it for forever."
skill.Image = "entities/item_force_breach.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "superkick")
end
KyberCore:AddSkill(skill)


///////////////////////////
// Skill Tree Config
///////////////////////////

local skill = {}
skill.Name = "Form VII: Vaapad"
skill.x = 0.399
skill.y = 0.8
skill.Cost = 1
skill.Requirements = {
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Barrier"
skill.x = 0.399
skill.y = 0.5
skill.Cost = 1
skill.Requirements = {
    "Form VII: Vaapad",
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Radiance"
skill.x = 0.3
skill.y = 0.5
skill.Cost = 1
skill.Requirements = {
    "Form VII: Vaapad",
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Boulder Throw"
skill.x = 0.5
skill.y = 0.5
skill.Cost = 1
skill.Requirements = {
    "Form VII: Vaapad",
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "???"
skill.x = 0.00
skill.y = 1.08
skill.Cost = 150
skill.Requirements = {
    "Speed 5",
    "Health 5",
    "Stamina 5",
    "Self Heal",
}
KyberCore:AddSkillToTree(skillTreeName, skill)

if KyberCore.Config.Developer then
    KyberCore:ReloadSkills()
end