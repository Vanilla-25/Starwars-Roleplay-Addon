//////////////////////
// Skill Tree Registry
//////////////////////
local skillTreeName = "Form 2: Makashi"

local skillTree = {}
skillTree.Name = skillTreeName
skillTree.Description = "Form 2: Makashi"
skillTree.Image = "kybercore/form2.png"
KyberCore:AddSkillTree(skillTree)

local skillTreeName2 = "Form 3: Soresu"

local skillTree = {}
skillTree.Name = skillTreeName2
skillTree.Description = "Form 3: Soresu"
skillTree.Image = "kybercore/form3.png"
KyberCore:AddSkillTree(skillTree)

local skillTreeName3 = "Form 4: Ataru"

local skillTree = {}
skillTree.Name = skillTreeName3
skillTree.Description = "Form 4: Ataru"
skillTree.Image = "kybercore/form4.png"
KyberCore:AddSkillTree(skillTree)

local skillTreeName4 = "Form 5: Shien"

local skillTree = {}
skillTree.Name = skillTreeName4
skillTree.Description = "Form V: Shien"
skillTree.Image = "kybercore/form5.png"
KyberCore:AddSkillTree(skillTree)

local skillTreeName5 = "Form 6: Niman"

local skillTree = {}
skillTree.Name = skillTreeName5
skillTree.Description = "Form 6: Niman"
skillTree.Image = "kybercore/form6.png"
KyberCore:AddSkillTree(skillTree)

local skillTreeName6 = "Form 7: Vaapad"

local skillTree = {}
skillTree.Name = skillTreeName6
skillTree.Description = "Form VII: Vaapad"
skillTree.Image = "kybercore/form7.png"
KyberCore:AddSkillTree(skillTree)

local skillTreeName7 = "Form Jar'Kai"

local skillTree = {}
skillTree.Name = skillTreeName7
skillTree.Description = "Form: Jar'Kai"
skillTree.Image = "kybercore/jarkai.png"
KyberCore:AddSkillTree(skillTree)

////////////////////
// Skill Registry
////////////////////

local skill = {}
skill.Name = "Form II: Makashi"
skill.Description = "Form 2 is the preferred style for lightsaber on lightsaber duelling and is seen as the most elegant of forms."
skill.Image = "kybercore/form2.png"
skill.Func = function(ply)
    KyberCore:AddKnownForm(ply, "form2")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Form III: Soresu"
skill.Description = "Form 3 is said to be the ultimate expression of defense. It's masters are said to be impervious to all forms of attacks."
skill.Image = "kybercore/form3.png"
skill.Func = function(ply)
    KyberCore:AddKnownForm(ply, "form3")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Form IV: Ataru"
skill.Description = "A form of lightsaber combat that focuses on aggression and unpredictability."
skill.Image = "kybercore/form4.png"
skill.Func = function(ply)
    KyberCore:AddKnownForm(ply, "form4")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Form V: Shien"
skill.Description = "The most physically demanding form. Form 5 uses strength to overpower their opponents and use their opponents attacks against them."
skill.Image = "kybercore/form5.png"
skill.Func = function(ply)
    KyberCore:AddKnownForm(ply, "form5")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Form VI: Niman"
skill.Description = "Form 6 is the most balanced of the forms. It draws from all styles and is re-marked for is practicality."
skill.Image = "kybercore/form6.png"
skill.Func = function(ply)
    KyberCore:AddKnownForm(ply, "form6")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Form VII: Vaapad"
skill.Description = "Vicious and unpredictable, Form 7 requires a user to attack unleashing their passion and emotion."
skill.Image = "kybercore/form7.png"
skill.Func = function(ply)
    KyberCore:AddKnownForm(ply, "form7")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Form: Jar'Kai"
skill.Description = "Jar'kai was the method of using 2 lightsaber during combat with the most common tactics to be heavily on the offensive.  MaxBlockPoints 70"
skill.Image = "kybercore/jarkai.png"
skill.Func = function(ply)
    KyberCore:AddKnownForm(ply, "formjk")
end
KyberCore:AddSkill(skill)

///////////////////////////
// Skill Tree Config
///////////////////////////

local skill = {}
skill.Name = "Form II: Makashi"
skill.x = 0.399
skill.y = 0.5
skill.Cost = 0
skill.Requirements = {
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Form III: Soresu"
skill.x = 0.399
skill.y = 0.5
skill.Cost = 0
skill.Requirements = {
}
KyberCore:AddSkillToTree(skillTreeName2, skill)

local skill = {}
skill.Name = "Form IV: Ataru"
skill.x = 0.399
skill.y = 0.5
skill.Cost = 0
skill.Requirements = {
}
KyberCore:AddSkillToTree(skillTreeName3, skill)

local skill = {}
skill.Name = "Form V: Shien"
skill.x = 0.399
skill.y = 0.5
skill.Cost = 0
skill.Requirements = {
}
KyberCore:AddSkillToTree(skillTreeName4, skill)

local skill = {}
skill.Name = "Form VI: Niman"
skill.x = 0.399
skill.y = 0.5
skill.Cost = 0
skill.Requirements = {
}
KyberCore:AddSkillToTree(skillTreeName5, skill)

local skill = {}
skill.Name = "Form VII: Vaapad"
skill.x = 0.399
skill.y = 0.5
skill.Cost = 0
skill.Requirements = {
}
KyberCore:AddSkillToTree(skillTreeName6, skill)

local skill = {}
skill.Name = "Form: Jar'Kai"
skill.x = 0.399
skill.y = 0.5
skill.Cost = 0
skill.Requirements = {
}
KyberCore:AddSkillToTree(skillTreeName7, skill)

if KyberCore.Config.Developer then
    KyberCore:ReloadSkills()
end