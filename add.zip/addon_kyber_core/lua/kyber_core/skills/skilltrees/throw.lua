//////////////////////
// Skill Tree Registry
//////////////////////
local skillTreeName = "Throw"

local skillTree = {}
skillTree.Name = skillTreeName
skillTree.Description = "Throw your lightsaber at enemies, striking from a distance."
skillTree.Image = "entities/item_force_throw.png"
KyberCore:AddSkillTree(skillTree)

////////////////////
// Skill Registry
////////////////////

local skill = {}
skill.Name = "Throw"
skill.Description = "Throw your lightsaber at enemies, striking from a distance."
skill.Image = "entities/item_force_throw.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "throw")
end
KyberCore:AddSkill(skill)

///////////////////////////
// Skill Tree Config
///////////////////////////

local skill = {}
skill.Name = "Throw"
skill.x = 0.399
skill.y = 0.5
skill.Cost = 1
skill.Requirements = {
}
KyberCore:AddSkillToTree(skillTreeName, skill)

if KyberCore.Config.Developer then
    KyberCore:ReloadSkills()
end