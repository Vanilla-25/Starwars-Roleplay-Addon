//////////////////////
// Skill Tree Registry
//////////////////////
local skillTreeName = "Fundamental"

local skillTree = {}
skillTree.Name = skillTreeName
skillTree.Description = "This is the Way"
skillTree.Image = "wos/skilltrees/fundamental.jpg"
KyberCore:AddSkillTree(skillTree)

////////////////////
// Skill Registry
////////////////////

local skill = {}
skill.Name = "Form I: Shii-Cho"
skill.Description = "Teaches the basic moves of attack, parry and block."
skill.Image = "kybercore/form1.png"
skill.Func = function(ply)
    KyberCore:AddKnownForm(ply, "form1")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Jump"
skill.Description = "Use the force to Jump up to areas which are normally out of range."
skill.Image = "entities/item_force_jump.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "jump_2")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Push"
skill.Description = "Use the force to send a target flying backwards from the user."
skill.Image = "entities/item_force_push.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "push")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Pull"
skill.Description = "Use the force to send a target flying towards the user."
skill.Image = "entities/item_force_pull.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "pull")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Sense"
skill.Description = "Use the force to enhance your vision seeing things that most cannot."
skill.Image = "entities/item_force_sense.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "sense")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Self Heal"
skill.Description = "Using the force to slowly heal oneself. While not as fast as Force Heal can be useful in a pinch."
skill.Image = "kybercore/self_heal.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "selfheal")
end
KyberCore:AddSkill(skill)

-- Stamina -- 
local skill = {}
skill.Name = "Stamina 1"
skill.Description = "Increase max stamina by +5."
skill.Image = "kybercore/stamina.png"
skill.Func = function(ply)
    if SERVER then
        KyberCore:AddBonusBlockPoints(ply, 5)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Stamina 2"
skill.Description = "Increase max stamina by +5."
skill.Image = "kybercore/stamina.png"
skill.Func = function(ply)
    if SERVER then
        KyberCore:AddBonusBlockPoints(ply, 5)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Stamina 3"
skill.Description = "Increase max stamina by +5."
skill.Image = "kybercore/stamina.png"
skill.Func = function(ply)
    if SERVER then
        KyberCore:AddBonusBlockPoints(ply, 5)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Stamina 4"
skill.Description = "Increase max stamina by +5."
skill.Image = "kybercore/stamina.png"
skill.Func = function(ply)
    if SERVER then
        KyberCore:AddBonusBlockPoints(ply, 5)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Stamina 5"
skill.Description = "Increase max stamina by +5."
skill.Image = "kybercore/stamina.png"
skill.Func = function(ply)
    if SERVER then
        KyberCore:AddBonusBlockPoints(ply, 5)
    end
end
KyberCore:AddSkill(skill)

-- Health --
local skill = {}
skill.Name = "Health 1"
skill.Description = "Increase max health by +50."
skill.Image = "entities/heal.png"
skill.Func = function(ply)
    if SERVER then
        KyberCore:AddBonusHealth(ply, 50)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Health 2"
skill.Description = "Increase max health by +50."
skill.Image = "entities/heal.png"
skill.Func = function(ply)
    if SERVER then
        KyberCore:AddBonusHealth(ply, 50)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Health 3"
skill.Description = "Increase max health by +50."
skill.Image = "entities/heal.png"
skill.Func = function(ply)
    if SERVER then
        KyberCore:AddBonusHealth(ply, 50)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Health 4"
skill.Description = "Increase max health by +50."
skill.Image = "entities/heal.png"
skill.Func = function(ply)
    if SERVER then
        KyberCore:AddBonusHealth(ply, 50)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Health 5"
skill.Description = "Increase max health by +50."
skill.Image = "entities/heal.png"
skill.Func = function(ply)
    if SERVER then
        KyberCore:AddBonusHealth(ply, 50)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Speed 1"
skill.Description = "Increase run speed by +15"
skill.Image = "entities/speed.png"
skill.Func = function(ply)
    if SERVER then
        KyberCore:AddBonusSpeed(ply, 15)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Speed 2"
skill.Description = "Increase run speed by +15"
skill.Image = "entities/speed.png"
skill.Func = function(ply)
    if SERVER then
        KyberCore:AddBonusSpeed(ply, 15)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Speed 3"
skill.Description = "Increase run speed by +15"
skill.Image = "entities/speed.png"
skill.Func = function(ply)
    if SERVER then
        KyberCore:AddBonusSpeed(ply, 15)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Speed 4"
skill.Description = "Increase run speed by +15"
skill.Image = "entities/speed.png"
skill.Func = function(ply)
    if SERVER then
        KyberCore:AddBonusSpeed(ply, 15)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Speed 5"
skill.Description = "Increase run speed by +15"
skill.Image = "entities/speed.png"
skill.Func = function(ply)
    if SERVER then
        KyberCore:AddBonusSpeed(ply, 15)
    end
end
KyberCore:AddSkill(skill)

///////////////////////////
// Skill Tree Config
///////////////////////////

local skill = {}
skill.Name = "Force Jump"
skill.x = 0.05
skill.y = 0.4
skill.Cost = 0
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Push"
skill.x = 0.195 
skill.y = 0.4
skill.Cost = 2
skill.Requirements = {
    "Force Jump",
    "Form I: Shii-Cho",
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Pull"
skill.x = 0.34
skill.y = 0.4
skill.Cost = 2
skill.Requirements = {
    "Force Jump",
    "Force Push",
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Sense"
skill.x = 0.485 
skill.y = 0.4
skill.Cost = 5
skill.Requirements = {
    "Force Jump",
    "Force Push",
    "Force Pull",
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Self Heal"
skill.x = 0.63
skill.y = 0.4
skill.Cost = 7
skill.Requirements = {
    "Force Jump",
    "Force Push",
    "Force Pull",
    "Force Sense",
}
KyberCore:AddSkillToTree(skillTreeName, skill)

-- Health -- 
local skill = {}
skill.Name = "Health 1"
skill.x = 0.1225
skill.y = 0.15
skill.Cost = 1
skill.Requirements = {
    "Force Jump",
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Health 2"
skill.x = 0.23125
skill.y = 0.15
skill.Cost = 2
skill.Requirements = {
    "Health 1",
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Health 3"
skill.x = 0.34
skill.y = 0.15
skill.Cost = 3
skill.Requirements = {
    "Health 2",
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Health 4"
skill.x = 0.44875
skill.y = 0.15
skill.Cost = 5
skill.Requirements = {
    "Health 3",
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Health 5"
skill.x = 0.5575
skill.y = 0.15
skill.Cost = 7
skill.Requirements = {
    "Health 4",
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Form I: Shii-Cho"
skill.x = 0.05
skill.y = 0.73
skill.Cost = 0
KyberCore:AddSkillToTree(skillTreeName, skill)

-- Stamina -- 
local skill = {}
skill.Name = "Stamina 1"
skill.x = 0.195
skill.y = 0.65
skill.Cost = 1
skill.Requirements = {
    "Form I: Shii-Cho",
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Stamina 2"
skill.x = 0.285625
skill.y = 0.65
skill.Cost = 2
skill.Requirements = {
    "Stamina 1",
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Stamina 3"
skill.x = 0.37625
skill.y = 0.65
skill.Cost = 3
skill.Requirements = {
    "Stamina 2",
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Stamina 4"
skill.x = 0.466875
skill.y = 0.65
skill.Cost = 5
skill.Requirements = {
    "Stamina 3",
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Stamina 5"
skill.x = 0.5575
skill.y = 0.65
skill.Cost = 7
skill.Requirements = {
    "Stamina 4",
}
KyberCore:AddSkillToTree(skillTreeName, skill)

-- Speed --
local skill = {}
skill.Name = "Speed 1"
skill.x = 0.195
skill.y = 0.87
skill.Cost = 1
skill.Requirements = {
    "Form I: Shii-Cho",
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Speed 2"
skill.x = 0.285625
skill.y = 0.87
skill.Cost = 2
skill.Requirements = {
    "Speed 1",
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Speed 3"
skill.x = 0.37625
skill.y = 0.87
skill.Cost = 3
skill.Requirements = {
    "Speed 2",
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Speed 4"
skill.x = 0.466875
skill.y = 0.87
skill.Cost = 5
skill.Requirements = {
    "Speed 3",
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Speed 5"
skill.x = 0.5575
skill.y = 0.87
skill.Cost = 7
skill.Requirements = {
    "Speed 4",
}
KyberCore:AddSkillToTree(skillTreeName, skill)

if KyberCore.Config.Developer then
    KyberCore:ReloadSkills()
end