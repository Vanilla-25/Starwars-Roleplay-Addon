//////////////////////
// Skill Tree Registry
//////////////////////
local skillTreeName = "Electric Judgement"

local skillTree = {}
skillTree.Name = skillTreeName
skillTree.Description = "Electric Judgment emits as a burst of electric energy directed at a target, intended to neutralize rather than to kill or severely harm."
skillTree.Image = "entities/item_force_lightning.png"
KyberCore:AddSkillTree(skillTree)

////////////////////
// Skill Registry
////////////////////

local skill = {}
skill.Name = "Electric Judgement"
skill.Description = "Electric Judgment emits as a burst of electric energy directed at a target, intended to neutralize rather than to kill or severely harm."
skill.Image = "entities/item_force_lightning.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "ej")
end
KyberCore:AddSkill(skill)

///////////////////////////
// Skill Tree Config
///////////////////////////

local skill = {}
skill.Name = "Electric Judgement"
skill.x = 0.399
skill.y = 0.5
skill.Cost = 1
skill.Requirements = {
}
KyberCore:AddSkillToTree(skillTreeName, skill)

if KyberCore.Config.Developer then
    KyberCore:ReloadSkills()
end