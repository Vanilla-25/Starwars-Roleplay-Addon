//////////////////////
// Skill Tree Registry
//////////////////////
local skillTreeName = "Developer Tree"

local skillTree = {}
skillTree.Name = skillTreeName
skillTree.Description = "hell yeah baby"
skillTree.Image = "icon16/bug.png"
skillTree.BackgroundImage = "stoneos/icons/bug.png"
skillTree.BackgroundColor = Color(255, 255, 255, 100)
skillTree.BackgroundSize = 0.5
skillTree.Exclusive = true
KyberCore:AddSkillTree(skillTree)

////////////////////
// Skill Registry
////////////////////

local skill = {}
skill.Name = "Force Die"
skill.Description = "Literally die."
skill.Image = "kybercore/die.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "die")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Super Jump"
skill.Description = "Fly, you beautiful bastard."
skill.Image = "entities/item_force_superman.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "superman")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Diamond Hurricane"
skill.Description = "Absolutely fucking destroy someone infront of you."
skill.Image = "kybercore/diam.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "diamondhurricane")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Divine Sorcery"
skill.Description = "No, I am not a wizard."
skill.Image = "kybercore/divine.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "divine_sorcery")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Laugh"
skill.Description = "Heheha!"
skill.Image = "entities/item_force_fuck.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "fuck")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Tears of Denial"
skill.Description = "Miracle taught by Morne, the Archbishop's apostle. Grants one chance to endure when HP reaches 0."
skill.Image = "kybercore/tears_of_denial.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "tears")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "KAMEHAMEHA"
skill.Description = "Vaporize your foes."
skill.Image = "entities/item_force_kamehameha.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "kamehameha")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Flash"
skill.Description = "My name is Inquisitor Allen, and I'm the fastest man alive."
skill.Image = "kybercore/flash.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "flash")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Glock 19"
skill.Description = "The Glock 19 is effectively a reduced-size Glock 17, called the 'Compact' by the manufacturer."
skill.Image = "kybercore/glock19.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "glock19")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Rock and Melon Throw"
skill.Description = "Lob a Rock at your foe"
skill.Image = "kybercore/gwobus.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "rock")
    KyberCore:AddKnownPower(ply, "melon")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Mind Trick"
skill.Description = "You will call me the cutest inquisitor alive."
skill.Image = "kybercore/mindtrick.jpg"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "mindtrick")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "HEY CATCH!"
skill.Description = "PARRY THIS CASUAL"
skill.Image = "entities/item_force_heycatch.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "heycatch")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Rocket"
skill.Description = "Fly, rocketman."
skill.Image = "entities/item_force_heal.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "rocket")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Rewind and Displacement"
skill.Description = "Cheers love, the cavalry's here!"
skill.Image = "entities/item_force_heal.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "rewind")
    KyberCore:AddKnownPower(ply, "displacement")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Telekinetic Assault"
skill.Description = "Throw a chunk of earth"
skill.Image = "entities/item_force_boulderthrow.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "sfrockthrow")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Snap"
skill.Description = "Snap"
skill.Image = "kybercore/snap.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "snap")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Unleash the Lightning"
skill.Description = "A Dark Side ability that fires Lightning Bolts out of your Hand"
skill.Image = "entities/item_force_lightning.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "lightning")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Auto Parry"
skill.Description = "Fine. I'll parry it."
skill.Image = "entities/item_force_heal.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "autoparry")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Blind"
skill.Description = "Make your enemies blind"
skill.Image = "kybercore/buck_t.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "blind")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Super-kick"
skill.Description = "Fuck you."
skill.Image = "entities/item_force_breach.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "superkick")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Give Cancer"
skill.Description = "cancer ray"
skill.Image = "entities/item_force_breach.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "cancer")
end
KyberCore:AddSkill(skill)

///////////////////////////
// Skill Tree Config
///////////////////////////

local skill = {}
skill.Name = "Force Die"
skill.x = 0.05
skill.y = 0.25
skill.Cost = 5
skill.Requirements = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Super Jump"
skill.x = 0.12
skill.y = 0.10
skill.Cost = 1
skill.Requirements = { "Force Die" }
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Laugh"
skill.x = 0.19
skill.y = 0.25
skill.Cost = 1
skill.Requirements = { "Super Jump", "Divine Sorcery"}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Divine Sorcery"
skill.x = 0.12
skill.y = 0.5
skill.Cost = 1
skill.Requirements = { "Force Die", "Diamond Hurricane" }
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Diamond Hurricane"
skill.x = 0.05
skill.y = 0.75
skill.Cost = 1
skill.Requirements = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "KAMEHAMEHA"
skill.x = 0.19
skill.y = 0.75
skill.Cost = 1
skill.Requirements = { "Tears of Denial", "Divine Sorcery" }
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Tears of Denial"
skill.x = 0.12
skill.y = 0.9
skill.Cost = 1
skill.Requirements = { "Diamond Hurricane" }
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Flash"
skill.x = 0.25
skill.y = 0.35
skill.Cost = 1
skill.Requirements = { "Laugh" }
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Glock 19"
skill.x = 0.25
skill.y = 0.55
skill.Cost = 1
skill.Requirements = { "KAMEHAMEHA" }
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Rock and Melon Throw"
skill.x = 0.32
skill.y = 0.55
skill.Cost = 1
skill.Requirements = { "Glock 19" }
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Mind Trick"
skill.x = 0.32
skill.y = 0.35
skill.Cost = 1
skill.Requirements = { "Force Flash" }
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "HEY CATCH!"
skill.x = 0.39
skill.y = 0.35
skill.Cost = 1
skill.Requirements = { "Mind Trick" }
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Rocket"
skill.x = 0.39
skill.y = 0.55
skill.Cost = 1
skill.Requirements = { "Rock and Melon Throw" }
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Rewind and Displacement"
skill.x = 0.46
skill.y = 0.35
skill.Cost = 1
skill.Requirements = { "HEY CATCH!" }
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Telekinetic Assault"
skill.x = 0.46
skill.y = 0.55
skill.Cost = 1
skill.Requirements = { "Rocket" }
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Unleash the Lightning"
skill.x = 0.53
skill.y = 0.35
skill.Cost = 1
skill.Requirements = { "Rewind and Displacement" }
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Snap"
skill.x = 0.53
skill.y = 0.55
skill.Cost = 1
skill.Requirements = { "Telekinetic Assault" }
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Auto Parry"
skill.x = 0.6
skill.y = 0.3
skill.Cost = 1
skill.Requirements = { "Unleash the Lightning" }
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Blind"
skill.x = 0.6
skill.y = 0.6
skill.Cost = 1
skill.Requirements = { "Force Snap" }
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Super-kick"
skill.x = 0.65
skill.y = 0.45
skill.Cost = 1
skill.Requirements = { "Auto Parry", "Blind" }
KyberCore:AddSkillToTree(skillTreeName, skill)

if KyberCore.Config.Developer then
    KyberCore:ReloadSkills()
end

local skill = {}
skill.Name = "Give Cancer"
skill.x = 0.8
skill.y = 0.8
skill.Cost = 1
skill.Requirements = { "Super-kick" }
KyberCore:AddSkillToTree(skillTreeName, skill)