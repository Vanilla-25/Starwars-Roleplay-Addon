//////////////////////
// Skill Tree Registry
//////////////////////
local skillTreeName = "Force Repair"

local skillTree = {}
skillTree.Name = skillTreeName
skillTree.Description = "Use the force to mend and repair your vehicle."
skillTree.Image = "kybercore/repair.png"
KyberCore:AddSkillTree(skillTree)

////////////////////
// Skill Registry
////////////////////

local skill = {}
skill.Name = "Force Repair"
skill.Description = "Use the force to mend and repair your vehicle."
skill.Image = "kybercore/repair.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "repair")
end
KyberCore:AddSkill(skill)

///////////////////////////
// Skill Tree Config
///////////////////////////

local skill = {}
skill.Name = "Force Repair"
skill.x = 0.399
skill.y = 0.5
skill.Cost = 1
skill.Requirements = {
}
KyberCore:AddSkillToTree(skillTreeName, skill)

if KyberCore.Config.Developer then
    KyberCore:ReloadSkills()
end
