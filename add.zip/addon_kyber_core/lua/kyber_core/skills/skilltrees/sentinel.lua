//////////////////////
// Skill Tree Registry
//////////////////////
local skillTreeName = "Pathway: Sentinel"

local skillTree = {}
skillTree.Name = skillTreeName
skillTree.Description = "The Way of the Sentinel"
skillTree.Image = "kybercore/cloak.png"
skillTree.BackgroundColor = Color(255, 255, 0, 180)
skillTree.BackgroundSize = 0.7
KyberCore:AddSkillTree(skillTree)

////////////////////
// Skill Registry
////////////////////

local skill = {}
skill.Name = "Force Cloak"
skill.Description = "Use the force to cloak yourself from the senses rendering you invisible for ??? seconds."
skill.Image = "kybercore/cloak.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "cloak")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Breach"
skill.Description = "Use the force and your leg to unlock pathways and doors that are normally locked."
skill.Image = "kybercore/breach.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "breach")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Sprint"
skill.Description = "Use the force to enhance yourself to sprint at a faster rate than your peers for a short period of time."
skill.Image = "kybercore/sprint.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "sprint")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Teleport"
skill.Description = "Use the force to teleport yourself to different locations of the users choice."
skill.Image = "kybercore/teleport.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "teleport")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Shadow step"
skill.Description = "Swap positions with a target and cause significant damage to the target."
skill.Image = "kybercore/step.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "shadowstep")
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Increase for Sentinels 1"
skill.Description = "Increases maximum force by +5"
skill.Image = "kybercore/force_increase.png"
skill.Func = function(ply)
    if SERVER then 
        KyberCore:AddBonusForce(ply, 5)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Increase for Sentinels 2"
skill.Description = "Increases maximum force by +15"
skill.Image = "kybercore/force_increase.png"
skill.Func = function(ply)
    if SERVER then 
        KyberCore:AddBonusForce(ply, 15)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Increase for Sentinels 3"
skill.Description = "Increases maximum force by +5"
skill.Image = "kybercore/force_increase.png"
skill.Func = function(ply)
    if SERVER then 
        KyberCore:AddBonusForce(ply, 5)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Increase for Sentinels 4"
skill.Description = "Increases maximum force by +20"
skill.Image = "kybercore/force_increase.png"
skill.Func = function(ply)
    if SERVER then 
        KyberCore:AddBonusForce(ply, 20)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Increase for Sentinels 5"
skill.Description = "Increases maximum force by +20"
skill.Image = "kybercore/force_increase.png"
skill.Func = function(ply)
    if SERVER then 
        KyberCore:AddBonusForce(ply, 20)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Increase for Sentinels 6"
skill.Description = "Increases maximum force by +20"
skill.Image = "kybercore/force_increase.png"
skill.Func = function(ply)
    if SERVER then 
        KyberCore:AddBonusForce(ply, 20)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Increase for Sentinels 7"
skill.Description = "Increases maximum force by +25"
skill.Image = "kybercore/force_increase.png"
skill.Func = function(ply)
    if SERVER then 
        KyberCore:AddBonusForce(ply, 25)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Increase for Sentinels 8"
skill.Description = "Increases maximum force by +25"
skill.Image = "kybercore/force_increase.png"
skill.Func = function(ply)
    if SERVER then 
        KyberCore:AddBonusForce(ply, 25)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Increase for Sentinels 9"
skill.Description = "Increases maximum force by +25"
skill.Image = "kybercore/force_increase.png"
skill.Func = function(ply)
    if SERVER then 
        KyberCore:AddBonusForce(ply, 25)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Increase for Sentinels 10"
skill.Description = "Increases maximum force by +30"
skill.Image = "kybercore/force_increase.png"
skill.Func = function(ply)
    if SERVER then 
        KyberCore:AddBonusForce(ply, 30)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Increase for Sentinels 11"
skill.Description = "Increases maximum force by +30"
skill.Image = "kybercore/force_increase.png"
skill.Func = function(ply)
    if SERVER then 
        KyberCore:AddBonusForce(ply, 30)
    end
end
KyberCore:AddSkill(skill)

local skill = {}
skill.Name = "Force Increase for Sentinels 12"
skill.Description = "Increases maximum force by +30"
skill.Image = "kybercore/force_increase.png"
skill.Func = function(ply)
    if SERVER then 
        KyberCore:AddBonusForce(ply, 30)
    end
end
KyberCore:AddSkill(skill)

///////////////////////////
// Skill Tree Config
///////////////////////////

local skill = {}
skill.Name = "Force Cloak"
skill.x = 0.05
skill.y = 0.5
skill.Cost = 2
skill.Requirements = {
    "Force Jump",
    "Form I: Shii-Cho",
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Breach"
skill.x = 0.32
skill.y = 0.5
skill.Cost = 5
skill.Requirements = {
    "Force Increase for Sentinels 5",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Sprint"
skill.x = 0.32
skill.y = 0.08
skill.Cost = 5
skill.Requirements = {
    "Force Increase for Sentinels 4",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Teleport"
skill.x = 0.32
skill.y = 0.9
skill.Cost = 5
skill.Requirements = {
    "Force Increase for Sentinels 6",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Shadow step"
skill.x = 0.62
skill.y = 0.5
skill.Cost = 10
skill.Requirements = {
    "Force Increase for Sentinels 10",
    "Force Increase for Sentinels 11",
    "Force Increase for Sentinels 12",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Increase for Sentinels 1"
skill.x = 0.15
skill.y = 0.12
skill.Cost = 3
skill.Requirements = {
    "Force Increase for Sentinels 2",
}
skill.Unlocks = {
    "Force Sprint",
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Increase for Sentinels 2"
skill.x = 0.13
skill.y = 0.5
skill.Cost = 2
skill.Requirements = {
    "Force Cloak",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Increase for Sentinels 3"
skill.x = 0.15
skill.y = 0.85
skill.Cost = 3
skill.Requirements = {
    "Force Increase for Sentinels 2",
}
skill.Unlocks = {
    "Force Teleport",
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Increase for Sentinels 4"
skill.x = 0.23
skill.y = 0.25
skill.Cost = 5
skill.Requirements = {
    "Force Increase for Sentinels 5",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Increase for Sentinels 5"
skill.x = 0.20
skill.y = 0.5
skill.Cost = 5
skill.Requirements = {
    "Force Increase for Sentinels 2",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Increase for Sentinels 6"
skill.x = 0.23
skill.y = 0.75
skill.Cost = 5
skill.Requirements = {
    "Force Increase for Sentinels 5",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Increase for Sentinels 7"
skill.x = 0.4
skill.y = 0.25
skill.Cost = 6
skill.Requirements = {
    "Force Sprint",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Increase for Sentinels 8"
skill.x = 0.4
skill.y = 0.75
skill.Cost = 6
skill.Requirements = {
    "Force Teleport",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Increase for Sentinels 9"
skill.x = 0.45
skill.y = 0.5
skill.Cost = 6
skill.Requirements = {
    "Force Breach",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Increase for Sentinels 10"
skill.x = 0.5
skill.y = 0.12
skill.Cost = 7
skill.Requirements = {
    "Force Increase for Sentinels 11",
}
skill.Unlocks = {
}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Increase for Sentinels 11"
skill.x = 0.53
skill.y = 0.5
skill.Cost = 7
skill.Requirements = {
    "Force Increase for Sentinels 9",
}
skill.Unlocks = {}
KyberCore:AddSkillToTree(skillTreeName, skill)

local skill = {}
skill.Name = "Force Increase for Sentinels 12"
skill.x = 0.5
skill.y = 0.85
skill.Cost = 7
skill.Requirements = {
    "Force Increase for Sentinels 11",
}
skill.Unlocks = {
}
KyberCore:AddSkillToTree(skillTreeName, skill)

if KyberCore.Config.Developer then
    KyberCore:ReloadSkills()
end