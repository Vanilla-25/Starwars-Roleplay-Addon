//////////////////////
// Skill Tree Registry
//////////////////////
local skillTreeName = "Lightning"

local skillTree = {}
skillTree.Name = skillTreeName
skillTree.Description = "A Dark Side ability that fires Lightning Bolts out of your Hand"
skillTree.Image = "entities/item_force_lightning.png"
KyberCore:AddSkillTree(skillTree)

////////////////////
// Skill Registry
////////////////////

local skill = {}
skill.Name = "Lightning"
skill.Description = "A Dark Side ability that fires Lightning Bolts out of your Hand"
skill.Image = "entities/item_force_lightning.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "lightning")
end
KyberCore:AddSkill(skill)

///////////////////////////
// Skill Tree Config
///////////////////////////

local skill = {}
skill.Name = "Lightning"
skill.x = 0.399
skill.y = 0.5
skill.Cost = 1
skill.Requirements = {
}
KyberCore:AddSkillToTree(skillTreeName, skill)

if KyberCore.Config.Developer then
    KyberCore:ReloadSkills()
end