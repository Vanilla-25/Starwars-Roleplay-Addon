//////////////////////
// Skill Tree Registry
//////////////////////
local skillTreeName = "Force Leap"

local skillTree = {}
skillTree.Name = skillTreeName
skillTree.Description = "Force Leap"
skillTree.Image = "entities/item_force_leap.png"
KyberCore:AddSkillTree(skillTree)

////////////////////
// Skill Registry
////////////////////

local skill = {}
skill.Name = "Force Leap"
skill.Description = "Launch yourself with the Force to reach areas beyond normal jumping range."
skill.Image = "entities/item_force_leap.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "jump_3")
end
KyberCore:AddSkill(skill)

///////////////////////////
// Skill Tree Config
///////////////////////////

local skill = {}
skill.Name = "Force Leap"
skill.x = 0.399
skill.y = 0.5
skill.Cost = 1
skill.Requirements = {
}
KyberCore:AddSkillToTree(skillTreeName, skill)

if KyberCore.Config.Developer then
    KyberCore:ReloadSkills()
end