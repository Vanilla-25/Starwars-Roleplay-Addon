//////////////////////
// Skill Tree Registry
//////////////////////
local skillTreeName = "Force Stasis"

local skillTree = {}
skillTree.Name = skillTreeName
skillTree.Description = "Force Stasis"
skillTree.Image = "kybercore/stasis.png"
KyberCore:AddSkillTree(skillTree)

////////////////////
// Skill Registry
////////////////////

local skill = {}
skill.Name = "Force Stasis"
skill.Description = "Use the force to freeze your enemies in their track and immobilise them for a few seconds."
skill.Image = "kybercore/stasis.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "stasis")
end
KyberCore:AddSkill(skill)

///////////////////////////
// Skill Tree Config
///////////////////////////

local skill = {}
skill.Name = "Force Stasis"
skill.x = 0.399
skill.y = 0.5
skill.Cost = 1
skill.Requirements = {
}
KyberCore:AddSkillToTree(skillTreeName, skill)

if KyberCore.Config.Developer then
    KyberCore:ReloadSkills()
end