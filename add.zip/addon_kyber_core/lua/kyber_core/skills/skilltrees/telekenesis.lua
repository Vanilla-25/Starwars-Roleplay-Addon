//////////////////////
// Skill Tree Registry
//////////////////////
local skillTreeName = "Force Telekenesis"

local skillTree = {}
skillTree.Name = skillTreeName
skillTree.Description = "Force Telekenesis"
skillTree.Image = "kybercore/telekenesis.png"
KyberCore:AddSkillTree(skillTree)

////////////////////
// Skill Registry
////////////////////

local skill = {}
skill.Name = "Force Telekenesis"
skill.Description = "Allows you to gain full control of a target and be able to manipulate the target in certain ways e.g. pick them up and throw them."
skill.Image = "kybercore/telekenesis.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "telekenesis")
end
KyberCore:AddSkill(skill)

///////////////////////////
// Skill Tree Config
///////////////////////////

local skill = {}
skill.Name = "Force Telekenesis"
skill.x = 0.399
skill.y = 0.5
skill.Cost = 1
skill.Requirements = {
}
KyberCore:AddSkillToTree(skillTreeName, skill)

if KyberCore.Config.Developer then
    KyberCore:ReloadSkills()
end