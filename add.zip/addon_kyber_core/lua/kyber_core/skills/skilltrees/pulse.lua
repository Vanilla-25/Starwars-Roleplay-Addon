//////////////////////
// Skill Tree Registry
//////////////////////
local skillTreeName = "Force Pulse"

local skillTree = {}
skillTree.Name = skillTreeName
skillTree.Description = "Force Pulse"
skillTree.Image = "kybercore/pulse.png"
KyberCore:AddSkillTree(skillTree)

////////////////////
// Skill Registry
////////////////////

local skill = {}
skill.Name = "Force Pulse"
skill.Description = "Unleash a destructive stream of force energy across the ground harming those that come into contact with it."
skill.Image = "kybercore/pulse.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "pulse")
end
KyberCore:AddSkill(skill)

///////////////////////////
// Skill Tree Config
///////////////////////////

local skill = {}
skill.Name = "Force Pulse"
skill.x = 0.399
skill.y = 0.5
skill.Cost = 1
skill.Requirements = {
}
KyberCore:AddSkillToTree(skillTreeName, skill)

if KyberCore.Config.Developer then
    KyberCore:ReloadSkills()
end
