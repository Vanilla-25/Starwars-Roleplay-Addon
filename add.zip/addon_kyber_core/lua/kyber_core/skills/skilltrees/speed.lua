//////////////////////
// Skill Tree Registry
//////////////////////
local skillTreeName = "Force Speed"

local skillTree = {}
skillTree.Name = skillTreeName
skillTree.Description = "Force Speed"
skillTree.Image = "entities/item_force_speed.png"
KyberCore:AddSkillTree(skillTree)

////////////////////
// Skill Registry
////////////////////

local skill = {}
skill.Name = "Force Speed"
skill.Description = "Use the force to enhance yourself to sprint at a faster rate than your peers for a short period of time. (+150 Speed)"
skill.Image = "entities/item_force_speed.png"
skill.Func = function(ply)
    KyberCore:AddKnownPower(ply, "speed")
end
KyberCore:AddSkill(skill)

///////////////////////////
// Skill Tree Config
///////////////////////////

local skill = {}
skill.Name = "Force Speed"
skill.x = 0.399
skill.y = 0.5
skill.Cost = 1
skill.Requirements = {
}
KyberCore:AddSkillToTree(skillTreeName, skill)

if KyberCore.Config.Developer then
    KyberCore:ReloadSkills()
end