KyberCore = KyberCore or {}

net.Receive("KyberCore.SyncWhitelists", function(len)
    local compressedWhitelists = net.ReadData(len)
    local whitelists = util.Decompress(compressedWhitelists)
    if not whitelists then return end

    whitelists = util.JSONToTable(whitelists)
    if not whitelists then return end

    LocalPlayer().KyberCore_Whitelists = whitelists
    hook.Run("KyberCore.SyncWhitelists", LocalPlayer(), whitelists)
end)

net.Receive("KyberCore.AddWhitelist", function(len)
    local tree = net.ReadString()
    if not tree or tree == "" then return end
    if not KyberCore:IsValidSkillTree(tree) then MsgC(Color(255, 0, 0), "[Kyber Core] Tried to whitelist to a non-existent skill tree: " .. tree .. "\n") return end
    if not LocalPlayer().KyberCore_Whitelists then LocalPlayer().KyberCore_Whitelists = {} end
    LocalPlayer().KyberCore_Whitelists[tree] = true

    if KyberCore.Config.Developer then
        MsgC(Color(183, 0, 255), "[Kyber Core] Added whitelist to skill tree: " .. tree .. "\n")
    end

    hook.Run("KyberCore.AddWhitelist", LocalPlayer(), tree)
end)

net.Receive("KyberCore.RemoveWhitelist", function(len)
    local tree = net.ReadString()
    if not tree or tree == "" then return end
    if not KyberCore:IsValidSkillTree(tree) then MsgC(Color(255, 0, 0), "[Kyber Core] Tried to remove whitelist from a non-existent skill tree: " .. tree .. "\n") return end
    if not LocalPlayer().KyberCore_Whitelists then LocalPlayer().KyberCore_Whitelists = {} end
    LocalPlayer().KyberCore_Whitelists[tree] = nil
    if KyberCore.Config.Developer then
        MsgC(Color(183, 0, 255), "[Kyber Core] Removed whitelist from skill tree: " .. tree .. "\n")
    end
    
    hook.Run("KyberCore.RemoveWhitelist", LocalPlayer(), tree)
end)