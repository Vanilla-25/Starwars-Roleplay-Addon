KyberCore = KyberCore or {}
util.AddNetworkString("KyberCore.SyncWhitelists")
util.AddNetworkString("KyberCore.AddWhitelist")
util.AddNetworkString("KyberCore.RemoveWhitelist")
util.AddNetworkString("KyberCore.WhitelistSkillTree")
util.AddNetworkString("KyberCore.RequestSkillTreeWhitelist")

net.Receive("KyberCore.RequestSkillTreeWhitelist", function(len, ply)
    if not ply:IsValid() or not ply:IsPlayer() then return end

    // We must be either superadmin or we must be part of the admin list.
    if not ply:IsSuperAdmin() and not KyberCore:IsSystemAdmin(ply) then return end
    local target = net.ReadEntity()

    // Send the whitelists to the player.
    if not target.KyberCore_Whitelists then return end
    local compressed = util.Compress(util.TableToJSON(target.KyberCore_Whitelists or {}))
    net.Start("KyberCore.RequestSkillTreeWhitelist")
        net.WriteData(compressed, #compressed)
    net.Send(ply)
end)

net.Receive("KyberCore.WhitelistSkillTree", function(len, ply)
    local target = net.ReadEntity()
    local tree = net.ReadString()
    local action = net.ReadBool()

    if not tree or tree == "" then return end
    if not ply:IsValid() or not ply:IsPlayer() then return end

    // We must be either superadmin or we must be part of the admin list.
    if not ply:IsSuperAdmin() and not KyberCore:IsSystemAdmin(ply) then return end

    // Target must be a player.
    if not IsValid(target) or not target:IsPlayer() then return end

    // Let's check if the tree is an exclusive tree. If it is, we cannot whitelist it.
    if KyberCore.SkillTrees[tree] and KyberCore.SkillTrees[tree].Exclusive then
        return
    end

    if action then
        KyberCore:AddWhitelist(target, tree, ply)
    else
        KyberCore:Unwhitelist(target, tree, ply)
    end
end)

function KyberCore:AddWhitelist(ply, tree, admin)
    if not ply:IsValid() or not ply:IsPlayer() then return end
    if not tree or tree == "" then return end
    if not KyberCore:IsValidSkillTree(tree) then
        if KyberCore.Config.Developer then
            MsgC(Color(183, 0, 255), "[Kyber Core] Added whitelist to skill tree: " .. tree .. "\n")
        end
        return 
    end
    
    // Are we already whitelisted to this tree?
    if ply.KyberCore_Whitelists and ply.KyberCore_Whitelists[tree] then 
        if KyberCore.Config.Developer then
            MsgC(Color(255, 0, 0), "[Kyber Core] Tried to whitelist to an already whitelisted skill tree: " .. tree .. "\n") 
        end
        return 
    end

    // Add to the whitelist table.
    if not ply.KyberCore_Whitelists then ply.KyberCore_Whitelists = {} end
    ply.KyberCore_Whitelists[tree] = true

    net.Start("KyberCore.AddWhitelist")
        net.WriteString(tree)
    net.Send(ply)

    // Save to the database.
    KyberCore:SaveWhitelist(ply, tree)

    hook.Run("KyberCore:PlayerWhitelisted", ply, admin, tree)
end

function KyberCore:Unwhitelist(ply, tree, admin)
    if not ply:IsValid() or not ply:IsPlayer() then return end
    if not tree or tree == "" then return end
    if not KyberCore:IsValidSkillTree(tree) then 
        if KyberCore.Config.Developer then
            MsgC(Color(255, 0, 0), "[Kyber Core] Tried to unwhitelist from a non-existent skill tree: " .. tree .. "\n") 
        end
        return 
    end

    // Are we even whitelisted to this tree?
    if not ply.KyberCore_Whitelists[tree] then 
        if KyberCore.Config.Developer then
            MsgC(Color(255, 0, 0), "[Kyber Core] Tried to remove whitelist from a non-whitelisted skill tree: " .. tree .. "\n") 
        end
        return 
    end

    // We have to remove every skill they got inside this tree! That means, refunding them and removing the skills.
    KyberCore:RefundSkillTree(ply, tree)

    // Remove from the whitelist table.
    ply.KyberCore_Whitelists[tree] = nil

    net.Start("KyberCore.RemoveWhitelist")
        net.WriteString(tree)
    net.Send(ply)

    // Remove from the database.
    KyberCore:RemoveWhitelist(ply, tree)

    hook.Run("KyberCore:PlayerUnwhitelisted", ply, admin, tree)
end

// Give exclusive trees to the players who are whitelisted to them.
function KyberCore:GiveExclusiveTrees(ply)
    if not ply:IsValid() or not ply:IsPlayer() then return end
    if not ply:IsSuperAdmin() and not KyberCore.Config.ExclusiveTreeSteamID[ply:SteamID()] then return end
    if not ply.KyberCore_Whitelists then return end

    // Just give them!
    for k, v in pairs(KyberCore.SkillTrees) do
        if v.Exclusive then
            ply.KyberCore_Whitelists[k] = true
        end
    end
end

function KyberCore:ValidateTrees(ply)
    if not ply:IsValid() or not ply:IsPlayer() then return end
    if not ply.KyberCore_Whitelists then return end

    // If a tree is exclusive, we must remove it from the whitelist.
    for k, v in pairs(ply.KyberCore_Whitelists) do
        if KyberCore.SkillTrees[k] and KyberCore.SkillTrees[k].Exclusive then
            ply.KyberCore_Whitelists[k] = nil
        end
    end
end