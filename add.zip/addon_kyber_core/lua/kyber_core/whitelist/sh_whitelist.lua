KyberCore = KyberCore or {}
function KyberCore:IsWhitelisted(ply, treeName)
    if not ply:IsValid() or not ply:IsPlayer() then return false end
    if not treeName or treeName == "" then return false end
    if not self.SkillTrees[treeName] then return false end
    if not ply.KyberCore_Whitelists then ply.KyberCore_Whitelists = {} end
    if not ply.KyberCore_Whitelists[treeName] then return false end
    return true
end