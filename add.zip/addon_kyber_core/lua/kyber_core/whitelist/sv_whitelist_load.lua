KyberCore = KyberCore or {}
MsgC(Color(183, 0, 255), "[Kyber Core] Loading Whitelists...\n")

// MYSQL:
function KyberCore:LoadWhitelistsMySQL(ply)
    ply.KyberCore_Whitelists = {}
    // Grab from the database.
    local steamID = ply:SteamID64()
    local query = "SELECT * FROM kybercore_whitelist WHERE unique_id = '" .. steamID .. "'"
    KyberCore.DB.Query(query, function(result)
        if result and #result > 0 then
            for _, trees in ipairs(result) do
                // If the tree doesn't exist, then oop! Let's complain about it.
                if not KyberCore.SkillTrees[trees.tree] then
                    if KyberCore.Config.Developer then
                        MsgC(Color(255, 0, 0), "[Kyber Core] Tried to load a non-existent whitelist tree: " .. trees.tree .. "\n") 
                    end
                    // We should remove this instead.
                    KyberCore:RemoveWhitelist(ply, trees.tree)
                    continue
                end
                
                ply.KyberCore_Whitelists[trees.tree] = true
            end

            // Compress the whitelist table.
            local whitelist = util.Compress(util.TableToJSON(ply.KyberCore_Whitelists))
            net.Start("KyberCore.SyncWhitelists")
                net.WriteData(whitelist, #whitelist)
            net.Send(ply)
        else
            ply.KyberCore_Whitelists = {}
            local whitelist = util.Compress(util.TableToJSON(ply.KyberCore_Whitelists))
            net.Start("KyberCore.SyncWhitelists")
                net.WriteData(whitelist, #whitelist)
            net.Send(ply)
        end
    end)

    KyberCore:ValidateTrees(ply)
    KyberCore:GiveExclusiveTrees(ply)
end

function KyberCore:SaveWhitelistsMySQL(ply, tree)
    MsgC(Color(183, 0, 255), "[Kyber Core] Saving whitelist tree: " .. tree .. "\n")
    // Save to the database.
    tree = sql.SQLStr(tree, true)

    local steamID = ply:SteamID64()
    local query = "INSERT INTO kybercore_whitelist (unique_id, tree) VALUES ('" .. steamID .. "', '" .. tree .. "')"
    KyberCore.DB.Query(query)
end

function KyberCore:RemoveWhitelistsMySQL(ply, tree)
    MsgC(Color(255, 0, 0), "[Kyber Core] Removing whitelist tree: " .. tree .. "\n")
    // Remove from the database.
    tree = sql.SQLStr(tree, true)

    local steamID = ply:SteamID64()
    local query = "DELETE FROM kybercore_whitelist WHERE unique_id = '" .. steamID .. "' AND tree = '" .. tree .. "'"
    KyberCore.DB.Query(query)
end

// SQLITE:
function KyberCore:LoadWhitelistsLocal(ply)
    ply.KyberCore_Whitelists = {}
    // Grab from the database.
    local steamID = ply:SteamID64()
    local query = "SELECT * FROM kybercore_whitelist WHERE unique_id = '" .. steamID .. "'"
    local result = sql.Query(query)
    if result and #result > 0 then
        for _, trees in ipairs(result) do
            if KyberCore.Config.Developer then
                MsgC(Color(183, 0, 255), "[Kyber Core] Loading whitelist tree: " .. trees.tree .. "\n")
            end
            // If the tree doesn't exist, then oop! Let's complain about it.
            if not KyberCore.SkillTrees[trees.tree] then
                if KyberCore.Config.Developer then
                    MsgC(Color(255, 0, 0), "[Kyber Core] Tried to load a non-existent whitelist tree: " .. trees.tree .. "\n") 
                end
                // We should remove this instead.
                KyberCore:RemoveWhitelist(ply, trees.tree)
                continue
            end
            ply.KyberCore_Whitelists[trees.tree] = true
        end

        // Compress the whitelist table.
        local whitelist = util.Compress(util.TableToJSON(ply.KyberCore_Whitelists))
        net.Start("KyberCore.SyncWhitelists")
            net.WriteData(whitelist, #whitelist)
        net.Send(ply)
    else
        ply.KyberCore_Whitelists = {}
        local whitelist = util.Compress(util.TableToJSON(ply.KyberCore_Whitelists))
        net.Start("KyberCore.SyncWhitelists")
            net.WriteData(whitelist, #whitelist)
        net.Send(ply)
    end

    KyberCore:ValidateTrees(ply)
    KyberCore:GiveExclusiveTrees(ply)
end

function KyberCore:SaveWhitelistsLocal(ply, tree)
    if KyberCore.Config.Developer then
        MsgC(Color(183, 0, 255), "[Kyber Core] Saving whitelist tree: " .. tree .. "\n")
    end
    // Save to the database.
    tree = sql.SQLStr(tree, true)

    local steamID = ply:SteamID64()
    local query = "INSERT INTO kybercore_whitelist (unique_id, tree) VALUES ('" .. steamID .. "', '" .. tree .. "')"
    sql.Query(query)
end

function KyberCore:RemoveWhitelistsLocal(ply, tree)
    if KyberCore.Config.Developer then
        MsgC(Color(255, 0, 0), "[Kyber Core] Removing whitelist tree: " .. tree .. "\n")
    end
    // Remove from the database.
    tree = sql.SQLStr(tree, true)

    local steamID = ply:SteamID64()
    local query = "DELETE FROM kybercore_whitelist WHERE unique_id = '" .. steamID .. "' AND tree = '" .. tree .. "'"
    sql.Query(query)
end

// Doers
function KyberCore:SaveWhitelist(ply, tree)
    if KyberCore.Config.SaveLocal then
        self:SaveWhitelistsLocal(ply, tree)
    else
        self:SaveWhitelistsMySQL(ply, tree)
    end
end

function KyberCore:RemoveWhitelist(ply, tree)
    if KyberCore.Config.SaveLocal then
        self:RemoveWhitelistsLocal(ply, tree)
    else
        self:RemoveWhitelistsMySQL(ply, tree)
    end
end

function KyberCore:LoadWhitelists(ply)
    if KyberCore.Config.SaveLocal then
        self:LoadWhitelistsLocal(ply)
    else
        self:LoadWhitelistsMySQL(ply)
    end
end

hook.Add("KyberCore:ClientFullyLoaded", "KyberCore:LoadPlayerWhitelists", function(ply)
    if ply:IsValid() and ply:IsPlayer() then
        KyberCore:LoadWhitelists(ply)
    end
end)