KyberCore = KyberCore or {}

function KyberCore:GetInventory(ply)
    if not ply:IsValid() or not ply:IsPlayer() then return end
    local inventory = ply:lscsGetInventory()
    return inventory
end

function KyberCore:GetEquipped(ply)
    if not ply:IsValid() or not ply:IsPlayer() then return end
    local equipped = ply:lscsGetEquipped()
    return equipped
end