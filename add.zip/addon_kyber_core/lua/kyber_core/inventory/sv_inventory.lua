KyberCore = KyberCore or {}

// Admin menu:
util.AddNetworkString("KyberCore.AdminRemoveItem")
net.Receive("KyberCore.AdminRemoveItem", function(len, ply)
    if not ply:IsSuperAdmin() and not KyberCore:IsSystemAdmin(ply) then return end
    local target = net.ReadEntity()
    local id = net.ReadInt(32)
    if not IsValid(target) or not target:IsPlayer() then return end
    target:lscsRemoveItem(id)
    
    hook.Run("KyberCore:AdminPlayerItemRemoved", target, ply, id)
end)

util.AddNetworkString("KyberCore.AdminGiveItem")
net.Receive("KyberCore.AdminGiveItem", function(len, ply)
    if not ply:IsSuperAdmin() and not KyberCore:IsSystemAdmin(ply) then return end
    local target = net.ReadEntity()
    local itemName = net.ReadString()
    if not IsValid(target) or not target:IsPlayer() then return end
    target:lscsAddInventory(itemName, nil, nil, false)

    hook.Run("KyberCore:AdminPlayerItemAdded", target, ply, itemName)
end)

util.AddNetworkString("KyberCore.AdminToggleItemEquip")
net.Receive("KyberCore.AdminToggleItemEquip", function(len, ply)
    if not ply:IsSuperAdmin() and not KyberCore:IsSystemAdmin(ply) then return end
    local target = net.ReadEntity()
    local id = net.ReadInt(32)
    local action = net.ReadBool()
    local hand = net.ReadBool()
    if not IsValid(target) or not target:IsPlayer() then return end

    // Get class from the item ID.
    local class = target:lscsGetInventory()[ id ]
    local Item = LSCS:ClassToItem(class)

    if action then
        if Item.type == "hilt" then
            target:lscsClearEquipped( "hilt", hand )
        end
    
        if Item.type == "crystal" then
            target:lscsClearEquipped( "crystal", hand )
        end

        target:lscsEquipItem(id, hand)
    else
        target:lscsEquipItem(id, nil)
    end

    hook.Run("KyberCore:AdminPlayerItemEquipped", target, ply, id, action, hand)
end)

util.AddNetworkString("KyberCore.AdminClearInventory")
net.Receive("KyberCore.AdminClearInventory", function(len, ply)
    if not ply:IsSuperAdmin() and not KyberCore:IsSystemAdmin(ply) then return end
    local target = net.ReadEntity()
    if not IsValid(target) or not target:IsPlayer() then return end
    target:lscsWipeInventory(false)

    hook.Run("KyberCore:AdminPlayerInventoryWiped", target, ply)
end)

util.AddNetworkString("KyberCore.AdminUnequipAll")
net.Receive("KyberCore.AdminUnequipAll", function(len, ply)
    if not ply:IsSuperAdmin() and not KyberCore:IsSystemAdmin(ply) then return end
    local target = net.ReadEntity()
    if not IsValid(target) or not target:IsPlayer() then return end
    target:lscsClearEquipped("hilt")
    target:lscsClearEquipped("crystal")

    hook.Run("KyberCore:AdminPlayerInventoryUnequipAll", target, ply)
end)

util.AddNetworkString("KyberCore.RequestInventory")
util.AddNetworkString("KyberCore.SendInventory")
net.Receive("KyberCore.RequestInventory", function(len, ply)
    if not IsValid(ply) or not ply:IsPlayer() then return end
    local target = net.ReadEntity()
    if not IsValid(target) or not target:IsPlayer() then return end
    if not target:lscsGetInventory() then return end

    local inventory = target:lscsGetInventory()
    local equipped = target:lscsGetEquipped()
    local compressed = util.Compress(util.TableToJSON(inventory))
    local equippedCompressed = util.Compress(util.TableToJSON(equipped))
    net.Start("KyberCore.SendInventory")
        net.WriteUInt(#compressed, 32)
        net.WriteData(compressed, #compressed)
        net.WriteUInt(#equippedCompressed, 32)
        net.WriteData(equippedCompressed, #equippedCompressed)
    net.Send(ply)
end)

hook.Add("LSCS:PostPlayerInventory", "KyberCore:AddedInventory", function(ply, item, index, loading)
    // If we're loading, then we shouldn't save.
    if loading then return end
    KyberCore:SaveInventory(ply, item, index)
end)

hook.Add("LSCS:OnPlayerDroppedItem", "KyberCore:RemovedInventory", function(ply, item, index)
    KyberCore:RemoveInventory(ply, index)
end)

hook.Add("KyberCore:OnPlayerInventoryRemove", "KyberCore:RemovedInventory", function(ply, item, index)
    KyberCore:RemoveInventory(ply, index)
end)

hook.Add("LSCS:OnPlayerEquippedItem", "KyberCore:EquippedInventory", function(ply, item, hand, index)
    if not item or not item.class then return end
    local itemName = item.class
    KyberCore:EquipItem(ply, itemName, hand, index)
end)

hook.Add("LSCS:OnPlayerUnEquippedItem", "KyberCore:UnequippedInventory", function(ply, item, index)
    local itemName = item.class
    KyberCore:UnequipItem(ply, itemName, index)
end)

hook.Add("KyberCore:OnPlayerInventoryWipe", "KyberCore:WipeInventory", function(ply)
    KyberCore:WipeInventory(ply)
end)