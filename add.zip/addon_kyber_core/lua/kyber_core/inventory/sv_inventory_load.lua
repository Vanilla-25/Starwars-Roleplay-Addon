KyberCore = KyberCore or {}

util.AddNetworkString("KyberCore.InventoryRefresh")

function KyberCore:LoadInventoryMySQL(ply)
    local steamID = ply:SteamID64()
    local query = "SELECT * FROM kybercore_inventory WHERE unique_id = '" .. steamID .. "'"
    local result = KyberCore.DB.Query(query, function(result)
        if result and #result > 0 then
            ply:lscsWipeInventory(false, true)
            for _, data in ipairs(result) do
                local slot = data.slot
                local item = data.item
                local hand = false
                local equipped = false
                data.equipped = tonumber(data.equipped)
                data.hand = tonumber(data.hand)

                if data.hand == 1 then
                    hand = true
                end

                if data.equipped == 1 then
                    equipped = true
                end

                if not equipped then
                    hand = nil
                end

                ply:lscsAddInventory(item, hand, slot, true)
            end
        else
            ply:lscsWipeInventory(false, true)
        end
    end)
end

function KyberCore:RemoveInventoryMySQL(ply, slot)
    local steamID = ply:SteamID64()
    local query = "DELETE FROM kybercore_inventory WHERE unique_id = '" .. steamID .. "' AND slot = '" .. slot .. "'"
    KyberCore.DB.Query(query)
end

function KyberCore:SaveInventoryMySQL(ply, item, slot)
    local steamID = ply:SteamID64()
    local query = "INSERT INTO kybercore_inventory (unique_id, slot, item, equipped, hand) VALUES ('" .. steamID .. "', '" .. slot .. "', '" .. item .. "', 0, 0) ON DUPLICATE KEY UPDATE item = '" .. item .. "'"
    KyberCore.DB.Query(query)
end

function KyberCore:EquipInventoryMySQL(ply, item, hand, slot)
    local steamID = ply:SteamID64()
    local query = "INSERT INTO kybercore_inventory (unique_id, slot, item, equipped, hand) VALUES ('" .. steamID .. "', '" .. slot .. "', '" .. item .. "', 1, " .. (hand and 1 or 0) .. ") ON DUPLICATE KEY UPDATE equipped = 1, hand = " .. (hand and 1 or 0)
    KyberCore.DB.Query(query)
end

function KyberCore:UnequipInventoryMySQL(ply, item, slot)
    local steamID = ply:SteamID64()
    local query = "INSERT INTO kybercore_inventory (unique_id, slot, item, equipped) VALUES ('" .. steamID .. "', '" .. slot .. "', '" .. item .. "', 0) ON DUPLICATE KEY UPDATE equipped = 0"
    KyberCore.DB.Query(query)
end

function KyberCore:WipeInventoryMySQL(ply)
    local steamID = ply:SteamID64()
    local query = "DELETE FROM kybercore_inventory WHERE unique_id = '" .. steamID .. "'"
    KyberCore.DB.Query(query)
end

// SQLITE:
function KyberCore:LoadInventoryLocal(ply)
    local steamID = ply:SteamID64()
    local query = "SELECT * FROM kybercore_inventory WHERE unique_id = '" .. steamID .. "'"
    local result = sql.Query(query)
    if result and #result > 0 then
        ply:lscsWipeInventory(false, true)
        for _, data in ipairs(result) do
            local slot = data.slot
            local item = data.item
            local hand = false
            local equipped = false
            data.equipped = tonumber(data.equipped)
            data.hand = tonumber(data.hand)

            if data.hand == 1 then
                hand = true
            end

            if data.equipped == 1 then
                equipped = true
            end

            if not equipped then
                hand = nil
            end

            ply:lscsAddInventory(item, hand, slot, true)
        end
    else
        ply:lscsWipeInventory(false, true)
    end
end

function KyberCore:RemoveInventoryLocal(ply, slot)
    local steamID = ply:SteamID64()
    local query = "DELETE FROM kybercore_inventory WHERE unique_id = '" .. steamID .. "' AND slot = '" .. slot .. "'"
    sql.Query(query)
end

function KyberCore:SaveInventoryLocal(ply, item, slot)
    local steamID = ply:SteamID64()
    local query = "INSERT OR REPLACE INTO kybercore_inventory (unique_id, slot, item, equipped, hand) VALUES ('" .. steamID .. "', '" .. slot .. "', '" .. item .. "', 0, 0)"
    sql.Query(query)
end

function KyberCore:EquipInventoryLocal(ply, item, hand, slot)
    local steamID = ply:SteamID64()
    local query = "INSERT OR REPLACE INTO kybercore_inventory (unique_id, slot, item, equipped, hand) VALUES ('" .. steamID .. "', '" .. slot .. "', '" .. item .. "', 1, " .. (hand and 1 or 0) .. ")"
    sql.Query(query)
end

function KyberCore:UnequipInventoryLocal(ply, item, slot)
    local steamID = ply:SteamID64()
    local query = "INSERT OR REPLACE INTO kybercore_inventory (unique_id, slot, item, equipped) VALUES ('" .. steamID .. "', '" .. slot .. "', '" .. item .. "', 0)"
    sql.Query(query)
end

function KyberCore:WipeInventoryLocal(ply)
    local steamID = ply:SteamID64()
    local query = "DELETE FROM kybercore_inventory WHERE unique_id = '" .. steamID .. "'"
    sql.Query(query)
end

function KyberCore:LoadInventory(ply)
    if not ply:IsValid() or not ply:IsPlayer() then return end
    if KyberCore.Config.SaveLocal then
        self:LoadInventoryLocal(ply)
    else
        self:LoadInventoryMySQL(ply)
    end
end

function KyberCore:SaveInventory(ply, item, slot)
    if not ply:IsValid() or not ply:IsPlayer() then return end
    if KyberCore.Config.SaveLocal then
        self:SaveInventoryLocal(ply, item, slot)
    else
        self:SaveInventoryMySQL(ply, item, slot)
    end
end

function KyberCore:RemoveInventory(ply, slot)
    if not ply:IsValid() or not ply:IsPlayer() then return end
    if KyberCore.Config.SaveLocal then
        self:RemoveInventoryLocal(ply, slot)
    else
        self:RemoveInventoryMySQL(ply, slot)
    end
end

function KyberCore:EquipItem(ply, item, hand, index)
    if not ply:IsValid() or not ply:IsPlayer() then return end
    if KyberCore.Config.SaveLocal then
        self:EquipInventoryLocal(ply, item, hand, index)
    else
        self:EquipInventoryMySQL(ply, item, hand, index)
    end
end

function KyberCore:UnequipItem(ply, item, index)
    if not ply:IsValid() or not ply:IsPlayer() then return end
    if KyberCore.Config.SaveLocal then
        self:UnequipInventoryLocal(ply, item, index)
    else
        self:UnequipInventoryMySQL(ply, item, index)
    end
end

function KyberCore:WipeInventory(ply)
    if not ply:IsValid() or not ply:IsPlayer() then return end
    if KyberCore.Config.SaveLocal then
        self:WipeInventoryLocal(ply)
    else
        self:WipeInventoryMySQL(ply)
    end
end

hook.Add("KyberCore:ClientFullyLoaded", "KyberCore:LoadPlayerInventory", function(ply)
    if ply:IsValid() and ply:IsPlayer() then
        KyberCore:LoadInventory(ply)
    end
end)

net.Receive("KyberCore.InventoryRefresh", function(len, ply)
    if not ply:IsValid() or not ply:IsPlayer() then return end

    // Cooldown code from Luna's LSCS! Thanks Luna!
    ply.KyberCoreRefreshInvNext = ply.KyberCoreRefreshInvNext or 0

    local Time = CurTime()

    if ply.KyberCoreRefreshInvNext > Time then
        ply.KyberCoreRefreshInvNext = ply.KyberCoreRefreshInvNext + 1
        ply:ChatPrint("[Kyber Core] - Please wait ".. math.Round(ply.KyberCoreRefreshInvNext - Time, 0) .." seconds before refreshing your Inventory again")
        return
    end

    ply.KyberCoreRefreshInvNext = Time + 10

    KyberCore:LoadInventory(ply)
end)