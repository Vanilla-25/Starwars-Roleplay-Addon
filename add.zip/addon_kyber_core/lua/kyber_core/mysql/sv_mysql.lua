KyberCore = KyberCore or {}
KyberCore.DB = {}
MsgC(Color(183, 0, 255), "[Kyber Core] Loading databases...\n")
require ("mysqloo")

function KyberCore:BeginMySQLConnection()
    if not (table.IsEmpty(KyberCore.DB)) then
        print("[Kyber Core] Reloading database connection...")
        KyberCore.DB:disconnect(true)
    end
    
    KyberCore.DB = mysqloo.connect(
        KyberCore.Config.MySQL_DATABASE_HOST, 
        KyberCore.Config.MySQL_DATABASE_USERNAME,
        KyberCore.Config.MySQL_DATABASE_PASSWORD,
        KyberCore.Config.MySQL_DATABASE_NAME,
        KyberCore.Config.MySQL_DATABASE_PORT
    )

    KyberCore.DB.onConnected = function() 
		print("[Kyber Core] Connected to MySQL Database!")
        KyberCore.DB:Init()
	end
    KyberCore.DB.onConnectionFailed = function(db, err) 
    	print("[Kyber Core] Failure to connect to MySQL Database: " .. err)
    end
    KyberCore.DB:connect()
end

function KyberCore.DB.Query(sql, callback)
    local query = KyberCore.DB:query(sql)

    -- print("[Kyber Core] - SQL Query - ", sql)

    function query:onSuccess(data)
        if (callback) then callback(data) end
    end
    function query:onError(err)
        print("[Kyber Core] - SQL Error - ERROR IN QUERY! Error:", err, " || sql: ", sql )
        print(sql)
        print(query:error())

    end
    query:start()
end

function KyberCore.DB.Escape(sqlstring)
    return KyberCore.DB:escape(sqlstring)
end

function KyberCore.DB:Init()
    local experience_table = [[
        CREATE TABLE IF NOT EXISTS kybercore_experience (
            unique_id VARCHAR(255) NOT NULL,
            experience INTEGER NOT NULL,
            level INTEGER NOT NULL,
            points INTEGER NOT NULL,
            PRIMARY KEY(unique_id)
        );
    ]]

    local skills_table = [[
        CREATE TABLE IF NOT EXISTS kybercore_skills (
            unique_id VARCHAR(255) NOT NULL,
            skills VARCHAR(255) NOT NULL,
            PRIMARY KEY(unique_id, skills)
        );
    ]]

    local inventory_table = [[
        CREATE TABLE IF NOT EXISTS kybercore_inventory (
            unique_id VARCHAR(255) NOT NULL,
            slot INTEGER NOT NULL,
            item VARCHAR(255) NOT NULL,
            equipped BOOL NOT NULL DEFAULT 0,
            hand BOOL NOT NULL DEFAULT 0,
            PRIMARY KEY(unique_id, slot)
        );
    ]]

    local whitelist_table = [[
        CREATE TABLE IF NOT EXISTS kybercore_whitelist (
            unique_id VARCHAR(255) NOT NULL,
            tree VARCHAR(255) NOT NULL,
            PRIMARY KEY(unique_id, tree)
        );
    ]]

    local admin_table = [[
        CREATE TABLE IF NOT EXISTS kybercore_admins (
            unique_id VARCHAR(255) NOT NULL,
            PRIMARY KEY(unique_id)
        );
    ]]

    local kybercore_duels = [[
        CREATE TABLE IF NOT EXISTS kybercore_duels (
            unique_id VARCHAR(255) NOT NULL,
            rating INTEGER NOT NULL,
            wins INTEGER NOT NULL,
            losses INTEGER NOT NULL,
            PRIMARY KEY(unique_id)
        );
    ]]

    KyberCore.DB.Query(experience_table)
    KyberCore.DB.Query(skills_table)
    KyberCore.DB.Query(inventory_table)
    KyberCore.DB.Query(whitelist_table)
    KyberCore.DB.Query(admin_table)
    KyberCore.DB.Query(kybercore_duels)
end

function KyberCore:BeginSQLiteConnection()
    local experience_table = [[
        CREATE TABLE IF NOT EXISTS kybercore_experience (
            unique_id TEXT NOT NULL,
            experience INTEGER NOT NULL,
            level INTEGER NOT NULL,
            points INTEGER NOT NULL,
            PRIMARY KEY(unique_id)
        );
    ]]

    local skills_table = [[
        CREATE TABLE IF NOT EXISTS kybercore_skills (
            unique_id TEXT NOT NULL,
            skills TEXT NOT NULL,
            PRIMARY KEY(unique_id, skills)
        );
    ]]

    local inventory_table = [[
        CREATE TABLE IF NOT EXISTS kybercore_inventory (
            unique_id TEXT NOT NULL,
            slot INTEGER NOT NULL,
            item TEXT NOT NULL,
            equipped BOOL NOT NULL DEFAULT 0,
            hand BOOL NOT NULL DEFAULT 0,
            PRIMARY KEY(unique_id, slot)
        );
    ]]

    local whitelist_table = [[
        CREATE TABLE IF NOT EXISTS kybercore_whitelist (
            unique_id TEXT NOT NULL,
            tree TEXT NOT NULL,
            PRIMARY KEY(unique_id, tree)
        );
    ]]

    local admin_table = [[
        CREATE TABLE IF NOT EXISTS kybercore_admins (
            unique_id TEXT NOT NULL,
            PRIMARY KEY(unique_id)
        );
    ]]

    local kybercore_duels = [[
        CREATE TABLE IF NOT EXISTS kybercore_duels (
            unique_id TEXT NOT NULL,
            rating INTEGER NOT NULL,
            wins INTEGER NOT NULL,
            losses INTEGER NOT NULL,
            PRIMARY KEY(unique_id)
        );
    ]]

    sql.Query(experience_table)
    sql.Query(skills_table)
    sql.Query(inventory_table)
    sql.Query(whitelist_table)
    sql.Query(admin_table)
    sql.Query(kybercore_duels)
end

function KyberCore:SQLInit()
    if KyberCore.Config.SaveLocal then
        KyberCore:BeginSQLiteConnection()
    else
        KyberCore:BeginMySQLConnection()
    end
end

KyberCore:SQLInit()

timer.Create("KyberCore:DatabaseKeepAlive", 300, 0, function()
    if KyberCore.Config.SaveLocal then return end

    local experience_table = [[
        CREATE TABLE IF NOT EXISTS kybercore_experience (
            unique_id VARCHAR(255) NOT NULL,
            experience INT NOT NULL,
            level INT NOT NULL,
            points INT NOT NULL,
            PRIMARY KEY(unique_id)
        );
    ]]

    KyberCore.DB.Query(experience_table)
end)