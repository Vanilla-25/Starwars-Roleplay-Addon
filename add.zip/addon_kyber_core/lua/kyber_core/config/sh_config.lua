KyberCore = KyberCore or {}
KyberCore.Config = KyberCore.Config or {}

////////////////////////////
// KyberCore Config
////////////////////////////
// If true, save all data to server's local sv.db file instead of mysql.
// If false, save all data to the setup mysql database. Please configure in sv_mysql_config.lua first.
// Please don't turn on this option if you haven't configured the mysql database yet. It won't save anything.
// DEFAULT: true
KyberCore.Config.SaveLocal = true

// Development mode!
// If true, we'll show way more information in the console and in client's console. I recommend you turn this on for development builds.
// If false, this will turn off lua autorefresh on skill trees!
// This is pretty safe to turn on, it will just spam the console a little bit more. Usually better to turn this off when you're done.
// DEFAULT: false 
KyberCore.Config.Developer = false

///////////////////////////////
// XP Config
///////////////////////////////
// Points awarded per level
// DEFAULT: 1
KyberCore.Config.PointsPerLevel = 1

// Fixed XP requirement for leveling up. If you want to use a formula, set this to false.
// DEFAULT: true
KyberCore.Config.FixedLeveling = true

// Required XP for level one, this is used for fixed leveling.
// DEFAULT: 100
KyberCore.Config.FixedXP = 100

// XP variable for leveling. Use this for the XP formula.
// DEFAULT: 100
KyberCore.Config.XPVariable = 100

// The XP formula for levels. By default, this is a set number, but you may change it to a formula if you want.
// DEFAULT: function( currentLevel ) return ( KyberCore.Config.XPVariable + (currentLevel * 50) ) end
KyberCore.Config.XPFormula = function( currentLevel )
    local req_xp = ( KyberCore.Config.XPVariable + (currentLevel * 50) )
    return req_xp
end

//////////////////////////////
// Combat Config
//////////////////////////////
// Base max blockpoints
// DEFAULT: 100
KyberCore.Config.BaseBlockpoints = 100

// Base blockpoint delay (in seconds)
// DEFAULT: 0.3
KyberCore.Config.BaseBlockpointDelay = 0.3

// Base blockpoint regen (per delay)
// DEFAULT: 3
KyberCore.Config.BaseBlockpointRegen = 3

// Drain blockpoints in the air
// DEFAULT: true
KyberCore.Config.DrainBlockpointsInAir = true

// Regenerate blockpoints while in the air
// DEFAULT: false
KyberCore.Config.RegenerateBlockpointsInAir = false

// Stop regenerating blockpoints while running
// DEFAULT: false
KyberCore.Config.RegenerateBPWhileRunning = false

// Use default LSCS blockpoints functionality. This will override all the other blockpoints settings above except for max blockpoints.
// DEFAULT: false
KyberCore.Config.UseDefaultLSCSBlockpoints = false

// Base max force
// DEFAULT: 100
KyberCore.Config.BaseMaxForce = 100

// Base force regen (per second)
// DEFAULT: 1.5
KyberCore.Config.BaseForceRegen = 1.5

// Base lightsaber damage
// DEFAULT: 200
KyberCore.Config.BaseSaberDamage = 200

//////////////////
// Funny Stuff
//////////////////
// Lock your skill tree to a specific steamid.
// This is used for exclusive skill trees. Skill trees marked with "exclusive" will not show up for whitelisting at all.
// Instead, it will be given when a player joins to superadmins or people with steamid in this table.
KyberCore.Config.ExclusiveTreeSteamID = {
    ["STEAM_0:0:89659362"] = true, // Stoneman
    ["STEAM_0:1:63020658"] = true, // Truce
}
