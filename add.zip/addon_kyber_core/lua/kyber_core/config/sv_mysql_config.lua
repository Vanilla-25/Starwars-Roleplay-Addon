// DO NOT SHARE!!!
KyberCore = KyberCore or {}
KyberCore.Config = KyberCore.Config or {}
KyberCore.Config.MySQL_DATABASE_HOST = ""
KyberCore.Config.MySQL_DATABASE_USERNAME = ""
KyberCore.Config.MySQL_DATABASE_PASSWORD = ""
KyberCore.Config.MySQL_DATABASE_NAME = ""
KyberCore.Config.MySQL_DATABASE_PORT = 3306