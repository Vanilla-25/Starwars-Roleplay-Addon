KyberCore = KyberCore or {}

util.AddNetworkString("KyberCore.SyncAdmins")

// MYSQL:
function KyberCore:SaveAdminMySQL(target)
    local steamid = sql.SQLStr(target, true)
    if KyberCore.Config.Developer then
        MsgC(Color(0, 255, 0), "[Kyber Core] Saving admin: " .. steamid .. "\n")
    end
    // Save to the database.
    steamid = KyberCore.DB.Escape(steamid)

    local query = "INSERT INTO kybercore_admins (unique_id) VALUES ('" .. steamid .. "')"
    KyberCore.DB.Query(query)
end

function KyberCore:RemoveAdminMySQL(target)
    local steamid = sql.SQLStr(target, true)
    if KyberCore.Config.Developer then
        MsgC(Color(255, 0, 0), "[Kyber Core] Removing admin: " .. steamid .. "\n")
    end
    // Remove from the database.
    steamid = KyberCore.DB.Escape(steamid)

    local query = "DELETE FROM kybercore_admins WHERE unique_id = '" .. steamid .. "'"
    KyberCore.DB.Query(query)
end

function KyberCore:LoadAdminMySQL()
    local query = "SELECT * FROM kybercore_admins"
    local result = KyberCore.DB.Query(query, function(result)
        local admins = {}
        KyberCore.Admins = {}

        if result and #result > 0 then
            for _, unique_id in ipairs(result) do
                local steamid = unique_id.unique_id
                // Ensure steamid here is a string.
                steamid = tostring(steamid)
                admins[steamid] = true
            end
        end

        KyberCore.Admins = admins
        
        net.Start("KyberCore.SyncAdmins")
            local compressed = util.Compress(util.TableToJSON(KyberCore.Admins))
            net.WriteData(compressed, #compressed)
        net.Broadcast()
    end)
end

//// SQLITE:
function KyberCore:SaveAdminLocal(target)
    local steamid = sql.SQLStr(target, true)
    if KyberCore.Config.Developer then
        MsgC(Color(0, 255, 0), "[Kyber Core] Saving admin: " .. steamid .. "\n")
    end
    // Save to the database.
    steamid = sql.SQLStr(steamid, true)

    local query = "INSERT INTO kybercore_admins (unique_id) VALUES ('" .. steamid .. "')"
    sql.Query(query)
end 

function KyberCore:RemoveAdminLocal(target)
    local steamid = sql.SQLStr(target, true)
    if KyberCore.Config.Developer then
        MsgC(Color(255, 0, 0), "[Kyber Core] Removing admin: " .. steamid .. "\n")
    end
    // Remove from the database.
    steamid = sql.SQLStr(steamid, true)

    local query = "DELETE FROM kybercore_admins WHERE unique_id = '" .. steamid .. "'"
    sql.Query(query)
end

function KyberCore:LoadAdminLocal()
    local query = "SELECT * FROM kybercore_admins"
    local result = sql.Query(query)

    local admins = {}

    if result and #result > 0 then
        for _, unique_id in ipairs(result) do
            local steamid = unique_id.unique_id
            // Ensure steamid here is a string.
            steamid = tostring(steamid)
            admins[steamid] = true
        end
    end

    KyberCore.Admins = admins

    // Sync to clients, if they are already connected somehow. Maybe just for when reloads happen.
    net.Start("KyberCore.SyncAdmins")
        local compressed = util.Compress(util.TableToJSON(KyberCore.Admins))
        net.WriteData(compressed, #compressed)
    net.Broadcast()
end

function KyberCore:LoadAdminPlayers(ply)
    // Send it back to the client!
    local compressed = util.Compress(util.TableToJSON(KyberCore.Admins))
    net.Start("KyberCore.SyncAdmins")
        net.WriteData(compressed, #compressed)
    net.Send(ply)
end

function KyberCore:SaveAdmin(target)
    if KyberCore.Config.SaveLocal then
        self:SaveAdminLocal(target)
    else
        self:SaveAdminMySQL(target)
    end
end

function KyberCore:RemoveAdmin(target)
    if KyberCore.Config.SaveLocal then
        self:RemoveAdminLocal(target)
    else
        self:RemoveAdminMySQL(target)
    end
end

function KyberCore:LoadAdmin()
    if KyberCore.Config.SaveLocal then
        self:LoadAdminLocal()
    else
        self:LoadAdminMySQL()
    end
end

KyberCore:LoadAdmin()

hook.Add("KyberCore:ClientFullyLoaded", "KyberCore:LoadPlayerAdmins", function(ply)
    if ply:IsValid() and ply:IsPlayer() then
        KyberCore:LoadAdminPlayers(ply)
    end
end)