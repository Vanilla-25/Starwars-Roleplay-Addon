KyberCore = KyberCore or {}
net.Receive("KyberCore.SyncAdmins", function(len, ply)
    local compressed = net.ReadData(len)
    local json = util.Decompress(compressed)
    local data = util.JSONToTable(json, nil, true)
    if KyberCore.Config.Developer then
        MsgC(Color(183, 0, 255), "[Kyber Core] Syncing admins...\n")
    end

    KyberCore.Admins = {}

    for steamid, _ in pairs(data) do
        if not KyberCore.Admins[steamid] then
            KyberCore.Admins[steamid] = true
        end
    end
end)