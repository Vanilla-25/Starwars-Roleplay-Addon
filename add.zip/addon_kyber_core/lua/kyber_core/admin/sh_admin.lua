KyberCore = KyberCore or {}
KyberCore.Admins = KyberCore.Admins or {}
function KyberCore:IsSystemAdmin(ply)
    if not IsValid(ply) or not ply:IsPlayer() then return false end
    if ply:IsSuperAdmin() then return true end
    if KyberCore.Admins[ply:SteamID64()] then return true end
    return false
end

function KyberCore:IsSystemAdminID(steamid)
    if not steamid or steamid == "" then return false end
    if not KyberCore.Admins[steamid] then return false end
    return true
end