KyberCore = KyberCore or {}
util.AddNetworkString("KyberCore.ToggleAdminAccess")

net.Receive("KyberCore.ToggleAdminAccess", function(len, ply)
    local target = net.ReadString()
    local action = net.ReadBool()

    if not target or target == "" then return end
    if not IsValid(ply) or not ply:IsPlayer() then return end
    
    if action then
        KyberCore:AddNewAdmin(ply, target)
    else
        KyberCore:RemoveExistingAdmin(ply, target)
    end
end)

function KyberCore:AddNewAdmin(ply, target)
    if not IsValid(ply) or not ply:IsPlayer() then return end
    if not target or target == "" then return end

    // We must either be superadmin or we must be part of the admin list already.
    if not ply:IsSuperAdmin() and not self:IsSystemAdmin(ply) then return end

    // Target must not be an admin already.
    if self:IsSystemAdminID(target) then
        return
    end

    // Great! Let's add the admin to the database.
    self:SaveAdmin(target)

    if KyberCore.Config.Developer then
        MsgC(Color(183, 0, 255), "[Kyber Core] Admin added: " .. target .. "\n")
    end

    // Set the target as an admin.
    self.Admins[target] = true

    hook.Run("KyberCore:AdminAdded", target, ply)

    // Let's sync!
    local compressed = util.Compress(util.TableToJSON(self.Admins))
    net.Start("KyberCore.SyncAdmins")
        net.WriteData(compressed, #compressed)
    net.Broadcast()
end

function KyberCore:RemoveExistingAdmin(ply, target)
    if not IsValid(ply) or not ply:IsPlayer() then return end
    if not target or target == "" then return end

    // We must either be superadmin or we must be part of the admin list already.
    if not ply:IsSuperAdmin() and not self:IsSystemAdmin(ply) then return end

    // Great! Let's remove the admin from the database.
    self:RemoveAdmin(target)

    // Remove the target as an admin.
    self.Admins[target] = nil

    hook.Run("KyberCore:AdminRemoved", target, ply)

    // Let's sync!
    local compressed = util.Compress(util.TableToJSON(self.Admins))
    net.Start("KyberCore.SyncAdmins")
        net.WriteData(compressed, #compressed)
    net.Broadcast()
end