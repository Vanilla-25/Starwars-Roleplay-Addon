--=====================================================================
/*		My Custom Holdtype
			Created by Master Truce( STEAM_0:1:63020658 )*/
            local DATA = {}
            DATA.Name = "Form7"
            DATA.HoldType = "wos-truce-form7"
            DATA.BaseHoldType = "melee2"
            DATA.Translations = {} 
            
            DATA.Translations[ ACT_MP_JUMP ] = {
                { Sequence = "balanced_jump", Weight = 1 },
            }
            
            DATA.Translations[ ACT_MP_RUN ] = {
                { Sequence = "wos_phalanx_b_run", Weight = 1 },
            }
            
            DATA.Translations[ ACT_MP_WALK ] = {
                { Sequence = "wos_phalanx_b_run", Weight = 1 },
            }
            
            DATA.Translations[ ACT_MP_STAND_IDLE ] = {
                { Sequence = "customcharacter_idle", Weight = 0.1 },
            }
           
            DATA.Translations[ ACT_MP_CROUCHWALK ] = {
                { Sequence = "cwalk_knife", Weight = 1 },
            }
            
            DATA.Translations[ ACT_MP_CROUCH_IDLE ] = {
                { Sequence = "cidle_knife", Weight = 1 },
            }
            
            wOS.AnimExtension:RegisterHoldtype( DATA )
            --=====================================================================