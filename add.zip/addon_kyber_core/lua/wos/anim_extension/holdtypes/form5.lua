--=====================================================================
/*		My Custom Holdtype
			Created by Master Truce( STEAM_0:1:63020658 )*/
            local DATA = {}
            DATA.Name = "Form5"
            DATA.HoldType = "wos-truce-form5"
            DATA.BaseHoldType = "melee2"
            DATA.Translations = {} 
            
            DATA.Translations[ ACT_MP_JUMP ] = {
                { Sequence = "balanced_jump", Weight = 1 },
            }
            
            DATA.Translations[ ACT_MP_RUN ] = {
                { Sequence = "wos_ryoku_r_run", Weight = 1 },
            }
            
            DATA.Translations[ ACT_MP_WALK ] = {
                { Sequence = "wos_ryoku_r_run", Weight = 1 },
            }
            
            DATA.Translations[ ACT_MP_STAND_IDLE ] = {
                { Sequence = "vanguard_h_idle", Weight = 0.1 },
            }
            
            wOS.AnimExtension:RegisterHoldtype( DATA )
            --=====================================================================