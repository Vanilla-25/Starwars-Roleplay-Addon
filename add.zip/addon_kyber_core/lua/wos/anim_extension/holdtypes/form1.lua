--=====================================================================
/*		My Custom Holdtype
			Created by Master Truce( STEAM_0:1:63020658 )*/
            local DATA = {}
            DATA.Name = "Form1"
            DATA.HoldType = "wos-truce-form1"
            DATA.BaseHoldType = "melee2"
            DATA.Translations = {} 
		
			DATA.Translations[ ACT_MP_STAND_IDLE ] = {
			{ Sequence = "wos_judge_h_idle", Weight = 1 },
			}

			DATA.Translations[ ACT_MP_SPRINT ] = {
			{ Sequence = "b_run", Weight = 1 },
			}

			DATA.Translations[ ACT_MP_RUN ] = {
			{ Sequence = "b_run", Weight = 1 },
			}	

			DATA.Translations[ ACT_MP_WALK ] = {
			{ Sequence = "b_run", Weight = 1 },
			}

            DATA.Translations[ ACT_MP_JUMP ] = {
                { Sequence = "balanced_jump", Weight = 1 },
            }
            

            wOS.AnimExtension:RegisterHoldtype( DATA )
            --=====================================================================