--=====================================================================
/*		My Custom Holdtype
			Created by Master Truce( STEAM_0:1:63020658 )*/
            local DATA = {}
            DATA.Name = "Formjk"
            DATA.HoldType = "wos-truce-formjk"
            DATA.BaseHoldType = "knife"
            DATA.Translations = {} 
            
            DATA.Translations[ ACT_MP_JUMP ] = {
                { Sequence = "balanced_jump", Weight = 1 },
            }
            
            DATA.Translations[ ACT_MP_RUN ] = {
                { Sequence = "dooka_run", Weight = 1 },
            }            
            
            DATA.Translations[ ACT_MP_WALK ] = {
                { Sequence = "dooka_walk", Weight = 1 },
            }            
            
            DATA.Translations[ ACT_MP_STAND_IDLE ] = {
                { Sequence = "r_idle", Weight = 1 },
            }            
            
            wOS.AnimExtension:RegisterHoldtype( DATA )
            --=====================================================================
