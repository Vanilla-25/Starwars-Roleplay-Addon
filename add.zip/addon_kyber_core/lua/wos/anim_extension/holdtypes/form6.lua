--=====================================================================
/*		My Custom Holdtype
			Created by Master Truce( STEAM_0:1:63020658 )*/
            local DATA = {}
            DATA.Name = "Form6"
            DATA.HoldType = "wos-truce-form6"
            DATA.BaseHoldType = "slam"
            DATA.Translations = {} 
            
            DATA.Translations[ ACT_MP_JUMP ] = {
                { Sequence = "balanced_jump", Weight = 1 },
            }
            
            DATA.Translations[ ACT_MP_RUN ] = {
                { Sequence = "wos_phalanx_b_run", Weight = 1 },
            }
            
            DATA.Translations[ ACT_MP_WALK ] = {
                { Sequence = "wos_phalanx_b_run", Weight = 1 },
            }
            
            DATA.Translations[ ACT_MP_STAND_IDLE ] = {
                { Sequence = "wos_phalanx_b_idle", Weight = 0.1 },
            }
            
            wOS.AnimExtension:RegisterHoldtype( DATA )
            --=====================================================================