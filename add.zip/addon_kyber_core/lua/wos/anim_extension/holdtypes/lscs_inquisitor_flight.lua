
local DATA = {}
DATA.Name = "[LSCS] Inquisitor Flight"
DATA.HoldType = "lscs_inquisitor_flight"
DATA.BaseHoldType = "grenade"
DATA.Translations = {} 
DATA.Translations[ ACT_MP_STAND_IDLE ] = "swimming_grenade"
DATA.Translations[ ACT_MP_WALK ] = "swimming_grenade"
DATA.Translations[ ACT_MP_RUN ] = "swimming_grenade"
DATA.Translations[ ACT_MP_JUMP ] = "swimming_grenade"
DATA.Translations[ ACT_MP_CROUCH_IDLE ] = "swimming_grenade"
DATA.Translations[ ACT_MP_CROUCHWALK ] = "swimming_grenade"
wOS.AnimExtension:RegisterHoldtype( DATA )
