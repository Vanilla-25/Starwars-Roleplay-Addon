concommand.Add("kybercore_credits", function(ply)
	if not ply:IsValid() or not ply:IsPlayer() then return end

	MsgC(Color(183, 0, 255), "[Kyber Core] CREDITS:\n")
	MsgC(Color(183, 0, 255), "[Kyber Core] Created by Stoneman & Truce\n")
	MsgC(Color(183, 0, 255), "[Kyber Core] Special thanks to:\n")
	MsgC(Color(183, 0, 255), "[Kyber Core] - Luna, for creating LSCS.\n")
    MsgC(Color(183, 0, 255), "[Kyber Core] - The australian community for their support.\n")
    MsgC(Color(183, 0, 255), "[Kyber Core] If you bought this addon, you are supporting us.\n")
    MsgC(Color(183, 0, 255), "[Kyber Core] Thank you for your support!\n")
    MsgC(Color(183, 0, 255), "[Kyber Core] If you got this addon for free, please consider buying it.\n")
    MsgC(Color(183, 0, 255), "[Kyber Core] It helps us a lot and we appreciate it.\n")
    MsgC(Color(183, 0, 255), "[Kyber Core] If you bought this addon from someone else other than Stoneman & Truce, please report them.\n")
end, nil, nil, FCVAR_UNREGISTERED)