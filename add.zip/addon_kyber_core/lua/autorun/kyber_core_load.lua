KyberCore = {}
KyberCore.Version = "1.0.1"

// Loading image, make ascii art
MsgC(Color(183, 0, 255), "==========================\n")
MsgC(Color(183, 0, 255), "   Kyber Core " .. KyberCore.Version .. "\n")
MsgC(Color(183, 0, 255), "   CREATED BY: Stoneman & Truce\n")
MsgC(Color(183, 0, 255), "==========================\n")
MsgC(Color(183, 0, 255), "[Kyber Core] INITIALIZING! Welcome to Kyber Core!\n")

function KyberCore:LoadDirectory(directory)
	local _, directories = file.Find(directory .. "/*", "LUA")

	for _, subdirectory in pairs(directories) do
		local relativePath = directory .. "/" .. subdirectory
		MsgC(Color(183, 0, 255), "[Kyber Core] Including directory: ", relativePath)
		KyberCore:LoadFolder(relativePath)
	end
end

function KyberCore:LoadFolder(directory)
	local files, _ = file.Find(directory .. "/*", "LUA")

	for _, fileName in pairs(files) do
		local relativePath = directory .. "/" .. fileName

		if string.StartWith(fileName, "sv_") then
			if SERVER then
				include(relativePath)
			end
		end

		if string.StartWith(fileName, "sh_") then
			AddCSLuaFile(relativePath)
			include(relativePath)
		end

		if string.StartWith(fileName, "cl_") then
			AddCSLuaFile(relativePath)

			if CLIENT then
				include(relativePath)
			end
		end
	end
end

if CLIENT then
	hook.Add("InitPostEntity", "KyberCore:ClientFullyLoaded", function()
		net.Start("KyberCore.ClientFullyLoaded")
		MsgC(Color(183, 0, 255), "[Kyber Core] Client fully loaded!\n")
		net.SendToServer()
	end)
end

if SERVER then
	util.AddNetworkString("KyberCore.ClientFullyLoaded")
	net.Receive("KyberCore.ClientFullyLoaded", function(len, ply)
		hook.Run("KyberCore:ClientFullyLoaded", ply)
	end)
end

// Loaders: In order!
KyberCore:LoadFolder("kyber_core/config")
KyberCore:LoadFolder("kyber_core/mysql")
KyberCore:LoadFolder("kyber_core/experience")
KyberCore:LoadFolder("kyber_core/skills")
KyberCore:LoadFolder("kyber_core/dueling")
KyberCore:LoadFolder("kyber_core/player")
KyberCore:LoadFolder("kyber_core/inventory")
KyberCore:LoadFolder("kyber_core/whitelist")
KyberCore:LoadFolder("kyber_core/admin")

// We're done. Let's hook.
hook.Run("KyberCore:LoadComplete")


concommand.Add("kybercore_credits", function(ply)
	if not ply:IsValid() or not ply:IsPlayer() then return end

	MsgC(Color(183, 0, 255), "[Kyber Core] CREDITS:\n")
	MsgC(Color(183, 0, 255), "[Kyber Core] Created by Stoneman & Truce\n")
	MsgC(Color(183, 0, 255), "[Kyber Core] Special thanks to:\n")
	MsgC(Color(183, 0, 255), "[Kyber Core] - Luna, for creating LSCS.\n")
    MsgC(Color(183, 0, 255), "[Kyber Core] - The australian community for their support.\n")
    MsgC(Color(183, 0, 255), "[Kyber Core] If you bought this addon, you are supporting us.\n")
    MsgC(Color(183, 0, 255), "[Kyber Core] Thank you for your support!\n")
    MsgC(Color(183, 0, 255), "[Kyber Core] If you got this addon for free, please consider buying it.\n")
    MsgC(Color(183, 0, 255), "[Kyber Core] It helps us a lot and we appreciate it.\n")
    MsgC(Color(183, 0, 255), "[Kyber Core] If you bought this addon from someone else other than Stoneman & Truce, please report them.\n")
end, nil, nil, FCVAR_UNREGISTERED)