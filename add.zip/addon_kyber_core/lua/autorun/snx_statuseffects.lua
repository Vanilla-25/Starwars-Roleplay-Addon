if SERVER then AddCSLuaFile() end

GMSNX = {}
GMSNX.StatusEffects = {
	["heal"] = {
		["string"] = "Healing",
		["function"] =
			function(target, dealer, effect, duration, amount)
				local mult
				if target == dealer then
					mult = 0.25
				else
					mult = 1
				end
				local hpam = amount*mult
				local hpdur = duration
				local hptick = (amount/duration)*mult

				local HealAmount
				for i = 1, hpdur*hptick do
					timer.Simple(i/hptick, function()
						if !target:IsValid() then return end
						local futureheal = ( hpam/hpdur )/hptick

						if (target:GetMaxHealth()*2) - target:Health() >= futureheal then
							HealAmount = futureheal
						else
							HealAmount = ((target:GetMaxHealth()*2) - target:Health())
						end

						target:SetHealth( target:Health() + HealAmount )
					end)
				end

				if effect then
					local ED_Heal = EffectData()
					ED_Heal:SetOrigin( target:GetPos() )
					ED_Heal:SetEntity( target )
					ED_Heal:SetMagnitude( hpam )
					ED_Heal:SetScale( hpdur )
					util.Effect("snx_passive_heal", ED_Heal, true, true)
				end
			end
		},
		["heavystun"] = {
			["string"] = "Heavy Stun",
			["function"] =
				function(target, dealer, effect, duration)
					local function RemoveFrozen(target)
						if target:IsValid() then
							target.SNXStatFrozen = false
	
							if target:IsPlayer() then
								//target:ScreenFade( SCREENFADE.IN, Color( 0, 200, 255, 125 ), 0.4, 0.2 )
								target:Freeze( false )
							elseif target:IsNPC() then
								target:SetCondition( 68 )
								if target:Health() < 1 then
									target:SetNPCState(7)
								end
							end
						end
					end
							
					local function UnRagdoll(target)
						if target:IsValid() then
							target.StonemanStatRagdoll = false
	
							if target:IsPlayer() then
								//target:ScreenFade( SCREENFADE.IN, Color( 0, 200, 255, 125 ), 0.4, 0.2 )
								target.IsInvisible = false

								target:SetNoDraw(false)
								target:SetNotSolid(false)
							
								target:DrawViewModel(!false)
								target:DrawShadow(true)
								target:SetMaterial("")
								target:SetRenderMode(RENDERMODE_NORMAL)

								if SERVER then
									target:DrawWorldModel(!false)
							
									if target.IsInvisible == true then
										target:GodEnable()
									else
										target:GodDisable()
									end
		
									local position = target.tw_Ragdoll:GetPos()
									target:UnSpectate()

									target.tw_Ragdoll:Remove()

									target:SetParent(NULL)
									
									hook.Add("PlayerLoadout", "stunned_" .. target:SteamID(), function( targ ) 
										if targ != target then return end
										hook.Remove("PlayerLoadout", "stunned_" .. targ:SteamID() )
										targ:SetPos(position +Vector(0, 0, 5))
										targ:StripWeapons()
										targ:SetHealth(target.TargetHealth)
										targ:SetModel(target.StonemanRagdollModel)
										targ:SetCollisionGroup(0)
									end)
								
									for k, weapon in pairs(target.tw_Weapons) do
										timer.Simple(0.3,function()
											target:Give(weapon)
										end)
									end
									target.tw_Weapons = nil
								end
							end
						end
					end

					if ((target:IsPlayer() and target ~= dealer) or target:IsNPC()) then
						if target.StonemanStatRagdoll then
							if target:Health() < 1 then
								UnRagdoll(target)
							end
						else
							target.StonemanStatRagdoll = true
		
							if target:IsPlayer() then
								target.StonemanRagdollModel = target:GetModel()
								//target:ScreenFade( SCREENFADE.OUT, Color( 0, 200, 255, 125 ), 0.2, 2.5 )
								target.tw_Weapons = {}
			
								for k, weapon in pairs(target:GetWeapons()) do
									table.insert(target.tw_Weapons, weapon:GetClass())
								end
								if SERVER then
									target.tw_Ragdoll = ents.Create("prop_ragdoll")
									target.tw_Ragdoll:SetPos(target:GetPos())
									target.tw_Ragdoll:SetModel(target.StonemanRagdollModel)
									target.tw_Ragdoll:SetAngles(target:GetAngles())
									target.tw_Ragdoll:SetSkin(target:GetSkin())
									target.tw_Ragdoll:SetMaterial(target:GetMaterial())
									target.tw_Ragdoll:Spawn()
							
									target.tw_Ragdoll:CallOnRemove("UnragdollPlayer", function(ragdoll)
										if IsValid(target) then
											target.IsInvisible = false
											
											target:SetModel(target.StonemanRagdollModel)
											target:SetNoDraw(false)
											target:SetNotSolid(false)
										
											target:SetCollisionGroup(0)
											target:DrawShadow(true)
											target:SetMaterial("")
											target:SetRenderMode(RENDERMODE_NORMAL)

											target:DrawViewModel(!false)
											target:DrawWorldModel(!false)
										
											if target.IsInvisible == true then
												target:GodEnable()
											else
												target:GodDisable()
											end

											local position = ragdoll:GetPos()
								
											target:SetParent(NULL)
											target:Spawn()
											timer.Simple(0.1, function()
												target:SetPos(position + Vector(0, 0, 5))
											end)
											
											if (target.tw_Weapons) then
												target:StripWeapons()
												for k, weapon in pairs(target.tw_Weapons) do
													target:Give(weapon)
												end
											end
								
											target.tw_Weapons = nil
										end
									end)
							
									target.tw_Ragdoll:SetCollisionGroup(COLLISION_GROUP_WEAPON)
								
									local velocity = target:GetVelocity()
									local physObjects = target.tw_Ragdoll:GetPhysicsObjectCount() - 1
								
									for i = 0, physObjects do
										local bone = target.tw_Ragdoll:GetPhysicsObjectNum(i)
								
										if IsValid(bone) then
											local position, angle = target:GetBonePosition(target.tw_Ragdoll:TranslatePhysBoneToBone(i))
								
											if (position and angle) then
												bone:SetPos(position)
												bone:SetAngles(angle)
											end
								
											bone:AddVelocity(velocity)
										end
									end
							
									target.TargetHealth = target:Health()
									target:StripWeapons()
									target:SetMoveType(MOVETYPE_OBSERVER)
									target:Spectate(OBS_MODE_CHASE)
									target:SpectateEntity(target.tw_Ragdoll)
									target:SetParent(target.tw_Ragdoll)
									
									target.IsInvisible = true
								
									target:DrawViewModel(!true)
									target:DrawWorldModel(!true)
									if target.IsInvisible == true then
										target:GodEnable()
									else
										target:GodDisable()
									end
								end
								target:DrawShadow(false)
								target:SetMaterial("models/effects/vol_light001")
								target:SetRenderMode(RENDERMODE_TRANSALPHA)
								if SERVER then
									target:Fire("alpha", 0, 0)
								end
							end
							
							timer.Simple( duration, function()
								UnRagdoll(target)
								timer.Simple( 0.3, function() -- was 0.5 orginally. changed value to test timer
									if target.SNXStatFrozen then
										if target:Health() < 1 then
											RemoveFrozen(target)
										end
									else
										target.SNXStatFrozen = true
				
										if target:IsPlayer() then
											//target:ScreenFade( SCREENFADE.OUT, Color( 0, 200, 255, 125 ), 0.2, 2.5 )
											target:Freeze( true ) 
										elseif target:IsNPC() then
											target:SetSchedule( SCHED_NPC_FREEZE )
											target:StopMoving()
										end
				
										timer.Simple( duration, function()
											RemoveFrozen(target)
										end)

										if effect then
											local ED_Stun = EffectData()
											ED_Stun:SetOrigin( target:GetPos() )
											ED_Stun:SetEntity( target )
											ED_Stun:SetScale( duration )
											util.Effect("snx_passive_stun", ED_Stun, true, true)
										end
									end
								end)
							end )
						end
		
						if effect then
							local ED_Stun = EffectData()
							ED_Stun:SetOrigin( target:GetPos() )
							ED_Stun:SetEntity( target )
							ED_Stun:SetScale( duration )
							util.Effect("snx_passive_stun", ED_Stun, true, true)
						end
					end
				end
			},
	["stun"] = {
		["string"] = "Stun",
		["function"] =
			function(target, dealer, effect, duration)
				local function RemoveFrozen(target)
					if target:IsValid() then
						target.SNXStatFrozen = false

						if target:IsPlayer() then
							//target:ScreenFade( SCREENFADE.IN, Color( 0, 200, 255, 125 ), 0.4, 0.2 )
							target:Freeze( false )
						elseif target:IsNPC() then
							target:SetCondition( 68 )
							if target:Health() < 1 then
								target:SetNPCState(7)
							end
						end
					end
				end

				if ((target:IsPlayer() and target ~= dealer) or target:IsNPC()) then
					if target.SNXStatFrozen then
						if target:Health() < 1 then
							RemoveFrozen(target)
						end
					else
						target.SNXStatFrozen = true

						if target:IsPlayer() then
							//target:ScreenFade( SCREENFADE.OUT, Color( 0, 200, 255, 125 ), 0.2, 2.5 )
							target:Freeze( true ) 
						elseif target:IsNPC() then
							target:SetSchedule( SCHED_NPC_FREEZE )
							target:StopMoving()
						end

						timer.Simple( duration, function()
							RemoveFrozen(target)
						end )
					end

					if effect then
						local ED_Stun = EffectData()
						ED_Stun:SetOrigin( target:GetPos() )
						ED_Stun:SetEntity( target )
						ED_Stun:SetScale( duration )
						util.Effect("snx_passive_stun", ED_Stun, true, true)
					end
				end
			end
		},
	["poison"] = {
		["string"] = "Poison",
		["function"] =
			function(target, dealer, effect, duration, damage)
				if !(target:IsPlayer() or target:IsNPC()) then return false end
				local tick = damage/duration
				if target:IsPlayer() then
					local playerdead = false
				end
				for i = 1, duration do
					timer.Simple(i-1, function()
						if target:IsPlayer() then
							if !target:Alive() then 
								playerdead = true
							end
							if playerdead then return end
						end
						if !target:IsValid() then return end
						local futdmg = ( damage/duration )
						target:TakeDamage(futdmg, dealer, dealer)
					end)
				end

				if effect then
					local ED_Poison = EffectData()
					ED_Poison:SetOrigin( target:GetPos() )
					ED_Poison:SetEntity( target )
					ED_Poison:SetMagnitude( damage )
					ED_Poison:SetScale( duration )
					util.Effect("snx_passive_poison", ED_Poison, true, true)
				end

			end
		},
}

function GMSNX:AddStatus(target, dealer, type, a, b, c)
	if target:IsPlayer() or target:IsNPC() then
		GMSNX.StatusEffects[type]["function"](target, dealer, c, a, b)
	end
end