--[[

heavily modified version of GVP's Lightsaber System for public use

please dont reupload, dont resell

best regards luna

]]--

LSCS = istable( LSCS ) and LSCS or { Hilt = {}, Blade = {}, Stance = {}, Force = {},BulletTracerDeflectable = {} }

AddCSLuaFile("lscs/init.lua")
include("lscs/init.lua")

if CLIENT then
	list.Set( "ContentCategoryIcons", "[LSCS]", "icon16/lscs.png" )
	list.Set( "ContentCategoryIcons", "[LSCS] - Ω Class Weapons", "icon16/lscs.png" )
    list.Set( "ContentCategoryIcons", "[LSCS] - SSS Class Weapons", "icon16/lscs.png" )
    list.Set( "ContentCategoryIcons", "[LSCS] - SS Class Weapons", "icon16/lscs.png" )
    list.Set( "ContentCategoryIcons", "[LSCS] - S Class Weapons", "icon16/lscs.png" )
    list.Set( "ContentCategoryIcons", "[LSCS] - A Class Weapons", "icon16/lscs.png" )
    list.Set( "ContentCategoryIcons", "[LSCS] - B Class Weapons", "icon16/lscs.png" )
    list.Set( "ContentCategoryIcons", "[LSCS] - C Class Weapons", "icon16/lscs.png" )
	list.Set( "ContentCategoryIcons", "[LSCS] - D Class Weapons", "icon16/lscs.png" )
 	list.Set( "ContentCategoryIcons", "[LSCS] - Training Weapons", "icon16/lscs.png" )
	list.Set( "ContentCategoryIcons", "[LSCS] - Melee Weapons", "icon16/lscs.png" )
	list.Set( "ContentCategoryIcons", "[LSCS] - Purge Trooper Weapons", "icon16/lscs.png" )
	list.Set( "ContentCategoryIcons", "[LSCS] - 5v1 Event Weapons", "icon16/lscs.png" )
	list.Set( "ContentCategoryIcons", "[LSCS] - 10v1 Event Weapons", "icon16/lscs.png" )
	list.Set( "ContentCategoryIcons", "[LSCS] - Tools", "icon16/lscs.png" )
	list.Set( "ContentCategoryIcons", "[LSCS] - Hilts", "icon16/lscs.png" )
	list.Set( "ContentCategoryIcons", "[LSCS] - Force", "icon16/lscs.png" )
	list.Set( "ContentCategoryIcons", "[LSCS] - Crystals", "icon16/lscs.png" )
	list.Set( "ContentCategoryIcons", "[LSCS] - Stances", "icon16/lscs.png" )

end
