-- #############################################
-- ADMIN MODULE
-- #############################################
local ADMIN_MODULE = GAS.Logging:MODULE()
ADMIN_MODULE.Category = "Kyber Core"
ADMIN_MODULE.Name        = "Admins"
ADMIN_MODULE.Colour   = Color(0 ,128, 255)

ADMIN_MODULE:Setup(function()
    ADMIN_MODULE:Hook("KyberCore:AdminAdded", "admin_added", function(target, whitelister)
        ADMIN_MODULE:Log("{1} added {2} to Kyber Core admins", GAS.Logging:FormatPlayer(whitelister), GAS.Logging:FormatPlayer(target))
    end)
    
    ADMIN_MODULE:Hook("KyberCore:AdminRemoved", "admin_removed", function(target, whitelister)
        ADMIN_MODULE:Log("{1} removed {2} from Kyber Core admins", GAS.Logging:FormatPlayer(whitelister), GAS.Logging:FormatPlayer(target))
    end)
end)

GAS.Logging:AddModule(ADMIN_MODULE)

-- #############################################
-- DUELING MODULE  
-- #############################################

local DUEL_MODULE = GAS.Logging:MODULE()
DUEL_MODULE.Category = "Kyber Core"
DUEL_MODULE.Name     = "Dueling System"
DUEL_MODULE.Colour   = Color(255, 0, 0)

DUEL_MODULE:Setup(function()
    DUEL_MODULE:Hook("KyberCore:ResetDuelRanks", "reset_duel_ranks", function(resetter)
        DUEL_MODULE:Log("{1} reset all duel rankings in the system", GAS.Logging:FormatPlayer(resetter))
    end)
    
    DUEL_MODULE:Hook("KyberCore:RequestDuel", "request_duel", function(player1, player2, isRanked)
        local rankType = isRanked and "ranked" or "casual"
        DUEL_MODULE:Log("{1} requested a {2} duel with {3}", GAS.Logging:FormatPlayer(player1), GAS.Logging:Highlight(rankType), GAS.Logging:FormatPlayer(player2))
    end)
    
    DUEL_MODULE:Hook("KyberCore:StartDuel", "start_duel", function(player1, player2)
        DUEL_MODULE:Log("A duel began between {1} and {2}", GAS.Logging:FormatPlayer(player1), GAS.Logging:FormatPlayer(player2))
    end)
    
    DUEL_MODULE:Hook("KyberCore:EndDuel", "end_duel", function(player1, player2, winner)
        DUEL_MODULE:Log("Duel between {1} and {2} ended with {3} as the winner", GAS.Logging:FormatPlayer(player1), GAS.Logging:FormatPlayer(player2), GAS.Logging:FormatPlayer(winner))
    end)
    
    DUEL_MODULE:Hook("KyberCore:UpdateRating", "update_rating", function(player, opponent, rating)
        DUEL_MODULE:Log("{1} has {2} rating points after dueling {3}", GAS.Logging:FormatPlayer(player), GAS.Logging:Highlight(rating), GAS.Logging:FormatPlayer(opponent))
    end)
    
    DUEL_MODULE:Hook("KyberCore:ForceEndDuel", "force_end_duel", function(admin, player)
        DUEL_MODULE:Log("{1} forced the duel on {2} to end", GAS.Logging:FormatPlayer(admin), GAS.Logging:FormatPlayer(player))
    end)
end)

GAS.Logging:AddModule(DUEL_MODULE)

-- #############################################
-- XP MODULE
-- #############################################

local XP_MODULE = GAS.Logging:MODULE()
XP_MODULE.Category = "Kyber Core"
XP_MODULE.Name     = "Experience & Leveling"
XP_MODULE.Colour   = Color(50, 205, 50)

XP_MODULE:Setup(function()
    XP_MODULE:Hook("KyberCore:PlayerXPAdded", "player_xp_added", function(player, amount)
        XP_MODULE:Log("{1} gained {2} XP", GAS.Logging:FormatPlayer(player), GAS.Logging:Highlight(amount))
    end)
    
    XP_MODULE:Hook("KyberCore:PlayerLevelUp", "player_level_up", function(player, newLevel, currentLevel)
        XP_MODULE:Log("{1} leveled up from level {2} to level {3}", GAS.Logging:FormatPlayer(player), GAS.Logging:Highlight(currentLevel), GAS.Logging:Highlight(newLevel))
    end)
    
    XP_MODULE:Hook("KyberCore:PlayerProgressReset", "player_progress_reset", function(player)
        XP_MODULE:Log("{1}'s progress was completely reset", GAS.Logging:FormatPlayer(player))
    end)
    
    -- Admin XP operations
    XP_MODULE:Hook("KyberCore:AdminPlayerXPAdded", "admin_xp_added", function(target, admin, amount)
        XP_MODULE:Log("{1} added {2} XP to {3}", GAS.Logging:FormatPlayer(admin), GAS.Logging:Highlight(amount), GAS.Logging:FormatPlayer(target))
    end)
    
    XP_MODULE:Hook("KyberCore:AdminPlayerLevelAdded", "admin_level_added", function(target, admin, amount)
        XP_MODULE:Log("{1} added {2} levels to {3}", GAS.Logging:FormatPlayer(admin), GAS.Logging:Highlight(amount), GAS.Logging:FormatPlayer(target))
    end)
    
    XP_MODULE:Hook("KyberCore:AdminPlayerPointsAdded", "admin_points_added", function(target, admin, amount)
        XP_MODULE:Log("{1} added {2} skill points to {3}", GAS.Logging:FormatPlayer(admin), GAS.Logging:Highlight(amount), GAS.Logging:FormatPlayer(target))
    end)
    
    XP_MODULE:Hook("KyberCore:AdminPlayerXPSet", "admin_xp_set", function(target, admin, amount)
        XP_MODULE:Log("{1} set {2}'s XP to {3}", GAS.Logging:FormatPlayer(admin), GAS.Logging:FormatPlayer(target), GAS.Logging:Highlight(amount))
    end)
    
    XP_MODULE:Hook("KyberCore:AdminPlayerLevelSet", "admin_level_set", function(target, admin, amount)
        XP_MODULE:Log("{1} set {2}'s level to {3}", GAS.Logging:FormatPlayer(admin), GAS.Logging:FormatPlayer(target), GAS.Logging:Highlight(amount))
    end)
    
    XP_MODULE:Hook("KyberCore:AdminPlayerPointsSet", "admin_points_set", function(target, admin, amount)
        XP_MODULE:Log("{1} set {2}'s skill points to {3}", GAS.Logging:FormatPlayer(admin), GAS.Logging:FormatPlayer(target), GAS.Logging:Highlight(amount))
    end)
end)

GAS.Logging:AddModule(XP_MODULE)

-- #############################################
-- INVENTORY MODULE
-- #############################################

local INV_MODULE = GAS.Logging:MODULE()
INV_MODULE.Category = "Kyber Core"
INV_MODULE.Name     = "Inventory System"
INV_MODULE.Colour   = Color(139, 69, 19)

INV_MODULE:Setup(function()
    INV_MODULE:Hook("LSCS:PostPlayerInventory", "post_player_inventory", function(player, item, index, loading)
        if not loading then
            INV_MODULE:Log("{1} received item {2} in inventory slot {3}", GAS.Logging:FormatPlayer(player), GAS.Logging:Highlight(item), GAS.Logging:Highlight(index))
        end
    end)
    
    INV_MODULE:Hook("LSCS:OnPlayerDroppedItem", "player_dropped_item", function(player, item, index)
        INV_MODULE:Log("{1} dropped {2} from inventory slot {3}", GAS.Logging:FormatPlayer(player), GAS.Logging:Highlight(item), GAS.Logging:Highlight(index))
    end)
    
    INV_MODULE:Hook("LSCS:OnPlayerInventoryRemove", "player_inventory_remove", function(player, item, index)
        INV_MODULE:Log("{1} had item {2} removed from inventory slot {3}", GAS.Logging:FormatPlayer(player), GAS.Logging:Highlight(item), GAS.Logging:Highlight(index))
    end)
    
    INV_MODULE:Hook("LSCS:OnPlayerInventoryWipe", "player_inventory_wipe", function(player)
        INV_MODULE:Log("{1}'s inventory was completely wiped", GAS.Logging:FormatPlayer(player))
    end)
    
    -- Admin inventory operations
    INV_MODULE:Hook("KyberCore:AdminPlayerItemRemoved", "admin_item_removed", function(target, admin, slot)
        INV_MODULE:Log("{1} removed an item from slot {2} in {3}'s inventory", GAS.Logging:FormatPlayer(admin), GAS.Logging:Highlight(slot), GAS.Logging:FormatPlayer(target))
    end)
    
    INV_MODULE:Hook("KyberCore:AdminPlayerItemAdded", "admin_item_added", function(target, admin, itemName)
        INV_MODULE:Log("{1} added item {2} to {3}'s inventory", GAS.Logging:FormatPlayer(admin), GAS.Logging:Highlight(itemName), GAS.Logging:FormatPlayer(target))
    end)
    
    INV_MODULE:Hook("KyberCore:AdminPlayerItemEquipped", "admin_item_equipped", function(target, admin, slot, isEquip, hand)
        local handText = hand and "right hand" or "left hand"
        local equipText = isEquip and "equipped" or "unequipped"
        INV_MODULE:Log("{1} {2} the item in slot {3} for {4}'s {5}", GAS.Logging:FormatPlayer(admin), GAS.Logging:Highlight(equipText), GAS.Logging:Highlight(slot), GAS.Logging:FormatPlayer(target), GAS.Logging:Highlight(handText))
    end)
    
    INV_MODULE:Hook("KyberCore:AdminPlayerInventoryWiped", "admin_inventory_wiped", function(target, admin)
        INV_MODULE:Log("{1} wiped {2}'s entire inventory", GAS.Logging:FormatPlayer(admin), GAS.Logging:FormatPlayer(target))
    end)
    
    INV_MODULE:Hook("KyberCore:AdminPlayerInventoryUnequipAll", "admin_inventory_unequip_all", function(target, admin)
        INV_MODULE:Log("{1} unequipped all items from {2}'s inventory", GAS.Logging:FormatPlayer(admin), GAS.Logging:FormatPlayer(target))
    end)
end)

GAS.Logging:AddModule(INV_MODULE)

-- #############################################
-- WHITELISTING MODULE
-- #############################################

local WHITELIST_MODULE = GAS.Logging:MODULE()
WHITELIST_MODULE.Category = "Kyber Core"
WHITELIST_MODULE.Name     = "Skill Trees & Whitelisting"
WHITELIST_MODULE.Colour   = Color(186, 85, 211)

WHITELIST_MODULE:Setup(function()
    WHITELIST_MODULE:Hook("KyberCore:PlayerWhitelisted", "player_whitelisted", function(player, admin, tree)
        WHITELIST_MODULE:Log("{1} whitelisted {2} to the {3} skill tree", GAS.Logging:FormatPlayer(admin), GAS.Logging:FormatPlayer(player), GAS.Logging:Highlight(tree))
    end)
    
    WHITELIST_MODULE:Hook("KyberCore:PlayerUnwhitelisted", "player_unwhitelisted", function(player, admin, tree)
        WHITELIST_MODULE:Log("{1} removed {2} from the {3} skill tree", GAS.Logging:FormatPlayer(admin), GAS.Logging:FormatPlayer(player), GAS.Logging:Highlight(tree))
    end)
end)

GAS.Logging:AddModule(WHITELIST_MODULE)