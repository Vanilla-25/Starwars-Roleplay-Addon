include("shared.lua")

function ENT:Initialize()
    self:SetModel("models/hunter/plates/plate4x6.mdl")
    self:SetMoveType(MOVETYPE_NONE)
    self:SetSolid(SOLID_VPHYSICS)

    -- Change collision group to allow player bullets to pass through
    self:SetCollisionGroup(COLLISION_GROUP_DEBRIS_TRIGGER)

    self:SetRenderMode(RENDERMODE_TRANSCOLOR)
    self:SetSubMaterial(0, "models/debug/debugwhite")
    self:SetColor(Color(150, 20, 255, 100)) -- Adjusted blue value to 255

    -- Set initial health
    self:SetHealth(5000)
    self:SetMaxHealth(5000)
    
    self.SpawnTime = CurTime()
    self.StartThink = true
    self:DrawShadow(false)

    if not IsValid(self:GetOwner()) then
        self:Remove()
        return
    end
end

hook.Add("EntityFireBullets", "BarrierIgnorePlayerBullets", function(ply, data)
    if not IsValid(ply) or not ply:IsPlayer() then return end

    local originalCallback = data.Callback

    data.Callback = function(attacker, tr, dmginfo)
        local hitEntity = tr.Entity

        if IsValid(hitEntity) and hitEntity:GetClass() == "barrier" then
            local bulletDir = (data.Src - tr.HitPos):GetNormalized()
            local barrierForward = hitEntity:GetAngles():Up() * -1
            local angle = math.deg(math.acos(bulletDir:Dot(barrierForward)))

            if angle > 90 then
                local bullet = table.Copy(data)
				local effectdata = EffectData()
					effectdata:SetStart( tr.HitPos )
					effectdata:SetOrigin( data.Src )
					effectdata:SetEntity( self )
				util.Effect( bullet.TracerName, effectdata, true, true )

                bullet.Src		= tr.HitPos + tr.Normal * 5
                bullet.Dir		= data.Dir
                // If bullet hits, we try to run the callback on the entity it hit
                if originalCallback then
                    bullet.Callback = function(attacker, tr, dmginfo)
                        originalCallback(attacker, tr, dmginfo)
                    end
                end

                ply:FireBullets( bullet )
            end
        else
            if originalCallback then
                originalCallback(attacker, tr, dmginfo)
            end
        end
    end
end)

function ENT:ResetProgress()
    self.Time = CurTime() + 1
end

function ENT:GetProgress()
    if not self.Time then
        return (2 + math.max(self.SpawnTime - CurTime(), -1)) / 2
    end
    return math.Clamp((self.Time - CurTime()) / 2, 0, 1)
end

function ENT:CalcMove(ply)
    local FT = FrameTime()
    local ShootPos = ply:GetShootPos()

    local trace = util.TraceLine({
        start = ShootPos,
        endpos = ShootPos + ply:EyeAngles():Forward() * 250,
        mask = MASK_SOLID_BRUSHONLY,
    })

    local start = ShootPos
    local sub = (trace.HitPos + trace.HitNormal * 20) - start
    local dir = sub:GetNormalized()
    local dist = math.min(sub:Length(), 150)

    local TargetPos = start + dir * (dist)
    local MoveSub = TargetPos - self:GetPos()
    local MoveDist = math.min(MoveSub:Length() * 10, 500)
    local MoveDir = MoveSub:GetNormalized()
    local MoveSpeed = MoveDist * FT
    local Move = MoveDir * MoveSpeed

    self:SetPos(self:GetPos() + Move)
    self:SetAngles(Angle(ply:EyeAngles().x - 90, ply:EyeAngles().y, 0))
end

function ENT:CalcFP(ply)
    local Time = CurTime()

    if (self._nextFP or 0) > Time then return end

    self._nextFP = Time + 1

    ply:lscsTakeForce(5)

    if ply:lscsGetForce() > 0 then return end

    if not self.Returning then
        self.Returning = true
        self:ResetProgress()
    end
end

function ENT:Think()
    self:NextThink(CurTime())

    if self.StartThink then
        local ply = self:GetOwner()
        if IsValid(ply) then
            self:CalcMove(ply)
            self:CalcFP(ply)
        else
            print("[DEBUG] Owner is not valid, removing entity")
            self:Remove()
        end
    end

    return true
end

function ENT:OnTakeDamage(dmginfo)
    local attacker = dmginfo:GetAttacker()

    if IsValid(attacker) and attacker:IsPlayer() then
        -- Ignore damage from players
        return
    end

    -- Apply damage to the entity
    self:SetHealth(self:Health() - dmginfo:GetDamage())

    -- If health is zero or less, remove the entity
    if self:Health() <= 0 then
        self:Remove()
    end
end

function ENT:OnRemove()
    --print("[DEBUG] Entity removed")
end

function ENT:UpdateTransmitState()
    return TRANSMIT_ALWAYS
end

hook.Add("PlayerSpawnedSENT", "MakeNPCShootAtEntity", function(ply, ent)
    if IsValid(ent) and ent:GetClass() == "barrier" then
        for _, npc in pairs(ents.FindByClass("npc_*")) do
            if IsValid(npc) then
                npc:AddEntityRelationship(ent, D_HT, 99)
            end
        end
    end
end)
