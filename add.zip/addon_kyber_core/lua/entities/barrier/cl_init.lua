include("shared.lua")

function ENT:OnRemove()
    if self.SND then
        self.SND:Stop()
    end
end

function ENT:DrawTranslucent()
    self:DrawModel()
end

function ENT:Draw()
    self:DrawModel()
end