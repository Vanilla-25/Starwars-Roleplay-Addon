
AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")

include("shared.lua")

/*---------------------------------------------------------
   Name: Initialize
---------------------------------------------------------*/

function ENT:Initialize()
	self.Entity:SetModel("models/weapons/darky_m/rust/w_rock.mdl")
	self.Entity:PhysicsInit(SOLID_VPHYSICS)
	self.Entity:SetMoveType(MOVETYPE_VPHYSICS)
	self.Entity:SetSolid(SOLID_VPHYSICS)
	self.LastSoundTime = 0  -- Initialize a variable to track the last time the sound was played
	self.SoundCooldown = 2  -- Set the cooldown time in seconds
	--self.Entity:DrawShadow(true)
end

/*---------------------------------------------------------
   Name: Collision
---------------------------------------------------------*/

function ENT:PhysicsCollide(data, phys)
	local currentTime = CurTime()  -- Get the current time

	-- Check if enough time has passed since the last sound was played
	if currentTime - self.LastSoundTime >= self.SoundCooldown then
		self.Entity:EmitSound("physics/concrete/rock_impact_hard1.wav")
		self.LastSoundTime = currentTime  -- Update the last sound time
	end

	timer.Simple(4, function()
		if not IsValid(self) then return end
		self:Remove()
	end)
end
