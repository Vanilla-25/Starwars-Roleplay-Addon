ENT.Type 			= "anim"
ENT.Base 			= "base_anim"
ENT.PrintName		= "Boulder"
ENT.Category		= "WOS_Powers"

ENT.Spawnable		= false