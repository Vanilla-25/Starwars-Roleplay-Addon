AddCSLuaFile()

ENT.Type            = "anim"

ENT.Spawnable       = false
ENT.AdminSpawnable  = false

ENT.AutomaticFrameAdvance = true
ENT.RenderGroup = RENDERGROUP_BOTH 

function ENT:SetupDataTables()
	self:NetworkVar( "Entity",0, "SWEP" )
end

if SERVER then
	function ENT:Initialize()
		local SWEP = self:GetSWEP()

		if not IsValid( SWEP ) then self:Remove() return end

		local ply = SWEP:GetOwner()

		if not IsValid( ply ) then self:Remove() return end

		local HiltMatch = SWEP:GetHiltR() == "inqss"

		self:SetMoveType( MOVETYPE_NONE )
		self:SetSolid( SOLID_NONE )
		self:SetCollisionGroup( COLLISION_GROUP_NONE )

		if HiltMatch then
			self:SetModel( ply:GetModel() )
			self:SetParent( ply, 0 )
			self:SetLocalPos( vector_origin )
			self:SetLocalAngles( angle_zero )
			self:AddEffects( EF_BONEMERGE )
		else
			self:SetModel( "models/lscs/saber_throw.mdl" )
			self:SetParent( ply, ply:LookupAttachment( "anim_attachment_RH" ) )
			self:SetLocalPos( Vector(-1,2,0) )
			self:SetLocalAngles( Angle(90,0,0) )
			self:PlayAnimation( "spin", 2.5 )
		end

		SWEP:SetActive( true )
		SWEP:SetProjectile( self )
		SWEP:CancelCombo( 100 )
		SWEP:SetDMGActive( true )

		self:DrawShadow( false )
	end

	function ENT:Think()
		self:NextThink( CurTime() )

		return true
	end

	function ENT:OnRemove()
		local SWEP = self:GetSWEP()

		if not IsValid( SWEP ) then return end

		local ply = SWEP:GetOwner()

		SWEP:SetProjectile( NULL )
		SWEP:SetDMGActive( false )
		SWEP:SetNextPrimaryAttack( CurTime() )
		SWEP:ResetHoldType()

		if IsValid( ply ) then
			ply:SetMoveType( MOVETYPE_WALK )
		end
	end

	function ENT:PlayAnimation( animation, playbackrate )
		playbackrate = playbackrate or 1

		local sequence = self:LookupSequence( animation )

		self:ResetSequence( sequence )
		self:SetPlaybackRate( playbackrate )
		self:SetSequence( sequence )
	end

	function ENT:UpdateTransmitState() 
		return TRANSMIT_ALWAYS
	end
else
	function ENT:Initialize()
		self.SND = CreateSound( self, "lscs/saber/saberspin_loop.wav" )
		self.SND:PlayEx(1,90)
	end

	function ENT:OnRemove()
		if self.SND then
			self.SND:Stop()
		end
	end

	function ENT:Draw()
	end

	function ENT:DrawTranslucent()
		local SWEP = self:GetSWEP()

		if not IsValid( SWEP ) then return end

		self:SetupBones()

		SWEP:DrawWorldModelTranslucent( nil, self )
	end
end