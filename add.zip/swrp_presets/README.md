# SWRP Preset System

Press **F6** (or type `!preset` in chat) to open the preset menu for your current DarkRP job.
Presets let players switch their playermodel and loadout within their regiment — like sub-classes or lore characters.

---

## Installation

1. Drop the `swrp_presets` folder into your server's `addons/` directory.
2. Restart the server.

```
addons/
└── swrp_presets/
    ├── addon.json
    └── lua/
        ├── autorun/
        │   └── swrp_presets_init.lua   ← boots everything
        └── swrp_presets/
            ├── sh/  (shared)
            ├── sv/  (server)
            ├── cl/  (client)
            └── configs/                ← YOUR regiment files go here
                └── 501st_trooper.lua   ← example
```

---

## Adding a Regiment

1. Copy `lua/swrp_presets/configs/501st_trooper.lua` and rename it.
2. Open the file and change the first argument of `RegisterJob(...)` to match the **exact job name** shown in-game (what `ply:getDarkRPVar("job")` returns — usually the job title like `"501st Trooper"`).
3. Fill in your presets.

### Preset Fields

| Field | Type | Description |
|---|---|---|
| `name` | string | Display name shown in the menu |
| `description` | string | Short description shown in the menu |
| `icon` | string | Optional icon path (e.g. `"icon16/star.png"`) |
| `model` | string | Full path to the playermodel `.mdl` |
| `weapons` | table | Array of weapon class names to give |
| `stripWeapons` | bool | If true, removes current weapons before giving new ones |
| `allowedRanks` | table or nil | Rank names allowed to use this preset. `nil` = everyone on the job |

### Example

```lua
SWRP_PRESETS.RegisterJob("501st Trooper", {
    {
        name         = "Stormtrooper",
        description  = "Standard 501st trooper.",
        model        = "models/player/501st/trooper.mdl",
        weapons      = { "weapon_dc15a", "weapon_dc17" },
        stripWeapons = true,
    },
    {
        name         = "ARC Trooper Fives",
        description  = "Lore character. Restricted to ARC rank.",
        model        = "models/player/501st/arc_fives.mdl",
        weapons      = { "weapon_dc17x2", "weapon_thermal_det" },
        stripWeapons = true,
        allowedRanks = { "ARC Trooper", "Commander" },
    },
})
```

---

## Features

- **F6** opens the menu (also `!preset` in chat)
- Preset persists across respawns — player keeps their selected preset when they die and respawn
- Preset is cleared when they change to a different job
- Rank-locked presets shown greyed out with a lock icon
- Supports unlimited presets per job, unlimited jobs

---

## Notes

- Job name matching is **case-insensitive**
- Player model must be added to the server's `workshop` or `FastDL`
- Weapon class names must be valid (check with `player_give <classname>` in console)
