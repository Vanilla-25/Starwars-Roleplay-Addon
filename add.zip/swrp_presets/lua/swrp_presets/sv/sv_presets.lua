-- ============================================================
--  SWRP Preset System - Server
-- ============================================================

util.AddNetworkString("swrp_presets_apply")
util.AddNetworkString("swrp_presets_notify")
util.AddNetworkString("swrp_presets_reset")

-- ─────────────────────────────────────────────────────────────────────────────
-- Persistence helpers
-- ─────────────────────────────────────────────────────────────────────────────

local SAVE_DIR = "swrp_presets/"
if not file.IsDir(SAVE_DIR, "DATA") then file.CreateDir(SAVE_DIR) end

local function GetSavePath(ply)  return SAVE_DIR .. ply:SteamID64() .. ".txt" end

local function ReadSaveFile(ply)
    local path = GetSavePath(ply)
    if not file.Exists(path, "DATA") then return {} end
    return util.JSONToTable(file.Read(path, "DATA")) or {}
end

-- SavePreset is now inlined inside ApplyPreset to keep modelIndex together.
-- Kept as a no-op stub so nothing else breaks if it is referenced externally.
local function SavePreset(ply, jobName, presetIndex) end

local function LoadPreset(ply, jobName)
    local v = ReadSaveFile(ply)[jobName]
    if type(v) == "table" then
        return v.preset, v.modelIndex
    elseif type(v) == "number" then
        -- Legacy format: just a preset index, no model variant
        return v, 1
    end
    return nil, nil
end

local function ClearPreset(ply, jobName)
    local data = ReadSaveFile(ply)
    if data[jobName] == nil then return end
    data[jobName] = nil
    file.Write(GetSavePath(ply), util.TableToJSON(data))
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Helpers
-- ─────────────────────────────────────────────────────────────────────────────

local function Notify(ply, msg)
    net.Start("swrp_presets_notify")
    net.WriteString(msg)
    net.Send(ply)
end

local function CanUsePreset(ply, preset)
    if not preset.allowedRanks then return true end
    local rank = string.lower(ply:getDarkRPVar("rank") or "")
    for _, r in ipairs(preset.allowedRanks) do
        if string.lower(r) == rank then return true end
    end
    return false
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Core: apply a preset
-- ─────────────────────────────────────────────────────────────────────────────

local function ApplyPreset(ply, presetIndex, silent, modelIndex)
    local presets = SWRP_PRESETS.GetPresetsForPlayer(ply)
    if not presets then
        if not silent then Notify(ply, "No presets found for your current job.") end
        return
    end

    local preset = presets[presetIndex]
    if not preset then
        if not silent then Notify(ply, "Invalid preset selected.") end
        return
    end

    if not CanUsePreset(ply, preset) then
        if not silent then Notify(ply, "You do not have the required rank for that preset.") end
        return
    end

    -- Resolve model: supports both a single string and a table of options
    local resolvedModel
    if type(preset.model) == "table" then
        modelIndex = modelIndex or 1
        resolvedModel = preset.model[math.Clamp(modelIndex, 1, #preset.model)]
    elseif type(preset.model) == "string" and preset.model ~= "" then
        resolvedModel = preset.model
        modelIndex = 1
    end

    if resolvedModel and resolvedModel ~= "" then ply:SetModel(resolvedModel) end
    if preset.stripWeapons then ply:StripWeapons() end
    if preset.weapons then
        for _, wep in ipairs(preset.weapons) do ply:Give(wep) end
    end

    -- Persist both the preset index and the chosen model variant
    local data = ReadSaveFile(ply)
    local jobName = ply:getDarkRPVar("job") or "unknown"
    data[jobName] = { preset = presetIndex, modelIndex = modelIndex or 1 }
    file.Write(GetSavePath(ply), util.TableToJSON(data))

    if not silent then
        Notify(ply, "Preset applied: " .. preset.name)
        print("[SWRP Presets] " .. ply:Nick() .. " applied preset: " .. preset.name)
    end
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Net receivers
-- ─────────────────────────────────────────────────────────────────────────────

net.Receive("swrp_presets_apply", function(len, ply)
    local presetIndex = net.ReadUInt(8)
    local modelIndex  = net.ReadUInt(8)
    ApplyPreset(ply, presetIndex, false, modelIndex)
end)

net.Receive("swrp_presets_reset", function(len, ply)
    local jobName = ply:getDarkRPVar("job")
    if not jobName then return end

    local jobTable
    for _, v in pairs(RPExtraTeams) do
        if string.lower(v.name) == string.lower(jobName) then
            jobTable = v; break
        end
    end

    ply:StripWeapons()

    if jobTable then
        if jobTable.model then
            ply:SetModel(type(jobTable.model) == "table" and jobTable.model[1] or jobTable.model)
        end
        if jobTable.weapons then
            for _, wep in ipairs(jobTable.weapons) do ply:Give(wep) end
        end
    end

    ClearPreset(ply, jobName)
    Notify(ply, "Reset to default job appearance.")
end)

-- ─────────────────────────────────────────────────────────────────────────────
-- Hooks
-- ─────────────────────────────────────────────────────────────────────────────

-- Re-apply saved preset on respawn (delayed so DarkRP assigns job first)
hook.Add("PlayerSpawn", "swrp_presets_restore", function(ply)
    timer.Simple(0.5, function()
        if not IsValid(ply) then return end
        local jobName = ply:getDarkRPVar("job")
        if not jobName then return end
        local idx, mdlIdx = LoadPreset(ply, jobName)
        if idx then ApplyPreset(ply, idx, true, mdlIdx) end
    end)
end)

-- Clear saved preset when player changes job
hook.Add("DarkRPVarChanged", "swrp_presets_jobchange", function(ply, varname, oldval, newval)
    if varname == "job" and oldval and oldval ~= newval then
        ClearPreset(ply, oldval)
    end
end)