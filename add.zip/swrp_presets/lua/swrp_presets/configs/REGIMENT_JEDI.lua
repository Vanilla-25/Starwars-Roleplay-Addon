-- ============================================================
--  SWRP Preset Config: Jedi Council
--  If you have multiple Jedi job tiers (Padawan, Knight, Master etc.)
--  just add them to the RegisterJobs list below.
-- ============================================================

SWRP_PRESETS.RegisterJobs({
    "Jedi Council",
    -- "Jedi Knight",
    -- "Jedi Padawan",
    -- Add more Jedi jobs here if needed
}, {

    -- ── Lore Characters ──────────────────────────────────────

    {
        name         = "Yoda",
        description  = "Grand Master of the Jedi Order.",
        icon         = "icon16/user.png",
        model        = "models/lucky/yoda_cgi.mdl",
        accentColor  = Color(100, 210, 80),
        weapons      = { "kc_yoda" },
        stripWeapons = false,
        allowedRanks = nil,
        category     = "Lore Characters",
    },

    {
        name         = "Obi-Wan Kenobi",
        description  = "A wise Jedi Master known for his calm nature, strong morals, and skill with a lightsaber.",
        icon         = "icon16/user.png",
        model        = "models/player/generalkenobi/cgikenobi.mdl",
        accentColor  = Color(80, 160, 255),
        weapons      = { "kc_obi_kenobi" },
        stripWeapons = false,
        allowedRanks = nil,
        category     = "Lore Characters",
    },

    {
        name         = "Kit Fisto",
        description  = "Kit Fisto is a skilled Jedi Master known for his aquatic abilities and proficiency with a lightsaber.",
        icon         = "icon16/user.png",
        model        = "models/synergy/jedi/lore/kit_fisto.mdl",
        accentColor  = Color(100, 210, 80),
        weapons      = { "" },
        stripWeapons = false,
        allowedRanks = nil,
        category     = "Lore Characters",
    },

    {
        name         = "Ki Adi Mundi",
        description  = "Ki Adi Mundi is a skilled Jedi Master known for his wisdom and combat skills.",
        icon         = "icon16/user.png",
        model        = "models/synergy/jedi/lore/ki_adi_mundi.mdl",
        accentColor  = Color(100, 210, 80),
        weapons      = { "" },
        stripWeapons = false,
        allowedRanks = nil,
        category     = "Lore Characters",
    },

    -- ── Field Operatives ─────────────────────────────────────

    {
        name         = "Jedi Knight",
        description  = "Frontline Jedi focused on combat and leadership.",
        icon         = "icon16/shield.png",
        model        = {
            "models/player/jedi/human/male/knight/male_human_knight.mdl",
            "models/player/jedi/human/female/knight/female_human_knight.mdl",
            "models/player/jedi/twilek/male/knight/twilek_knight_male.mdl",
            "models/player/jedi/twilek/female/knight/twilek_female_knight.mdl",
            "models/player/jedi/rodian/male/knight/rodian_male_knight.mdl",
            "models/player/jedi/rodian/female/knight/female_rodian_knight.mdl",
            "models/player/jedi/keldoran/male/knight/male_keldoran_knight.mdl",
            "models/player/jedi/keldoran/female/knight/female_keldoran_knight.mdl",
            "models/player/jedi/chiss/male/knight/male_chiss_knight.mdl",
            "models/player/jedi/chiss/female/knight/female_chiss_knight.mdl",
            "models/player/jedi/kaleesh/male/knight/male_kaleesh_knight.mdl",
            "models/player/jedi/pantoran/male/knight/pantoran_male_knight.mdl",
            "models/player/jedi/pantoran/female/knight/female_pantoran_knight.mdl",
            "models/player/jedi/tholothian/male/knight/male_tholothian_knight.mdl",
            "models/player/jedi/tholothian/female/knight/female_tholothian_knight.mdl",
            "models/player/jedi/zabrak/male/knight/male_zabrak_knight.mdl",
            "models/player/jedi/zabrak/female/knight/female_zabrak_knight.mdl",
        },
        accentColor  = Color(80, 120, 255),
        weapons      = { "" },
        stripWeapons = false,
        allowedRanks = nil,
        category     = "Field Operatives",
    },

    {
        name         = "Jedi Guardian",
        description  = "Powerful Jedi defenders specializing in lightsaber combat.",
        icon         = "icon16/shield.png",
        model        = {
            "models/player/jedi/human/male/guardian/male_human_guardian.mdl",
            "models/player/jedi/human/female/guardian/female_human_guardian.mdl",
            "models/player/jedi/twilek/male/guardian/twilek_guardian_male.mdl",
            "models/player/jedi/twilek/female/guardian/twilek_female_guardian.mdl",
            "models/player/jedi/rodian/male/guardian/rodian_male_guardian.mdl",
            "models/player/jedi/rodian/female/guardian/female_rodian_guardian.mdl",
            "models/player/jedi/keldoran/male/guardian/male_keldoran_guardian.mdl",
            "models/player/jedi/keldoran/female/guardian/female_keldoran_guardian.mdl",
            "models/player/jedi/chiss/male/guardian/male_chiss_guardian.mdl",
            "models/player/jedi/chiss/female/guardian/female_chiss_guardian.mdl",
            "models/player/jedi/kaleesh/male/guardian/male_kaleesh_guardian.mdl",
            "models/player/jedi/kaleesh/female/guardian/female_kaleesh_guardian.mdl",
            "models/player/jedi/pantoran/male/guardian/pantoran_male_guardian.mdl",
            "models/player/jedi/pantoran/female/guardian/female_pantoran_guardian.mdl",
            "models/player/jedi/tholothian/male/guardian/male_tholothian_guardian.mdl",
            "models/player/jedi/tholothian/female/guardian/female_tholothian_guardian.mdl",
            "models/player/jedi/zabrak/male/guardian/male_zabrak_guardian.mdl",
            "models/player/jedi/zabrak/female/guardian/female_zabrak_guardian.mdl",
        },
        accentColor  = Color(255, 80, 80),
        weapons      = { "" },
        stripWeapons = false,
        allowedRanks = nil,
        category     = "Field Operatives",
    },

    {
        name         = "Jedi Sentinel",
        description  = "Balanced Jedi combining combat and Force abilities.",
        icon         = "icon16/lightning.png",
        model        = {
            "models/player/jedi/human/male/sentinel/male_human_sentinel.mdl",
            "models/player/jedi/human/female/sentinel/female_human_sentinel.mdl",
            "models/player/jedi/twilek/male/sentinel/twilek_sentinel_male.mdl",
            "models/player/jedi/twilek/female/sentinel/twilek_female_sentinel.mdl",
            "models/player/jedi/rodian/male/sentinel/rodian_male_sentinel.mdl",
            "models/player/jedi/rodian/female/sentinel/female_rodian_sentinel.mdl",
            "models/player/jedi/keldoran/male/sentinel/male_keldoran_sentinel.mdl",
            "models/player/jedi/keldoran/female/sentinel/female_keldoran_sentinel.mdl",
            "models/player/jedi/chiss/male/sentinel/male_chiss_sentinel.mdl",
            "models/player/jedi/chiss/female/sentinel/female_chiss_sentinel.mdl",
            "models/player/jedi/kaleesh/male/sentinel/male_kaleesh_sentinel.mdl",
            "models/player/jedi/kaleesh/female/sentinel/female_kaleesh_sentinel.mdl",
            "models/player/jedi/pantoran/male/sentinel/pantoran_male_sentinel.mdl",
            "models/player/jedi/pantoran/female/sentinel/female_pantoran_sentinel.mdl",
            "models/player/jedi/tholothian/male/sentinel/male_tholothian_sentinel.mdl",
            "models/player/jedi/tholothian/female/sentinel/female_tholothian_sentinel.mdl",
            "models/player/jedi/zabrak/male/sentinel/male_zabrak_sentinel.mdl",
            "models/player/jedi/zabrak/female/sentinel/female_zabrak_sentinel.mdl",
        },
        accentColor  = Color(255, 200, 80),
        weapons      = { "" },
        stripWeapons = false,
        allowedRanks = nil,
        category     = "Field Operatives",
    },

    {
        name         = "Jedi Consular",
        description  = "Wise Jedi focused on the Force and diplomacy.",
        icon         = "icon16/book.png",
        model        = {
            "models/player/jedi/human/male/consular/male_human_consular.mdl",
            "models/player/jedi/human/female/consular/female_human_consular.mdl",
            "models/player/jedi/twilek/male/consular/twilek_consular_male.mdl",
            "models/player/jedi/twilek/female/consular/twilek_female_consular.mdl",
            "models/player/jedi/rodian/male/consular/rodian_male_consular.mdl",
            "models/player/jedi/rodian/female/consular/female_rodian_consular.mdl",
            "models/player/jedi/keldoran/male/consular/male_keldoran_consular.mdl",
            "models/player/jedi/keldoran/female/consular/female_keldoran_consular.mdl",
            "models/player/jedi/chiss/male/consular/male_chiss_consular.mdl",
            "models/player/jedi/chiss/female/consular/female_chiss_consular.mdl",
            "models/player/jedi/kaleesh/male/consular/male_kaleesh_consular.mdl",
            "models/player/jedi/kaleesh/female/consular/female_kaleesh_consular.mdl",
            "models/player/jedi/pantoran/male/consular/pantoran_male_consular.mdl",
            "models/player/jedi/pantoran/female/consular/female_pantoran_consular.mdl",
            "models/player/jedi/tholothian/male/consular/male_tholothian_consular.mdl",
            "models/player/jedi/tholothian/female/consular/female_tholothian_consular.mdl",
            "models/player/jedi/zabrak/male/consular/male_zabrak_consular.mdl",
            "models/player/jedi/zabrak/female/consular/female_zabrak_consular.mdl",
        },
        accentColor  = Color(80, 255, 160),
        weapons      = { "" },
        stripWeapons = false,
        allowedRanks = nil,
        category     = "Field Operatives",
    },

})

SWRP_PRESETS.RegisterJobs({
    "Jedi Padawan",
}, {

    -- ── Lore Characters ──────────────────────────────────────

    {
        name         = "Caleb Dume",
        description  = "Survivor Jedi Kanan Jarrus wields blue lightsaber and is a skilled combatant and Force user.",
        icon         = "icon16/user.png",
        model        = "models/synergy/jedi/lore/caleb.mdl",
        accentColor = Color(70, 140, 255),
        weapons      = { "mvp_perfecthands", "climb_swep2", "kybercore_tablet", "kc_lscs_personal" },
        stripWeapons = true,
        allowedRanks = nil,
        category     = "Lore Characters",
    },

    {
        name         = "Cal Kestis",
        description  = "Survivor Jedi Cal Kestis wields blue lightsaber and is a skilled combatant and Force user.",
        icon         = "icon16/user.png",
        model        = "models/synergy/jedi/lore/cal.mdl",
        accentColor = Color(255, 170, 60),
        weapons      = { "mvp_perfecthands", "climb_swep2", "kybercore_tablet", "kc_lscs_personal" },
        stripWeapons = true,
        allowedRanks = nil,
        category     = "Lore Characters",
    },

    {
        name         = "Cal Kestis",
        description  = "Survivor Jedi Cal Kestis wields blue lightsaber and is a skilled combatant and Force user.",
        icon         = "icon16/user.png",
        model        = "models/synergy/jedi/lore/cal.mdl",
        accentColor = Color(255, 170, 60),
        weapons      = { "mvp_perfecthands", "climb_swep2", "kybercore_tablet", "kc_lscs_personal" },
        stripWeapons = true,
        allowedRanks = nil,
        category     = "Lore Characters",
    },

})
