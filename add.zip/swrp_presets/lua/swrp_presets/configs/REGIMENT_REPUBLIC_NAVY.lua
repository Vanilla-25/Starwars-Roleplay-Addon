-- ============================================================
--  SWRP Preset Config: Republic Navy
--  All Navy tiers share the same preset list.
--  Add or remove job names from the table below as needed.
-- ============================================================

local NAVY_WEAPONS = {
    "arccw_cgi_k_dc15s",
    "arccw_cgi_k_dc17_navy",
    "sw_navypad",
    "mvp_perfecthands",
    "climb_swep2",
}

SWRP_PRESETS.RegisterJobs({
    "Republic Navy Enlisted",
    "Republic Navy NCO",
    "Republic Navy Officer",
    "Republic Navy Command",
}, {

    {
        name         = "Wilhuff Tarkin",
        description  = "A strategic Republic naval officer known for his ruthless efficiency.",
        icon         = "icon16/user.png",
        model        = "models/navy/gnavytarkin.mdl",
        accentColor  = Color(80, 160, 220),
        weapons      = NAVY_WEAPONS,
        stripWeapons = true,
        allowedRanks = nil,
        category     = "Republic Navy",
    },

    {
        name         = "Wullf Yularen",
        description  = "Admiral of the Republic Navy and close military advisor to the Jedi.",
        icon         = "icon16/user.png",
        model        = "models/navy/gnavyyularen.mdl",
        accentColor  = Color(80, 160, 220),
        weapons      = NAVY_WEAPONS,
        stripWeapons = true,
        allowedRanks = nil,
        category     = "Republic Navy",
    },

    {
        name         = "Dao",
        description  = "A Republic naval officer responsible for fleet coordination.",
        icon         = "icon16/user.png",
        model        = "models/navy/gnavydao.mdl",
        accentColor  = Color(80, 160, 220),
        weapons      = NAVY_WEAPONS,
        stripWeapons = true,
        allowedRanks = nil,
        category     = "Republic Navy",
    },

    {
        name         = "Orson Krennic",
        description  = "An ambitious officer working within the Republic military structure.",
        icon         = "icon16/user.png",
        model        = "models/navy/gnavykrennic.mdl",
        accentColor  = Color(80, 160, 220),
        weapons      = NAVY_WEAPONS,
        stripWeapons = true,
        allowedRanks = nil,
        category     = "Republic Navy",
    },

    {
        name         = "Kilian",
        description  = "A Republic Navy officer serving within fleet command operations.",
        icon         = "icon16/user.png",
        model        = "models/navy/gnavykilian.mdl",
        accentColor  = Color(80, 160, 220),
        weapons      = NAVY_WEAPONS,
        stripWeapons = true,
        allowedRanks = nil,
        category     = "Republic Navy",
    },

    {
        name         = "Armand Isard",
        description  = "A Republic intelligence and naval official overseeing strategic operations.",
        icon         = "icon16/user.png",
        model        = "models/navy/gnavyarmand.mdl",
        accentColor  = Color(80, 160, 220),
        weapons      = NAVY_WEAPONS,
        stripWeapons = true,
        allowedRanks = nil,
        category     = "Republic Navy",
    },

})
