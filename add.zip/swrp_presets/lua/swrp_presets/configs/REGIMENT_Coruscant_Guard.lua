-- ============================================================
--  SWRP Preset Config: 501st Legion
--  All 501st tiers share the same preset list.
--  Add or remove job names from the table below as needed.
-- ============================================================

SWRP_PRESETS.RegisterJobs({
    "Coruscant Guard NCO",
    "Coruscant Guard Officer",
    "Coruscant Guard Command",
}, {

    {
        name         = "Commander Fox",
        description  = "",
        icon         = "icon16/user.png",
        model        = "models/aussiwozzi/cgi/base/cg_fox.mdl",
        accentColor  = Color(80, 160, 220),
        weapons      = {
            "arccw_cgi_k_dc15s",
            "arccw_cgi_k_dc15a",
            "arccw_cgi_k_akimbo_dc17_ext",
            "weapon_boosterpack",
            "weapon_officer_boost",
            "mvp_perfecthands",
            "climb_swep2",
        },
        stripWeapons = true,
        allowedRanks = nil,
        category     = "Lore Characters",
    },

    {
        name         = "Thorn",
        description  = "",
        icon         = "icon16/user.png",
        model        = "models/aussiwozzi/cgi/base/cg_thorn.mdl",
        accentColor  = Color(80, 160, 220),
        weapons      = {
            "arccw_cgi_k_dc15s",
            "arccw_cgi_k_dc15a",
            "arccw_cgi_k_akimbo_dc17_ext",
            "weapon_boosterpack",
            "weapon_officer_boost",
            "mvp_perfecthands",
            "climb_swep2",
        },
        stripWeapons = true,
        allowedRanks = nil,
        category     = "Lore Characters",
    },

    {
        name         = "Hound",
        description  = "",
        icon         = "icon16/user.png",
        model        = "models/aussiwozzi/cgi/base/cg_hound.mdl",
        accentColor  = Color(80, 160, 220),
        weapons      = {
            "arccw_cgi_k_dc15s",
            "arccw_cgi_k_dc15a",
            "arccw_cgi_k_akimbo_dc17_ext",
            "weapon_boosterpack",
            "weapon_officer_boost",
            "mvp_perfecthands",
            "climb_swep2",
        },
        stripWeapons = true,
        allowedRanks = nil,
        category     = "Lore Characters",
    },
    
    {
        name         = "Stone",
        description  = "",
        icon         = "icon16/user.png",
        model        = "models/aussiwozzi/cgi/base/cg_stone.mdl",
        accentColor  = Color(80, 160, 220),
        weapons      = {
            "arccw_cgi_k_dc15s",
            "arccw_cgi_k_dc15a",
            "arccw_cgi_k_akimbo_dc17_ext",
            "weapon_boosterpack",
            "weapon_officer_boost",
            "mvp_perfecthands",
            "climb_swep2",
        },
        stripWeapons = true,
        allowedRanks = nil,
        category     = "Lore Characters",
    },

    {
        name         = "Jek",
        description  = "",
        icon         = "icon16/user.png",
        model        = "models/aussiwozzi/cgi/base/cg_jek.mdl",
        accentColor  = Color(80, 160, 220),
        weapons      = {
            "arccw_cgi_k_dc15s",
            "arccw_cgi_k_dc15a",
            "arccw_cgi_k_akimbo_dc17_ext",
            "weapon_boosterpack",
            "weapon_officer_boost",
            "mvp_perfecthands",
            "climb_swep2",
        },
        stripWeapons = true,
        allowedRanks = nil,
        category     = "Lore Characters",
    },

    {
        name         = "Rys",
        description  = "",
        icon         = "icon16/user.png",
        model        = "models/aussiwozzi/cgi/base/cg_rys.mdl",
        accentColor  = Color(80, 160, 220),
        weapons      = {
            "arccw_cgi_k_dc15s",
            "arccw_cgi_k_dc15a",
            "arccw_cgi_k_akimbo_dc17_ext",
            "weapon_boosterpack",
            "weapon_officer_boost",
            "mvp_perfecthands",
            "climb_swep2",
        },
        stripWeapons = true,
        allowedRanks = nil,
        category     = "Lore Characters",
    },

    {
        name         = "Thire",
        description  = "",
        icon         = "icon16/user.png",
        model        = "models/aussiwozzi/cgi/base/cg_thire.mdl",
        accentColor  = Color(80, 160, 220),
        weapons      = {
            "arccw_cgi_k_dc15s",
            "arccw_cgi_k_dc15a",
            "arccw_cgi_k_akimbo_dc17_ext",
            "weapon_boosterpack",
            "weapon_officer_boost",
            "mvp_perfecthands",
            "climb_swep2",
        },
        stripWeapons = true,
        allowedRanks = nil,
        category     = "Lore Characters",
    },

    -- Add more 501st presets here

})