-- ============================================================
--  SWRP Preset Config: Republic Navy
--  All Navy tiers share the same preset list.
--  Add or remove job names from the table below as needed.
-- ============================================================

local NAVY_WEAPONS = {
    "arccw_cgi_k_dc15s",
    "arccw_cgi_k_dc17_navy",
    "sw_navypad",
    "mvp_perfecthands",
    "climb_swep2",
}

SWRP_PRESETS.RegisterJobs({
    "Republic high Command",

}, {

    {
        name         = "RHC 1st",
        description  = "",
        icon         = "icon16/user.png",
        model        = "models/linguine/playermodels/bluemilk_rhc/bluemilk_rhc.mdl",
        accentColor  = Color(80, 160, 220),
        weapons      = NAVY_WEAPONS,
        stripWeapons = true,
        allowedRanks = nil,
        category     = "High Command",
    },

    {
        name         = "RHC 2nd",
        description  = "",
        icon         = "icon16/user.png",
        model        = "models/linguine/playermodels/arc_rhc/rhc_arc_red.mdl",
        accentColor  = Color(80, 160, 220),
        weapons      = NAVY_WEAPONS,
        stripWeapons = true,
        allowedRanks = nil,
        category     = "High Command",
    },

    {
        name         = "RHC 3rd",
        description  = "",
        icon         = "icon16/user.png",
        model        = "models/linguine/playermodels/lala/lala_rhc.mdl",
        accentColor  = Color(80, 160, 220),
        weapons      = NAVY_WEAPONS,
        stripWeapons = true,
        allowedRanks = nil,
        category     = "High Command",
    },

})
