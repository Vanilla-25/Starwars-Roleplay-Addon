-- ============================================================
--  SWRP Preset Config: 501st Legion
--  All 501st tiers share the same preset list.
--  Add or remove job names from the table below as needed.
-- ============================================================

SWRP_PRESETS.RegisterJobs({
    "501st Enlisted",
    "501st NCO",
    "501st Officer",
    "501st Command",
}, {

    {
        name         = "Captain Rex",
        description  = "Captain of the 501st Legion, known for his resourcefulness and loyalty.",
        icon         = "icon16/user.png",
        model        = "models/aussiwozzi/cgi/base/501st_rex.mdl",
        accentColor  = Color(80, 160, 220),
        weapons      = {
            "arccw_cgi_k_dc15s",
            "arccw_cgi_k_dc15a",
            "arccw_cgi_k_akimbo_dc17_ext",
            "weapon_boosterpack",
            "weapon_officer_boost",
            "mvp_perfecthands",
            "climb_swep2",
        },
        stripWeapons = true,
        allowedRanks = nil,
        category     = "Lore Characters",
    },

    -- Add more 501st presets here

})
