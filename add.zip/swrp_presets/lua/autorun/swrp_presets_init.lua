-- ============================================================
--  SWRP Preset System - Autorun Entry Point
-- ============================================================

SWRP_PRESETS = {}

-- ============================================================
--  API: Register presets for a single job
-- ============================================================
function SWRP_PRESETS.RegisterJob(jobName, presets)
    SWRP_PRESETS[jobName] = presets
end

-- ============================================================
--  API: Register the SAME preset table for multiple jobs at once.
--  Use this when several ranks/tiers in a regiment share identical
--  presets — define the presets once, pass all job names in jobs{}.
--
--  Example:
--    SWRP_PRESETS.RegisterJobs({
--        "77th Trooper Enlisted",
--        "77th Trooper NCO",
--        "77th Trooper Officer",
--        "77th Trooper Command",
--    }, { ... presets ... })
-- ============================================================
function SWRP_PRESETS.RegisterJobs(jobs, presets)
    for _, jobName in ipairs(jobs) do
        SWRP_PRESETS[jobName] = presets
    end
end

-- ============================================================
--  Helper: Get presets for a player's current job
-- ============================================================
function SWRP_PRESETS.GetPresetsForPlayer(ply)
    if not IsValid(ply) then return nil end
    local job = ply:getDarkRPVar("job")
    if not job then return nil end
    local jobLower = string.lower(job)
    for jobCmd, presets in pairs(SWRP_PRESETS) do
        if type(presets) == "table" and type(jobCmd) == "string" then
            if string.lower(jobCmd) == jobLower then
                return presets, jobCmd
            end
        end
    end
    return nil
end

-- ============================================================
--  Load all config files
-- ============================================================
local configPath = "swrp_presets/configs/"

if SERVER then
    local files = file.Find("lua/" .. configPath .. "*.lua", "GAME")
    for _, f in ipairs(files) do
        AddCSLuaFile(configPath .. f)
        include(configPath .. f)
    end
    include("swrp_presets/sv/sv_presets.lua")
    AddCSLuaFile("swrp_presets/cl/cl_presets.lua")
end

if CLIENT then
    local files = file.Find(configPath .. "*.lua", "LUA")
    for _, f in ipairs(files) do
        include(configPath .. f)
    end
    include("swrp_presets/cl/cl_presets.lua")
end

print("[SWRP Presets] Loaded successfully.")