# sw_navypad — Naval Command Datapad

A Garry's Mod SWEP addon providing a sleek in-game Navy command datapad UI.

## File Structure

```
sw_navypad/
├── lua/
│   ├── autorun/
│   │   └── navypad_init.lua        ← Loads menu on client, registers CSLua on server
│   ├── navypad/
│   │   └── navypad_menu.lua        ← Full UI: DEFCON, Requests, Training pages
│   └── weapons/
│       └── sw_navypad/
│           └── shared.lua          ← SWEP definition; left-click opens menu
└── README.md
```

## Pages

| Icon | Page | Description |
|------|------|-------------|
| 🔔 Bell | DEFCON Status | Set current DEFCON level (5→1) with colour-coded cards |
| 📄 Document | Incoming Requests | View, approve, or deny pending requests |
| 📊 Chart | Training Room Stats | Visual progress bars for training metrics |

## Installation

1. Drop the `sw_navypad` folder into `garrysmod/addons/`.
2. Restart the server (or use `lua_openscript_cl` in a dev environment).
3. Spawn the **Navy Pad** weapon from the **[Helix] Equipment** category.
4. Left-click to open the menu.

## Extending

- **Add more request entries** — edit `NavyPad.Requests` table in `navypad_menu.lua`.
- **Add more training stats** — edit `NavyPad.TrainingStats`.
- **Sync DEFCON over the network** — add a `net` message in `shared.lua` and broadcast from the `DoClick` handler in `BuildDefconPage`.
- **Add more sidebar pages** — push a new entry into `navItems` and add a matching `Build*Page` function.
