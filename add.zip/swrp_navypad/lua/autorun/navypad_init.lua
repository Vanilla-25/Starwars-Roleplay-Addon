-- Navy Pad autorun loader
if SERVER then
	AddCSLuaFile( "navypad/navypad_menu.lua" )
end

if CLIENT then
	include( "navypad/navypad_menu.lua" )
end