-- ============================================================
--  NAVAL COMMAND DATAPAD  |  sw_navypad
--  UI overhauled — skill-points aesthetic
-- ============================================================

NavyPad = NavyPad or {}
NavyPad.CurrentDefcon = 5
NavyPad.ActivePage    = "home"

-- ── Fonts ─────────────────────────────────────────────────────
surface.CreateFont( "NP_Title",    { font = "Roboto", size = 17, weight = 800 } )
surface.CreateFont( "NP_SectLbl",  { font = "Roboto", size = 11, weight = 700 } )
surface.CreateFont( "NP_Body",     { font = "Roboto", size = 13, weight = 500 } )
surface.CreateFont( "NP_BodyBold", { font = "Roboto", size = 13, weight = 800 } )
surface.CreateFont( "NP_Small",    { font = "Roboto", size = 11, weight = 400 } )
surface.CreateFont( "NP_SmBold",   { font = "Roboto", size = 11, weight = 700 } )
surface.CreateFont( "NP_Micro",    { font = "Roboto", size = 10, weight = 400 } )
surface.CreateFont( "NP_DefNum",   { font = "Roboto", size = 36, weight = 900 } )
surface.CreateFont( "NP_DefTitle", { font = "Roboto", size = 13, weight = 800 } )
surface.CreateFont( "NP_Welcome",  { font = "Roboto", size = 26, weight = 900 } )
surface.CreateFont( "NP_Stat",     { font = "Roboto", size = 13, weight = 700 } )
surface.CreateFont( "NP_PerkName", { font = "Roboto", size = 13, weight = 700 } )
surface.CreateFont( "NP_HudMain", { font = "Roboto", size = 14, weight = 900 } )
surface.CreateFont( "NP_HudSub",  { font = "Roboto", size = 10, weight = 700 } )

-- ── Theme — exact skill points palette ───────────────────────
local T = {
    Bg        = Color(12,  14,  18),
    Panel     = Color(18,  21,  27),
    Panel2    = Color(23,  27,  34),
    Card      = Color(28,  33,  42),
    CardHov   = Color(36,  43,  55),
    CardSel   = Color(32,  44,  64),
    Border    = Color(42,  52,  68),
    BorderDim = Color(28,  36,  48),
    Accent    = Color(100, 160, 255),
    AccentBg  = Color(18,  30,  60),
    Text      = Color(218, 224, 235),
    Dim       = Color(105, 120, 145),
    Faint     = Color(60,  74,  92),
    Green     = Color(55,  210, 115),
    GreenBg   = Color(16,  40,  26),
    Danger    = Color(220, 75,  75),
    DangerBg  = Color(50,  16,  16),
    Gold      = Color(230, 185, 60),
    Amber     = Color(230, 185, 60),
    AmberBg   = Color(50,  38,  10),
    -- DEFCON colours
    D5 = Color(30,  220, 120),
    D4 = Color(120, 210, 40),
    D3 = Color(255, 190, 0),
    D2 = Color(255, 100, 10),
    D1 = Color(230, 20,  20),
}
local function FA(c, a) return ColorAlpha(c, a) end

-- ── Draw helpers ──────────────────────────────────────────────
local function Rect(x, y, w, h, c)    draw.RoundedBox(0, x, y, w, h, c) end
local function RRct(r, x, y, w, h, c) draw.RoundedBox(r, x, y, w, h, c) end
local function Bord(x, y, w, h, c)    surface.SetDrawColor(c); surface.DrawOutlinedRect(x,y,w,h,1) end
local function Ln(x1,y1,x2,y2,c)      surface.SetDrawColor(c); surface.DrawLine(x1,y1,x2,y2) end
local function Txt(t,f,x,y,c,ax,ay)   draw.SimpleText(t,f,x,y,c,ax or 0,ay or 0) end

local function DrawBar(x, y, w, h, frac, col)
    RRct(h, x, y, w, h, Color(10,12,20))
    if frac > 0 then
        RRct(h, x, y, math.max(math.floor(w * frac), h), h, col or T.Accent)
    end
    Bord(x, y, w, h, FA(T.Border, 200))
end

local function DrawPips(x, y, current, maxPts, col)
    local pw, gap = 10, 3
    for i = 1, maxPts do
        local px = x + (i-1)*(pw+gap)
        local filled = i <= current
        RRct(2, px, y, pw, pw, filled and (current >= maxPts and T.Gold or (col or T.Accent)) or Color(10,12,20))
        if not filled then Bord(px, y, pw, pw, FA(T.Border, 160)) end
    end
end

-- ── DEFCON data ───────────────────────────────────────────────
local DefconColors = { T.D5, T.D4, T.D3, T.D2, T.D1 }
NavyPad.DefconLevels = {
    [5] = { label="DEFCON 5", title="Normal Duties",   desc="All clear. Continue standard operations.",          color=T.D5 },
    [4] = { label="DEFCON 4", title="Possible Threat", desc="Possible threat. Weapons out, on safety.",          color=T.D4 },
    [3] = { label="DEFCON 3", title="Threat Imminent", desc="Threat imminent. Weapons free, off safety.",        color=T.D3 },
    [2] = { label="DEFCON 2", title="Lockdown",        desc="Lockdown all major areas immediately.",             color=T.D2 },
    [1] = { label="DEFCON 1", title="Evacuate",        desc="Evacuate all non-essential personnel now.",         color=T.D1 },
}

NavyPad.Requests = {}
NavyPad.TrainingStats = {
    { name="Marksmanship",    score=87, max=100, unit="pts" },
    { name="Navigation",      score=92, max=100, unit="pts" },
    { name="Hand-to-Hand",    score=74, max=100, unit="pts" },
    { name="Protocol",        score=95, max=100, unit="pts" },
    { name="Active Trainees", score=12, max=20,  unit=""    },
    { name="Room Capacity",   score=18, max=20,  unit=""    },
}

-- ══════════════════════════════════════════════════════════════
--  OPEN MENU
-- ══════════════════════════════════════════════════════════════
function NavyPad.OpenMenu()
    if IsValid(NavyPad._frame) then NavyPad._frame:Remove() end

    local W, H   = 980, 620
    local HDR_H  = 46
    local SB_W   = 52
    local PAD    = 8

    local frame = vgui.Create("DFrame")
    NavyPad._frame = frame
    frame:SetSize(W, H)
    frame:Center()
    frame:SetTitle("")
    frame:SetDraggable(true)
    frame:ShowCloseButton(false)
    frame:MakePopup()

    -- ── Main frame paint ──────────────────────────────────────
    frame.Paint = function(self, w, h)
        -- Base
        RRct(6, 0, 0, w, h, T.Bg)
        -- Header bar
        RRct(6, 0, 0, w, HDR_H, T.Panel)
        -- Cyan top accent
        surface.SetDrawColor(T.Accent)
        surface.DrawRect(0, 0, w, 2)
        -- Divider
        surface.SetDrawColor(FA(T.Border, 200))
        surface.DrawRect(0, HDR_H, w, 1)
        -- Outer border
        Bord(0, 0, w, h, FA(T.Border, 200))

        -- Logo: small accent box with icon
        RRct(4, 10, 8, 30, 30, T.Panel2)
        Bord(10, 8, 30, 30, FA(T.Accent, 160))
        surface.SetDrawColor(FA(T.Accent, 200))
        surface.DrawRect(22, 15, 8, 2)
        surface.DrawRect(22, 19, 8, 2)
        surface.DrawRect(22, 23, 5, 2)

        -- Title
        Txt("NAVAL COMMAND DATAPAD", "NP_Title", w/2, HDR_H/2, T.Text, 1, 1)

        -- DEFCON status right
        local def = NavyPad.DefconLevels[NavyPad.CurrentDefcon]
        local sx = w - 16
        Txt(def.label .. "  ·  " .. string.upper(def.title), "NP_Micro", sx, HDR_H/2, def.color, 2, 1)
    end

    -- ── Close button ──────────────────────────────────────────
    local close = vgui.Create("DButton", frame)
    close:SetSize(26, 26)
    close:SetPos(W-36, 10)
    close:SetText("")
    local cH, cL = 0, CurTime()
    close.Think = function()
        local dt = CurTime()-cL; cL = CurTime()
        cH = math.Approach(cH, close:IsHovered() and 1 or 0, dt*14)
    end
    close.Paint = function(s, w, h)
        RRct(4, 0, 0, w, h, FA(T.DangerBg, math.Round(140 + 115*cH)))
        Bord(0, 0, w, h, FA(T.Danger, math.Round(80 + 175*cH)))
        surface.SetDrawColor(ColorAlpha(T.Text, math.Round(100 + 155*cH)))
        surface.DrawLine(7, 7, w-7, h-7)
        surface.DrawLine(w-7, 7, 7, h-7)
    end
    close.DoClick = function() frame:Remove() end

    -- ── Sidebar ───────────────────────────────────────────────
    local sb = vgui.Create("DPanel", frame)
    sb:SetSize(SB_W, H - HDR_H)
    sb:SetPos(0, HDR_H)
    sb.Paint = function(s, w, h)
        Rect(0, 0, w, h, T.Panel)
        surface.SetDrawColor(FA(T.Border, 200))
        surface.DrawRect(w-1, 0, 1, h)
        surface.SetDrawColor(FA(T.Accent, 80))
        surface.DrawRect(10, 0, w-20, 1)
    end

    local navs = {
        { page="home",     tip="Home",
          drawIcon = function(cx, cy, act)
              local c = act and T.Accent or T.Dim
              surface.SetDrawColor(c)
              surface.DrawRect(cx-9, cy-11, 18, 15)
              surface.DrawRect(cx-5, cy+4, 10, 5)
              surface.SetDrawColor(act and T.Amber or T.Faint)
              surface.DrawRect(cx-6, cy-8, 12, 2)
              surface.DrawRect(cx-6, cy-4, 12, 2)
              surface.DrawRect(cx-6, cy,   8,  2)
          end },
        { page="defcon",   tip="DEFCON Status",
          drawIcon = function(cx, cy, act)
              local c = act and T.Accent or T.Dim
              surface.SetDrawColor(c)
              surface.DrawRect(cx-7,  cy-11, 14, 11)
              surface.DrawRect(cx-10, cy,    20,  4)
              surface.DrawRect(cx-3,  cy+4,   6,  4)
              if act then
                  surface.SetDrawColor(T.Amber)
                  surface.DrawRect(cx-2, cy-14, 4, 4)
              end
          end },
        { page="requests", tip="Requests & Training",
          drawIcon = function(cx, cy, act)
              local c = act and T.Accent or T.Dim
              surface.SetDrawColor(c)
              surface.DrawRect(cx-11, cy-9, 10, 18)
              surface.DrawRect(cx+1,  cy-9, 10, 18)
              if act then
                  surface.SetDrawColor(T.Amber)
                  surface.DrawRect(cx-1, cy-9, 2, 18)
              end
          end },
    }

    for i, nav in ipairs(navs) do
        local btn = vgui.Create("DButton", sb)
        btn:SetSize(SB_W, 56)
        btn:SetPos(0, 4 + (i-1)*60)
        btn:SetText("")
        btn:SetTooltip(nav.tip)
        local bH2, bL2 = 0, CurTime()
        btn.Think = function()
            local dt = CurTime()-bL2; bL2 = CurTime()
            bH2 = math.Approach(bH2, btn:IsHovered() and 1 or 0, dt*14)
        end
        btn.Paint = function(s, w, h)
            local act = NavyPad.ActivePage == nav.page
            if act then
                Rect(0, 0, w, h, FA(T.AccentBg, 180))
                surface.SetDrawColor(T.Accent)
                surface.DrawRect(0, 0, 3, h)
                surface.SetDrawColor(FA(T.Border, 200))
                surface.DrawRect(0, 0, w, 1)
                surface.DrawRect(0, h-1, w, 1)
            elseif bH2 > 0 then
                Rect(0, 0, w, h, FA(T.CardHov, math.Round(bH2*160)))
            end
            nav.drawIcon(w/2, h/2, act)
        end
        btn.DoClick = function()
            NavyPad.ActivePage = nav.page
            NavyPad.RefreshContent()
        end
    end

    -- Subtle bottom divider pip
    local vbadge = vgui.Create("DPanel", sb)
    vbadge:SetSize(SB_W, 28)
    vbadge:SetPos(0, H-HDR_H-32)
    vbadge.Paint = function(s, w, h)
        surface.SetDrawColor(FA(T.Border, 180))
        surface.DrawRect(8, 0, w-16, 1)
        for k = 0, 2 do
            RRct(2, w/2 - 8 + k*8, 10, 4, 4,
                FA(T.Accent, 40 + k*40))
        end
    end

    -- ── Content area ──────────────────────────────────────────
    local content = vgui.Create("DPanel", frame)
    content:SetSize(W - SB_W - 10, H - HDR_H - 6)
    content:SetPos(SB_W + 6, HDR_H + 3)
    content.Paint = function() end
    NavyPad._content = content

    NavyPad.RefreshContent()
end

-- ══════════════════════════════════════════════════════════════
function NavyPad.RefreshContent()
    local c = NavyPad._content
    if not IsValid(c) then return end
    for _, v in ipairs(c:GetChildren()) do v:Remove() end
    local W, H = c:GetSize()
    if     NavyPad.ActivePage == "home"     then NavyPad.BuildHome(c, W, H)
    elseif NavyPad.ActivePage == "defcon"   then NavyPad.BuildDefcon(c, W, H)
    elseif NavyPad.ActivePage == "requests" then NavyPad.BuildRequests(c, W, H)
    end
end

-- ══════════════════════════════════════════════════════════════
--  HOME
-- ══════════════════════════════════════════════════════════════
function NavyPad.BuildHome(parent, W, H)
    local PAD = 10

    -- Main bg panel
    local p = vgui.Create("DPanel", parent)
    p:SetSize(W, H)
    p:SetPos(0, 0)
    p.Paint = function(self, w, h)
        Rect(0, 0, w, h, T.Bg)
    end

    local name = IsValid(LocalPlayer()) and LocalPlayer():Name() or "Commander"

    -- ── Welcome card ──────────────────────────────────────────
    local welCard = vgui.Create("DPanel", p)
    welCard:SetPos(PAD, PAD)
    welCard:SetSize(W - PAD*2, 160)
    welCard.Paint = function(self, w, h)
        RRct(5, 0, 0, w, h, T.Card)
        Bord(0, 0, w, h, T.Border)
        surface.SetDrawColor(T.Accent)
        surface.DrawRect(0, 0, w, 2)

        -- Faint horizontal rule lines for depth
        surface.SetDrawColor(FA(T.Border, 120))
        surface.DrawRect(12, 60, w-24, 1)
        surface.DrawRect(12, h-60, w-24, 1)

        -- Welcome text
        Txt("WELCOME, " .. string.upper(name), "NP_Welcome", w/2, h/2+0, T.Text, 1, 1)
        Txt("SELECT A MODULE FROM THE SIDEBAR TO CONTINUE.", "NP_Micro", w/2, h/2+24, FA(T.Dim, 200), 1, 1)

        -- Amber rule
        local rw = 160
        surface.SetDrawColor(FA(T.Amber, 140))
        surface.DrawRect(w/2 - rw/2, h/2+15, rw, 1)
    end

    -- ── Status bar ────────────────────────────────────────────
    local def = NavyPad.DefconLevels[NavyPad.CurrentDefcon]

    local statusCard = vgui.Create("DPanel", p)
    statusCard:SetPos(PAD, PAD + 170)
    statusCard:SetSize(W - PAD*2, 60)
    statusCard.Paint = function(self, w, h)
        RRct(5, 0, 0, w, h, T.Card)
        Bord(0, 0, w, h, T.Border)
        local dc = NavyPad.DefconLevels[NavyPad.CurrentDefcon]
        surface.SetDrawColor(dc.color)
        surface.DrawRect(0, 0, w, 2)

        Txt("CURRENT STATUS", "NP_SectLbl", 14, 10, FA(T.Dim, 200))
        Txt(dc.label .. "  —  " .. string.upper(dc.title), "NP_BodyBold", 14, 28, dc.color)

        Txt("REPUBLIC NAVAL AUTHORITY  ◆  SECTOR 7 COMMAND", "NP_Micro", w - 14, 36, FA(T.Dim, 160), 2, 1)
    end

    -- ── Quick-stat cards ──────────────────────────────────────
    local stats = {
        { label = "DEFCON LEVEL", value = tostring(NavyPad.CurrentDefcon), col = def.color },
        { label = "OPEN REQUESTS", value = tostring(#NavyPad.Requests),   col = T.Accent  },
        { label = "ACTIVE MODULE", value = "HOME",                         col = T.Amber   },
    }
    local cardW = math.floor((W - PAD*2 - 8*2) / 3)
    for i, s in ipairs(stats) do
        local sc = vgui.Create("DPanel", p)
        sc:SetPos(PAD + (i-1)*(cardW + 8), PAD + 240)
        sc:SetSize(cardW, 78)
        sc.Paint = function(self, w, h)
            RRct(5, 0, 0, w, h, T.Card)
            Bord(0, 0, w, h, T.Border)
            surface.SetDrawColor(s.col)
            surface.DrawRect(0, 0, w, 2)
            Txt(s.label, "NP_SectLbl", 12, 12, FA(T.Dim, 200))
            Txt(s.value, "NP_Stat",    12, 36, s.col)
        end
    end

    -- ── Training overview strip ───────────────────────────────
    local trainingCard = vgui.Create("DPanel", p)
    trainingCard:SetPos(PAD, PAD + 330)
    trainingCard:SetSize(W - PAD*2, H - PAD - 330 - PAD)
    trainingCard.Paint = function(self, w, h)
        RRct(5, 0, 0, w, h, T.Card)
        Bord(0, 0, w, h, T.Border)
        surface.SetDrawColor(T.Accent)
        surface.DrawRect(0, 0, w, 2)
        Txt("TRAINING OVERVIEW", "NP_SectLbl", 12, 10, FA(T.Dim, 200))
        Ln(6, 26, w-6, 26, FA(T.Border, 200))

        local cols = math.ceil(#NavyPad.TrainingStats / 2)
        local colW = math.floor((w - 24) / cols)
        for idx, stat in ipairs(NavyPad.TrainingStats) do
            local col = (idx-1) % cols
            local row = math.floor((idx-1) / cols)
            local sx = 12 + col * colW
            local sy = 34 + row * 48

            local pct = stat.score / stat.max
            local barCol = pct >= 0.85 and T.Green or (pct >= 0.6 and T.Accent or T.D3)

            Txt(string.upper(stat.name), "NP_SmBold", sx, sy, T.Text)
            local sc2 = stat.unit ~= "" and (stat.score .. "/" .. stat.max .. " " .. stat.unit) or (stat.score .. "/" .. stat.max)
            Txt(sc2, "NP_Small", sx + colW - 10, sy, FA(T.Dim, 200), 2)

            DrawBar(sx, sy + 18, colW - 14, 8, pct, barCol)
        end
    end
end

-- ══════════════════════════════════════════════════════════════
--  DEFCON
-- ══════════════════════════════════════════════════════════════
function NavyPad.BuildDefcon(parent, W, H)
    local PAD = 10

    local p = vgui.Create("DPanel", parent)
    p:SetSize(W, H)
    p:SetPos(0, 0)
    p.Paint = function(self, w, h) Rect(0, 0, w, h, T.Bg) end

    -- Section header card
    local hdrCard = vgui.Create("DPanel", p)
    hdrCard:SetPos(PAD, PAD)
    hdrCard:SetSize(W - PAD*2, 44)
    hdrCard.Paint = function(self, w, h)
        RRct(5, 0, 0, w, h, T.Card)
        Bord(0, 0, w, h, T.Border)
        surface.SetDrawColor(T.Amber)
        surface.DrawRect(0, 0, w, 2)
        Txt("DEFCON STATUS CONTROL", "NP_Title", w/2, h/2, T.Text, 1, 1)
        Txt("AUTHORISED PERSONNEL ONLY — CHANGES BROADCAST FLEET-WIDE", "NP_Micro", w/2, h-10, FA(T.Dim, 180), 1, 1)
    end

    -- DEFCON level cards (5 → 1, displayed top to bottom)
    local cardH = 76
    local cardW = W - PAD*2

    for i = 5, 1, -1 do
        local lvl = NavyPad.DefconLevels[i]
        local idx = 6 - i
        local ry  = PAD + 54 + (idx-1) * (cardH + 6)

        local card = vgui.Create("DPanel", p)
        card:SetSize(cardW, cardH)
        card:SetPos(PAD, ry)

        local hH, hL = 0, CurTime()
        card.Think = function()
            local dt = CurTime()-hL; hL = CurTime()
            hH = math.Approach(hH, (NavyPad.CurrentDefcon ~= i and card:IsHovered()) and 1 or 0, dt*14)
        end

        card.Paint = function(self, w, h)
            local act = NavyPad.CurrentDefcon == i
            local t   = CurTime()

            -- Background
            if act then
                RRct(5, 0, 0, w, h, T.Card)
                -- Tinted layer
                RRct(5, 0, 0, w, h, ColorAlpha(lvl.color, 18))
            else
                RRct(5, 0, 0, w, h, hH > 0 and T.CardHov or T.Card)
            end

            -- Top accent line
            surface.SetDrawColor(act and lvl.color or FA(lvl.color, 80))
            surface.DrawRect(0, 0, w, 2)

            -- Left colour slab
            RRct(3, 0, 2, 6, h-4, ColorAlpha(lvl.color, act and 220 or 90))

            -- DEFCON number
            Txt(tostring(i), "NP_DefNum", 46, h/2, act and lvl.color or FA(lvl.color, 140), 1, 1)

            -- Separator
            surface.SetDrawColor(act and FA(T.Accent, 120) or FA(T.Border, 160))
            surface.DrawRect(78, 10, 1, h-20)

            -- Label + desc
            Txt(string.upper(lvl.title), "NP_DefTitle", 92, h/2 - 12, act and T.Text or FA(T.Text, 180))
            Txt(lvl.desc, "NP_Small", 92, h/2 + 5,  FA(T.Dim, 200))

            -- Active pulse indicator
            if act then
                local pr  = w - 55
                local pc  = h/2
                local ring = math.abs(math.sin(t*2.5)) * 6
                surface.SetDrawColor(ColorAlpha(lvl.color, 60 + math.floor(math.sin(t*2.5)*30)))
                surface.DrawOutlinedRect(pr-12-ring, pc-12-ring, (12+ring)*2, (12+ring)*2, 1)
                RRct(2, pr-4, pc-4, 8, 8, lvl.color)
                Txt("ACTIVE", "NP_Micro", pr, pc+12, lvl.color, 1)
            end

            -- Border
            if act then
                Bord(0, 0, w, h, FA(lvl.color, 180))
            else
                Bord(0, 0, w, h, FA(T.Border, hH > 0 and 200 or 160))
            end
        end

        -- Set Level button
        local btn = vgui.Create("DButton", card)
        btn:SetSize(100, 30)
        btn:SetPos(cardW - 114, (cardH - 30)/2)
        btn:SetText("")
        btn:SetCursor("hand")
        local bH2, bL2 = 0, CurTime()
        btn.Think = function()
            local dt = CurTime()-bL2; bL2 = CurTime()
            bH2 = math.Approach(bH2, btn:IsHovered() and 1 or 0, dt*14)
        end
        btn.Paint = function(s, bw, bh)
            if NavyPad.CurrentDefcon == i then return end
            RRct(4, 0, 0, bw, bh, FA(T.AccentBg, math.Round(180+75*bH2)))
            Bord(0, 0, bw, bh, FA(T.Accent, math.Round(80+175*bH2)))
            Txt("SET LEVEL", "NP_SmBold", bw/2, bh/2, bH2>0.4 and T.Text or FA(T.Accent,200), 1, 1)
        end
        btn.DoClick = function()
            NavyPad.CurrentDefcon = i
            NavyPad.ShowAlert(i)
            if IsValid(NavyPad._frame) then NavyPad._frame:InvalidateLayout() end
            NavyPad.RefreshContent()
        end
    end
end

-- ══════════════════════════════════════════════════════════════
--  REQUESTS + TRAINING
-- ══════════════════════════════════════════════════════════════
function NavyPad.BuildRequests(parent, W, H)
    local PAD  = 10
    local halfW = math.floor((W - PAD*3) / 2)

    local p = vgui.Create("DPanel", parent)
    p:SetSize(W, H)
    p:SetPos(0, 0)
    p.Paint = function(self, w, h) Rect(0, 0, w, h, T.Bg) end

    -- ── Left: Incoming Requests ───────────────────────────────
    local left = vgui.Create("DPanel", p)
    left:SetPos(PAD, PAD)
    left:SetSize(halfW, H - PAD*2)
    left.Paint = function(self, w, h)
        RRct(5, 0, 0, w, h, T.Card)
        Bord(0, 0, w, h, T.Border)
        surface.SetDrawColor(T.Cyan or T.Accent)
        surface.DrawRect(0, 0, w, 2)
        Txt("INCOMING REQUESTS", "NP_Title", w/2, 14, T.Text, 1, 1)
        Ln(6, 32, w-6, 32, FA(T.Border, 200))
    end

    -- Scroll list
    local scroll = vgui.Create("DScrollPanel", left)
    scroll:SetSize(halfW - 16, H - PAD*2 - 40)
    scroll:SetPos(8, 38)
    scroll:GetVBar():SetWide(3)

    if #NavyPad.Requests == 0 then
        local empty = vgui.Create("DPanel", scroll)
        empty:SetSize(halfW - 24, 80)
        empty:Dock(TOP)
        empty:DockMargin(0, 8, 0, 0)
        empty.Paint = function(self, w, h)
            RRct(4, 0, 0, w, h, T.Panel2)
            Bord(0, 0, w, h, FA(T.Border, 160))
            Txt("NO CLAIM REQUESTS", "NP_SmBold", w/2, h/2-8, FA(T.Dim, 200), 1, 1)
            Txt("All clear.", "NP_Small", w/2, h/2+8, T.Faint, 1, 1)
        end
    else
        for _, req in ipairs(NavyPad.Requests) do
            local sc = req.status == "Approved" and T.Green or (req.status == "Denied" and T.Danger or T.D3)
            local row = vgui.Create("DPanel", scroll)
            row:SetSize(halfW - 24, 64)
            row:Dock(TOP)
            row:DockMargin(0, 0, 0, 6)
            row.Paint = function(self, w, h)
                RRct(4, 0, 0, w, h, T.Panel2)
                -- Status left bar
                RRct(3, 0, 0, 4, h, sc)
                Bord(0, 0, w, h, FA(T.Border, 160))
                Txt(req.from,   "NP_BodyBold", 12, 10, T.Text)
                Txt(req.detail, "NP_Small",    12, 28, FA(T.Dim, 200))
                Txt(req.status, "NP_SmBold",   w-10, 10, sc, 2)
                Txt(req.time,   "NP_Small",    w-10, 28, T.Faint, 2)
            end
        end
    end

    -- ── Right: Training Stats ─────────────────────────────────
    local right = vgui.Create("DPanel", p)
    right:SetPos(PAD*2 + halfW, PAD)
    right:SetSize(halfW, H - PAD*2)
    right.Paint = function(self, w, h)
        RRct(5, 0, 0, w, h, T.Card)
        Bord(0, 0, w, h, T.Border)
        surface.SetDrawColor(T.Amber)
        surface.DrawRect(0, 0, w, 2)
        Txt("TRAINING ROOM STATUS", "NP_Title", w/2, 14, T.Text, 1, 1)
        Ln(6, 32, w-6, 32, FA(T.Border, 200))
    end

    for i, stat in ipairs(NavyPad.TrainingStats) do
        local pct    = stat.score / stat.max
        local barCol = pct >= 0.85 and T.Green or (pct >= 0.6 and T.Accent or T.D3)

        local row = vgui.Create("DPanel", right)
        row:SetSize(halfW - 24, 52)
        row:SetPos(12, 40 + (i-1) * 58)
        row.Paint = function(self, w, h)
            RRct(4, 0, 0, w, h, T.Panel2)
            Bord(0, 0, w, h, FA(T.Border, 160))

            -- Coloured left accent
            RRct(3, 0, 0, 4, h, FA(barCol, 180))

            Txt(string.upper(stat.name), "NP_SmBold", 12, 9, T.Text)
            local sc2 = stat.unit ~= "" and (stat.score .. "/" .. stat.max .. " " .. stat.unit) or (stat.score .. "/" .. stat.max)
            Txt(sc2, "NP_Small", w-10, 9, FA(T.Dim, 200), 2)

            -- Bar
            DrawBar(12, 30, w - 52, 8, pct, barCol)

            -- Percentage
            Txt(math.floor(pct*100) .. "%", "NP_SmBold", w-10, 26, barCol, 2)
        end
    end
end

-- ══════════════════════════════════════════════════════════════
--  ALERT TOAST
-- ══════════════════════════════════════════════════════════════
function NavyPad.ShowAlert(level)
    local lvl = NavyPad.DefconLevels[level]
    if not lvl then return end
    if IsValid(NavyPad._alert) then NavyPad._alert:Remove() end

    local SW, SH = ScrW(), ScrH()
    local AW, AH = 320, 108
    local pad    = 20
    local ax     = SW - AW - pad
    local ay     = SH - AH - pad

    local alert = vgui.Create("DPanel")
    NavyPad._alert = alert
    alert:SetSize(AW, AH)
    alert:SetPos(ax, ay + 30)
    alert:SetAlpha(0)
    alert:AlphaTo(255, 0.3, 0)
    alert:MoveTo(ax, ay, 0.3, 0, -1)

    alert._born = SysTime()
    alert.Paint = function(self, w, h)
        local col = lvl.color
        local age = SysTime() - self._born

        -- Base card
        RRct(5, 0, 0, w, h, T.Card)
        -- Tinted tint
        RRct(5, 0, 0, w, h, ColorAlpha(col, 14))
        -- Top bar
        surface.SetDrawColor(col)
        surface.DrawRect(0, 0, w, 2)
        -- Left slab
        RRct(3, 0, 2, 4, h-4, ColorAlpha(col, 160))
        -- Border
        Bord(0, 0, w, h, FA(col, 140))

        -- Icon box
        RRct(4, 10, 12, 40, 40, T.Panel2)
        Bord(10, 12, 40, 40, FA(col, 180))
        Txt(tostring(level), "NP_DefNum", 30, 32, col, 1, 1)

        -- Text
        Txt("DEFCON LEVEL CHANGED", "NP_SmBold", 60, 16, FA(T.Dim, 200))
        Txt(lvl.label,              "NP_BodyBold",60, 32, col)
        Txt(string.upper(lvl.title),"NP_Small",   60, 50, FA(T.Text, 200))
        Txt(lvl.desc,               "NP_Micro",   10, 76, FA(T.Dim, 180))

        -- Progress bar
        local progress = 1 - math.min(1, age/6)
        DrawBar(10, h-10, w-20, 5, progress, col)
    end

    timer.Simple(6, function()
        if IsValid(alert) then
            alert:AlphaTo(0, 0.5, 0, function()
                if IsValid(alert) then alert:Remove() end
            end)
        end
    end)
end
-- ══════════════════════════════════════════════════════════════
--  DEFCON HUD BADGE  (top-centre, only shown for DEFCON 1-4)
-- ══════════════════════════════════════════════════════════════
hook.Add("HUDPaint", "NavyPad_DefconHUD", function()
    local defcon = NavyPad.CurrentDefcon
    if defcon >= 5 then return end          -- DEFCON 5 = hide entirely

    local lvl = NavyPad.DefconLevels[defcon]
    if not lvl then return end

    local col   = lvl.color                 -- e.g. D4 green, D3 amber, etc.
    local label = string.upper(lvl.label)   -- "DEFCON 4"
    local sub   = string.upper(lvl.title)   -- "POSSIBLE THREAT"

    -- Badge dimensions — matches the screenshot proportions
    local BW, BH = 138, 36
    local bx = math.floor((ScrW() - BW) / 2)
    local by = 40   -- ~2 fingers from top

    -- Dark fill  (very dark, like the screenshot background)
    draw.RoundedBox(3, bx, by, BW, BH, Color(8, 18, 8, 230))

    -- Coloured border (1 px outline matching DEFCON colour)
    surface.SetDrawColor(ColorAlpha(col, 220))
    surface.DrawOutlinedRect(bx, by, BW, BH, 1)

    -- Thin top accent line inside border
    surface.SetDrawColor(ColorAlpha(col, 180))
    surface.DrawRect(bx + 1, by + 1, BW - 2, 2)

    -- "DEFCON 4" — main bold text, centred
    draw.SimpleText(label, "NP_HudMain", bx + BW/2, by + 11, col, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

    -- "POSSIBLE THREAT" — smaller subtitle, centred
    draw.SimpleText(sub, "NP_HudSub", bx + BW/2, by + 25, ColorAlpha(col, 200), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
end)