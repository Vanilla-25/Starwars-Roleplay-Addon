-- ============================================
--  Death System | Shared Config
-- ============================================

DEATH_SYSTEM = DEATH_SYSTEM or {}

-- How long the player must hold E to respawn (seconds)
DEATH_SYSTEM.RespawnHoldTime = 3

-- Material paths (relative to /materials/)
DEATH_SYSTEM.MatMedical = "death_system/medical_emblem"
DEATH_SYSTEM.MatSkull   = "death_system/skull"
