-- ============================================
--  Death System | Server
-- ============================================

util.AddNetworkString("DeathSystem_Respawn")
util.AddNetworkString("DeathSystem_PlayerDied")

-- Notify the dying player's client
hook.Add("PlayerDeath", "DeathSystem_OnDeath", function(victim, inflictor, attacker)
    if not IsValid(victim) then return end
    if not victim:IsPlayer() then return end

    print("[DeathSystem] PlayerDeath fired for: " .. victim:Nick())

    timer.Simple(0.1, function()
        if IsValid(victim) then
            print("[DeathSystem] Sending DeathSystem_PlayerDied to: " .. victim:Nick())
            net.Start("DeathSystem_PlayerDied")
            net.Send(victim)
        end
    end)
end)

-- Fallback: catch deaths that PlayerDeath may miss (e.g. world kills, suicide)
hook.Add("Think", "DeathSystem_DeathFallback", function()
    for _, ply in ipairs(player.GetAll()) do
        if IsValid(ply) and not ply:Alive() then
            if not ply.DS_WasDead then
                ply.DS_WasDead = true
                print("[DeathSystem] Fallback death detected for: " .. ply:Nick())
                net.Start("DeathSystem_PlayerDied")
                net.Send(ply)
            end
        else
            if IsValid(ply) then
                ply.DS_WasDead = false
            end
        end
    end
end)

-- Handle respawn request from the client
net.Receive("DeathSystem_Respawn", function(len, ply)
    if not IsValid(ply) then return end
    if not ply:Alive() then
        ply:Spawn()
    end
end)