-- ============================================
--  Death System | Client HUD
-- ============================================

include("death_system/sh_death.lua")

-- ── State ─────────────────────────────────────────────────────────────────────
local isDead       = false
local holdStart    = nil
local holdProgress = 0
local respawnSent  = false

-- ── Materials ─────────────────────────────────────────────────────────────────
local matMedical = Material(DEATH_SYSTEM.MatMedical, "noclamp smooth")
local matSkull   = Material(DEATH_SYSTEM.MatSkull,   "noclamp smooth")

-- ── Net: server tells us we just died ─────────────────────────────────────────
net.Receive("DeathSystem_PlayerDied", function()
    print("[DeathSystem] CLIENT received PlayerDied net message")
    isDead       = true
    holdStart    = nil
    holdProgress = 0
    respawnSent  = false
end)

-- ── Reset when we come back alive ─────────────────────────────────────────────
hook.Add("Think", "DeathSystem_AliveCheck", function()
    if isDead and IsValid(LocalPlayer()) and LocalPlayer():Alive() then
        isDead       = false
        holdStart    = nil
        holdProgress = 0
        respawnSent  = false
    end
end)

-- ── Hold-E progress ───────────────────────────────────────────────────────────
hook.Add("Think", "DeathSystem_HoldE", function()
    if not isDead or respawnSent then return end

    if input.IsKeyDown(KEY_E) then
        holdStart    = holdStart or CurTime()
        holdProgress = math.Clamp((CurTime() - holdStart) / DEATH_SYSTEM.RespawnHoldTime, 0, 1)

        if holdProgress >= 1 then
            respawnSent = true
            net.Start("DeathSystem_Respawn")
            net.SendToServer()
        end
    else
        holdStart    = nil
        holdProgress = 0
    end
end)

-- ── Draw function ─────────────────────────────────────────────────────────────
local function DrawDeathHUD()
    if not isDead then return end

    local sw, sh = ScrW(), ScrH()
    local centerX = sw * 0.5

    -- ── Red screen tint ───────────────────────────────────────────────────────
    surface.SetDrawColor(180, 0, 0, 40)
    surface.DrawRect(0, 0, sw, sh)

    -- ── Bar ───────────────────────────────────────────────────────────────────
    local barW = sw * 0.30
    local barH = sh * 0.014
    local barX = centerX - barW * 0.5
    local barY = sh * 0.90

    -- ── Text positions — top to bottom: Health Critical, Comms, Hold E, bar ───
    local holdY   = barY - sh * 0.028
    local commsY  = holdY - sh * 0.028
    local titleY  = commsY - sh * 0.038

    -- ── Logos — tight either side of the text block ───────────────────────────
    local logoSz = sh * 0.075
    -- Measure roughly how wide the comms text is and hug it
    local textHalfW = sw * 0.10
    local logoLX = centerX - textHalfW - logoSz - sw * 0.005
    local logoRX = centerX + textHalfW + sw * 0.005
    local logoY  = titleY + (sh * 0.088 - logoSz) * 0.5  -- vertically centred on title+comms

    -- ── Medical logos ─────────────────────────────────────────────────────────
    surface.SetDrawColor(255, 255, 255, 220)
    surface.SetMaterial(matMedical)
    surface.DrawTexturedRect(logoLX, logoY, logoSz, logoSz)
    surface.DrawTexturedRect(logoRX, logoY, logoSz, logoSz)

    -- ── "Health Critical" — biggest, pure red ─────────────────────────────────
    draw.SimpleText(
        "Health Critical",
        "DermaLarge",
        centerX,
        titleY,
        Color(255, 0, 0, 255),
        TEXT_ALIGN_CENTER,
        TEXT_ALIGN_TOP
    )

    -- ── "Comms for a medic or" — medium, white ────────────────────────────────
    draw.SimpleText(
        "Comms for a medic or",
        "DermaDefaultBold",
        centerX,
        commsY,
        Color(255, 255, 255, 230),
        TEXT_ALIGN_CENTER,
        TEXT_ALIGN_TOP
    )

    -- ── "Hold 'E' to respawn" — smallest, dimmer, just above bar ─────────────
    draw.SimpleText(
        "Hold 'E' to respawn",
        "DermaDefaultBold",
        centerX,
        holdY,
        Color(180, 180, 180, 200),
        TEXT_ALIGN_CENTER,
        TEXT_ALIGN_TOP
    )

    -- ── Bar track — transparent dark grey ─────────────────────────────────────
    draw.RoundedBox(barH * 0.5, barX, barY, barW * holdProgress, barH, Color(210, 25, 25, 255))

    -- ── Bar fill ──────────────────────────────────────────────────────────────
    if holdProgress > 0 then
        draw.RoundedBox(barH * 0.5, barX, barY, barW, barH, Color(60, 60, 60, 100))
    end

    -- ── Bar border ────────────────────────────────────────────────────────────
    surface.SetDrawColor(80, 80, 80, 80)
    surface.DrawOutlinedRect(barX, barY, barW, barH, 1)
end

-- Hook into all three so it works regardless of gamemode behaviour when dead
hook.Add("HUDPaint",           "DeathSystem_DrawHUD",     DrawDeathHUD)
hook.Add("HUDPaintBackground", "DeathSystem_DrawHUDBG",   DrawDeathHUD)
hook.Add("PostRenderVGUI",     "DeathSystem_DrawHUDVGUI", DrawDeathHUD)