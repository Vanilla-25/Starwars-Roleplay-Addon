-- ============================================================
--  qmenu_tools_control.lua
--  Place in: garrysmod/addons/qmenu_tools_control/lua/autorun/
--
--  - Blocks the Q menu for all players by default
--  - !tools [name] gives physgun + toolgun and opens Q menu access
--  - !untools [name] strips those weapons and revokes Q menu access
--  - On death: Q menu access is revoked (weapons are cleared by GMod)
-- ============================================================

-- ============================================================
--  CONFIGURATION
-- ============================================================

local CONFIG = {
    -- Who can use the !tools / !untools commands?
    -- "admin"      = server admins only (default)
    -- "superadmin" = superadmins only
    -- "everyone"   = any player (not recommended for RP)
    command_permission = "admin",

    -- Message prefix shown in chat
    chat_prefix = "[Tools]",

    -- Should tools persist if the player disconnects and reconnects?
    -- false = revoked on disconnect (recommended for RP)
    persist_on_rejoin = false,

    -- Weapons given when !tools is used (stripped on !untools)
    -- GMod clears these automatically on death, so no need to strip manually then
    tools_weapons = {
        "weapon_physgun",
        "gmod_tool",
    },
}

-- ============================================================
--  SERVER-SIDE
-- ============================================================
if SERVER then

    -- SteamID -> true for players currently holding tools access
    local toolsEnabled = {}

    util.AddNetworkString("QMenuTools_SetState")

    -- Cache hot-path config values as locals
    local PREFIX   = CONFIG.chat_prefix
    local WEAPONS  = CONFIG.tools_weapons
    local PERSIST  = CONFIG.persist_on_rejoin

    -- --------------------------------------------------------
    --  Helpers
    -- --------------------------------------------------------

    local function hasPermission(ply)
        if CONFIG.command_permission == "everyone"   then return true end
        if CONFIG.command_permission == "superadmin" then return ply:IsSuperAdmin() end
        return ply:IsAdmin()
    end

    local function hasToolsAccess(ply)
        return toolsEnabled[ply:SteamID()] ~= nil
    end

    local function sendState(ply, state)
        net.Start("QMenuTools_SetState")
            net.WriteBool(state)
        net.Send(ply)
    end

    -- Find players by partial name (case-insensitive).
    -- Returns immediately on an exact match to skip scanning the rest.
    local function findPlayer(name)
        local nameLower = string.lower(name)
        local found = {}
        for _, ply in ipairs(player.GetAll()) do
            local nick = string.lower(ply:Nick())
            if nick == nameLower then
                -- Exact match — return immediately, no ambiguity possible
                return { ply }
            end
            if string.find(nick, nameLower, 1, true) then
                found[#found + 1] = ply
            end
        end
        return found
    end

    -- Give weapons + unlock Q menu
    local function grantTools(ply)
        toolsEnabled[ply:SteamID()] = true
        for i = 1, #WEAPONS do
            if not ply:HasWeapon(WEAPONS[i]) then
                ply:Give(WEAPONS[i])
            end
        end
        sendState(ply, true)
    end

    -- Strip weapons + lock Q menu
    local function revokeTools(ply)
        toolsEnabled[ply:SteamID()] = nil
        for i = 1, #WEAPONS do
            if ply:HasWeapon(WEAPONS[i]) then
                ply:StripWeapon(WEAPONS[i])
            end
        end
        sendState(ply, false)
    end

    -- --------------------------------------------------------
    --  Hooks
    -- --------------------------------------------------------

    -- Send the correct locked/unlocked state shortly after the player fully loads in.
    -- We don't re-grant weapons here — grantTools() already did that when the
    -- admin ran !tools. persist_on_rejoin just preserves the access flag across
    -- reconnects; weapons must be re-issued via the loadout on respawn if needed.
    hook.Add("PlayerInitialSpawn", "QMenuTools_InitialSpawn", function(ply)
        if not PERSIST then
            -- Clear any stale entry for this SteamID immediately on connect
            toolsEnabled[ply:SteamID()] = nil
        end
        -- Small delay so the net message arrives after the client has loaded
        timer.Simple(2, function()
            if not IsValid(ply) then return end
            sendState(ply, hasToolsAccess(ply))
        end)
    end)

    -- On death: revoke Q menu access.
    -- GMod automatically clears the player's inventory on death,
    -- so we only need to update the flag and notify the client.
    hook.Add("PlayerDeath", "QMenuTools_OnDeath", function(ply)
        if hasToolsAccess(ply) then
            toolsEnabled[ply:SteamID()] = nil
            sendState(ply, false)
        end
    end)

    -- On disconnect: clean up if not persisting
    hook.Add("PlayerDisconnected", "QMenuTools_Disconnect", function(ply)
        if not PERSIST then
            toolsEnabled[ply:SteamID()] = nil
        end
    end)

    -- --------------------------------------------------------
    --  Chat Commands
    -- --------------------------------------------------------

    -- Shared logic for resolving a target from chat args and running an action on them
    local function resolveAndAct(caller, args, action)
        local searchName = table.concat(args, " ", 2)
        local targets = findPlayer(searchName)

        if #targets == 0 then
            caller:ChatPrint(PREFIX .. " No player found matching: " .. searchName)
        elseif #targets > 1 then
            caller:ChatPrint(PREFIX .. " Multiple players matched. Be more specific:")
            for i = 1, #targets do
                caller:ChatPrint("  - " .. targets[i]:Nick())
            end
        else
            action(targets[1])
        end
    end

    hook.Add("PlayerSay", "QMenuTools_ChatCommand", function(ply, text)
        local args = string.Explode(" ", string.Trim(text))
        local cmd  = string.lower(args[1] or "")

        -- Early exit if not a command we care about
        if cmd ~= "!tools" and cmd ~= "!untools" then return end

        if not hasPermission(ply) then
            ply:ChatPrint(PREFIX .. " You don't have permission to use this command.")
            return ""
        end

        -- ---- !tools [name / me] ----
        if cmd == "!tools" then
            if not args[2] or args[2] == "me" then
                -- Self-target
                if hasToolsAccess(ply) then
                    ply:ChatPrint(PREFIX .. " You already have tools access.")
                else
                    grantTools(ply)
                    ply:ChatPrint(PREFIX .. " You have been given the physgun, toolgun, and Q menu access.")
                end
            else
                resolveAndAct(ply, args, function(target)
                    if hasToolsAccess(target) then
                        ply:ChatPrint(PREFIX .. " " .. target:Nick() .. " already has tools access.")
                    else
                        grantTools(target)
                        ply:ChatPrint(PREFIX .. " Gave tools access to " .. target:Nick() .. ".")
                        target:ChatPrint(PREFIX .. " You have been given the physgun, toolgun, and Q menu access by " .. ply:Nick() .. ".")
                    end
                end)
            end
            return ""
        end

        -- ---- !untools [name / me] ----
        if cmd == "!untools" then
            if not args[2] or args[2] == "me" then
                -- Self-target
                if not hasToolsAccess(ply) then
                    ply:ChatPrint(PREFIX .. " You don't have tools access.")
                else
                    revokeTools(ply)
                    ply:ChatPrint(PREFIX .. " Your tools access has been revoked.")
                end
            else
                resolveAndAct(ply, args, function(target)
                    if not hasToolsAccess(target) then
                        ply:ChatPrint(PREFIX .. " " .. target:Nick() .. " doesn't have tools access.")
                    else
                        revokeTools(target)
                        ply:ChatPrint(PREFIX .. " Revoked tools access from " .. target:Nick() .. ".")
                        target:ChatPrint(PREFIX .. " Your tools access has been revoked by " .. ply:Nick() .. ".")
                    end
                end)
            end
            return ""
        end
    end)

end -- SERVER

-- ============================================================
--  CLIENT-SIDE
-- ============================================================
if CLIENT then

    local canOpenQMenu = false

    -- Receive state update from server
    net.Receive("QMenuTools_SetState", function()
        local newState = net.ReadBool()

        -- Only show a chat message if the state actually changed
        if newState == canOpenQMenu then return end
        canOpenQMenu = newState

        if canOpenQMenu then
            chat.AddText(Color(100, 220, 100), "[Tools] ", color_white, "You have been given the physgun, toolgun, and Q menu access.")
        else
            chat.AddText(Color(220, 100, 100), "[Tools] ", color_white, "Your tools access has been revoked.")
        end
    end)

    -- Block the Q menu unless the player has been granted access
    hook.Add("OnSpawnMenuOpen", "QMenuTools_BlockQMenu", function()
        if not canOpenQMenu then
            return false -- silently block
        end
    end)

end -- CLIENT