-- ============================================
--  Death System | Autorun Loader
-- ============================================

if SERVER then
    AddCSLuaFile("death_system/sh_death.lua")
    AddCSLuaFile("death_system/cl_death.lua")

    include("death_system/sh_death.lua")
    include("death_system/sv_death.lua")
end

if CLIENT then
    include("death_system/cl_death.lua")
end
