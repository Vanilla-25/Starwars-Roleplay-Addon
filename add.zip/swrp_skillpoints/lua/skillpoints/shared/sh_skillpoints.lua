-- ============================================================
-- SKILL POINTS SYSTEM - Shared
-- ============================================================

SKILLPOINTS = SKILLPOINTS or {}

SKILLPOINTS.Config = {
    -- XP
    XP_PER_DROID_KILL     = 50,
    XP_PER_EVENT          = 200,
    XP_PER_MINUTE         = 5,
    TIME_XP_INTERVAL      = 60,   -- seconds between passive XP ticks

    -- Levelling
    BASE_XP_REQUIRED      = 1000,
    XP_SCALING            = 1.25,

    -- Skill Points
    LEVELS_PER_SKILLPOINT = 5,
    SKILLPOINT_BUY_COST   = 25000,
    RESET_SKILL_COST      = 0,

    -- Base stats (centralised so client HUD and server ApplyStats stay in sync)
    BASE_HEALTH           = 100,
    BASE_WALK_SPEED       = 180,
    BASE_RUN_SPEED        = 280,

    Skills = {
        xp_gain = {
            name        = "Experience Gain",
            description = "Increases all XP gained by 20% per point.",
            max_points  = 5,
            bonus_value = 20,   -- percent per point
        },
        health = {
            name        = "Health",
            description = "Increases maximum health by 15 per point.",
            max_points  = 10,
            bonus_value = 15,   -- flat HP per point
        },
        speed = {
            name        = "Sprinter",
            description = "Increases run speed by 5 per point.",
            max_points  = 10,
            bonus_value = 5,    -- flat speed units per point
        },
    },
}

-- ── XP / Level helpers ────────────────────────────────────────

-- Total XP required to *reach* a given level (level 1 = 0 XP)
function SKILLPOINTS.GetXPForLevel(level)
    if level <= 1 then return 0 end
    local total, cfg = 0, SKILLPOINTS.Config
    for i = 1, level - 1 do
        total = total + math.floor(cfg.BASE_XP_REQUIRED * cfg.XP_SCALING ^ (i - 1))
    end
    return total
end

-- XP needed to advance from `level` to `level + 1`
function SKILLPOINTS.GetXPToNextLevel(level)
    local cfg = SKILLPOINTS.Config
    return math.floor(cfg.BASE_XP_REQUIRED * cfg.XP_SCALING ^ (level - 1))
end

-- Derive current level from accumulated XP
function SKILLPOINTS.GetLevelFromXP(totalXP)
    local level = 1
    while SKILLPOINTS.GetXPForLevel(level + 1) <= totalXP do
        level = level + 1
    end
    return level
end

-- Skill points earned purely through levelling
function SKILLPOINTS.GetEarnedSkillPoints(level)
    return math.floor(level / SKILLPOINTS.Config.LEVELS_PER_SKILLPOINT)
end

-- Unspent skill points for a raw data table
function SKILLPOINTS.GetAvailableSP(d)
    local level = SKILLPOINTS.GetLevelFromXP(d.total_xp)
    local spent = d.skill_xp_gain + d.skill_health + d.skill_speed
    return SKILLPOINTS.GetEarnedSkillPoints(level) + d.bought_skillpoints - spent
end