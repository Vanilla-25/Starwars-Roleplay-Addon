-- ============================================================
-- SKILL POINTS SYSTEM - Server
-- ============================================================

util.AddNetworkString("SP_SyncData")
util.AddNetworkString("SP_AddXP")
util.AddNetworkString("SP_BuySkillPoint")
util.AddNetworkString("SP_UpgradeSkill")
util.AddNetworkString("SP_ResetSkills")
util.AddNetworkString("SP_RequestTopPlayers")
util.AddNetworkString("SP_TopPlayersData")
util.AddNetworkString("SP_DevAction")

-- ── Database ──────────────────────────────────────────────────
sql.Query([[
    CREATE TABLE IF NOT EXISTS skillpoints_data (
        steamid            TEXT PRIMARY KEY,
        name               TEXT,
        total_xp           INTEGER DEFAULT 0,
        bought_skillpoints INTEGER DEFAULT 0,
        skill_xp_gain      INTEGER DEFAULT 0,
        skill_health       INTEGER DEFAULT 0,
        skill_speed        INTEGER DEFAULT 0
    )
]])

local function LoadPlayer(ply)
    local sid = ply:SteamID()
    local row = sql.QueryRow("SELECT * FROM skillpoints_data WHERE steamid = " .. sql.SQLStr(sid))

    if not row then
        sql.Query("INSERT INTO skillpoints_data (steamid, name) VALUES ("
            .. sql.SQLStr(sid) .. ", " .. sql.SQLStr(ply:Nick()) .. ")")
        row = { total_xp = 0, bought_skillpoints = 0, skill_xp_gain = 0, skill_health = 0, skill_speed = 0 }
    end

    ply.SP_Data = {
        total_xp           = tonumber(row.total_xp)           or 0,
        bought_skillpoints = tonumber(row.bought_skillpoints) or 0,
        skill_xp_gain      = tonumber(row.skill_xp_gain)      or 0,
        skill_health       = tonumber(row.skill_health)        or 0,
        skill_speed        = tonumber(row.skill_speed)         or 0,
    }
end

local function SavePlayer(ply)
    if not IsValid(ply) or not ply.SP_Data then return end
    local d = ply.SP_Data
    sql.Query(string.format(
        "UPDATE skillpoints_data SET name=%s, total_xp=%d, bought_skillpoints=%d,"
        .. " skill_xp_gain=%d, skill_health=%d, skill_speed=%d WHERE steamid=%s",
        sql.SQLStr(ply:Nick()), d.total_xp, d.bought_skillpoints,
        d.skill_xp_gain, d.skill_health, d.skill_speed, sql.SQLStr(ply:SteamID())
    ))
end

-- ── Sync ─────────────────────────────────────────────────────
local function BroadcastNWVars(ply)
    local d      = ply.SP_Data
    local level  = SKILLPOINTS.GetLevelFromXP(d.total_xp)
    local xpFrom = SKILLPOINTS.GetXPForLevel(level)
    local xpTo   = SKILLPOINTS.GetXPForLevel(level + 1)
    ply:SetNWInt("sp_level",       level)
    ply:SetNWInt("sp_total_xp",    d.total_xp)
    ply:SetNWInt("sp_xp_current",  d.total_xp - xpFrom)
    ply:SetNWInt("sp_xp_required", xpTo - xpFrom)
    ply:SetNWInt("xp_rank",        level)   -- backwards-compat alias
end

local function SyncToPlayer(ply)
    if not IsValid(ply) or not ply.SP_Data then return end
    BroadcastNWVars(ply)
    net.Start("SP_SyncData")
    net.WriteTable(ply.SP_Data)
    net.Send(ply)
end

-- ── Apply stat bonuses ────────────────────────────────────────
-- Called on spawn and after any upgrade/reset so stats always
-- reflect the player's current skill investment.
local function ApplyStats(ply)
    if not IsValid(ply) or not ply.SP_Data then return end
    local d   = ply.SP_Data
    local cfg = SKILLPOINTS.Config

    -- Max health
    local maxHP = cfg.BASE_HEALTH + d.skill_health * cfg.Skills.health.bonus_value
    ply:SetMaxHealth(maxHP)
    ply:SetHealth(maxHP)   -- always restore to full on apply (spawn / upgrade)

    -- Movement speed
    local bonusSpd = d.skill_speed * cfg.Skills.speed.bonus_value
    ply:SetWalkSpeed(cfg.BASE_WALK_SPEED + bonusSpd)
    ply:SetRunSpeed(cfg.BASE_RUN_SPEED   + bonusSpd * 2)
end

-- ── XP ───────────────────────────────────────────────────────
local function GiveXP(ply, amount, reason)
    if not IsValid(ply) or not ply.SP_Data then return end
    local d   = ply.SP_Data
    local cfg = SKILLPOINTS.Config

    local multiplier = 1 + (d.skill_xp_gain * cfg.Skills.xp_gain.bonus_value / 100)
    local gained     = math.floor(amount * multiplier)

    local oldLevel = SKILLPOINTS.GetLevelFromXP(d.total_xp)
    d.total_xp     = d.total_xp + gained
    local newLevel = SKILLPOINTS.GetLevelFromXP(d.total_xp)

    if newLevel > oldLevel then
        for lvl = oldLevel + 1, newLevel do
            ply:ChatPrint("[SkillPoints] Level Up! You are now Level " .. lvl .. "!")
            if lvl % cfg.LEVELS_PER_SKILLPOINT == 0 then
                ply:ChatPrint("[SkillPoints] You earned a Skill Point!")
            end
        end
        -- Re-apply stats in case new level unlocked more HP / speed
        if ply:Alive() then ApplyStats(ply) end
    end

    SavePlayer(ply)
    SyncToPlayer(ply)

    net.Start("SP_AddXP")
    net.WriteInt(gained, 32)
    net.WriteString(reason or "")
    net.Send(ply)
end

-- ── Money helpers (DarkRP / SAM / generic) ───────────────────
local function GetMoney(ply)
    if ply.getDarkRPVar then return ply:getDarkRPVar("money") or 0 end
    if ply.GetMoney     then return ply:GetMoney() end
    return nil
end

local function TakeMoney(ply, amount)
    local m = GetMoney(ply)
    if not m or m < amount then return false end
    if ply.addMoney  then ply:addMoney(-amount)
    elseif ply.SetMoney then ply:SetMoney(m - amount) end
    return true
end

-- ── Hooks ────────────────────────────────────────────────────

hook.Add("PlayerInitialSpawn", "SP_Load", function(ply)
    -- Short delay so SteamID and nick are available
    timer.Simple(1, function()
        if not IsValid(ply) then return end
        LoadPlayer(ply)
        -- Extra half-second lets the gamemode finish setting up the pawn
        timer.Simple(0.5, function()
            if IsValid(ply) then
                SyncToPlayer(ply)
            end
        end)
    end)
end)

-- PlayerSpawn fires on EVERY spawn (initial + respawn after death).
-- This is where we re-apply health, speed etc. so they persist across deaths.
hook.Add("PlayerSpawn", "SP_ApplyOnSpawn", function(ply)
    -- timer.Simple(0) defers to next tick so the gamemode has already set
    -- default health/speed before we override them.
    timer.Simple(0, function()
        if IsValid(ply) and ply.SP_Data then
            ApplyStats(ply)
        end
    end)
end)

hook.Add("PlayerDisconnected", "SP_Save", function(ply)
    SavePlayer(ply)
end)

-- Passive XP tick
timer.Create("SP_PassiveXP", SKILLPOINTS.Config.TIME_XP_INTERVAL, 0, function()
    for _, ply in ipairs(player.GetAll()) do
        if IsValid(ply) and ply:Alive() then
            GiveXP(ply, SKILLPOINTS.Config.XP_PER_MINUTE, "Time Played")
        end
    end
end)

-- XP for NPC / droid kills
hook.Add("OnNPCKilled", "SP_NPCKillXP", function(npc, attacker)
    if IsValid(attacker) and attacker:IsPlayer() then
        GiveXP(attacker, SKILLPOINTS.Config.XP_PER_DROID_KILL, "Droid Eliminated")
    end
end)

-- ── Net receivers ─────────────────────────────────────────────

net.Receive("SP_BuySkillPoint", function(_, ply)
    if not ply.SP_Data then return end
    local cost = SKILLPOINTS.Config.SKILLPOINT_BUY_COST

    if GetMoney(ply) == nil then
        ply:ChatPrint("[SkillPoints] No money system detected — granting SP for free.")
    elseif not TakeMoney(ply, cost) then
        ply:ChatPrint("[SkillPoints] You can reset your skills for free.")
        return
    end

    ply.SP_Data.bought_skillpoints = ply.SP_Data.bought_skillpoints + 1
    SavePlayer(ply)
    SyncToPlayer(ply)
    ply:ChatPrint("[SkillPoints] Purchased a Skill Point!")
end)

net.Receive("SP_UpgradeSkill", function(_, ply)
    if not ply.SP_Data then return end

    local skillKey = net.ReadString()
    local skillDef = SKILLPOINTS.Config.Skills[skillKey]
    if not skillDef then return end

    local d       = ply.SP_Data
    local avail   = SKILLPOINTS.GetAvailableSP(d)
    local current = d["skill_" .. skillKey] or 0

    if avail <= 0 then
        ply:ChatPrint("[SkillPoints] No skill points available!"); return
    end
    if current >= skillDef.max_points then
        ply:ChatPrint("[SkillPoints] Skill is already maxed!"); return
    end

    d["skill_" .. skillKey] = current + 1
    if ply:Alive() then ApplyStats(ply) end
    SavePlayer(ply)
    SyncToPlayer(ply)
    ply:ChatPrint("[SkillPoints] Upgraded " .. skillDef.name .. "!")
end)

net.Receive("SP_ResetSkills", function(_, ply)
    if not ply.SP_Data then return end
    local cost = SKILLPOINTS.Config.RESET_SKILL_COST

    if GetMoney(ply) == nil then
        ply:ChatPrint("[SkillPoints] No money system detected — resetting for free.")
    elseif not TakeMoney(ply, cost) then
        ply:ChatPrint("[SkillPoints] Not enough credits! Reset costs $" .. cost); return
    end

    local d = ply.SP_Data
    d.skill_xp_gain = 0
    d.skill_health  = 0
    d.skill_speed   = 0

    if ply:Alive() then ApplyStats(ply) end
    SavePlayer(ply)
    SyncToPlayer(ply)
    ply:ChatPrint("[SkillPoints] Skills reset! Your skill points have been refunded.")
end)

net.Receive("SP_RequestTopPlayers", function(_, ply)
    local rows = sql.Query("SELECT name, total_xp FROM skillpoints_data ORDER BY total_xp DESC LIMIT 3")
    local top  = {}
    if rows then
        for _, row in ipairs(rows) do
            table.insert(top, {
                name  = row.name,
                level = SKILLPOINTS.GetLevelFromXP(tonumber(row.total_xp) or 0),
            })
        end
    end
    net.Start("SP_TopPlayersData")
    net.WriteTable(top)
    net.Send(ply)
end)

-- ── Dev / Admin actions (superadmin only) ─────────────────────
net.Receive("SP_DevAction", function(_, ply)
    if not ply:IsSuperAdmin() then return end
    if not ply.SP_Data then return end

    local action = net.ReadString()
    local value  = net.ReadInt(32)
    local d      = ply.SP_Data

    if action == "xp_add" then
        GiveXP(ply, math.max(0, value), "Dev: XP Added")

    elseif action == "xp_set" then
        d.total_xp = math.max(0, value)
        SavePlayer(ply); SyncToPlayer(ply)
        if ply:Alive() then ApplyStats(ply) end
        ply:ChatPrint("[Dev] Total XP set to " .. d.total_xp)

    elseif action == "level_set" then
        d.total_xp = SKILLPOINTS.GetXPForLevel(math.max(1, value))
        SavePlayer(ply); SyncToPlayer(ply)
        if ply:Alive() then ApplyStats(ply) end
        ply:ChatPrint("[Dev] Level set to " .. value)

    elseif action == "sp_set" then
        d.bought_skillpoints = math.max(0, value)
        SavePlayer(ply); SyncToPlayer(ply)
        ply:ChatPrint("[Dev] Bought skill points set to " .. d.bought_skillpoints)
    end
end)

-- ── Public API ───────────────────────────────────────────────
function SKILLPOINTS.GiveEventXP(ply)
    GiveXP(ply, SKILLPOINTS.Config.XP_PER_EVENT, "Event Completed")
end