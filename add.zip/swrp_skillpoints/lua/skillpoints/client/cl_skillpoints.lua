-- ============================================================
-- SKILL POINTS SYSTEM - Client
-- Layout: Left sidebar + compact centred perk cards  |  Vanilla
-- ============================================================

local SP_LocalData = {
    total_xp           = 0,
    bought_skillpoints = 0,
    skill_xp_gain      = 0,
    skill_health       = 0,
    skill_speed        = 0,
}
local SP_TopPlayers = {}
local SP_Frame      = nil

-- ── Theme ─────────────────────────────────────────────────────
local T = {
    Bg        = Color(12,  14,  18),
    Panel     = Color(18,  21,  27),
    Panel2    = Color(23,  27,  34),
    Card      = Color(28,  33,  42),
    CardHov   = Color(36,  43,  55),
    CardSel   = Color(32,  44,  64),
    Border    = Color(42,  52,  68),
    BorderDim = Color(28,  36,  48),
    Accent    = Color(100, 160, 255),
    AccentBg  = Color(18,  30,  60),
    Text      = Color(218, 224, 235),
    Dim       = Color(105, 120, 145),
    Faint     = Color(60,  74,  92),
    Green     = Color(55,  210, 115),
    GreenBg   = Color(16,  40,  26),
    Danger    = Color(220, 75,  75),
    DangerBg  = Color(50,  16,  16),
    Gold      = Color(230, 185, 60),
    Silver    = Color(160, 175, 200),
    Bronze    = Color(185, 125, 60),
    XPBg      = Color(10,  12,  20),
    Survival  = Color(220, 75,  90),
    SurvBg    = Color(50,  16,  22),
    Mobility  = Color(70,  150, 240),
    MobBg     = Color(16,  38,  70),
    Utility   = Color(60,  205, 155),
    UtilBg    = Color(16,  52,  42),
    DevBg     = Color(8,   10,  14),
    DevAccent = Color(255, 165, 30),
    DevBorder = Color(80,  55,  20),
}
local function FA(c, a) return ColorAlpha(c, a) end

-- ── Fonts ─────────────────────────────────────────────────────
surface.CreateFont("SP_Title",    { font = "Purista", size = 16, weight = 700 })
surface.CreateFont("SP_SectLbl",  { font = "Purista", size = 12, weight = 600 })
surface.CreateFont("SP_PerkName", { font = "Purista", size = 14, weight = 700 })
surface.CreateFont("SP_PerkCat",  { font = "Purista", size = 10, weight = 600 })
surface.CreateFont("SP_CardIcon", { font = "Purista", size = 18, weight = 700 })
surface.CreateFont("SP_Stat",     { font = "Purista", size = 13, weight = 700 })
surface.CreateFont("SP_Heading",  { font = "Purista", size = 11, weight = 600 })
surface.CreateFont("SP_Small",    { font = "Ubuntu",  size = 11, weight = 400 })
surface.CreateFont("SP_Sub",      { font = "Ubuntu",  size = 10, weight = 400 })
surface.CreateFont("SP_Dev",      { font = "Ubuntu",  size = 11, weight = 400 })
surface.CreateFont("SP_DevTitle", { font = "Purista", size = 13, weight = 700 })

-- ── Draw helpers ──────────────────────────────────────────────
local function Rect(x, y, w, h, c)        draw.RoundedBox(0, x, y, w, h, c) end
local function RRct(r, x, y, w, h, c)     draw.RoundedBox(r, x, y, w, h, c) end
local function Bord(x, y, w, h, c)        surface.SetDrawColor(c); surface.DrawOutlinedRect(x, y, w, h, 1) end
local function Ln(x1, y1, x2, y2, c)      surface.SetDrawColor(c); surface.DrawLine(x1, y1, x2, y2) end
local function Txt(t, f, x, y, c, ax, ay) draw.SimpleText(t, f, x, y, c, ax or 0, ay or 0) end
local function TxtW(str, font)
    surface.SetFont(font); return select(1, surface.GetTextSize(str))
end

local blurMat = Material("pp/blurscreen")
local function DrawBlur(panel, amount, passes)
    local bx, by = panel:LocalToScreen(0, 0)
    surface.SetDrawColor(255, 255, 255, 255)
    surface.SetMaterial(blurMat)
    for i = 1, (passes or 2) do
        blurMat:SetFloat("$blur", (i / (passes or 2)) * (amount or 5))
        blurMat:Recompute()
        render.UpdateScreenEffectTexture()
        surface.DrawTexturedRect(-bx, -by, ScrW(), ScrH())
    end
end

local function DrawXPBar(x, y, w, h, level, totalXP)
    local xpFrom = SKILLPOINTS.GetXPForLevel(level)
    local needed = math.max(SKILLPOINTS.GetXPForLevel(level + 1) - xpFrom, 1)
    local frac   = math.Clamp((totalXP - xpFrom) / needed, 0, 1)
    RRct(h, x, y, w, h, T.XPBg)
    if frac > 0 then RRct(h, x, y, math.max(math.floor(w * frac), h), h, T.Accent) end
    Bord(x, y, w, h, FA(T.Border, 200))
end

local PIP_W, PIP_GAP = 8, 2
local function PipRowW(n) return n * PIP_W + (n - 1) * PIP_GAP end
local function DrawPips(x, y, cur, max, col)
    for i = 1, max do
        local px = x + (i - 1) * (PIP_W + PIP_GAP)
        local on = (i <= cur)
        RRct(2, px, y, PIP_W, PIP_W,
            on and (cur >= max and T.Gold or (col or T.Accent)) or T.XPBg)
        if not on then Bord(px, y, PIP_W, PIP_W, FA(T.Border, 150)) end
    end
end

-- ── Notifications ─────────────────────────────────────────────
local SP_TYPE_MAP = { [0]=0, [1]=1, [2]=2 }
local function PushNotif(msg, sub, ntype)
    local ft = SP_TYPE_MAP[ntype] or 0
    if F2Notify then F2Notify.Push(msg, sub or "", ft)
    else timer.Simple(0, function() if F2Notify then F2Notify.Push(msg, sub or "", ft) end end) end
end
function SP_ShowNotif(txt) PushNotif(txt, "", 0) end

-- ── Net ───────────────────────────────────────────────────────
net.Receive("SP_SyncData", function()
    SP_LocalData = net.ReadTable()
    if IsValid(SP_Frame) and SP_Frame._rebuild then SP_Frame._rebuild() end
end)
net.Receive("SP_AddXP", function()
    PushNotif("+" .. net.ReadInt(32) .. " XP", net.ReadString(), 1)
end)
net.Receive("SP_TopPlayersData", function()
    SP_TopPlayers = net.ReadTable()
end)

-- ── Skill definitions ─────────────────────────────────────────
local Skills = {
    { netKey="health",  dataKey="skill_health",  name="Health",     cat="Survivability", catCol=T.Survival, iconBg=T.SurvBg, icon="HP",  desc="+15 max health per point", max=10 },
    { netKey="speed",   dataKey="skill_speed",   name="Sprinter",   cat="Mobility",      catCol=T.Mobility, iconBg=T.MobBg,  icon="SPD", desc="+5 run speed per point",   max=10 },
    { netKey="xp_gain", dataKey="skill_xp_gain", name="Experience", cat="Utility",       catCol=T.Utility,  iconBg=T.UtilBg, icon="XP",  desc="+20% XP per point",        max=5  },
}

-- ── Close ─────────────────────────────────────────────────────
local function CloseMenu()
    if IsValid(SP_Frame) then SP_Frame:Remove(); SP_Frame = nil end
    gui.EnableScreenClicker(false)
end

-- ── Dev panel ─────────────────────────────────────────────────
local devPanel, devVisible = nil, false
local function DevSend(action, value)
    net.Start("SP_DevAction"); net.WriteString(action)
    net.WriteInt(math.floor(tonumber(value) or 0), 32); net.SendToServer()
end

local function BuildDevPanel(parent, sw, sh)
    if IsValid(devPanel) then devPanel:Remove(); devPanel = nil end
    if not devVisible then return end
    local DW = 200
    devPanel = vgui.Create("DPanel", parent)
    devPanel:SetPos(sw - DW, 0); devPanel:SetSize(DW, sh); devPanel:SetZPos(100)
    devPanel.Paint = function(self, w, h)
        Rect(0, 0, w, h, T.DevBg)
        Rect(0, 0, 1, h, FA(T.DevAccent, 120))
        Txt("DEV PANEL", "SP_DevTitle", w/2, 14, T.DevAccent, 1, 1)
        Ln(8, 28, w-8, 28, FA(T.DevAccent, 80))
        Txt("by Vanilla", "SP_Sub", w/2, sh-14, FA(T.DevAccent, 70), 1, 1)
    end
    local function DL(y, t) local l=vgui.Create("DLabel",devPanel); l:SetPos(10,y); l:SetSize(DW-20,16); l:SetText(t); l:SetFont("SP_Dev"); l:SetTextColor(FA(T.DevAccent,200)) end
    local function DE(y, hint)
        local bg=vgui.Create("DPanel",devPanel); bg:SetPos(10,y); bg:SetSize(DW-20,22)
        bg.Paint=function(s,w,h) RRct(3,0,0,w,h,Color(16,19,25)); Bord(0,0,w,h,FA(T.DevBorder,200)) end
        local e=vgui.Create("DTextEntry",bg); e:SetPos(5,3); e:SetSize(DW-30,16); e:SetFont("SP_Dev")
        e:SetTextColor(T.Text); e:SetCursorColor(T.DevAccent); e:SetPaintBackground(false)
        e:SetPlaceholderText(hint); e:SetPlaceholderColor(T.Faint); return e
    end
    local function DB(y, lbl, bg2, fn)
        local b=vgui.Create("DButton",devPanel); b:SetPos(10,y); b:SetSize(DW-20,22); b:SetText(""); b:SetCursor("hand")
        local hA,lt=0,CurTime()
        b.Think=function() local dt=CurTime()-lt; lt=CurTime(); hA=math.Approach(hA,b:IsHovered() and 1 or 0,dt*14) end
        b.Paint=function(s,w,h) RRct(3,0,0,w,h,FA(bg2,math.Round(180+75*hA))); Bord(0,0,w,h,FA(T.DevAccent,math.Round(80+175*hA))); Txt(lbl,"SP_Dev",w/2,h/2,T.Text,1,1) end
        b.DoClick=fn; return b
    end
    local function DS() local cy2=_cy; Ln(10,cy2,DW-10,cy2,FA(T.DevBorder,160)); _cy=_cy+8 end
    _cy=36
    DL(_cy,"ADD XP"); _cy=_cy+16; local eAX=DE(_cy,"e.g. 500"); _cy=_cy+28
    DB(_cy,"Add XP",T.GreenBg,function() DevSend("xp_add",eAX:GetValue()); eAX:SetValue(""); PushNotif("Dev: XP sent","",1) end); _cy=_cy+28
    Ln(10,_cy,DW-10,_cy,FA(T.DevBorder,160)); _cy=_cy+8
    DL(_cy,"SET TOTAL XP"); _cy=_cy+16; local eSX=DE(_cy,"e.g. 5000"); _cy=_cy+28
    DB(_cy,"Set XP",T.AccentBg,function() DevSend("xp_set",eSX:GetValue()); eSX:SetValue(""); PushNotif("Dev: XP set","",1) end); _cy=_cy+28
    Ln(10,_cy,DW-10,_cy,FA(T.DevBorder,160)); _cy=_cy+8
    DL(_cy,"SET LEVEL"); _cy=_cy+16; local eLV=DE(_cy,"e.g. 20"); _cy=_cy+28
    DB(_cy,"Set Level",Color(30,22,52),function() DevSend("level_set",eLV:GetValue()); eLV:SetValue(""); PushNotif("Dev: Level set","",1) end); _cy=_cy+28
    Ln(10,_cy,DW-10,_cy,FA(T.DevBorder,160)); _cy=_cy+8
    DL(_cy,"SET BOUGHT SP"); _cy=_cy+16; local eSP=DE(_cy,"e.g. 10"); _cy=_cy+28
    DB(_cy,"Set SP",Color(40,26,12),function() DevSend("sp_set",eSP:GetValue()); eSP:SetValue(""); PushNotif("Dev: SP set","",1) end); _cy=_cy+28
    Ln(10,_cy,DW-10,_cy,FA(T.DevBorder,160)); _cy=_cy+8
    DL(_cy,"QUICK"); _cy=_cy+16
    DB(_cy,"+1000 XP",T.GreenBg,function() DevSend("xp_add",1000); PushNotif("Dev: +1000 XP","",1) end); _cy=_cy+26
    DB(_cy,"+5000 XP",T.GreenBg,function() DevSend("xp_add",5000); PushNotif("Dev: +5000 XP","",1) end); _cy=_cy+26
    DB(_cy,"+1 SP",Color(40,26,12),function() DevSend("sp_set",(SP_LocalData.bought_skillpoints or 0)+1); PushNotif("Dev: +1 SP","",1) end); _cy=_cy+30
    Ln(10,_cy,DW-10,_cy,FA(T.DevBorder,160)); _cy=_cy+8
    DB(_cy,"[ Hide Dev Panel ]",T.DangerBg,function() devVisible=false; if IsValid(devPanel) then devPanel:Remove(); devPanel=nil end end)
end

-- ═════════════════════════════════════════════════════════════
-- OPEN MENU
-- ═════════════════════════════════════════════════════════════
function SP_OpenMenu()
    CloseMenu()
    net.Start("SP_RequestTopPlayers"); net.SendToServer()

    local sw, sh   = ScrW(), ScrH()
    local TOPBAR_H = 48
    local PAD      = 14   -- outer padding from screen edge

    -- ── Full-screen overlay ───────────────────────────────────
    local overlay = vgui.Create("DFrame")
    overlay:SetSize(sw, sh); overlay:SetPos(0, 0)
    overlay:SetTitle(""); overlay:ShowCloseButton(false)
    overlay:SetDraggable(false); overlay:SetSizable(false)
    overlay:MakePopup(); overlay:SetKeyboardInputEnabled(true)
    SP_Frame = overlay
    overlay.Paint = function(self, w, h)
        DrawBlur(self, 8, 3)
        Rect(0, 0, w, h, Color(8, 10, 16, 190))
    end
    overlay.OnMousePressed = function(self, btn)
        if btn == MOUSE_LEFT and vgui.GetHoveredPanel() == self then CloseMenu() end
    end

    -- ── TOP BAR ───────────────────────────────────────────────
    local topbar = vgui.Create("DPanel", overlay)
    topbar:SetSize(sw, TOPBAR_H); topbar:SetPos(0, 0)

    local CBTN_W, CBTN_H = 72, 26
    local cbtnX = sw - CBTN_W - 10

    topbar.Paint = function(self, w, h)
        DrawBlur(self, 5, 2)
        Rect(0, 0, w, h, FA(T.Panel, 235))
        surface.SetDrawColor(T.Accent); surface.DrawRect(0, h-2, w, 2)

        -- Logo
        RRct(3, 12, h/2-8, 16, 16, T.Accent)
        Txt("S", "SP_Heading", 20, h/2, Color(255,255,255), 1, 1)
        Txt("SKILL POINTS", "SP_Title", 34, h/2-4, T.Text, 0, 1)
        Txt("perk upgrades", "SP_Sub",  34, h/2+6, FA(T.Dim, 190), 0, 1)

        -- Right strip (stops before buttons)
        local lvl    = SKILLPOINTS.GetLevelFromXP(SP_LocalData.total_xp)
        local avail  = SKILLPOINTS.GetAvailableSP(SP_LocalData)
        local xpFrom = SKILLPOINTS.GetXPForLevel(lvl)
        local needed = math.max(SKILLPOINTS.GetXPForLevel(lvl+1) - xpFrom, 1)
        local midY   = h/2
        local sep    = FA(T.BorderDim, 200)
        local rx     = cbtnX - 14
        -- Reserve space for DEV button if superadmin
        if LocalPlayer():IsSuperAdmin() then rx = rx - 62 end

        local spStr = avail .. " SP"
        Txt(spStr,      "SP_SectLbl", rx, midY-4, avail > 0 and T.Green or T.Dim, 2, 1)
        Txt("AVAILABLE", "SP_Sub",    rx, midY+6, FA(T.Dim, 140), 2, 1)
        rx = rx - TxtW(spStr, "SP_SectLbl") - 12
        surface.SetDrawColor(sep); surface.DrawRect(rx, midY-6, 1, 12); rx = rx - 10

        local lvlStr = "LV " .. lvl
        Txt(lvlStr, "SP_SectLbl", rx, midY-4, T.Accent, 2, 1)
        Txt("LEVEL", "SP_Sub",    rx, midY+6, FA(T.Dim, 140), 2, 1)
        rx = rx - TxtW(lvlStr, "SP_SectLbl") - 12
        surface.SetDrawColor(sep); surface.DrawRect(rx, midY-6, 1, 12); rx = rx - 10

        local xpStr = (SP_LocalData.total_xp - xpFrom) .. "/" .. needed .. " XP"
        Txt(xpStr,    "SP_SectLbl", rx, midY-4, FA(T.Text, 190), 2, 1)
        Txt("PROGRESS", "SP_Sub",   rx, midY+6, FA(T.Dim, 140), 2, 1)
    end

    -- Close button
    local closeBtn = vgui.Create("DButton", topbar)
    closeBtn:SetPos(cbtnX, math.floor((TOPBAR_H-CBTN_H)/2))
    closeBtn:SetSize(CBTN_W, CBTN_H); closeBtn:SetText(""); closeBtn:SetCursor("hand")
    local cH, cL = 0, CurTime()
    closeBtn.Think = function() local dt=CurTime()-cL; cL=CurTime(); cH=math.Approach(cH,closeBtn:IsHovered() and 1 or 0,dt*14) end
    closeBtn.Paint = function(self, w, h)
        if cH>0 then RRct(4,0,0,w,h,FA(T.Danger,math.Round(cH*45))) end
        surface.SetDrawColor(FA(T.Danger,math.Round(Lerp(cH,65,200)))); surface.DrawRect(5,h-2,w-10,2)
        Txt("✕  CLOSE","SP_SectLbl",w/2,h/2,FA(T.Text,math.Round(Lerp(cH,155,255))),1,1)
    end
    closeBtn.DoClick = CloseMenu

    -- Dev toggle
    if LocalPlayer():IsSuperAdmin() then
        local devBtn = vgui.Create("DButton", topbar)
        devBtn:SetPos(cbtnX-58, math.floor((TOPBAR_H-22)/2)); devBtn:SetSize(52,22)
        devBtn:SetText("DEV"); devBtn:SetFont("SP_Dev"); devBtn:SetCursor("hand")
        devBtn.Paint = function(self, w, h)
            local on = self:IsHovered() or devVisible
            RRct(3,0,0,w,h, on and FA(T.DevAccent,28) or FA(T.Border,70))
            Bord(0,0,w,h, on and FA(T.DevAccent,200) or FA(T.Border,110))
            self:SetTextColor(on and T.DevAccent or T.Dim)
        end
        devBtn.DoClick = function() devVisible=not devVisible; BuildDevPanel(overlay,sw,sh) end
    end

    -- ── BODY AREA (below topbar, full remaining height) ───────
    local bodyY  = TOPBAR_H + PAD
    local bodyH  = sh - TOPBAR_H - PAD * 2
    local bodyW  = sw - PAD * 2

    -- ── LEFT SIDEBAR ──────────────────────────────────────────
    local SIDE_W = 240
    local sidebar = vgui.Create("DPanel", overlay)
    sidebar:SetPos(PAD, bodyY); sidebar:SetSize(SIDE_W, bodyH)
    sidebar.Paint = function(self, w, h)
        DrawBlur(self, 4, 2)
        RRct(6, 0, 0, w, h, FA(T.Panel, 220))
        surface.SetDrawColor(T.Accent); surface.DrawRect(0, 0, w, 2)
        Bord(0, 0, w, h, FA(T.Border, 160))
    end

    -- Helper: draw a section heading inside sidebar
    local function SideHeading(parent, y, label)
        local lp = vgui.Create("DPanel", parent)
        lp:SetPos(0, y); lp:SetSize(SIDE_W, 22)
        lp.Paint = function(self, w, h)
            Rect(0, 0, w, h, FA(T.Panel2, 200))
            surface.SetDrawColor(FA(T.Border, 120)); surface.DrawRect(0, h-1, w, 1)
            Txt(label, "SP_Heading", 12, h/2, FA(T.Dim, 200), 0, 1)
        end
        return lp
    end

    -- ── Sidebar: player stats block ───────────────────────────
    local cy = 8  -- cursor y inside sidebar

    -- Title row
    SideHeading(sidebar, cy, "PLAYER STATS"); cy = cy + 26

    -- Stats drawn directly in sidebar paint — use a sub-panel so we can update it
    local statsPanel = vgui.Create("DPanel", sidebar)
    statsPanel:SetPos(0, cy); statsPanel:SetSize(SIDE_W, 118)
    statsPanel.Paint = function(self, w, h)
        local lvl   = SKILLPOINTS.GetLevelFromXP(SP_LocalData.total_xp)
        local avail = SKILLPOINTS.GetAvailableSP(SP_LocalData)
        local rows  = {
            { "Level",      tostring(lvl),                             T.Accent },
            { "Total XP",   tostring(SP_LocalData.total_xp),           T.Dim   },
            { "Available",  tostring(avail) .. " SP",                  avail > 0 and T.Green or T.Dim },
            { "Purchased",  tostring(SP_LocalData.bought_skillpoints) .. " SP", T.Dim },
        }
        for i, r in ipairs(rows) do
            local ry = 4 + (i-1) * 27
            -- Row separator
            if i > 1 then
                surface.SetDrawColor(FA(T.Border, 60))
                surface.DrawRect(12, ry-4, w-24, 1)
            end
            Txt(r[1], "SP_Sub",   14,  ry+9, FA(T.Dim, 190), 0, 1)
            Txt(r[2], "SP_Stat",  w-14, ry+9, r[3],          2, 1)
        end
    end
    cy = cy + 122

    -- XP bar row
    local xpPanel = vgui.Create("DPanel", sidebar)
    xpPanel:SetPos(0, cy); xpPanel:SetSize(SIDE_W, 40)
    xpPanel.Paint = function(self, w, h)
        local lvl    = SKILLPOINTS.GetLevelFromXP(SP_LocalData.total_xp)
        local xpFrom = SKILLPOINTS.GetXPForLevel(lvl)
        local needed = math.max(SKILLPOINTS.GetXPForLevel(lvl+1) - xpFrom, 1)
        local cur    = SP_LocalData.total_xp - xpFrom
        DrawXPBar(12, 10, w-24, 7, lvl, SP_LocalData.total_xp)
        Txt("XP  " .. cur .. " / " .. needed, "SP_Sub",
            w/2, 25, FA(T.Dim, 180), 1, 1)
    end
    cy = cy + 44

    -- Divider
    local divA = vgui.Create("DPanel", sidebar)
    divA:SetPos(0, cy); divA:SetSize(SIDE_W, 1)
    divA.Paint = function(self, w, h) Rect(0,0,w,h,FA(T.Border,80)) end
    cy = cy + 9

    -- ── Sidebar: leaderboard ──────────────────────────────────
    SideHeading(sidebar, cy, "TOP PLAYERS"); cy = cy + 26

    local lbPanel = vgui.Create("DPanel", sidebar)
    lbPanel:SetPos(0, cy); lbPanel:SetSize(SIDE_W, 68)
    lbPanel.Paint = function(self, w, h)
        local mc = { T.Gold, T.Silver, T.Bronze }
        if #SP_TopPlayers == 0 then
            Txt("No data yet", "SP_Sub", w/2, h/2, FA(T.Faint, 150), 1, 1); return
        end
        for idx, p in ipairs(SP_TopPlayers) do
            local ty = 6 + (idx-1) * 21
            -- medal dot
            RRct(2, 12, ty+3, 8, 8, FA(mc[idx] or T.Dim, 180))
            Txt(p.name,            "SP_Small", 28,   ty+7, FA(T.Text, 200), 0, 1)
            Txt("Lv." .. p.level,  "SP_Sub",   w-12, ty+7, mc[idx] or T.Dim, 2, 1)
        end
    end
    cy = cy + 72

    -- Divider
    local divB = vgui.Create("DPanel", sidebar)
    divB:SetPos(0, cy); divB:SetSize(SIDE_W, 1)
    divB.Paint = function(self, w, h) Rect(0,0,w,h,FA(T.Border,80)) end
    cy = cy + 9

    -- ── Sidebar: Buy SP button ────────────────────────────────
    SideHeading(sidebar, cy, "SKILL POINTS"); cy = cy + 26

    local buyBtn = vgui.Create("DButton", sidebar)
    buyBtn:SetPos(12, cy); buyBtn:SetSize(SIDE_W-24, 36)
    buyBtn:SetText(""); buyBtn:SetCursor("hand")
    local bH, bL = 0, CurTime()
    buyBtn.Think = function() local dt=CurTime()-bL; bL=CurTime(); bH=math.Approach(bH,buyBtn:IsHovered() and 1 or 0,dt*14) end
    buyBtn.Paint = function(self, w, h)
        RRct(5, 0, 0, w, h, FA(T.GreenBg, math.Round(200+55*bH)))
        surface.SetDrawColor(FA(T.Green, math.Round(90+165*bH))); surface.DrawOutlinedRect(0,0,w,h,1)
        surface.SetDrawColor(FA(T.Green, math.Round(Lerp(bH,110,255)))); surface.DrawRect(0,0,3,h)
        Txt("BUY SKILL POINT",  "SP_SectLbl", w/2, h/2-6, T.Green, 1, 1)
        Txt("$"..SKILLPOINTS.Config.SKILLPOINT_BUY_COST, "SP_Sub", w/2, h/2+6, FA(T.Green,170), 1, 1)
    end
    buyBtn.DoClick = function()
        net.Start("SP_BuySkillPoint"); net.SendToServer()
        PushNotif("Purchasing skill point...","$"..SKILLPOINTS.Config.SKILLPOINT_BUY_COST,0)
        surface.PlaySound("buttons/button17.wav")
    end
    cy = cy + 42

    -- Reset button
    local resetBtn = vgui.Create("DButton", sidebar)
    resetBtn:SetPos(12, cy); resetBtn:SetSize(SIDE_W-24, 30)
    resetBtn:SetText(""); resetBtn:SetCursor("hand")
    local rH, rL = 0, CurTime()
    resetBtn.Think = function() local dt=CurTime()-rL; rL=CurTime(); rH=math.Approach(rH,resetBtn:IsHovered() and 1 or 0,dt*14) end
    resetBtn.Paint = function(self, w, h)
        RRct(5, 0, 0, w, h, FA(T.DangerBg, math.Round(160+75*rH)))
        surface.SetDrawColor(FA(T.Danger, math.Round(70+175*rH))); surface.DrawOutlinedRect(0,0,w,h,1)
        surface.SetDrawColor(FA(T.Danger, math.Round(Lerp(rH,100,255)))); surface.DrawRect(0,0,3,h)
        local lbl = rH>0.5 and T.Text or FA(T.Danger,200)
        Txt("RESET ALL SKILLS", "SP_Heading", w/2, h/2-5, lbl, 1, 1)
        local cost = SKILLPOINTS.Config.RESET_SKILL_COST==0 and "free" or ("$"..SKILLPOINTS.Config.RESET_SKILL_COST)
        Txt(cost, "SP_Sub", w/2, h/2+6, FA(T.Danger,150), 1, 1)
    end
    resetBtn.DoClick = function()
        net.Start("SP_ResetSkills"); net.SendToServer()
        PushNotif("Skills reset!","Your points have been refunded.",1)
        surface.PlaySound("buttons/button17.wav")
    end

    -- ── RIGHT AREA: compact perk cards centred ────────────────
    local rightX = PAD + SIDE_W + PAD
    local rightW = sw - rightX - PAD
    local rightH = bodyH

    -- Card dimensions — compact, not full height
    -- 3 cards side by side, centred vertically in rightH
    local CARD_W   = math.min(200, math.floor((rightW - 24) / 3))  -- max 200px wide
    local CARD_H   = math.min(320, math.floor(rightH * 0.75))      -- max 320px, 75% of area height
    local CARD_GAP = 12
    local totalCardsW = #Skills * CARD_W + (#Skills-1) * CARD_GAP
    -- Centre the group horizontally in rightW, vertically in rightH
    local cardsStartX = rightX + math.floor((rightW - totalCardsW) / 2)
    local cardsStartY = bodyY  + math.floor((rightH - CARD_H) / 2)

    -- "PERKS" label above the cards
    local perksLbl = vgui.Create("DPanel", overlay)
    perksLbl:SetPos(cardsStartX, cardsStartY - 28); perksLbl:SetSize(totalCardsW, 22)
    perksLbl.Paint = function(self, w, h)
        local avail = SKILLPOINTS.GetAvailableSP(SP_LocalData)
        Txt("PERKS", "SP_Heading", 0, h/2, FA(T.Dim, 180), 0, 1)
        local badge = avail .. " point" .. (avail==1 and "" or "s") .. " available"
        Txt(badge, "SP_Sub", w, h/2, avail>0 and T.Green or FA(T.Faint,130), 2, 1)
    end

    local selectedIdx = nil
    local RebuildUpgrade  -- forward declared

    -- Upgrade button below the cards
    local UPG_W = totalCardsW
    local UPG_H = 36
    local upgY  = cardsStartY + CARD_H + 10

    local upgradeBtn = vgui.Create("DButton", overlay)
    upgradeBtn:SetPos(cardsStartX, upgY); upgradeBtn:SetSize(UPG_W, UPG_H)
    upgradeBtn:SetText(""); upgradeBtn:SetEnabled(false); upgradeBtn:SetCursor("hand")
    local uH, uL = 0, CurTime()
    upgradeBtn.Think = function()
        local dt=CurTime()-uL; uL=CurTime()
        uH=math.Approach(uH,(upgradeBtn:IsHovered() and upgradeBtn:IsEnabled()) and 1 or 0,dt*14)
    end
    upgradeBtn.Paint = function(self, w, h)
        local en = self:IsEnabled()
        local sk = selectedIdx and Skills[selectedIdx]
        local ac = (en and sk) and sk.catCol or T.Accent
        if en then
            RRct(6, 0, 0, w, h, FA(T.AccentBg, math.Round(200+55*uH)))
            if uH>0 then RRct(6,0,0,w,h,FA(Color(255,255,255),math.Round(uH*12))) end
            surface.SetDrawColor(FA(ac,math.Round(90+165*uH))); surface.DrawOutlinedRect(0,0,w,h,1)
            surface.SetDrawColor(FA(ac,math.Round(Lerp(uH,110,255)))); surface.DrawRect(0,0,3,h)
            Txt("▶  UPGRADE PERK","SP_SectLbl",w/2,h/2-6,T.Text,1,1)
            if sk then Txt(sk.name,"SP_Sub",w/2,h/2+6,FA(ac,190),1,1) end
        else
            RRct(6,0,0,w,h,FA(T.Card,120))
            surface.SetDrawColor(FA(T.Border,55)); surface.DrawOutlinedRect(0,0,w,h,1)
            Txt("SELECT A PERK TO UPGRADE","SP_SectLbl",w/2,h/2,FA(T.Faint,75),1,1)
        end
    end
    upgradeBtn.DoClick = function()
        local sk = selectedIdx and Skills[selectedIdx]; if not sk then return end
        local cur = SP_LocalData[sk.dataKey] or 0
        if SKILLPOINTS.GetAvailableSP(SP_LocalData) <= 0 then
            PushNotif("No skill points available!","",2); surface.PlaySound("buttons/button10.wav"); return
        end
        if cur >= sk.max then
            PushNotif(sk.name.." is already maxed!","",2); surface.PlaySound("buttons/button10.wav"); return
        end
        SP_LocalData[sk.dataKey] = cur + 1
        net.Start("SP_UpgradeSkill"); net.WriteString(sk.netKey); net.SendToServer()
        PushNotif(sk.name.." upgraded!",(cur+1).."/"..sk.max.." pts",1)
        surface.PlaySound("buttons/button17.wav")
        if RebuildUpgrade then RebuildUpgrade() end
    end

    -- ── Perk cards ────────────────────────────────────────────
    for i, sk in ipairs(Skills) do
        local cx = cardsStartX + (i-1) * (CARD_W + CARD_GAP)
        local card = vgui.Create("DPanel", overlay)
        card:SetPos(cx, cardsStartY); card:SetSize(CARD_W, CARD_H)
        card:SetCursor("hand")

        local hov, ht = 0, CurTime()
        card.Think = function(self)
            local dt=CurTime()-ht; ht=CurTime()
            hov=math.Approach(hov,self:IsHovered() and 1 or 0,dt*10)
        end

        card.Paint = function(self, w, h)
            local isSel = (selectedIdx == i)
            local cur   = SP_LocalData[sk.dataKey] or 0

            -- Background
            DrawBlur(self, 4, 2)
            local base = isSel and T.CardSel or T.Card
            RRct(8, 0, 0, w, h, FA(Color(
                math.Round(Lerp(hov, base.r, T.CardHov.r)),
                math.Round(Lerp(hov, base.g, T.CardHov.g)),
                math.Round(Lerp(hov, base.b, T.CardHov.b))
            ), isSel and 225 or math.Round(Lerp(hov, 195, 215))))
            if isSel then RRct(8,0,0,w,h,FA(T.Accent,12)) end

            -- Top stripe
            draw.RoundedBox(8,0,0,w,4,FA(sk.catCol,isSel and 255 or math.Round(Lerp(hov,110,210))))
            -- Left edge bar (selected)
            if isSel then draw.RoundedBox(4,0,5,3,h-10,FA(T.Accent,200)) end
            -- Border
            surface.SetDrawColor(isSel and FA(T.Accent,185) or FA(T.Border,math.Round(Lerp(hov,75,155))))
            surface.DrawOutlinedRect(0,0,w,h,1)

            local IP = 10  -- inner padding

            -- Category label
            Txt(sk.cat, "SP_PerkCat", w/2, 14, FA(sk.catCol, isSel and 220 or math.Round(Lerp(hov,140,220))), 1, 1)

            -- Icon badge (44x44)
            local ISZ = 44
            local ix  = math.floor((w-ISZ)/2)
            local iy  = 24
            RRct(8, ix, iy, ISZ, ISZ, FA(sk.iconBg, 215))
            surface.SetDrawColor(FA(sk.catCol, isSel and 190 or math.Round(Lerp(hov,60,170))))
            surface.DrawOutlinedRect(ix, iy, ISZ, ISZ, 1)
            Txt(sk.icon, "SP_CardIcon", w/2, iy+math.floor(ISZ/2), sk.catCol, 1, 1)

            -- Perk name
            local nameY = iy + ISZ + 10
            Txt(sk.name, "SP_PerkName", w/2, nameY, T.Text, 1, 1)

            -- Div 1
            local d1 = nameY + 18
            surface.SetDrawColor(FA(T.Border,110)); surface.DrawRect(IP,d1,w-IP*2,1)

            -- Desc
            Txt(sk.desc, "SP_Sub", w/2, d1+11, FA(T.Text,155), 1, 1)

            -- Div 2
            local d2 = d1 + 24
            surface.SetDrawColor(FA(T.Border,80)); surface.DrawRect(IP,d2,w-IP*2,1)

            -- Pips
            local pw = PipRowW(sk.max)
            local px = math.floor((w-pw)/2)
            local py = d2 + 12
            DrawPips(px, py, cur, sk.max, sk.catCol)
            Txt(cur.." / "..sk.max, "SP_Sub", w/2, py+14, FA(T.Dim,180), 1, 1)

            -- Div 3
            local d3 = py + 28
            surface.SetDrawColor(FA(T.Border,80)); surface.DrawRect(IP,d3,w-IP*2,1)

            -- Bonus value
            local cfg = SKILLPOINTS.Config.Skills[sk.netKey]
            if cfg then
                local bv  = cur * cfg.bonus_value
                local bs  = sk.netKey=="xp_gain" and ("+"..bv.."%") or sk.netKey=="health" and ("+"..bv.." HP") or ("+"..bv.." SPD")
                Txt(bs, "SP_Stat", w/2, d3+11, cur>0 and sk.catCol or FA(T.Faint,110), 1, 1)
            end

            -- Status badge
            local by2 = d3 + 26
            if cur >= sk.max then
                local bw=48; RRct(4,math.floor((w-bw)/2),by2,bw,16,FA(T.Gold,28))
                surface.SetDrawColor(FA(T.Gold,130)); surface.DrawOutlinedRect(math.floor((w-bw)/2),by2,bw,16,1)
                Txt("MAXED","SP_Sub",w/2,by2+8,T.Gold,1,1)
            elseif isSel then
                local bw=60; RRct(4,math.floor((w-bw)/2),by2,bw,16,FA(T.Accent,20))
                surface.SetDrawColor(FA(T.Accent,130)); surface.DrawOutlinedRect(math.floor((w-bw)/2),by2,bw,16,1)
                Txt("SELECTED","SP_Sub",w/2,by2+8,T.Accent,1,1)
            elseif cur > 0 then
                Txt("INVESTED","SP_Sub",w/2,by2+8,FA(sk.catCol,140),1,1)
            else
                Txt("CLICK TO SELECT","SP_Sub",w/2,by2+8,FA(T.Faint,80),1,1)
            end
        end

        card.OnMousePressed = function(self, btn)
            if btn ~= MOUSE_LEFT then return end
            selectedIdx = (selectedIdx == i) and nil or i
            if RebuildUpgrade then RebuildUpgrade() end
            surface.PlaySound("buttons/button3.wav")
        end
    end

    -- ── RebuildUpgrade ────────────────────────────────────────
    RebuildUpgrade = function()
        if not IsValid(upgradeBtn) then return end
        local hasSel = selectedIdx ~= nil and Skills[selectedIdx] ~= nil
        if hasSel then
            local sk  = Skills[selectedIdx]
            local cur = SP_LocalData[sk.dataKey] or 0
            upgradeBtn:SetEnabled(SKILLPOINTS.GetAvailableSP(SP_LocalData) > 0 and cur < sk.max)
        else
            upgradeBtn:SetEnabled(false)
        end
    end

    SP_Frame._rebuild = RebuildUpgrade
    RebuildUpgrade()
    surface.PlaySound("buttons/button9.wav")
end

-- ── F3 / ESC toggle ───────────────────────────────────────────
local _f3Was = false
hook.Add("Think", "SP_F3Toggle", function()
    local down = input.IsKeyDown(KEY_F3)
    if down and not _f3Was then
        if IsValid(SP_Frame) then CloseMenu() else SP_OpenMenu() end
    end
    _f3Was = down
    if input.WasKeyPressed(KEY_ESCAPE) and IsValid(SP_Frame) then CloseMenu() end
end)