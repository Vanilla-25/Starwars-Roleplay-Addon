-- ============================================================
-- SKILL POINTS SYSTEM - addon/autorun loader
-- ============================================================
-- Place this addon in: garrysmod/addons/skillpoints/
-- Structure:
--   addons/skillpoints/
--     lua/
--       autorun/
--         skillpoints_init.lua    <-- this file
--       skillpoints/
--         shared/sh_skillpoints.lua
--         server/sv_skillpoints.lua
--         client/cl_skillpoints.lua

AddCSLuaFile("skillpoints/shared/sh_skillpoints.lua")
AddCSLuaFile("skillpoints/client/cl_skillpoints.lua")

include("skillpoints/shared/sh_skillpoints.lua")

if SERVER then
    include("skillpoints/server/sv_skillpoints.lua")
end

if CLIENT then
    include("skillpoints/client/cl_skillpoints.lua")
end
