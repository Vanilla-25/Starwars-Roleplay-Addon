-- ============================================================
--  sh_config.lua  –  Configuration
-- ============================================================

DEFIB = DEFIB or { CONFIG = {} }

local C = DEFIB.CONFIG

C.respawnTimer     = 60     -- Seconds before a downed player can respawn on their own
C.forceRespawn     = false  -- Auto-respawn when the timer expires
C.reviveHealth     = 50     -- HP given on revive
C.reviveRange      = 100    -- Units from ragdoll to be able to revive
C.chargeTime       = 0.6    -- Seconds to hold right-click to charge
C.rechargeCooldown = 5     -- Seconds after a revive before you can charge again
C.maxUses          = 0      -- Uses before the defib breaks (0 = unlimited)

C.jobBlacklist = {
    -- ["Zombie"] = true,
}