-- ============================================================
--  sv_main.lua  –  Server Logic
-- ============================================================

util.AddNetworkString( "DEFIB_ShowHint" )
util.AddNetworkString( "DEFIB_RagdollSpawned" )
util.AddNetworkString( "DEFIB_RagdollRemoved" )

-- ============================================================
--  Utility: send a notification to a player
--  Sends msg, sub, and type over the net.
--  Client receives it and routes through F2Notify.Push.
--  Types: 0=INFO  1=SUCCESS  2=WARN  3=ERROR  4=SYSTEM
-- ============================================================
local function SendHint( ply, msg, sub, ntype )
    net.Start( "DEFIB_ShowHint" )
        net.WriteString( msg   or "" )
        net.WriteString( sub   or "" )
        net.WriteUInt(   ntype or 0, 4 )
    net.Send( ply )
end

DEFIB = DEFIB or {}
DEFIB.SendHint = SendHint

-- ============================================================
--  On death: snapshot loadout, make ragdoll, enter spectate
-- ============================================================
hook.Add( "DoPlayerDeath", "DEFIB_OnDeath", function( ply )
    if DEFIB.CONFIG.jobBlacklist[ team.GetName( ply:Team() ) ] then return end

    -- Snapshot weapons
    ply.DEFIB_weapons = {}
    for _, wep in ipairs( ply:GetWeapons() ) do
        local entry = { class = wep:GetClass(), ammo1 = 0, ammo2 = 0 }
        local t1 = wep:GetPrimaryAmmoType()
        local t2 = wep:GetSecondaryAmmoType()
        if t1 > 0 then entry.ammo1 = ply:GetAmmoCount( t1 ) end
        if t2 > 0 then entry.ammo2 = ply:GetAmmoCount( t2 ) end
        table.insert( ply.DEFIB_weapons, entry )
    end
    ply.DEFIB_activeWep = IsValid( ply:GetActiveWeapon() ) and ply:GetActiveWeapon():GetClass() or nil
    ply.DEFIB_deathTime = CurTime()

    -- Create ragdoll
    local rag = ents.Create( "prop_ragdoll" )
    rag:SetPos( ply:GetPos() )
    rag:SetAngles( ply:GetAngles() )
    rag:SetModel( ply:GetModel() )
    rag:SetColor( ply:GetColor() )
    rag:SetSkin( ply:GetSkin() )
    rag:SetOwner( ply )
    rag.DEFIB_owner = ply
    rag:Spawn()
    rag:Activate()
    rag:SetCollisionGroup( COLLISION_GROUP_DEBRIS_TRIGGER )

    ply.DEFIB_ragdoll = rag

    -- Delay one tick so the ragdoll entity is fully networked to all clients
    -- before we send the message. If we send it immediately, clients receive
    -- the net message before the entity exists on their end and ReadEntity()
    -- returns NULL, so the outline never registers.
    local ragRef = rag
    local plyRef = ply
    timer.Simple( 0.1, function()
        if not IsValid( ragRef ) or not IsValid( plyRef ) then return end
        net.Start( "DEFIB_RagdollSpawned" )
            net.WriteEntity( ragRef )
            net.WriteEntity( plyRef )
        net.Broadcast()
    end )

    ply:Spectate( OBS_MODE_CHASE )
    ply:SpectateEntity( rag )
end )

-- ============================================================
--  Block GMod's own ragdoll from spawning
-- ============================================================
hook.Add( "PlayerDeath", "DEFIB_KillNativeRagdollImmediate", function( ply )
    if DEFIB.CONFIG.jobBlacklist[ team.GetName( ply:Team() ) ] then return end
    timer.Simple( 0, function()
        if not IsValid( ply ) then return end
        local r = ply:GetRagdollEntity()
        if IsValid( r ) then r:Remove() end
    end )
end )

hook.Add( "PlayerPostThink", "DEFIB_KillNativeRagdollSafetyNet", function( ply )
    if ply:Alive() then return end
    local r = ply:GetRagdollEntity()
    if IsValid( r ) then r:Remove() end
end )

-- ============================================================
--  Block auto-respawn while timer is running
-- ============================================================
hook.Add( "PlayerDeathThink", "DEFIB_BlockRespawn", function( ply )
    if DEFIB.CONFIG.jobBlacklist[ team.GetName( ply:Team() ) ] then return end
    if not ply.DEFIB_deathTime then return end

    local elapsed = CurTime() - ply.DEFIB_deathTime
    if elapsed < DEFIB.CONFIG.respawnTimer then
        return false
    elseif DEFIB.CONFIG.forceRespawn then
        ply:Spawn()
    end
end )

-- ============================================================
--  Cleanup ragdoll on spawn or disconnect
-- ============================================================
local function CleanupRagdoll( ply )
    if IsValid( ply.DEFIB_ragdoll ) then
        -- Tell clients to remove this ragdoll from their outline list
        net.Start( "DEFIB_RagdollRemoved" )
            net.WriteEntity( ply.DEFIB_ragdoll )
        net.Broadcast()
        ply.DEFIB_ragdoll:Remove()
    end
    ply.DEFIB_ragdoll   = nil
    ply.DEFIB_deathTime = nil
end

hook.Add( "PlayerSpawn",        "DEFIB_CleanupOnSpawn",      CleanupRagdoll )
hook.Add( "PlayerDisconnected", "DEFIB_CleanupOnDisconnect", CleanupRagdoll )

-- ============================================================
--  Revive: restore loadout, spawn, fix collision
-- ============================================================
local pendingCollision = {}

local function RestoreCollision()
    for i = #pendingCollision, 1, -1 do
        local ply = pendingCollision[i]
        if not IsValid( ply ) then
            table.remove( pendingCollision, i )
            continue
        end

        local phys    = ply:GetPhysicsObject()
        local blocked = ( IsValid( phys ) and phys:IsPenetrating() )

        if not blocked then
            for _, other in ipairs( player.GetAll() ) do
                if other ~= ply and ply:GetPos():DistToSqr( other:GetPos() ) < 70 * 70 then
                    blocked = true
                    break
                end
            end
        end

        if not blocked then
            ply:SetCollisionGroup( COLLISION_GROUP_PLAYER )
            table.remove( pendingCollision, i )
        end
    end
end

local lastCollCheck = 0
hook.Add( "Think", "DEFIB_CollisionRestore", function()
    if CurTime() < lastCollCheck then return end
    lastCollCheck = CurTime() + 0.5
    RestoreCollision()
end )

function DEFIB.Revive( ply, spawnPos, spawnAng, hp )
    if not IsValid( ply ) then return end

    if ply.DEFIB_weapons then
        for _, entry in ipairs( ply.DEFIB_weapons ) do
            local wep = ply:Give( entry.class )
            if IsValid( wep ) then
                local t1 = wep:GetPrimaryAmmoType()
                local t2 = wep:GetSecondaryAmmoType()
                if t1 > 0 and entry.ammo1 > 0 then ply:SetAmmo( entry.ammo1, t1 ) end
                if t2 > 0 and entry.ammo2 > 0 then ply:SetAmmo( entry.ammo2, t2 ) end
            end
        end
    end

    if ply.DEFIB_activeWep then
        ply:SelectWeapon( ply.DEFIB_activeWep )
    end

    ply:Spawn()
    ply:SetPos( spawnPos )
    if spawnAng then ply:SetAngles( spawnAng ) end
    ply:SetHealth( math.Clamp( hp or DEFIB.CONFIG.reviveHealth, 1, ply:GetMaxHealth() ) )

    ply:SetCollisionGroup( COLLISION_GROUP_PASSABLE_DOOR )
    table.insert( pendingCollision, ply )
end