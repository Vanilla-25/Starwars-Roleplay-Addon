-- ============================================================
--  cl_main.lua  –  Client: Hints + ESP + Ragdoll nameplates
-- ============================================================

-- ============================================================
--  Fonts  (lazy so ScrH() is valid at creation time)
-- ============================================================
local fontsReady = false
local lastScrH   = 0

local function CreateFonts()
    local h = ScrH()
    surface.CreateFont( "DEFIB_Hint",      { font="Roboto", size=math.Round(h*0.022), weight=600, antialias=true } )
    surface.CreateFont( "DEFIB_HintSub",   { font="Roboto", size=math.Round(h*0.016), weight=400, antialias=true } )
    surface.CreateFont( "DEFIB_Nameplate", { font="Roboto", size=math.Round(h*0.018), weight=700, antialias=true } )
    fontsReady = true
    lastScrH   = h
end

hook.Add( "OnScreenSizeChanged", "DEFIB_RecreateFonts", function() CreateFonts() end )

-- ============================================================
--  Ragdoll tracking
-- ============================================================
local defibRagdolls = {}   -- [ent] = ownerEnt

net.Receive( "DEFIB_RagdollSpawned", function()
    local rag   = net.ReadEntity()
    local owner = net.ReadEntity()
    if IsValid( rag ) then
        defibRagdolls[ rag ] = owner
        return
    end
    timer.Create( "DEFIB_WaitForRagdoll_" .. tostring(rag), 0.1, 20, function()
        if IsValid( rag ) then
            defibRagdolls[ rag ] = owner
            timer.Remove( "DEFIB_WaitForRagdoll_" .. tostring(rag) )
        end
    end )
end )

net.Receive( "DEFIB_RagdollRemoved", function()
    defibRagdolls[ net.ReadEntity() ] = nil
end )

hook.Add( "EntityRemoved", "DEFIB_RagdollCleanup", function(ent)
    defibRagdolls[ ent ] = nil
end )

-- ============================================================
--  ESP outline  (PreDrawHalos)
-- ============================================================
local OUTLINE_W   = 4
local COL_FAR     = Color( 220, 50,  50,  255 )
local COL_NEAR    = Color( 60,  230, 100, 255 )

hook.Add( "PreDrawHalos", "DEFIB_RagdollOutline", function()
    local lp = LocalPlayer()
    if not IsValid( lp ) then return end
    local wep = lp:GetActiveWeapon()
    if not IsValid( wep ) or wep:GetClass() ~= "weapon_defibrillator" then return end

    local range = ( DEFIB and DEFIB.CONFIG and DEFIB.CONFIG.reviveRange ) or 100

    for rag in pairs( defibRagdolls ) do
        if not IsValid( rag ) then defibRagdolls[rag] = nil continue end
        local near = rag:GetPos():Distance( lp:GetPos() ) <= range
        halo.Add( { rag }, near and COL_NEAR or COL_FAR, OUTLINE_W, OUTLINE_W, 1, false, true )
    end
end )

-- ============================================================
--  World-space nameplates above ragdolls
--  Visible through walls, fade as you get further away.
-- ============================================================
local function DrawRoundedTextBox( text, font, x, y, textCol, boxCol )
    surface.SetFont( font )
    local tw, th = surface.GetTextSize( text )
    local pad    = 6
    local bw, bh = tw + pad*2, th + pad*2
    draw.RoundedBox( 6, x - bw*0.5, y - bh*0.5, bw, bh, boxCol )
    draw.SimpleText( text, font, x, y, textCol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
end

hook.Add( "DrawTranslucentRenderables", "DEFIB_RagdollNameplates", function( depth, sky )
    if sky then return end
    local lp = LocalPlayer()
    if not IsValid( lp ) then return end

    local wep = lp:GetActiveWeapon()
    if not IsValid( wep ) or wep:GetClass() ~= "weapon_defibrillator" then return end

    local range      = ( DEFIB and DEFIB.CONFIG and DEFIB.CONFIG.reviveRange ) or 100
    local fadeStart  = range * 4
    local fadeEnd    = range * 0.8

    if not fontsReady then return end

    for rag, owner in pairs( defibRagdolls ) do
        if not IsValid( rag ) then defibRagdolls[rag] = nil continue end

        local dist  = rag:GetPos():Distance( lp:GetPos() )
        local alpha = math.Clamp( 255 * ( 1 - ( dist - fadeEnd ) / ( fadeStart - fadeEnd ) ), 0, 255 )
        if alpha <= 0 then continue end

        local inRange = dist <= range
        local pos     = rag:GetPos() + Vector(0,0,72)
        local screen  = pos:ToScreen()
        if not screen.visible then continue end

        local name    = IsValid( owner ) and owner:Name() or "Unknown"
        local label   = inRange and ( "↑ REVIVE " .. name ) or name

        local boxCol  = inRange
            and Color( 30, 180, 70,  math.Round(alpha*0.85) )
            or  Color( 180, 20, 20,  math.Round(alpha*0.85) )
        local txtCol  = Color( 255, 255, 255, alpha )

        DrawRoundedTextBox( label, "DEFIB_Nameplate", screen.x, screen.y, txtCol, boxCol )
    end
end )

-- ============================================================
--  Notifications
--  Receives msg + sub + type from server and routes through
--  F2Notify.Push exactly like the F2 slots client does.
--  Falls back to a simple built-in toast if F2Notify isn't loaded.
-- ============================================================

-- Fallback toast queue (only used when F2Notify is absent)
local hints     = {}
local HINT_LIFE = 5

net.Receive( "DEFIB_ShowHint", function()
    local msg   = net.ReadString()
    local sub   = net.ReadString()
    local ntype = net.ReadUInt( 4 )

    -- Route through F2Notify if it's available (same as F2 slots client)
    if F2Notify then
        F2Notify.Push( msg, sub, ntype )
        return
    end

    -- Built-in fallback toast
    table.insert( hints, {
        msg    = msg,
        sub    = sub,
        ntype  = ntype,
        born   = CurTime(),
        slideX = 60,
    })
    while #hints > 6 do table.remove( hints, 1 ) end
end )

local function LerpSnap( t, a, b )
    local v = Lerp( t, a, b )
    return math.abs( v - b ) < 0.5 and b or v
end

hook.Add( "HUDPaint", "DEFIB_DrawHints", function()
    -- If F2Notify is loaded it handles drawing — clear our queue and bail
    if F2Notify then hints = {}; return end
    if #hints == 0 then return end

    if not fontsReady or ScrH() ~= lastScrH then CreateFonts() end

    local now    = CurTime()
    local sw, sh = ScrW(), ScrH()

    -- Type -> colour map matching F2Notify exactly
    local typeCol = {
        [0] = Color( 80,  160, 255 ),   -- INFO
        [1] = Color( 55,  210, 115 ),   -- SUCCESS
        [2] = Color( 220, 175, 40  ),   -- WARN
        [3] = Color( 220, 75,  75  ),   -- ERROR
        [4] = Color( 80,  160, 255 ),   -- SYSTEM
    }

    -- Expire old hints
    for i = #hints, 1, -1 do
        if now - hints[i].born > HINT_LIFE then table.remove( hints, i ) end
    end

    local baseY = sh * 0.82
    local slotH = sh * 0.045

    for i, h in ipairs( hints ) do
        local age     = now - h.born
        local fadeIn  = math.Clamp( age / 0.18, 0, 1 )
        local fadeOut = 1 - math.Clamp( ( age - ( HINT_LIFE - 0.8 ) ) / 0.8, 0, 1 )
        local alpha   = math.Round( 255 * fadeIn * fadeOut )
        if alpha <= 0 then continue end

        h.slideX = LerpSnap( FrameTime() * 12, h.slideX, 0 )

        local ac      = typeCol[ h.ntype ] or typeCol[0]
        local hasSub  = h.sub and h.sub ~= ""

        surface.SetFont( "DEFIB_Hint" )
        local tw  = surface.GetTextSize( h.msg )
        local pad = 10
        local bw  = math.max( tw + pad * 2 + 36, 220 )
        local bh  = hasSub and math.Round( sh * 0.048 ) or math.Round( sh * 0.034 )
        local x   = sw * 0.5 - bw * 0.5 + h.slideX
        local y   = baseY - ( i - 1 ) * slotH

        -- Shadow
        draw.RoundedBox( 8, x+2, y - bh*0.5+2, bw, bh, Color(0,0,0, math.Round(alpha*0.35)) )
        -- Card
        draw.RoundedBox( 8, x,   y - bh*0.5,   bw, bh, Color(15, 20, 35, math.Round(alpha*0.90)) )
        -- Left accent bar
        surface.SetDrawColor( ac.r, ac.g, ac.b, alpha )
        surface.DrawRect( x, y - bh*0.5, 3, bh )
        -- Top stripe
        surface.DrawRect( x+3, y - bh*0.5, bw-3, 2 )

        local textY = hasSub and ( y - bh*0.5 + 14 ) or y
        draw.SimpleText( h.msg, "DEFIB_Hint",
            x + 14, textY, Color(230,240,255,alpha), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER )
        if hasSub then
            draw.SimpleText( h.sub, "DEFIB_HintSub",
                x + 14, y - bh*0.5 + 32, Color(140,155,180,math.Round(alpha*0.85)), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER )
        end
    end
end )