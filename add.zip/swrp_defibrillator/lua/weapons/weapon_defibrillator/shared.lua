-- ============================================================
--  weapon_defibrillator/shared.lua
--  Charge with right-click, revive a downed player with left-click.
-- ============================================================

if SERVER then AddCSLuaFile() end

SWEP.PrintName       = "Defibrillator"
SWEP.Author          = ""
SWEP.Instructions    = "SECONDARY: Hold to charge.  PRIMARY: Revive a downed player."
SWEP.AdminSpawnable  = true
SWEP.Spawnable       = true

SWEP.ViewModel       = Model( "models/weapons/custom/v_defib.mdl" )
SWEP.WorldModel      = Model( "models/weapons/custom/w_defib.mdl" )
SWEP.UseHands        = true

if CLIENT then
    SWEP.Category      = "Medical"
    SWEP.Slot          = 4
    SWEP.SlotPos       = 2
    SWEP.ViewModelFOV  = 69
    SWEP.DrawCrosshair = true
    SWEP.DrawAmmo      = false
end

SWEP.Primary.Ammo          = "None"
SWEP.Primary.ClipSize      = -1
SWEP.Primary.DefaultClip   = -1
SWEP.Primary.Delay         = 1
SWEP.Primary.Automatic     = false
SWEP.Secondary.Ammo        = "None"
SWEP.Secondary.ClipSize    = -1
SWEP.Secondary.DefaultClip = -1

-- Internal state
-- FIX #4: IsCharged is now a NetworkVar so the server and client are always
--         in sync.  The old plain field was never replicated.
SWEP.Charging       = false
SWEP.ChargeStart    = 0
SWEP.IsReviving     = false
SWEP.ReviveStart    = 0
SWEP.ReviveTarget   = nil
SWEP.NextChargeTime = 0

-- ============================================================
--  Shorthand: pull a value from DEFIB.CONFIG with a fallback
-- ============================================================
local function cfg( key, default )
    return ( DEFIB and DEFIB.CONFIG and DEFIB.CONFIG[key] ) or default
end

-- ============================================================
--  NETWORKVARS
-- ============================================================
function SWEP:SetupDataTables()
    -- IsCharged replicated so server can authoritatively validate before reviving
    self:NetworkVar( "Bool",    0, "IsCharged" )
    -- UseCount replicated so the client HUD always shows the real server value
    -- rather than a local copy that can drift or reset on weapon re-creation
    self:NetworkVar( "Int",     0, "UseCount"  )
end

-- ============================================================
--  INITIALIZE / DEPLOY / HOLSTER
-- ============================================================
function SWEP:Initialize()
    self:SetHoldType( "knife" )
end

function SWEP:Deploy()
    self.Weapon:SendWeaponAnim( ACT_VM_DEPLOY )
    return true
end

function SWEP:Holster()
    self.Charging   = false
    self.IsReviving = false
    -- IsCharged kept intentionally (NetworkVar, persists across switches)
    return true
end

-- ============================================================
--  Find a nearby player ragdoll to revive
-- ============================================================
function SWEP:FindTarget()
    local owner = self:GetOwner()
    if not IsValid( owner ) then return end

    local range = cfg( "reviveRange", 100 )

    -- Eye trace first
    local tr = owner:GetEyeTrace()
    if IsValid( tr.Entity )
    and tr.Entity:GetClass() == "prop_ragdoll"
    and tr.Entity.DEFIB_owner
    and tr.Entity:GetPos():DistToSqr( owner:GetPos() ) <= range * range then
        return tr.Entity
    end

    -- Nearby sweep fallback
    local best, bestDist = nil, range * range
    for _, ent in ipairs( ents.FindByClass( "prop_ragdoll" ) ) do
        if not ent.DEFIB_owner then continue end
        local d = ent:GetPos():DistToSqr( owner:GetPos() )
        if d < bestDist then best, bestDist = ent, d end
    end

    return best
end

-- ============================================================
--  PRIMARY – fire (needs a full charge first)
-- ============================================================
function SWEP:PrimaryAttack()
    local owner = self:GetOwner()
    if not IsValid( owner ) or self.IsReviving then return end

    if not self:GetIsCharged() then
        -- FIX #3: Sound emitted server-side only to avoid double-play.
        if SERVER then
            self:EmitSound( "defibrillator/defib_recharge.wav", 55, 60 )
        end
        return
    end

    local target = self:FindTarget()

    if not target then
        -- FIX #3: Server-side only sound + client-side only effect.
        if SERVER then
            self:EmitSound( "ncs_defib/defib_shock.wav", 75, 100 )
        end
        if CLIENT then
            local ed = EffectData()
            ed:SetOrigin( owner:EyePos() + owner:EyeAngles():Forward() * 40 )
            ed:SetScale( 2 )
            util.Effect( "ElectricSpark", ed )
        end
        self:SetIsCharged( false )
        return
    end

    self:SetIsCharged( false )
    self.IsReviving   = true
    self.ReviveStart  = CurTime()
    self.ReviveTarget = target

    owner:SetAnimation( PLAYER_ATTACK1 )
    self:SendWeaponAnim( ACT_VM_PRIMARYATTACK )

    -- FIX #3: Server-side only sound + client-side only effect.
    if SERVER then
        self:EmitSound( "ncs_defib/defib_shock.wav", 75, 100 )
    end
    if CLIENT then
        local ed = EffectData()
        ed:SetOrigin( owner:EyePos() + owner:EyeAngles():Forward() * 40 )
        ed:SetScale( 3 )
        util.Effect( "ElectricSpark", ed )
    end
end

-- ============================================================
--  SECONDARY – hold to charge
-- ============================================================
function SWEP:SecondaryAttack()
    if self:GetIsCharged() or self.IsReviving then return end
    if CurTime() < self.NextChargeTime then return end
    if not self.Charging then
        self.Charging    = true
        self.ChargeStart = CurTime()
        -- FIX #3: Server-side only sound.
        if SERVER then
            self:EmitSound( "ncs_defib/defib_recharge.wav", 60, 100 )
        end
    end
end

-- ============================================================
--  THINK
-- ============================================================
function SWEP:Think()
    local owner = self:GetOwner()
    if not IsValid( owner ) then return end

    if self.IsReviving then
        local target  = self.ReviveTarget
        local range   = cfg( "reviveRange", 100 )

        -- FIX #6: Abort threshold now matches the initial targeting range
        --         (was incorrectly range * 2, letting revives complete from
        --         twice the acquisition distance).
        if not IsValid( target )
        or target:GetPos():Distance( owner:GetPos() ) > range then
            self.IsReviving   = false
            self.ReviveTarget = nil
            return
        end

        if CurTime() - self.ReviveStart >= 0.3 then
            self.IsReviving = false
            if SERVER then self:FinishRevive( target ) end
            self.ReviveTarget = nil
        end
        return
    end

    if self.Charging and not self:GetIsCharged() then
        if not owner:KeyDown( IN_ATTACK2 ) then
            self.Charging = false
            -- FIX #3: Server-side only sound.
            if SERVER then
                self:EmitSound( "ncs_defib/defib_recharge.wav", 45, 65 )
            end
            return
        end

        if CurTime() - self.ChargeStart >= cfg( "chargeTime", 2.0 ) then
            self:SetIsCharged( true )
            self.Charging = false
            -- FIX #3: Server-side only sound.
            if SERVER then
                self:EmitSound( "defibrillator/defib_recharge.wav", 75, 100 )
            end
        end
    end
end

-- ============================================================
--  SERVER: complete the revive
-- ============================================================
if SERVER then
    function SWEP:FinishRevive( ragdoll )
        if not IsValid( ragdoll ) then return end

        local owner  = self:GetOwner()
        local target = ragdoll.DEFIB_owner
        if not IsValid( target ) then return end

        local cooldown = cfg( "rechargeCooldown", 5 )
        local maxUses  = cfg( "maxUses", 5 )

        -- Spawn position: where the medic is looking
        local eyePos = owner:EyePos()
        local eyeAng = owner:EyeAngles()
        local tr = util.TraceLine({
            start  = eyePos,
            endpos = eyePos + eyeAng:Forward() * 1000,
            filter = { owner, ragdoll },
            mask   = MASK_SOLID_BRUSHONLY,
        })

        local spawnPos = tr.HitPos + Vector( 0, 0, 10 )
        local spawnAng = Angle( 0, eyeAng.y + 180, 0 )

        -- Spark on ragdoll before removing it
        local ed = EffectData()
        ed:SetOrigin( ragdoll:GetPos() + Vector( 0, 0, 40 ) )
        ed:SetScale( 2 )
        util.Effect( "ElectricSpark", ed )

        SafeRemoveEntity( ragdoll )

        -- FIX #1: Pass reviveHealth explicitly so DEFIB.CONFIG is read here
        --         on the server (where sh_config.lua is guaranteed loaded)
        --         rather than relying on cfg() inside DEFIB.Revive at an
        --         uncertain load-order point.
        DEFIB.Revive( target, spawnPos, spawnAng, cfg( "reviveHealth", 50 ) )

        target:EmitSound( "ncs_defib/defib_shock.wav", 75, 120 )

        DEFIB.SendHint( owner,  "Player Revived",        target:Name() .. " is back on their feet.",  1 )
        DEFIB.SendHint( target, "You Were Revived",      "Revived by " .. owner:Name() .. ".",         1 )

        -- Cooldown and use tracking
        local newCount = self:GetUseCount() + 1
        self:SetUseCount( newCount )
        self.NextChargeTime = CurTime() + cooldown

        if maxUses > 0 and newCount >= maxUses then
            owner:EmitSound( "ncs_defib/defib_break.wav", 75, 100 )
            DEFIB.SendHint( owner, "Defibrillator Broken", "You have used all charges.", 3 )
            timer.Simple( 0.6, function()
                if IsValid( owner ) then owner:StripWeapon( "weapon_defibrillator" ) end
            end )
        else
            timer.Simple( cooldown, function()
                if not IsValid( self ) or not IsValid( owner ) then return end
                if owner:GetActiveWeapon() ~= self then return end
                owner:EmitSound( "ncs_defib/defib_recharge.wav", 70, 100 )
            end )
        end
    end
end

-- ============================================================
--  HUD
-- ============================================================
if CLIENT then

    -- Fonts created lazily (ScrH may be 0 at load time)
    local hudFontsReady = false
    local hudLastScrH   = 0

    local function CreateHUDFonts()
        local h = ScrH()
        surface.CreateFont( "DEFIB_HUD_Label",  { font="Roboto", size=math.Round(h*0.016), weight=500, antialias=true } )
        surface.CreateFont( "DEFIB_HUD_Status", { font="Roboto", size=math.Round(h*0.018), weight=700, antialias=true } )
        surface.CreateFont( "DEFIB_HUD_Big",    { font="Roboto", size=math.Round(h*0.022), weight=800, antialias=true } )
        hudFontsReady = true
        hudLastScrH   = h
    end

    hook.Add( "OnScreenSizeChanged", "DEFIB_RecreateHUDFonts", function() CreateHUDFonts() end )

    -- Smooth animated values that lerp toward their targets each frame
    local anim = {
        barPct    = 0,   -- charge / cooldown bar fill  0-1
        barAlpha  = 0,   -- whole panel alpha            0-1
        pulseT    = 0,   -- drives the charged glow pulse
        shakeT    = 0,   -- revive shake timer
    }

    -- Helper: lerp a value toward target this frame
    local function Ease( cur, target, speed )
        return cur + ( target - cur ) * math.Clamp( FrameTime() * speed, 0, 1 )
    end

    -- Draw one use-pip (filled or empty)
    local function DrawPip( x, y, r, filled, col )
        -- outer ring
        surface.SetDrawColor( col.r, col.g, col.b, 160 )
        surface.DrawRect( x-r, y-r, r*2, r*2 )
        if filled then
            surface.SetDrawColor( col.r, col.g, col.b, 230 )
            surface.DrawRect( x-r+2, y-r+2, r*2-4, r*2-4 )
        end
    end

    -- Draw a rounded bar with an animated shine sweep
    local function DrawBar( x, y, w, h, pct, colFill, colBg, cornerR, shinePct )
        -- background track
        draw.RoundedBox( cornerR, x, y, w, h, colBg )
        -- filled portion
        if pct > 0 then
            local fw = math.max( cornerR*2, w * pct )
            draw.RoundedBox( cornerR, x, y, fw, h, colFill )
            -- shine overlay that sweeps across
            if shinePct and shinePct > 0 and shinePct < 1 then
                local sx = x + fw * shinePct - 8
                surface.SetDrawColor( 255, 255, 255, 40 )
                surface.DrawRect( sx, y, 16, h )
            end
        end
    end

    function SWEP:DrawHUD()
        local owner = self:GetOwner()
        if not IsValid( owner ) then return end

        if not hudFontsReady or ScrH() ~= hudLastScrH then CreateHUDFonts() end

        local sw, sh      = ScrW(), ScrH()
        local now         = CurTime()
        local maxUses     = cfg( "maxUses", 2 )
        local cooldown    = cfg( "rechargeCooldown", 5 )
        local chargeTime  = cfg( "chargeTime", 2.0 )
        local usesLeft    = maxUses - self:GetUseCount()
        local isCharged   = self:GetIsCharged()
        local isReviving  = self.IsReviving
        local isCooling   = now < self.NextChargeTime
        local isCharging  = self.Charging and not isCharged

        -- ── determine bar fill target and colours ──────────────
        local barTarget, barR, barG, barB

        if isReviving then
            barTarget = 1
            barR, barG, barB = 255, 80, 80
        elseif isCooling then
            barTarget = 1 - ( self.NextChargeTime - now ) / cooldown
            barR, barG, barB = 130, 70, 220
        elseif isCharged then
            barTarget = 1
            barR, barG, barB = 255, 200, 0
        elseif isCharging then
            barTarget = math.Clamp( ( now - self.ChargeStart ) / chargeTime, 0, 1 )
            barR, barG, barB = 0, 160, 255
        else
            barTarget = 0
            barR, barG, barB = 0, 160, 255
        end

        -- ── animate values ─────────────────────────────────────
        local speed = ( math.abs( anim.barPct - barTarget ) < 0.02 ) and 14 or 8
        anim.barPct   = Ease( anim.barPct,   barTarget,   speed )
        anim.barAlpha = Ease( anim.barAlpha, 1,           10    )
        anim.pulseT   = now   -- just store time, used for math below
        anim.shakeT   = isReviving and ( anim.shakeT + FrameTime() ) or 0

        local panelAlpha = math.Round( anim.barAlpha * 220 )

        -- ── layout ─────────────────────────────────────────────
        local panelW  = math.Round( sw * 0.22 )
        local panelH  = math.Round( sh * 0.09 )
        local panelX  = math.Round( sw * 0.5 - panelW * 0.5 )
        local panelY  = math.Round( sh * 0.86 - panelH )

        -- subtle revive shake
        if isReviving then
            panelX = panelX + math.Round( math.sin( anim.shakeT * 28 ) * 2 )
        end

        local barH    = math.Round( sh * 0.012 )
        local barX    = panelX + 14
        local barW    = panelW - 28
        local barY    = panelY + panelH - barH - 12

        -- ── panel background ───────────────────────────────────
        -- Drop shadow
        draw.RoundedBox( 10, panelX+3, panelY+3, panelW, panelH, Color(0,0,0, math.Round(panelAlpha*0.35)) )
        -- Main background
        draw.RoundedBox( 10, panelX, panelY, panelW, panelH, Color(10, 14, 26, math.Round(panelAlpha*0.92)) )
        -- Top accent line  (colour matches bar)
        local pulseA = isCharged
            and math.Round( 180 + 75 * math.sin( now * 5 ) )
            or  180
        draw.RoundedBox( 6, panelX, panelY, panelW, 3, Color(barR, barG, barB, pulseA) )

        -- ── status text ────────────────────────────────────────
        local statusText, statusCol

        if isReviving then
            statusText = "REVIVING..."
            statusCol  = Color( 255, 100, 100, panelAlpha )
        elseif isCooling then
            local secs = math.ceil( self.NextChargeTime - now )
            statusText = "RECHARGING  " .. secs .. "s"
            statusCol  = Color( 160, 120, 255, panelAlpha )
        elseif isCharged then
            -- pulsing gold text when charged
            local ta = math.Round( 200 + 55 * math.sin( now * 6 ) )
            statusText = "CHARGED  —  FIRE TO REVIVE"
            statusCol  = Color( 255, 210, 50, ta )
        elseif isCharging then
            statusText = "CHARGING..."
            statusCol  = Color( 80, 200, 255, panelAlpha )
        else
            statusText = "DEFIBRILLATOR"
            statusCol  = Color( 160, 180, 210, panelAlpha )
        end

        draw.SimpleText( statusText, "DEFIB_HUD_Status",
            panelX + panelW * 0.5, panelY + 18,
            statusCol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )

        -- ── sub-label ──────────────────────────────────────────
        local subText = ""
        if not isCharged and not isReviving and not isCooling and not isCharging then
            subText = "HOLD  [RMB]  TO CHARGE"
        elseif isCharging then
            subText = "RELEASE TO CANCEL"
        end
        if subText ~= "" then
            draw.SimpleText( subText, "DEFIB_HUD_Label",
                panelX + panelW * 0.5, panelY + 34,
                Color( 100, 120, 150, panelAlpha ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
        end

        -- ── use pips ───────────────────────────────────────────
        if maxUses > 0 then
            local pipR    = 5
            local spacing = pipR * 3
            local totalW  = maxUses * spacing - ( spacing - pipR * 2 )
            local pipBaseX = panelX + panelW * 0.5 - totalW * 0.5 + pipR
            local pipY    = barY - 14

            for i = 1, maxUses do
                local filled = i <= usesLeft
                local px     = pipBaseX + ( i - 1 ) * spacing
                local col    = filled
                    and Color( 80, 210, 255, panelAlpha )
                    or  Color( 60, 65,  80,  panelAlpha )
                -- glow on last pip when 1 use left
                if filled and usesLeft == 1 then
                    local ga = math.Round( 80 + 80 * math.sin( now * 7 ) )
                    draw.RoundedBox( 4, px - pipR - 3, pipY - pipR - 3, (pipR+3)*2, (pipR+3)*2,
                        Color( 255, 60, 60, ga ) )
                end
                draw.RoundedBox( 3, px - pipR, pipY - pipR, pipR*2, pipR*2,
                    Color( col.r, col.g, col.b, filled and panelAlpha or math.Round(panelAlpha*0.4) ) )
                -- inner fill
                if filled then
                    draw.RoundedBox( 2, px - pipR + 2, pipY - pipR + 2, pipR*2-4, pipR*2-4,
                        Color( col.r, col.g, col.b, math.Round(panelAlpha*0.9) ) )
                end
            end
        end

        -- ── charge / cooldown bar ──────────────────────────────
        local shinePct = isCharging and math.Clamp( ( now - self.ChargeStart ) / chargeTime, 0, 1 ) or nil

        DrawBar(
            barX, barY, barW, barH,
            math.Clamp( anim.barPct, 0, 1 ),
            Color( barR, barG, barB, panelAlpha ),
            Color( 25, 30, 50, panelAlpha ),
            math.floor( barH * 0.5 ),
            shinePct
        )

        -- ── charged glow bloom under the bar ───────────────────
        if isCharged then
            local glow = math.Round( 30 + 25 * math.sin( now * 5 ) )
            surface.SetDrawColor( 255, 200, 0, glow )
            surface.DrawRect( barX, barY - 2, barW, barH + 4 )
        end
    end
end