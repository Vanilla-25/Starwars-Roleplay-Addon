-- ============================================================
--  defibrillator_init.lua  –  Bootstrap
-- ============================================================

DEFIB = DEFIB or { CONFIG = {} }

local dir = "defibrillator_system/"

local function Load( f )
    local side = string.lower( string.sub( f, 1, 3 ) )
    local path = dir .. f
    if side == "sv_" then
        if SERVER then include( path ) end
    elseif side == "sh_" then
        if SERVER then AddCSLuaFile( path ) end
        include( path )
    elseif side == "cl_" then
        if SERVER then AddCSLuaFile( path ) end
        if CLIENT then include( path ) end
    end
end

local files = file.Find( dir .. "*.lua", "LUA" )
for _, f in ipairs( files ) do Load( f ) end

if SERVER then
    AddCSLuaFile( "weapons/weapon_defibrillator/shared.lua" )
end

if CLIENT then
    list.Set( "Weapon", "weapon_defibrillator", {
        PrintName = "Defibrillator",
        Category  = "Medical",
        Spawnable = true,
    })
end
